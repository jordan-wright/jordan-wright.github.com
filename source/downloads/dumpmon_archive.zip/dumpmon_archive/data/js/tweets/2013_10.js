Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PD9SR6L15B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nme4NpnA",
      "display_url" : "pastebin.com\/raw.php?i=nme4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396166781078753280",
  "text" : "http:\/\/t.co\/PD9SR6L15B Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 396166781078753280,
  "created_at" : "2013-11-01 06:48:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Uhs7eQQXNm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f7NVLNXd",
      "display_url" : "pastebin.com\/raw.php?i=f7NV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396148771043549185",
  "text" : "http:\/\/t.co\/Uhs7eQQXNm Found possible Google API key(s) #infoleak",
  "id" : 396148771043549185,
  "created_at" : "2013-11-01 05:36:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/igg1xWEtCc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y2cBPHMW",
      "display_url" : "pastebin.com\/raw.php?i=y2cB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396142057166610433",
  "text" : "http:\/\/t.co\/igg1xWEtCc Hashes: 186 Keywords: -0.14 #infoleak",
  "id" : 396142057166610433,
  "created_at" : "2013-11-01 05:10:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fHXMp4dcLe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gvnwjdKd",
      "display_url" : "pastebin.com\/raw.php?i=gvnw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396120467716583424",
  "text" : "http:\/\/t.co\/fHXMp4dcLe Emails: 38 Keywords: 0.11 #infoleak",
  "id" : 396120467716583424,
  "created_at" : "2013-11-01 03:44:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xoPcuFGQd0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N6DZssjU",
      "display_url" : "pastebin.com\/raw.php?i=N6DZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396112779771256832",
  "text" : "http:\/\/t.co\/xoPcuFGQd0 Emails: 3 Keywords: 0.55 #infoleak",
  "id" : 396112779771256832,
  "created_at" : "2013-11-01 03:13:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/31x81rReFu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y8XjCuzR",
      "display_url" : "pastebin.com\/raw.php?i=y8Xj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396112635285872640",
  "text" : "http:\/\/t.co\/31x81rReFu Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 396112635285872640,
  "created_at" : "2013-11-01 03:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CyDDkxji0D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MsZwiHcR",
      "display_url" : "pastebin.com\/raw.php?i=MsZw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396094635312824320",
  "text" : "http:\/\/t.co\/CyDDkxji0D Emails: 116 Hashes: 131 E\/H: 0.89 Keywords: 0.55 #infoleak",
  "id" : 396094635312824320,
  "created_at" : "2013-11-01 02:01:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O4TZxTkYND",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KunqAG34",
      "display_url" : "pastebin.com\/raw.php?i=Kunq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396091236311777280",
  "text" : "http:\/\/t.co\/O4TZxTkYND Emails: 100 Keywords: 0.11 #infoleak",
  "id" : 396091236311777280,
  "created_at" : "2013-11-01 01:48:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aUk5sD7vEH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yqJ97FEi",
      "display_url" : "pastebin.com\/raw.php?i=yqJ9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396081953163575296",
  "text" : "http:\/\/t.co\/aUk5sD7vEH Emails: 80 Hashes: 80 E\/H: 1.0 Keywords: 0.55 #infoleak",
  "id" : 396081953163575296,
  "created_at" : "2013-11-01 01:11:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/whiyTnxSvR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ePHpP8Pu",
      "display_url" : "pastebin.com\/raw.php?i=ePHp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396080132248440832",
  "text" : "http:\/\/t.co\/whiyTnxSvR Emails: 218 Keywords: 0.33 #infoleak",
  "id" : 396080132248440832,
  "created_at" : "2013-11-01 01:03:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7eLf5F42Z7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZzCPmJww",
      "display_url" : "pastebin.com\/raw.php?i=ZzCP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396072018551922690",
  "text" : "http:\/\/t.co\/7eLf5F42Z7 Emails: 806 Keywords: 0.19 #infoleak",
  "id" : 396072018551922690,
  "created_at" : "2013-11-01 00:31:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xd2dfvXgoe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4TJTaViH",
      "display_url" : "pastebin.com\/raw.php?i=4TJT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396067953629597696",
  "text" : "http:\/\/t.co\/Xd2dfvXgoe Hashes: 68 Keywords: 0.22 #infoleak",
  "id" : 396067953629597696,
  "created_at" : "2013-11-01 00:15:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xioXGvsRRQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1EVtMHTG",
      "display_url" : "pastebin.com\/raw.php?i=1EVt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396065736088502272",
  "text" : "http:\/\/t.co\/xioXGvsRRQ Emails: 22 Hashes: 26 E\/H: 0.85 Keywords: 0.22 #infoleak",
  "id" : 396065736088502272,
  "created_at" : "2013-11-01 00:06:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xhw15URcfD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tuSgL5vv",
      "display_url" : "pastebin.com\/raw.php?i=tuSg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396047959084654592",
  "text" : "http:\/\/t.co\/xhw15URcfD Hashes: 200 Keywords: 0.16 #infoleak",
  "id" : 396047959084654592,
  "created_at" : "2013-10-31 22:56:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XDE40VmF2L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dBPHT9vC",
      "display_url" : "pastebin.com\/raw.php?i=dBPH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396046881945436160",
  "text" : "http:\/\/t.co\/XDE40VmF2L Found possible Google API key(s) #infoleak",
  "id" : 396046881945436160,
  "created_at" : "2013-10-31 22:51:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YkfEHqLUZL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=65jutSa8",
      "display_url" : "pastebin.com\/raw.php?i=65ju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396041126106263552",
  "text" : "http:\/\/t.co\/YkfEHqLUZL Emails: 129 Keywords: 0.08 #infoleak",
  "id" : 396041126106263552,
  "created_at" : "2013-10-31 22:28:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QlsaiZFAHx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MYJfFFyR",
      "display_url" : "pastebin.com\/raw.php?i=MYJf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396032385386434560",
  "text" : "http:\/\/t.co\/QlsaiZFAHx Emails: 70 Keywords: 0.22 #infoleak",
  "id" : 396032385386434560,
  "created_at" : "2013-10-31 21:54:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dZIQsHzvxX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=45byZikq",
      "display_url" : "pastebin.com\/raw.php?i=45by\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396028245734203392",
  "text" : "http:\/\/t.co\/dZIQsHzvxX Emails: 70 Keywords: 0.22 #infoleak",
  "id" : 396028245734203392,
  "created_at" : "2013-10-31 21:37:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aXdCrxvCxT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JKiHL0Xe",
      "display_url" : "pastebin.com\/raw.php?i=JKiH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396025803802034176",
  "text" : "http:\/\/t.co\/aXdCrxvCxT Emails: 156 Keywords: 0.0 #infoleak",
  "id" : 396025803802034176,
  "created_at" : "2013-10-31 21:28:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0nqoecRRMK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yHF30N9F",
      "display_url" : "pastebin.com\/raw.php?i=yHF3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396008170838974464",
  "text" : "http:\/\/t.co\/0nqoecRRMK Found possible Google API key(s) #infoleak",
  "id" : 396008170838974464,
  "created_at" : "2013-10-31 20:18:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xEAaAuClKR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HP1wYDzz",
      "display_url" : "pastebin.com\/raw.php?i=HP1w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396005718106468352",
  "text" : "http:\/\/t.co\/xEAaAuClKR Emails: 29 Keywords: 0.55 #infoleak",
  "id" : 396005718106468352,
  "created_at" : "2013-10-31 20:08:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/69od8rhJ19",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yPyUaGLn",
      "display_url" : "pastebin.com\/raw.php?i=yPyU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396005632345518080",
  "text" : "http:\/\/t.co\/69od8rhJ19 Found possible Google API key(s) #infoleak",
  "id" : 396005632345518080,
  "created_at" : "2013-10-31 20:07:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qDp1tgiNnw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SBSwGWf5",
      "display_url" : "pastebin.com\/raw.php?i=SBSw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396002752792260608",
  "text" : "http:\/\/t.co\/qDp1tgiNnw Emails: 43 Hashes: 497 E\/H: 0.09 Keywords: 0.19 #infoleak",
  "id" : 396002752792260608,
  "created_at" : "2013-10-31 19:56:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qUT8nitQJT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GbFJsWTC",
      "display_url" : "pastebin.com\/raw.php?i=GbFJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395996973179736064",
  "text" : "http:\/\/t.co\/qUT8nitQJT Found possible Google API key(s) #infoleak",
  "id" : 395996973179736064,
  "created_at" : "2013-10-31 19:33:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l6t3GSiG6A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zmiMWrj5",
      "display_url" : "pastebin.com\/raw.php?i=zmiM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395968014509555712",
  "text" : "http:\/\/t.co\/l6t3GSiG6A Emails: 135 Keywords: 0.0 #infoleak",
  "id" : 395968014509555712,
  "created_at" : "2013-10-31 17:38:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vjvWWYa9SR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y9WwdYRg",
      "display_url" : "pastebin.com\/raw.php?i=Y9Ww\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395954799255908353",
  "text" : "http:\/\/t.co\/vjvWWYa9SR Emails: 34 Keywords: 0.11 #infoleak",
  "id" : 395954799255908353,
  "created_at" : "2013-10-31 16:45:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8K4UxbXcjB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RjUapDLP",
      "display_url" : "pastebin.com\/raw.php?i=RjUa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395953008002867202",
  "text" : "http:\/\/t.co\/8K4UxbXcjB Hashes: 63 Keywords: 0.0 #infoleak",
  "id" : 395953008002867202,
  "created_at" : "2013-10-31 16:38:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H36IE0xw2B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sR5WaJ3k",
      "display_url" : "pastebin.com\/raw.php?i=sR5W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395932301193781249",
  "text" : "http:\/\/t.co\/H36IE0xw2B Hashes: 63 Keywords: 0.16 #infoleak",
  "id" : 395932301193781249,
  "created_at" : "2013-10-31 15:16:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xYb85fTUew",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EHBkBFuT",
      "display_url" : "pastebin.com\/raw.php?i=EHBk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395928690720141312",
  "text" : "http:\/\/t.co\/xYb85fTUew Emails: 228 Keywords: 0.3 #infoleak",
  "id" : 395928690720141312,
  "created_at" : "2013-10-31 15:02:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DZDySfjnHo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TAgSS21S",
      "display_url" : "pastebin.com\/raw.php?i=TAgS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395926634366124032",
  "text" : "http:\/\/t.co\/DZDySfjnHo Emails: 3710 Keywords: 0.33 #infoleak",
  "id" : 395926634366124032,
  "created_at" : "2013-10-31 14:54:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y77zdk2NFd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dzc0mNNQ",
      "display_url" : "pastebin.com\/raw.php?i=dzc0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395924918136623104",
  "text" : "http:\/\/t.co\/y77zdk2NFd Found possible Google API key(s) #infoleak",
  "id" : 395924918136623104,
  "created_at" : "2013-10-31 14:47:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K46AjJ0er0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d1Wafvab",
      "display_url" : "pastebin.com\/raw.php?i=d1Wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395912754659225600",
  "text" : "http:\/\/t.co\/K46AjJ0er0 Emails: 492 Keywords: 0.3 #infoleak",
  "id" : 395912754659225600,
  "created_at" : "2013-10-31 13:58:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c37xxNv4vH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vwPMfzVD",
      "display_url" : "pastebin.com\/raw.php?i=vwPM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395912508499697664",
  "text" : "http:\/\/t.co\/c37xxNv4vH Hashes: 114 Keywords: 0.16 #infoleak",
  "id" : 395912508499697664,
  "created_at" : "2013-10-31 13:57:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mb6rihSF8w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zv8V2DbH",
      "display_url" : "pastebin.com\/raw.php?i=Zv8V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395912077388173313",
  "text" : "http:\/\/t.co\/mb6rihSF8w Emails: 59 Keywords: 0.55 #infoleak",
  "id" : 395912077388173313,
  "created_at" : "2013-10-31 13:56:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d5ijVt6Okd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v8G1kqkp",
      "display_url" : "pastebin.com\/raw.php?i=v8G1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395911674223263745",
  "text" : "http:\/\/t.co\/d5ijVt6Okd Emails: 59 Keywords: 0.55 #infoleak",
  "id" : 395911674223263745,
  "created_at" : "2013-10-31 13:54:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yKXUwq5FM7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=irEHNgFV",
      "display_url" : "pastebin.com\/raw.php?i=irEH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395909306186338304",
  "text" : "http:\/\/t.co\/yKXUwq5FM7 Emails: 99 Keywords: -0.03 #infoleak",
  "id" : 395909306186338304,
  "created_at" : "2013-10-31 13:45:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y5ZtLU3dIG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yWJjiRCx",
      "display_url" : "pastebin.com\/raw.php?i=yWJj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395903205713793026",
  "text" : "http:\/\/t.co\/y5ZtLU3dIG Emails: 2436 Keywords: 0.11 #infoleak",
  "id" : 395903205713793026,
  "created_at" : "2013-10-31 13:20:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OQdk5T5yxg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZRw8bMXK",
      "display_url" : "pastebin.com\/raw.php?i=ZRw8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395837064005967872",
  "text" : "http:\/\/t.co\/OQdk5T5yxg Found possible Google API key(s) #infoleak",
  "id" : 395837064005967872,
  "created_at" : "2013-10-31 08:58:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QMhZU1CFFw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RSkjcjNf",
      "display_url" : "pastebin.com\/raw.php?i=RSkj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395811630828617728",
  "text" : "http:\/\/t.co\/QMhZU1CFFw Emails: 83 Hashes: 110 E\/H: 0.75 Keywords: 0.05 #infoleak",
  "id" : 395811630828617728,
  "created_at" : "2013-10-31 07:17:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8bC8DfUjUF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v153nc8H",
      "display_url" : "pastebin.com\/raw.php?i=v153\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395800762694909952",
  "text" : "http:\/\/t.co\/8bC8DfUjUF Emails: 72 Keywords: 0.0 #infoleak",
  "id" : 395800762694909952,
  "created_at" : "2013-10-31 06:33:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dsmIHGkJ1u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rY1tD8Vk",
      "display_url" : "pastebin.com\/raw.php?i=rY1t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395797603771621376",
  "text" : "http:\/\/t.co\/dsmIHGkJ1u Emails: 36 Keywords: 0.11 #infoleak",
  "id" : 395797603771621376,
  "created_at" : "2013-10-31 06:21:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hPYbqjpqvy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cjFsSK78",
      "display_url" : "pastebin.com\/raw.php?i=cjFs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395780607008972801",
  "text" : "http:\/\/t.co\/hPYbqjpqvy Emails: 1175 Keywords: 0.0 #infoleak",
  "id" : 395780607008972801,
  "created_at" : "2013-10-31 05:13:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NnaOX1nvOz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mHnRT0HG",
      "display_url" : "pastebin.com\/raw.php?i=mHnR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395760057616302080",
  "text" : "http:\/\/t.co\/NnaOX1nvOz Hashes: 256 Keywords: 0.0 #infoleak",
  "id" : 395760057616302080,
  "created_at" : "2013-10-31 03:52:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I2BHq4Dj8A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6zchZqbg",
      "display_url" : "pastebin.com\/raw.php?i=6zch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395752266734383104",
  "text" : "http:\/\/t.co\/I2BHq4Dj8A Emails: 17 Keywords: 0.55 #infoleak",
  "id" : 395752266734383104,
  "created_at" : "2013-10-31 03:21:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3rq78YfM4c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KtQ6VJm6",
      "display_url" : "pastebin.com\/raw.php?i=KtQ6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395737608895995904",
  "text" : "http:\/\/t.co\/3rq78YfM4c Found possible Google API key(s) #infoleak",
  "id" : 395737608895995904,
  "created_at" : "2013-10-31 02:22:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dzQGIxNRw7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2D9bYY0B",
      "display_url" : "pastebin.com\/raw.php?i=2D9b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395733445323681793",
  "text" : "http:\/\/t.co\/dzQGIxNRw7 Emails: 67 Keywords: 0.22 #infoleak",
  "id" : 395733445323681793,
  "created_at" : "2013-10-31 02:06:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sMp4mMoZac",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pnVgfyaX",
      "display_url" : "pastebin.com\/raw.php?i=pnVg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395721532023906304",
  "text" : "http:\/\/t.co\/sMp4mMoZac Found possible Google API key(s) #infoleak",
  "id" : 395721532023906304,
  "created_at" : "2013-10-31 01:19:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I0u0BD7alB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bsvCj5F1",
      "display_url" : "pastebin.com\/raw.php?i=bsvC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395692205551013888",
  "text" : "http:\/\/t.co\/I0u0BD7alB Found possible Google API key(s) #infoleak",
  "id" : 395692205551013888,
  "created_at" : "2013-10-30 23:22:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nRl72u1owo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p0y8Q7WK",
      "display_url" : "pastebin.com\/raw.php?i=p0y8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395687213033201664",
  "text" : "http:\/\/t.co\/nRl72u1owo Emails: 2001 Keywords: 0.22 #infoleak",
  "id" : 395687213033201664,
  "created_at" : "2013-10-30 23:02:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m3uSZgKMrv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aeuHka5R",
      "display_url" : "pastebin.com\/raw.php?i=aeuH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395686954840231937",
  "text" : "http:\/\/t.co\/m3uSZgKMrv Emails: 35 Keywords: -0.06 #infoleak",
  "id" : 395686954840231937,
  "created_at" : "2013-10-30 23:01:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JeORFnlHmz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GDkz9maM",
      "display_url" : "pastebin.com\/raw.php?i=GDkz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395683438713245696",
  "text" : "http:\/\/t.co\/JeORFnlHmz Emails: 123 Keywords: 0.33 #infoleak",
  "id" : 395683438713245696,
  "created_at" : "2013-10-30 22:47:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UJpq0FRaZw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YRACBRZE",
      "display_url" : "pastebin.com\/raw.php?i=YRAC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395673465929224192",
  "text" : "http:\/\/t.co\/UJpq0FRaZw Emails: 5253 Keywords: 0.08 #infoleak",
  "id" : 395673465929224192,
  "created_at" : "2013-10-30 22:08:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PjDVUSCYzR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=taRFuSd7",
      "display_url" : "pastebin.com\/raw.php?i=taRF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395668185069809664",
  "text" : "http:\/\/t.co\/PjDVUSCYzR Found possible Google API key(s) #infoleak",
  "id" : 395668185069809664,
  "created_at" : "2013-10-30 21:47:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TXj7JxPpVb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zgbEQGjL",
      "display_url" : "pastebin.com\/raw.php?i=zgbE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395666604366626817",
  "text" : "http:\/\/t.co\/TXj7JxPpVb Emails: 5590 Hashes: 2 E\/H: 2795.0 Keywords: 0.08 #infoleak",
  "id" : 395666604366626817,
  "created_at" : "2013-10-30 21:40:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lWfEppm2p0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZUXcq8CR",
      "display_url" : "pastebin.com\/raw.php?i=ZUXc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395658892123713536",
  "text" : "http:\/\/t.co\/lWfEppm2p0 Emails: 1994 Keywords: 0.0 #infoleak",
  "id" : 395658892123713536,
  "created_at" : "2013-10-30 21:10:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LKrm9LH1nJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zZN6st0C",
      "display_url" : "pastebin.com\/raw.php?i=zZN6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395658448865472512",
  "text" : "http:\/\/t.co\/LKrm9LH1nJ Emails: 1939 Keywords: 0.08 #infoleak",
  "id" : 395658448865472512,
  "created_at" : "2013-10-30 21:08:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6H6HESZuUr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gtvwC1uY",
      "display_url" : "pastebin.com\/raw.php?i=gtvw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395638532657516545",
  "text" : "http:\/\/t.co\/6H6HESZuUr Found possible Google API key(s) #infoleak",
  "id" : 395638532657516545,
  "created_at" : "2013-10-30 19:49:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6nHs8PAYQR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ue4Y7Eq8",
      "display_url" : "pastebin.com\/raw.php?i=ue4Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395630058276007937",
  "text" : "http:\/\/t.co\/6nHs8PAYQR Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 395630058276007937,
  "created_at" : "2013-10-30 19:15:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7EmbkYwE23",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J1QdAfgZ",
      "display_url" : "pastebin.com\/raw.php?i=J1Qd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395626725079384064",
  "text" : "http:\/\/t.co\/7EmbkYwE23 Emails: 21 Keywords: 0.11 #infoleak",
  "id" : 395626725079384064,
  "created_at" : "2013-10-30 19:02:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6PvTwT4v7B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WPFFbvW8",
      "display_url" : "pastebin.com\/raw.php?i=WPFF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395612420082638848",
  "text" : "http:\/\/t.co\/6PvTwT4v7B Emails: 22 Keywords: 0.19 #infoleak",
  "id" : 395612420082638848,
  "created_at" : "2013-10-30 18:05:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gfwnPsq3Rx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WQSWDWXR",
      "display_url" : "pastebin.com\/raw.php?i=WQSW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395586178520338432",
  "text" : "http:\/\/t.co\/gfwnPsq3Rx Hashes: 31 Keywords: 0.33 #infoleak",
  "id" : 395586178520338432,
  "created_at" : "2013-10-30 16:21:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2cvRthOO24",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dxGgBhYB",
      "display_url" : "pastebin.com\/raw.php?i=dxGg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395584956539228160",
  "text" : "http:\/\/t.co\/2cvRthOO24 Hashes: 1823 Keywords: 0.11 #infoleak",
  "id" : 395584956539228160,
  "created_at" : "2013-10-30 16:16:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SDdXG5fh0J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9NcQ64Au",
      "display_url" : "pastebin.com\/raw.php?i=9NcQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395579329540677632",
  "text" : "http:\/\/t.co\/SDdXG5fh0J Keywords: 0.55 #infoleak",
  "id" : 395579329540677632,
  "created_at" : "2013-10-30 15:53:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jfT2Qy0QhV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LWDR3zC8",
      "display_url" : "pastebin.com\/raw.php?i=LWDR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395579153329569792",
  "text" : "http:\/\/t.co\/jfT2Qy0QhV Hashes: 4718 Keywords: 0.11 #infoleak",
  "id" : 395579153329569792,
  "created_at" : "2013-10-30 15:53:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YlSQ9nGJxd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EWeCugCh",
      "display_url" : "pastebin.com\/raw.php?i=EWeC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395578311230775296",
  "text" : "http:\/\/t.co\/YlSQ9nGJxd Emails: 101 Keywords: 0.0 #infoleak",
  "id" : 395578311230775296,
  "created_at" : "2013-10-30 15:49:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IctYMQPgAV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CSQfiymh",
      "display_url" : "pastebin.com\/raw.php?i=CSQf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395574262783680513",
  "text" : "http:\/\/t.co\/IctYMQPgAV Found possible Google API key(s) #infoleak",
  "id" : 395574262783680513,
  "created_at" : "2013-10-30 15:33:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dqEUU6HdMD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HmHSTdXR",
      "display_url" : "pastebin.com\/raw.php?i=HmHS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395573914388029440",
  "text" : "http:\/\/t.co\/dqEUU6HdMD Found possible Google API key(s) #infoleak",
  "id" : 395573914388029440,
  "created_at" : "2013-10-30 15:32:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SAA5QJPqEb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v0FjSkWR",
      "display_url" : "pastebin.com\/raw.php?i=v0Fj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395567755442671616",
  "text" : "http:\/\/t.co\/SAA5QJPqEb Found possible Google API key(s) #infoleak",
  "id" : 395567755442671616,
  "created_at" : "2013-10-30 15:07:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5nXZYNTb13",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UpiF6YK9",
      "display_url" : "pastebin.com\/raw.php?i=UpiF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395567660458446849",
  "text" : "http:\/\/t.co\/5nXZYNTb13 Emails: 3093 Keywords: 0.3 #infoleak",
  "id" : 395567660458446849,
  "created_at" : "2013-10-30 15:07:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zkpoFopqaf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hhjeE6pr",
      "display_url" : "pastebin.com\/raw.php?i=hhje\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395566467661307905",
  "text" : "http:\/\/t.co\/zkpoFopqaf Emails: 1085 Hashes: 1792 E\/H: 0.61 Keywords: 0.44 #infoleak",
  "id" : 395566467661307905,
  "created_at" : "2013-10-30 15:02:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zyribqkDr8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tH7DiEAw",
      "display_url" : "pastebin.com\/raw.php?i=tH7D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395564133334016000",
  "text" : "http:\/\/t.co\/zyribqkDr8 Emails: 434 Keywords: 0.0 #infoleak",
  "id" : 395564133334016000,
  "created_at" : "2013-10-30 14:53:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wa23MUfNf9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P5hg9wQd",
      "display_url" : "pastebin.com\/raw.php?i=P5hg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395543994861490176",
  "text" : "http:\/\/t.co\/Wa23MUfNf9 Emails: 110 Keywords: 0.0 #infoleak",
  "id" : 395543994861490176,
  "created_at" : "2013-10-30 13:33:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SoAnVMsSPm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QGwi8xTt",
      "display_url" : "pastebin.com\/raw.php?i=QGwi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395534243293433856",
  "text" : "http:\/\/t.co\/SoAnVMsSPm Found possible Google API key(s) #infoleak",
  "id" : 395534243293433856,
  "created_at" : "2013-10-30 12:54:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/veiEbxhcUE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t934ZXMw",
      "display_url" : "pastebin.com\/raw.php?i=t934\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395532732622577664",
  "text" : "http:\/\/t.co\/veiEbxhcUE Found possible Google API key(s) #infoleak",
  "id" : 395532732622577664,
  "created_at" : "2013-10-30 12:48:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yLkiC2n1Y1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fn6nnmM8",
      "display_url" : "pastebin.com\/raw.php?i=Fn6n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395524935856058370",
  "text" : "http:\/\/t.co\/yLkiC2n1Y1 Emails: 27 Hashes: 75 E\/H: 0.36 Keywords: 0.0 #infoleak",
  "id" : 395524935856058370,
  "created_at" : "2013-10-30 12:17:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hq5ldel6gj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r9Gjmiay",
      "display_url" : "pastebin.com\/raw.php?i=r9Gj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395524215115235329",
  "text" : "http:\/\/t.co\/hq5ldel6gj Found possible Google API key(s) #infoleak",
  "id" : 395524215115235329,
  "created_at" : "2013-10-30 12:14:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RooYrSvWcA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k5BRSPji",
      "display_url" : "pastebin.com\/raw.php?i=k5BR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395500457226801153",
  "text" : "http:\/\/t.co\/RooYrSvWcA Found possible Google API key(s) #infoleak",
  "id" : 395500457226801153,
  "created_at" : "2013-10-30 10:40:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZGz516Rjip",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fstheg8y",
      "display_url" : "pastebin.com\/raw.php?i=fsth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395497118120415232",
  "text" : "http:\/\/t.co\/ZGz516Rjip Found possible Google API key(s) #infoleak",
  "id" : 395497118120415232,
  "created_at" : "2013-10-30 10:27:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dwZMjL8Ppg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Kt4eEFGr",
      "display_url" : "pastebin.com\/raw.php?i=Kt4e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395487345606000640",
  "text" : "http:\/\/t.co\/dwZMjL8Ppg Hashes: 1722 Keywords: -0.31 #infoleak",
  "id" : 395487345606000640,
  "created_at" : "2013-10-30 09:48:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AdAeiHiwol",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qYrRmRXM",
      "display_url" : "pastebin.com\/raw.php?i=qYrR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395480520433225728",
  "text" : "http:\/\/t.co\/AdAeiHiwol Hashes: 179 Keywords: 0.05 #infoleak",
  "id" : 395480520433225728,
  "created_at" : "2013-10-30 09:21:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EvwiijP8CU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xULGzeXU",
      "display_url" : "pastebin.com\/raw.php?i=xULG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395435084225847296",
  "text" : "http:\/\/t.co\/EvwiijP8CU Emails: 48 Keywords: -0.03 #infoleak",
  "id" : 395435084225847296,
  "created_at" : "2013-10-30 06:20:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UnJb915sB3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FNcR4NmP",
      "display_url" : "pastebin.com\/raw.php?i=FNcR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395400506970894336",
  "text" : "http:\/\/t.co\/UnJb915sB3 Emails: 7658 Hashes: 5911 E\/H: 1.3 Keywords: 0.44 #infoleak",
  "id" : 395400506970894336,
  "created_at" : "2013-10-30 04:03:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/62MUTwdRUw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XGz5L9sL",
      "display_url" : "pastebin.com\/raw.php?i=XGz5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395398393960206336",
  "text" : "http:\/\/t.co\/62MUTwdRUw Hashes: 32 Keywords: 0.22 #infoleak",
  "id" : 395398393960206336,
  "created_at" : "2013-10-30 03:54:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dujHh2CcZI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9dXLRxiN",
      "display_url" : "pastebin.com\/raw.php?i=9dXL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395398096646971392",
  "text" : "http:\/\/t.co\/dujHh2CcZI Emails: 7617 Hashes: 5875 E\/H: 1.3 Keywords: 0.44 #infoleak",
  "id" : 395398096646971392,
  "created_at" : "2013-10-30 03:53:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DoR8xVn03W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J0Z48RKM",
      "display_url" : "pastebin.com\/raw.php?i=J0Z4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395382481534197760",
  "text" : "http:\/\/t.co\/DoR8xVn03W Hashes: 48 Keywords: 0.11 #infoleak",
  "id" : 395382481534197760,
  "created_at" : "2013-10-30 02:51:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hPgk9RcfIJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ks5WUNkp",
      "display_url" : "pastebin.com\/raw.php?i=ks5W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395357738781270017",
  "text" : "http:\/\/t.co\/hPgk9RcfIJ Emails: 1170 Keywords: 0.08 #infoleak",
  "id" : 395357738781270017,
  "created_at" : "2013-10-30 01:13:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TiaqALnzph",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gX1aJjhS",
      "display_url" : "pastebin.com\/raw.php?i=gX1a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395320328127148032",
  "text" : "http:\/\/t.co\/TiaqALnzph Emails: 40 Keywords: -0.03 #infoleak",
  "id" : 395320328127148032,
  "created_at" : "2013-10-29 22:44:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lS01HpOjin",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LJB7V9yw",
      "display_url" : "pastebin.com\/raw.php?i=LJB7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395320062384431104",
  "text" : "http:\/\/t.co\/lS01HpOjin Emails: 4 Hashes: 38 E\/H: 0.11 Keywords: 0.11 #infoleak",
  "id" : 395320062384431104,
  "created_at" : "2013-10-29 22:43:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5a01fseCSI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6WD5g6RQ",
      "display_url" : "pastebin.com\/raw.php?i=6WD5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395314017402892288",
  "text" : "http:\/\/t.co\/5a01fseCSI Emails: 611 Keywords: 0.44 #infoleak",
  "id" : 395314017402892288,
  "created_at" : "2013-10-29 22:19:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ir5j0wYb1I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TgvwmUmx",
      "display_url" : "pastebin.com\/raw.php?i=Tgvw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395310577439891456",
  "text" : "http:\/\/t.co\/ir5j0wYb1I Emails: 62 Keywords: 0.0 #infoleak",
  "id" : 395310577439891456,
  "created_at" : "2013-10-29 22:06:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QzwKa7uofx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t0Gtz6U3",
      "display_url" : "pastebin.com\/raw.php?i=t0Gt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395307810562404353",
  "text" : "http:\/\/t.co\/QzwKa7uofx Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 395307810562404353,
  "created_at" : "2013-10-29 21:55:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ptr0zhJeB8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f9RUPG43",
      "display_url" : "pastebin.com\/raw.php?i=f9RU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395307342238978048",
  "text" : "http:\/\/t.co\/Ptr0zhJeB8 Emails: 331 Hashes: 338 E\/H: 0.98 Keywords: 0.11 #infoleak",
  "id" : 395307342238978048,
  "created_at" : "2013-10-29 21:53:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FjNoFFt7R4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7CcGtFmP",
      "display_url" : "pastebin.com\/raw.php?i=7CcG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395297072523378688",
  "text" : "http:\/\/t.co\/FjNoFFt7R4 Emails: 377 Keywords: 0.11 #infoleak",
  "id" : 395297072523378688,
  "created_at" : "2013-10-29 21:12:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ejUjUvU3V4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bY31F2ZS",
      "display_url" : "pastebin.com\/raw.php?i=bY31\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395267998400786433",
  "text" : "http:\/\/t.co\/ejUjUvU3V4 Hashes: 32 Keywords: -0.14 #infoleak",
  "id" : 395267998400786433,
  "created_at" : "2013-10-29 19:16:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AX9HwJQF6T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gb8EVeTP",
      "display_url" : "pastebin.com\/raw.php?i=Gb8E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395265337718874112",
  "text" : "http:\/\/t.co\/AX9HwJQF6T Hashes: 51 Keywords: 0.22 #infoleak",
  "id" : 395265337718874112,
  "created_at" : "2013-10-29 19:06:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aDgb1vcMJY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jEjgWVrA",
      "display_url" : "pastebin.com\/raw.php?i=jEjg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395248419653951488",
  "text" : "http:\/\/t.co\/aDgb1vcMJY Emails: 35 Keywords: -0.14 #infoleak",
  "id" : 395248419653951488,
  "created_at" : "2013-10-29 17:59:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vR2Plm1HRm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XSdb71Re",
      "display_url" : "pastebin.com\/raw.php?i=XSdb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395245953474510848",
  "text" : "http:\/\/t.co\/vR2Plm1HRm Emails: 123 Keywords: 0.33 #infoleak",
  "id" : 395245953474510848,
  "created_at" : "2013-10-29 17:49:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BkS09s3DOe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u4FepmgU",
      "display_url" : "pastebin.com\/raw.php?i=u4Fe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395244188582678528",
  "text" : "http:\/\/t.co\/BkS09s3DOe Emails: 57 Keywords: 0.22 #infoleak",
  "id" : 395244188582678528,
  "created_at" : "2013-10-29 17:42:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/07KWNeMDXd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gxMeLNYJ",
      "display_url" : "pastebin.com\/raw.php?i=gxMe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395241391216803840",
  "text" : "http:\/\/t.co\/07KWNeMDXd Hashes: 534 Keywords: 0.11 #infoleak",
  "id" : 395241391216803840,
  "created_at" : "2013-10-29 17:31:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8emRzRVlMW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aLxCKkxx",
      "display_url" : "pastebin.com\/raw.php?i=aLxC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395240974323965953",
  "text" : "http:\/\/t.co\/8emRzRVlMW Hashes: 648 Keywords: -0.03 #infoleak",
  "id" : 395240974323965953,
  "created_at" : "2013-10-29 17:29:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fZEfaEvrAg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iL1aNVdQ",
      "display_url" : "pastebin.com\/raw.php?i=iL1a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395240258268176384",
  "text" : "http:\/\/t.co\/fZEfaEvrAg Emails: 89 Keywords: 0.0 #infoleak",
  "id" : 395240258268176384,
  "created_at" : "2013-10-29 17:26:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/94k9vlAhSu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A4Mr3UBc",
      "display_url" : "pastebin.com\/raw.php?i=A4Mr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395236937331511297",
  "text" : "http:\/\/t.co\/94k9vlAhSu Emails: 23 Keywords: 0.22 #infoleak",
  "id" : 395236937331511297,
  "created_at" : "2013-10-29 17:13:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KMVqjbxNzQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nXicwLey",
      "display_url" : "pastebin.com\/raw.php?i=nXic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394987593953050624",
  "text" : "http:\/\/t.co\/KMVqjbxNzQ Emails: 451 Keywords: -0.03 #infoleak",
  "id" : 394987593953050624,
  "created_at" : "2013-10-29 00:42:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8r7vdWdjFG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BWUUjqWr",
      "display_url" : "pastebin.com\/raw.php?i=BWUU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394981588858974209",
  "text" : "http:\/\/t.co\/8r7vdWdjFG Emails: 1 Hashes: 144 E\/H: 0.01 Keywords: -0.03 #infoleak",
  "id" : 394981588858974209,
  "created_at" : "2013-10-29 00:18:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hgRDH656Wp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YbUMVuMt",
      "display_url" : "pastebin.com\/raw.php?i=YbUM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394979840899567616",
  "text" : "http:\/\/t.co\/hgRDH656Wp Hashes: 573 Keywords: 0.0 #infoleak",
  "id" : 394979840899567616,
  "created_at" : "2013-10-29 00:11:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zqfyXyAjvt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=76AGcE14",
      "display_url" : "pastebin.com\/raw.php?i=76AG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394979683814490112",
  "text" : "http:\/\/t.co\/zqfyXyAjvt Emails: 1 Hashes: 1797 E\/H: 0.0 Keywords: 0.33 #infoleak",
  "id" : 394979683814490112,
  "created_at" : "2013-10-29 00:11:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pdf69h8u2K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZnWZ0B5A",
      "display_url" : "pastebin.com\/raw.php?i=ZnWZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394974373406191616",
  "text" : "http:\/\/t.co\/pdf69h8u2K Possible cisco configuration #infoleak",
  "id" : 394974373406191616,
  "created_at" : "2013-10-28 23:50:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dV1tnMiuCf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ey1Fv4zs",
      "display_url" : "pastebin.com\/raw.php?i=Ey1F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394974042333007872",
  "text" : "http:\/\/t.co\/dV1tnMiuCf Emails: 50 Keywords: -0.14 #infoleak",
  "id" : 394974042333007872,
  "created_at" : "2013-10-28 23:48:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f1D2aRC2EK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8JQ49X5m",
      "display_url" : "pastebin.com\/raw.php?i=8JQ4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394941953176920064",
  "text" : "http:\/\/t.co\/f1D2aRC2EK Emails: 55 Keywords: -0.03 #infoleak",
  "id" : 394941953176920064,
  "created_at" : "2013-10-28 21:41:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L6xkxGNWh7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=97jsDECV",
      "display_url" : "pastebin.com\/raw.php?i=97js\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394938090252292096",
  "text" : "http:\/\/t.co\/L6xkxGNWh7 Emails: 26 Keywords: -0.03 #infoleak",
  "id" : 394938090252292096,
  "created_at" : "2013-10-28 21:25:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PUXHm1gB9W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bm7tbx4X",
      "display_url" : "pastebin.com\/raw.php?i=bm7t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394937030976622592",
  "text" : "http:\/\/t.co\/PUXHm1gB9W Hashes: 34 Keywords: 0.33 #infoleak",
  "id" : 394937030976622592,
  "created_at" : "2013-10-28 21:21:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DUMNiPegDN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7v82T5xA",
      "display_url" : "pastebin.com\/raw.php?i=7v82\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394935743857979392",
  "text" : "http:\/\/t.co\/DUMNiPegDN Keywords: 0.55 #infoleak",
  "id" : 394935743857979392,
  "created_at" : "2013-10-28 21:16:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qIziYqsock",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3R8q36CZ",
      "display_url" : "pastebin.com\/raw.php?i=3R8q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394934575840763904",
  "text" : "http:\/\/t.co\/qIziYqsock Keywords: 0.55 #infoleak",
  "id" : 394934575840763904,
  "created_at" : "2013-10-28 21:11:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SebZ97fAKS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PmLNrD4r",
      "display_url" : "pastebin.com\/raw.php?i=PmLN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394927763091501056",
  "text" : "http:\/\/t.co\/SebZ97fAKS Hashes: 132 Keywords: -0.14 #infoleak",
  "id" : 394927763091501056,
  "created_at" : "2013-10-28 20:44:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N7Nr4Fs07h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xXsyMXBe",
      "display_url" : "pastebin.com\/raw.php?i=xXsy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394926397426118656",
  "text" : "http:\/\/t.co\/N7Nr4Fs07h Emails: 340 Hashes: 359 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 394926397426118656,
  "created_at" : "2013-10-28 20:39:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YZJo5IpEQu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2ajtTyyu",
      "display_url" : "pastebin.com\/raw.php?i=2ajt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394922393476415488",
  "text" : "http:\/\/t.co\/YZJo5IpEQu Keywords: 0.66 #infoleak",
  "id" : 394922393476415488,
  "created_at" : "2013-10-28 20:23:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JxWibhpDU3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SqhfbBCP",
      "display_url" : "pastebin.com\/raw.php?i=Sqhf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394911745942122497",
  "text" : "http:\/\/t.co\/JxWibhpDU3 Emails: 55 Keywords: -0.14 #infoleak",
  "id" : 394911745942122497,
  "created_at" : "2013-10-28 19:41:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wOIQr4qpMw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XXufZr4g",
      "display_url" : "pastebin.com\/raw.php?i=XXuf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394910847685771264",
  "text" : "http:\/\/t.co\/wOIQr4qpMw Emails: 38 Keywords: -0.14 #infoleak",
  "id" : 394910847685771264,
  "created_at" : "2013-10-28 19:37:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WvGGQpVejj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EVuUZ2Hm",
      "display_url" : "pastebin.com\/raw.php?i=EVuU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394902386684071937",
  "text" : "http:\/\/t.co\/WvGGQpVejj Found possible Google API key(s) #infoleak",
  "id" : 394902386684071937,
  "created_at" : "2013-10-28 19:04:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/puaYlFcdJz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zXpRZsA1",
      "display_url" : "pastebin.com\/raw.php?i=zXpR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394900070643941376",
  "text" : "http:\/\/t.co\/puaYlFcdJz Hashes: 31 Keywords: 0.0 #infoleak",
  "id" : 394900070643941376,
  "created_at" : "2013-10-28 18:54:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GcgPebYFQw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9xk4LChS",
      "display_url" : "pastebin.com\/raw.php?i=9xk4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394897343159361537",
  "text" : "http:\/\/t.co\/GcgPebYFQw Hashes: 45 Keywords: 0.08 #infoleak",
  "id" : 394897343159361537,
  "created_at" : "2013-10-28 18:43:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZBaNxY0ffI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MZUkgAPa",
      "display_url" : "pastebin.com\/raw.php?i=MZUk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394893548706754560",
  "text" : "http:\/\/t.co\/ZBaNxY0ffI Found possible Google API key(s) #infoleak",
  "id" : 394893548706754560,
  "created_at" : "2013-10-28 18:28:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4XZbhMnctN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HxZ30VMP",
      "display_url" : "pastebin.com\/raw.php?i=HxZ3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394892767442128896",
  "text" : "http:\/\/t.co\/4XZbhMnctN Emails: 60 Keywords: 0.0 #infoleak",
  "id" : 394892767442128896,
  "created_at" : "2013-10-28 18:25:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KLRJ59aYB7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Lx44PM4C",
      "display_url" : "pastebin.com\/raw.php?i=Lx44\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394890846702538752",
  "text" : "http:\/\/t.co\/KLRJ59aYB7 Emails: 64 Keywords: 0.11 #infoleak",
  "id" : 394890846702538752,
  "created_at" : "2013-10-28 18:18:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iuLdAVG1Fe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p9NP1d9h",
      "display_url" : "pastebin.com\/raw.php?i=p9NP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394890128893571072",
  "text" : "http:\/\/t.co\/iuLdAVG1Fe Hashes: 126 Keywords: 0.08 #infoleak",
  "id" : 394890128893571072,
  "created_at" : "2013-10-28 18:15:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8P0kRtffm6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=52fJiLcT",
      "display_url" : "pastebin.com\/raw.php?i=52fJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394880705265541121",
  "text" : "http:\/\/t.co\/8P0kRtffm6 Found possible Google API key(s) #infoleak",
  "id" : 394880705265541121,
  "created_at" : "2013-10-28 17:37:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tj7GWLkfUZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gvj77iPA",
      "display_url" : "pastebin.com\/raw.php?i=Gvj7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394876260632899584",
  "text" : "http:\/\/t.co\/Tj7GWLkfUZ Emails: 338 Keywords: 0.11 #infoleak",
  "id" : 394876260632899584,
  "created_at" : "2013-10-28 17:20:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0IZakJ4uli",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i0acyweT",
      "display_url" : "pastebin.com\/raw.php?i=i0ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394875821279563776",
  "text" : "http:\/\/t.co\/0IZakJ4uli Emails: 351 Hashes: 353 E\/H: 0.99 Keywords: 0.11 #infoleak",
  "id" : 394875821279563776,
  "created_at" : "2013-10-28 17:18:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PQxUDwa4PG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SFHGnVr3",
      "display_url" : "pastebin.com\/raw.php?i=SFHG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394873174325592064",
  "text" : "http:\/\/t.co\/PQxUDwa4PG Hashes: 40 Keywords: 0.0 #infoleak",
  "id" : 394873174325592064,
  "created_at" : "2013-10-28 17:07:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e22y2MEdAo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TZGbrhLR",
      "display_url" : "pastebin.com\/raw.php?i=TZGb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394869393428975616",
  "text" : "http:\/\/t.co\/e22y2MEdAo Found possible Google API key(s) #infoleak",
  "id" : 394869393428975616,
  "created_at" : "2013-10-28 16:52:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7nyOiROg4A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H8hA7hLQ",
      "display_url" : "pastebin.com\/raw.php?i=H8hA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394860568080703488",
  "text" : "http:\/\/t.co\/7nyOiROg4A Hashes: 40 Keywords: 0.0 #infoleak",
  "id" : 394860568080703488,
  "created_at" : "2013-10-28 16:17:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X9AbWuDIKy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zye67ggZ",
      "display_url" : "pastebin.com\/raw.php?i=Zye6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394838433761214464",
  "text" : "http:\/\/t.co\/X9AbWuDIKy Found possible Google API key(s) #infoleak",
  "id" : 394838433761214464,
  "created_at" : "2013-10-28 14:49:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rzq8mGaUbA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GJVc1BeX",
      "display_url" : "pastebin.com\/raw.php?i=GJVc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394831654088220672",
  "text" : "http:\/\/t.co\/rzq8mGaUbA Hashes: 3 Keywords: 0.66 #infoleak",
  "id" : 394831654088220672,
  "created_at" : "2013-10-28 14:22:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AI4T5kVMkc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JJN4ND0F",
      "display_url" : "pastebin.com\/raw.php?i=JJN4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394831446377889793",
  "text" : "http:\/\/t.co\/AI4T5kVMkc Hashes: 1 Keywords: 0.55 #infoleak",
  "id" : 394831446377889793,
  "created_at" : "2013-10-28 14:22:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LOLU96hE5E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cc6qThRQ",
      "display_url" : "pastebin.com\/raw.php?i=Cc6q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394831371413114880",
  "text" : "http:\/\/t.co\/LOLU96hE5E Emails: 7 Hashes: 2 E\/H: 3.5 Keywords: 0.66 #infoleak",
  "id" : 394831371413114880,
  "created_at" : "2013-10-28 14:21:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ptLLVn71BA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ANrA1dTj",
      "display_url" : "pastebin.com\/raw.php?i=ANrA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394830342005084161",
  "text" : "http:\/\/t.co\/ptLLVn71BA Emails: 263 Hashes: 800 E\/H: 0.33 Keywords: 0.33 #infoleak",
  "id" : 394830342005084161,
  "created_at" : "2013-10-28 14:17:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wFCcYRiWHZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=phnzdMmt",
      "display_url" : "pastebin.com\/raw.php?i=phnz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394822968938733568",
  "text" : "http:\/\/t.co\/wFCcYRiWHZ Emails: 243 Keywords: 0.3 #infoleak",
  "id" : 394822968938733568,
  "created_at" : "2013-10-28 13:48:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QcVwWwtYRl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZL4C6080",
      "display_url" : "pastebin.com\/raw.php?i=ZL4C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394819303620362240",
  "text" : "http:\/\/t.co\/QcVwWwtYRl Hashes: 44 Keywords: -0.03 #infoleak",
  "id" : 394819303620362240,
  "created_at" : "2013-10-28 13:33:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9YJbN7M6ny",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=67GgPkEu",
      "display_url" : "pastebin.com\/raw.php?i=67Gg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394768142108344320",
  "text" : "http:\/\/t.co\/9YJbN7M6ny Emails: 198 Keywords: 0.11 #infoleak",
  "id" : 394768142108344320,
  "created_at" : "2013-10-28 10:10:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mC3MqabYK0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1HiX6LKy",
      "display_url" : "pastebin.com\/raw.php?i=1HiX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394739566759780352",
  "text" : "http:\/\/t.co\/mC3MqabYK0 Possible cisco configuration #infoleak",
  "id" : 394739566759780352,
  "created_at" : "2013-10-28 08:17:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jbpbTrWncw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VaDNy7ND",
      "display_url" : "pastebin.com\/raw.php?i=VaDN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394730215835848705",
  "text" : "http:\/\/t.co\/jbpbTrWncw Emails: 4457 Keywords: 0.44 #infoleak",
  "id" : 394730215835848705,
  "created_at" : "2013-10-28 07:39:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QtHBhJMUs9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wqDbd2a0",
      "display_url" : "pastebin.com\/raw.php?i=wqDb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394718476784263169",
  "text" : "http:\/\/t.co\/QtHBhJMUs9 Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 394718476784263169,
  "created_at" : "2013-10-28 06:53:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sglw1DziES",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1yucNxQZ",
      "display_url" : "pastebin.com\/raw.php?i=1yuc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394685306839920640",
  "text" : "http:\/\/t.co\/sglw1DziES Emails: 5 Keywords: 0.55 #infoleak",
  "id" : 394685306839920640,
  "created_at" : "2013-10-28 04:41:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UIrwKFUxa3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TiWU9B0q",
      "display_url" : "pastebin.com\/raw.php?i=TiWU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394679077371527169",
  "text" : "http:\/\/t.co\/UIrwKFUxa3 Emails: 10355 Hashes: 3 E\/H: 3451.67 Keywords: 0.22 #infoleak",
  "id" : 394679077371527169,
  "created_at" : "2013-10-28 04:16:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fo8vPgWzxL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0cZQJgdq",
      "display_url" : "pastebin.com\/raw.php?i=0cZQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394658798012342272",
  "text" : "http:\/\/t.co\/Fo8vPgWzxL Emails: 158 Hashes: 10 E\/H: 15.8 Keywords: 0.22 #infoleak",
  "id" : 394658798012342272,
  "created_at" : "2013-10-28 02:56:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dUov69JvE3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u6XTk9v2",
      "display_url" : "pastebin.com\/raw.php?i=u6XT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394657309122519040",
  "text" : "http:\/\/t.co\/dUov69JvE3 Emails: 1009 Hashes: 2041 E\/H: 0.49 Keywords: 0.44 #infoleak",
  "id" : 394657309122519040,
  "created_at" : "2013-10-28 02:50:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y8YKNjxFyn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3acESxem",
      "display_url" : "pastebin.com\/raw.php?i=3acE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394641699332317184",
  "text" : "http:\/\/t.co\/y8YKNjxFyn Emails: 3 Keywords: 0.66 #infoleak",
  "id" : 394641699332317184,
  "created_at" : "2013-10-28 01:48:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lJZJmyak4s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qMncLRwz",
      "display_url" : "pastebin.com\/raw.php?i=qMnc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394630109576974336",
  "text" : "http:\/\/t.co\/lJZJmyak4s Hashes: 51 Keywords: 0.22 #infoleak",
  "id" : 394630109576974336,
  "created_at" : "2013-10-28 01:02:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eUxlGcHtIV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JR4DxXeb",
      "display_url" : "pastebin.com\/raw.php?i=JR4D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394624768000811008",
  "text" : "http:\/\/t.co\/eUxlGcHtIV Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 394624768000811008,
  "created_at" : "2013-10-28 00:40:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TVHfmEzrOp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4HC0kUzJ",
      "display_url" : "pastebin.com\/raw.php?i=4HC0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394617162393870336",
  "text" : "http:\/\/t.co\/TVHfmEzrOp Found possible Google API key(s) #infoleak",
  "id" : 394617162393870336,
  "created_at" : "2013-10-28 00:10:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GxjxaVYSuA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JCKPEJML",
      "display_url" : "pastebin.com\/raw.php?i=JCKP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394607859465326593",
  "text" : "http:\/\/t.co\/GxjxaVYSuA Emails: 123 Keywords: 0.33 #infoleak",
  "id" : 394607859465326593,
  "created_at" : "2013-10-27 23:33:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KH2KwLoYrg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BxaXFNd0",
      "display_url" : "pastebin.com\/raw.php?i=BxaX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394596291503607808",
  "text" : "http:\/\/t.co\/KH2KwLoYrg Possible cisco configuration #infoleak",
  "id" : 394596291503607808,
  "created_at" : "2013-10-27 22:47:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1rYj1an1Lu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iBvLjV8c",
      "display_url" : "pastebin.com\/raw.php?i=iBvL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394587812499951617",
  "text" : "http:\/\/t.co\/1rYj1an1Lu Hashes: 104 Keywords: 0.22 #infoleak",
  "id" : 394587812499951617,
  "created_at" : "2013-10-27 22:14:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TkaX72ibRN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gLE1jPHR",
      "display_url" : "pastebin.com\/raw.php?i=gLE1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394582577282957312",
  "text" : "http:\/\/t.co\/TkaX72ibRN Emails: 1498 Hashes: 1503 E\/H: 1.0 Keywords: 0.08 #infoleak",
  "id" : 394582577282957312,
  "created_at" : "2013-10-27 21:53:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4T4lAnCDzB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7u7tNkBM",
      "display_url" : "pastebin.com\/raw.php?i=7u7t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394573562503131137",
  "text" : "http:\/\/t.co\/4T4lAnCDzB Possible cisco configuration #infoleak",
  "id" : 394573562503131137,
  "created_at" : "2013-10-27 21:17:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dTTMsbkvgt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RZ4yTMuD",
      "display_url" : "pastebin.com\/raw.php?i=RZ4y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394557854733963264",
  "text" : "http:\/\/t.co\/dTTMsbkvgt Emails: 22 Keywords: -0.03 #infoleak",
  "id" : 394557854733963264,
  "created_at" : "2013-10-27 20:14:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tPUzx96QsO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bPEn0ahs",
      "display_url" : "pastebin.com\/raw.php?i=bPEn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394556654479343616",
  "text" : "http:\/\/t.co\/tPUzx96QsO Emails: 27 Keywords: 0.08 #infoleak",
  "id" : 394556654479343616,
  "created_at" : "2013-10-27 20:10:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MJq2YelJt7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U4njb7e5",
      "display_url" : "pastebin.com\/raw.php?i=U4nj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394548540560519168",
  "text" : "http:\/\/t.co\/MJq2YelJt7 Hashes: 35 Keywords: 0.0 #infoleak",
  "id" : 394548540560519168,
  "created_at" : "2013-10-27 19:37:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q3vKP0aUNh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=njC5JngG",
      "display_url" : "pastebin.com\/raw.php?i=njC5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394544068752969728",
  "text" : "http:\/\/t.co\/q3vKP0aUNh Hashes: 30 Keywords: 0.11 #infoleak",
  "id" : 394544068752969728,
  "created_at" : "2013-10-27 19:20:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0YqQdsbxdx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2fEGsdiB",
      "display_url" : "pastebin.com\/raw.php?i=2fEG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394523046007943169",
  "text" : "http:\/\/t.co\/0YqQdsbxdx Found possible Google API key(s) #infoleak",
  "id" : 394523046007943169,
  "created_at" : "2013-10-27 17:56:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EG7kNWFAtq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vjBer1hf",
      "display_url" : "pastebin.com\/raw.php?i=vjBe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394521442303221760",
  "text" : "http:\/\/t.co\/EG7kNWFAtq Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 394521442303221760,
  "created_at" : "2013-10-27 17:50:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9YlUrViS4o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iNi58qnV",
      "display_url" : "pastebin.com\/raw.php?i=iNi5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394517962473754624",
  "text" : "http:\/\/t.co\/9YlUrViS4o Emails: 7450 Keywords: 0.19 #infoleak",
  "id" : 394517962473754624,
  "created_at" : "2013-10-27 17:36:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W22wUeOO3l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g3Gtvuy4",
      "display_url" : "pastebin.com\/raw.php?i=g3Gt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394514696595726336",
  "text" : "http:\/\/t.co\/W22wUeOO3l Emails: 373 Keywords: 0.08 #infoleak",
  "id" : 394514696595726336,
  "created_at" : "2013-10-27 17:23:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SXvAL99Ewe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fi6jDwc7",
      "display_url" : "pastebin.com\/raw.php?i=Fi6j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394510578426724352",
  "text" : "http:\/\/t.co\/SXvAL99Ewe Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 394510578426724352,
  "created_at" : "2013-10-27 17:07:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dNH9N1GmF5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a68ErDhH",
      "display_url" : "pastebin.com\/raw.php?i=a68E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394504492671959040",
  "text" : "http:\/\/t.co\/dNH9N1GmF5 Found possible Google API key(s) #infoleak",
  "id" : 394504492671959040,
  "created_at" : "2013-10-27 16:42:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/co03LA9QEE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q0f7aNua",
      "display_url" : "pastebin.com\/raw.php?i=Q0f7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394502694670323712",
  "text" : "http:\/\/t.co\/co03LA9QEE Keywords: 0.55 #infoleak",
  "id" : 394502694670323712,
  "created_at" : "2013-10-27 16:35:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RkcEEWht4h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tbE0dvKd",
      "display_url" : "pastebin.com\/raw.php?i=tbE0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394502170734628865",
  "text" : "http:\/\/t.co\/RkcEEWht4h Emails: 1054 Keywords: 0.33 #infoleak",
  "id" : 394502170734628865,
  "created_at" : "2013-10-27 16:33:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L0xNWtd50n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xRadA58n",
      "display_url" : "pastebin.com\/raw.php?i=xRad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394499353932361728",
  "text" : "http:\/\/t.co\/L0xNWtd50n Found possible Google API key(s) #infoleak",
  "id" : 394499353932361728,
  "created_at" : "2013-10-27 16:22:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9bWsAlBUMY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YJkLq6bv",
      "display_url" : "pastebin.com\/raw.php?i=YJkL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394494803427082241",
  "text" : "http:\/\/t.co\/9bWsAlBUMY Emails: 143 Keywords: 0.22 #infoleak",
  "id" : 394494803427082241,
  "created_at" : "2013-10-27 16:04:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gbltUvxi0b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xSs93Abm",
      "display_url" : "pastebin.com\/raw.php?i=xSs9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394482961245941760",
  "text" : "http:\/\/t.co\/gbltUvxi0b Emails: 94 Keywords: 0.0 #infoleak",
  "id" : 394482961245941760,
  "created_at" : "2013-10-27 15:17:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xwyJfqemKx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=itbeH4yZ",
      "display_url" : "pastebin.com\/raw.php?i=itbe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394482751551729664",
  "text" : "http:\/\/t.co\/xwyJfqemKx Keywords: 0.66 #infoleak",
  "id" : 394482751551729664,
  "created_at" : "2013-10-27 15:16:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JUDkThJAgR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z27zGqXh",
      "display_url" : "pastebin.com\/raw.php?i=z27z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394477012925968384",
  "text" : "http:\/\/t.co\/JUDkThJAgR Emails: 49 Keywords: 0.22 #infoleak",
  "id" : 394477012925968384,
  "created_at" : "2013-10-27 14:53:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F7XL4teucc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YWUhxK86",
      "display_url" : "pastebin.com\/raw.php?i=YWUh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394476827864862720",
  "text" : "http:\/\/t.co\/F7XL4teucc Emails: 49 Keywords: 0.22 #infoleak",
  "id" : 394476827864862720,
  "created_at" : "2013-10-27 14:52:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zEYEGkpsd8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2VheNtc5",
      "display_url" : "pastebin.com\/raw.php?i=2Vhe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394473344948387840",
  "text" : "http:\/\/t.co\/zEYEGkpsd8 Emails: 15 Hashes: 13 E\/H: 1.15 Keywords: 0.55 #infoleak",
  "id" : 394473344948387840,
  "created_at" : "2013-10-27 14:39:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NQfXw0pHUd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1JiUBr9Z",
      "display_url" : "pastebin.com\/raw.php?i=1JiU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394473002529595393",
  "text" : "http:\/\/t.co\/NQfXw0pHUd Found possible Google API key(s) #infoleak",
  "id" : 394473002529595393,
  "created_at" : "2013-10-27 14:37:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hFrJ0k4Tvp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N75Nfudv",
      "display_url" : "pastebin.com\/raw.php?i=N75N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394469335197962240",
  "text" : "http:\/\/t.co\/hFrJ0k4Tvp Keywords: 0.66 #infoleak",
  "id" : 394469335197962240,
  "created_at" : "2013-10-27 14:23:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ep60I5Aobf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=axNbM8iY",
      "display_url" : "pastebin.com\/raw.php?i=axNb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394465551247880195",
  "text" : "http:\/\/t.co\/ep60I5Aobf Emails: 48 Keywords: 0.33 #infoleak",
  "id" : 394465551247880195,
  "created_at" : "2013-10-27 14:08:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pBrAn8hvWD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dPdpeTyu",
      "display_url" : "pastebin.com\/raw.php?i=dPdp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394459002207096834",
  "text" : "http:\/\/t.co\/pBrAn8hvWD Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 394459002207096834,
  "created_at" : "2013-10-27 13:42:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rKWyzbv3ST",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TNVfgVf3",
      "display_url" : "pastebin.com\/raw.php?i=TNVf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394456649156395008",
  "text" : "http:\/\/t.co\/rKWyzbv3ST Emails: 2 Hashes: 80 E\/H: 0.03 Keywords: 0.22 #infoleak",
  "id" : 394456649156395008,
  "created_at" : "2013-10-27 13:32:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mdmUEDCx4b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KQ31T6Jz",
      "display_url" : "pastebin.com\/raw.php?i=KQ31\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394436615772184576",
  "text" : "http:\/\/t.co\/mdmUEDCx4b Emails: 118 Keywords: 0.11 #infoleak",
  "id" : 394436615772184576,
  "created_at" : "2013-10-27 12:13:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d6G2MLWsWP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=raFw9jGy",
      "display_url" : "pastebin.com\/raw.php?i=raFw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394434112519286784",
  "text" : "http:\/\/t.co\/d6G2MLWsWP Emails: 85 Keywords: 0.0 #infoleak",
  "id" : 394434112519286784,
  "created_at" : "2013-10-27 12:03:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wyENT0dKDx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wZfgu5K4",
      "display_url" : "pastebin.com\/raw.php?i=wZfg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394431203064819712",
  "text" : "http:\/\/t.co\/wyENT0dKDx Emails: 81 Keywords: 0.08 #infoleak",
  "id" : 394431203064819712,
  "created_at" : "2013-10-27 11:51:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1EbGj2Levd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9y65fw48",
      "display_url" : "pastebin.com\/raw.php?i=9y65\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394408237291687936",
  "text" : "http:\/\/t.co\/1EbGj2Levd Found possible Google API key(s) #infoleak",
  "id" : 394408237291687936,
  "created_at" : "2013-10-27 10:20:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PdHd0p5Tf9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RBxk1Lvj",
      "display_url" : "pastebin.com\/raw.php?i=RBxk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394405914846830592",
  "text" : "http:\/\/t.co\/PdHd0p5Tf9 Emails: 117 Hashes: 116 E\/H: 1.01 Keywords: 0.19 #infoleak",
  "id" : 394405914846830592,
  "created_at" : "2013-10-27 10:11:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cx0UMdqXna",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9sbrQBB3",
      "display_url" : "pastebin.com\/raw.php?i=9sbr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394405026086387712",
  "text" : "http:\/\/t.co\/cx0UMdqXna Found possible Google API key(s) #infoleak",
  "id" : 394405026086387712,
  "created_at" : "2013-10-27 10:07:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Cx4Jf9NG8y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dm2apFis",
      "display_url" : "pastebin.com\/raw.php?i=Dm2a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394387973229142016",
  "text" : "http:\/\/t.co\/Cx4Jf9NG8y Found possible Google API key(s) #infoleak",
  "id" : 394387973229142016,
  "created_at" : "2013-10-27 08:59:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y21vT3AriW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WMmt68rf",
      "display_url" : "pastebin.com\/raw.php?i=WMmt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394303689659150338",
  "text" : "http:\/\/t.co\/Y21vT3AriW Hashes: 1387 Keywords: 0.22 #infoleak",
  "id" : 394303689659150338,
  "created_at" : "2013-10-27 03:25:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8FNPUY9YF2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pSt4w2jn",
      "display_url" : "pastebin.com\/raw.php?i=pSt4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394291586026065921",
  "text" : "http:\/\/t.co\/8FNPUY9YF2 Emails: 49 Keywords: 0.0 #infoleak",
  "id" : 394291586026065921,
  "created_at" : "2013-10-27 02:36:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fmyvaqkjLd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7pADgWYE",
      "display_url" : "pastebin.com\/raw.php?i=7pAD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394272516052504576",
  "text" : "http:\/\/t.co\/fmyvaqkjLd Hashes: 294 Keywords: -0.06 #infoleak",
  "id" : 394272516052504576,
  "created_at" : "2013-10-27 01:21:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QkqgFwbI8B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tiK1TfW9",
      "display_url" : "pastebin.com\/raw.php?i=tiK1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394263164742664192",
  "text" : "http:\/\/t.co\/QkqgFwbI8B Found possible Google API key(s) #infoleak",
  "id" : 394263164742664192,
  "created_at" : "2013-10-27 00:43:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9Z40cWadp0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QH7mAm4q",
      "display_url" : "pastebin.com\/raw.php?i=QH7m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394260407780524032",
  "text" : "http:\/\/t.co\/9Z40cWadp0 Possible cisco configuration #infoleak",
  "id" : 394260407780524032,
  "created_at" : "2013-10-27 00:33:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zOlkvzkaD0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LpRQ9TaY",
      "display_url" : "pastebin.com\/raw.php?i=LpRQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394240436048367616",
  "text" : "http:\/\/t.co\/zOlkvzkaD0 Found possible Google API key(s) #infoleak",
  "id" : 394240436048367616,
  "created_at" : "2013-10-26 23:13:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/50YeuEdqO2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bDugmHKe",
      "display_url" : "pastebin.com\/raw.php?i=bDug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394235610463870977",
  "text" : "http:\/\/t.co\/50YeuEdqO2 Emails: 114 Keywords: 0.22 #infoleak",
  "id" : 394235610463870977,
  "created_at" : "2013-10-26 22:54:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4T7ZT0BtFm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pTGbgh7p",
      "display_url" : "pastebin.com\/raw.php?i=pTGb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394201382716063744",
  "text" : "http:\/\/t.co\/4T7ZT0BtFm Found possible Google API key(s) #infoleak",
  "id" : 394201382716063744,
  "created_at" : "2013-10-26 20:38:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QDxUR7MdXk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5VsjtmR8",
      "display_url" : "pastebin.com\/raw.php?i=5Vsj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394200072159629312",
  "text" : "http:\/\/t.co\/QDxUR7MdXk Found possible Google API key(s) #infoleak",
  "id" : 394200072159629312,
  "created_at" : "2013-10-26 20:33:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EOqLJzvES5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PGkhSMcV",
      "display_url" : "pastebin.com\/raw.php?i=PGkh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394185840198316032",
  "text" : "http:\/\/t.co\/EOqLJzvES5 Emails: 396 Keywords: 0.0 #infoleak",
  "id" : 394185840198316032,
  "created_at" : "2013-10-26 19:36:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/97fh6aKy6r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ypF5PEvk",
      "display_url" : "pastebin.com\/raw.php?i=ypF5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394185452086784000",
  "text" : "http:\/\/t.co\/97fh6aKy6r Emails: 469 Keywords: 0.11 #infoleak",
  "id" : 394185452086784000,
  "created_at" : "2013-10-26 19:35:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CZVehCfNdQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4mNEY0vd",
      "display_url" : "pastebin.com\/raw.php?i=4mNE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394174717738766336",
  "text" : "http:\/\/t.co\/CZVehCfNdQ Hashes: 77 Keywords: 0.0 #infoleak",
  "id" : 394174717738766336,
  "created_at" : "2013-10-26 18:52:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JXyQEFzARm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XhjcRf86",
      "display_url" : "pastebin.com\/raw.php?i=Xhjc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394174466000842752",
  "text" : "http:\/\/t.co\/JXyQEFzARm Found possible Google API key(s) #infoleak",
  "id" : 394174466000842752,
  "created_at" : "2013-10-26 18:51:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rcJDbkF9nn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=srgZ61kU",
      "display_url" : "pastebin.com\/raw.php?i=srgZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394162813230272512",
  "text" : "http:\/\/t.co\/rcJDbkF9nn Emails: 151 Keywords: 0.41 #infoleak",
  "id" : 394162813230272512,
  "created_at" : "2013-10-26 18:05:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UdcInFp8ej",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=inAvDEvT",
      "display_url" : "pastebin.com\/raw.php?i=inAv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394156327590580226",
  "text" : "http:\/\/t.co\/UdcInFp8ej Emails: 51 Hashes: 22 E\/H: 2.32 Keywords: 0.11 #infoleak",
  "id" : 394156327590580226,
  "created_at" : "2013-10-26 17:39:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PZeoezHB2B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1d8dKtEM",
      "display_url" : "pastebin.com\/raw.php?i=1d8d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394127795950874624",
  "text" : "http:\/\/t.co\/PZeoezHB2B Hashes: 3 Keywords: 0.77 #infoleak",
  "id" : 394127795950874624,
  "created_at" : "2013-10-26 15:46:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/owDpH2gYOS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ucve0EJv",
      "display_url" : "pastebin.com\/raw.php?i=Ucve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394122406568030208",
  "text" : "http:\/\/t.co\/owDpH2gYOS Hashes: 60 Keywords: 0.22 #infoleak",
  "id" : 394122406568030208,
  "created_at" : "2013-10-26 15:24:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hGM7wZDA8x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cMas7em2",
      "display_url" : "pastebin.com\/raw.php?i=cMas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394113070345121792",
  "text" : "http:\/\/t.co\/hGM7wZDA8x Hashes: 89 Keywords: -0.14 #infoleak",
  "id" : 394113070345121792,
  "created_at" : "2013-10-26 14:47:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bcB1W5hVca",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AZ7hqm9V",
      "display_url" : "pastebin.com\/raw.php?i=AZ7h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394113050908696576",
  "text" : "http:\/\/t.co\/bcB1W5hVca Emails: 679 Keywords: 0.22 #infoleak",
  "id" : 394113050908696576,
  "created_at" : "2013-10-26 14:47:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hsZGillkIx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wqGqVtj3",
      "display_url" : "pastebin.com\/raw.php?i=wqGq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394104544298168320",
  "text" : "http:\/\/t.co\/hsZGillkIx Emails: 74 Keywords: 0.11 #infoleak",
  "id" : 394104544298168320,
  "created_at" : "2013-10-26 14:13:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UmRetVqhOe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SGBAeMej",
      "display_url" : "pastebin.com\/raw.php?i=SGBA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394096778510757890",
  "text" : "http:\/\/t.co\/UmRetVqhOe Emails: 20 Keywords: 0.63 #infoleak",
  "id" : 394096778510757890,
  "created_at" : "2013-10-26 13:42:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zrqODRf7us",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TqT3avFS",
      "display_url" : "pastebin.com\/raw.php?i=TqT3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394084580262563840",
  "text" : "http:\/\/t.co\/zrqODRf7us Emails: 489 Hashes: 537 E\/H: 0.91 Keywords: 0.19 #infoleak",
  "id" : 394084580262563840,
  "created_at" : "2013-10-26 12:54:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KyhNVGaB5C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iSL1ipzU",
      "display_url" : "pastebin.com\/raw.php?i=iSL1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394084073817128961",
  "text" : "http:\/\/t.co\/KyhNVGaB5C Emails: 489 Hashes: 537 E\/H: 0.91 Keywords: 0.19 #infoleak",
  "id" : 394084073817128961,
  "created_at" : "2013-10-26 12:52:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RHrtu8Jptd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S9VeVR1j",
      "display_url" : "pastebin.com\/raw.php?i=S9Ve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394078675475251200",
  "text" : "http:\/\/t.co\/RHrtu8Jptd Emails: 256 Hashes: 256 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 394078675475251200,
  "created_at" : "2013-10-26 12:30:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/acFrEIil9I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zSem0kgK",
      "display_url" : "pastebin.com\/raw.php?i=zSem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394070620717084672",
  "text" : "http:\/\/t.co\/acFrEIil9I Found possible Google API key(s) #infoleak",
  "id" : 394070620717084672,
  "created_at" : "2013-10-26 11:58:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v7Pu9Z4jdk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=puDNyHE7",
      "display_url" : "pastebin.com\/raw.php?i=puDN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394041593063153664",
  "text" : "http:\/\/t.co\/v7Pu9Z4jdk Emails: 309 Hashes: 558 E\/H: 0.55 Keywords: 0.22 #infoleak",
  "id" : 394041593063153664,
  "created_at" : "2013-10-26 10:03:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7mqPw8CQBz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UCgkSBW5",
      "display_url" : "pastebin.com\/raw.php?i=UCgk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394038655364239360",
  "text" : "http:\/\/t.co\/7mqPw8CQBz Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 394038655364239360,
  "created_at" : "2013-10-26 09:51:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3BGtuEgtAX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tFJH5saQ",
      "display_url" : "pastebin.com\/raw.php?i=tFJH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394015399827628032",
  "text" : "http:\/\/t.co\/3BGtuEgtAX Found possible Google API key(s) #infoleak",
  "id" : 394015399827628032,
  "created_at" : "2013-10-26 08:19:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TvwYy1f7Dl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zfvt8G8y",
      "display_url" : "pastebin.com\/raw.php?i=zfvt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394010049544069121",
  "text" : "http:\/\/t.co\/TvwYy1f7Dl Emails: 32 Keywords: 0.11 #infoleak",
  "id" : 394010049544069121,
  "created_at" : "2013-10-26 07:58:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zEDDF74IIx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PdbPZ963",
      "display_url" : "pastebin.com\/raw.php?i=PdbP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393996357708414976",
  "text" : "http:\/\/t.co\/zEDDF74IIx Emails: 1498 Hashes: 1503 E\/H: 1.0 Keywords: 0.08 #infoleak",
  "id" : 393996357708414976,
  "created_at" : "2013-10-26 07:03:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hghghXYSwv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DuJmUbeM",
      "display_url" : "pastebin.com\/raw.php?i=DuJm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393995679464300544",
  "text" : "http:\/\/t.co\/hghghXYSwv Emails: 439 Keywords: 0.0 #infoleak",
  "id" : 393995679464300544,
  "created_at" : "2013-10-26 07:01:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zfKfyIZW9c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q08F6LfK",
      "display_url" : "pastebin.com\/raw.php?i=q08F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393985080202248192",
  "text" : "http:\/\/t.co\/zfKfyIZW9c Emails: 46 Keywords: -0.03 #infoleak",
  "id" : 393985080202248192,
  "created_at" : "2013-10-26 06:18:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hnnKPN36be",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8SyxP0Y3",
      "display_url" : "pastebin.com\/raw.php?i=8Syx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393981163766702080",
  "text" : "http:\/\/t.co\/hnnKPN36be Emails: 55 Keywords: -0.14 #infoleak",
  "id" : 393981163766702080,
  "created_at" : "2013-10-26 06:03:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SCcnHpcGZS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tgwu7L15",
      "display_url" : "pastebin.com\/raw.php?i=tgwu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393964466146009088",
  "text" : "http:\/\/t.co\/SCcnHpcGZS Found possible Google API key(s) #infoleak",
  "id" : 393964466146009088,
  "created_at" : "2013-10-26 04:57:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7OVeb3P7N9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P0FCM4es",
      "display_url" : "pastebin.com\/raw.php?i=P0FC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393942096656080896",
  "text" : "http:\/\/t.co\/7OVeb3P7N9 Emails: 72 Keywords: 0.55 #infoleak",
  "id" : 393942096656080896,
  "created_at" : "2013-10-26 03:28:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eQ59nWCtaG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=agzuKNQt",
      "display_url" : "pastebin.com\/raw.php?i=agzu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393903767906562048",
  "text" : "http:\/\/t.co\/eQ59nWCtaG Hashes: 34 Keywords: 0.0 #infoleak",
  "id" : 393903767906562048,
  "created_at" : "2013-10-26 00:55:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QAvSdv4cmr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eysqEKes",
      "display_url" : "pastebin.com\/raw.php?i=eysq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393879365257134080",
  "text" : "http:\/\/t.co\/QAvSdv4cmr Hashes: 85 Keywords: 0.11 #infoleak",
  "id" : 393879365257134080,
  "created_at" : "2013-10-25 23:18:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z4pkQbFeHy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zJTQK80C",
      "display_url" : "pastebin.com\/raw.php?i=zJTQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393844357570125824",
  "text" : "http:\/\/t.co\/Z4pkQbFeHy Keywords: 0.55 #infoleak",
  "id" : 393844357570125824,
  "created_at" : "2013-10-25 20:59:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bTUq5h1cfP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3h9GM7sM",
      "display_url" : "pastebin.com\/raw.php?i=3h9G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393843807315165185",
  "text" : "http:\/\/t.co\/bTUq5h1cfP Emails: 1062 Hashes: 1062 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 393843807315165185,
  "created_at" : "2013-10-25 20:57:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6vfUQj7M90",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X7qmSg0G",
      "display_url" : "pastebin.com\/raw.php?i=X7qm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393820498900946944",
  "text" : "http:\/\/t.co\/6vfUQj7M90 Emails: 1 Hashes: 280 E\/H: 0.0 Keywords: -0.03 #infoleak",
  "id" : 393820498900946944,
  "created_at" : "2013-10-25 19:24:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UdbobQJ2kd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1fsV2fBb",
      "display_url" : "pastebin.com\/raw.php?i=1fsV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393753410576453634",
  "text" : "http:\/\/t.co\/UdbobQJ2kd Found possible Google API key(s) #infoleak",
  "id" : 393753410576453634,
  "created_at" : "2013-10-25 14:58:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/05MmmIwrLk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dRBmP3wp",
      "display_url" : "pastebin.com\/raw.php?i=dRBm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393744964569411585",
  "text" : "http:\/\/t.co\/05MmmIwrLk Emails: 27 Keywords: 0.11 #infoleak",
  "id" : 393744964569411585,
  "created_at" : "2013-10-25 14:24:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jJ4qowDl6M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qSu3W2Pc",
      "display_url" : "pastebin.com\/raw.php?i=qSu3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393712695100190720",
  "text" : "http:\/\/t.co\/jJ4qowDl6M Found possible Google API key(s) #infoleak",
  "id" : 393712695100190720,
  "created_at" : "2013-10-25 12:16:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zVrz8ZWpTh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7CyFkE9i",
      "display_url" : "pastebin.com\/raw.php?i=7CyF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393711990515851264",
  "text" : "http:\/\/t.co\/zVrz8ZWpTh Hashes: 44 Keywords: -0.03 #infoleak",
  "id" : 393711990515851264,
  "created_at" : "2013-10-25 12:13:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BrJz884jX0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=21uvqiNy",
      "display_url" : "pastebin.com\/raw.php?i=21uv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393698284021108736",
  "text" : "http:\/\/t.co\/BrJz884jX0 Found possible Google API key(s) #infoleak",
  "id" : 393698284021108736,
  "created_at" : "2013-10-25 11:19:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oQylJbHqjC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6SKmd7mW",
      "display_url" : "pastebin.com\/raw.php?i=6SKm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393689772159275008",
  "text" : "http:\/\/t.co\/oQylJbHqjC Hashes: 44 Keywords: -0.03 #infoleak",
  "id" : 393689772159275008,
  "created_at" : "2013-10-25 10:45:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dPlFzadrpz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MYNGSeZp",
      "display_url" : "pastebin.com\/raw.php?i=MYNG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393683906597113856",
  "text" : "http:\/\/t.co\/dPlFzadrpz Emails: 3 Hashes: 72 E\/H: 0.04 Keywords: -0.06 #infoleak",
  "id" : 393683906597113856,
  "created_at" : "2013-10-25 10:22:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/worqBAe34W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=76UtvTiM",
      "display_url" : "pastebin.com\/raw.php?i=76Ut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393677532941131776",
  "text" : "http:\/\/t.co\/worqBAe34W Emails: 106 Keywords: 0.44 #infoleak",
  "id" : 393677532941131776,
  "created_at" : "2013-10-25 09:56:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MmODqpr7MH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AF0wuQP9",
      "display_url" : "pastebin.com\/raw.php?i=AF0w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393673611266912256",
  "text" : "http:\/\/t.co\/MmODqpr7MH Emails: 4 Hashes: 32 E\/H: 0.13 Keywords: 0.3 #infoleak",
  "id" : 393673611266912256,
  "created_at" : "2013-10-25 09:41:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T1oJdLQKnN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pMKuVZnF",
      "display_url" : "pastebin.com\/raw.php?i=pMKu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393659477959774208",
  "text" : "http:\/\/t.co\/T1oJdLQKnN Emails: 2869 Keywords: 0.22 #infoleak",
  "id" : 393659477959774208,
  "created_at" : "2013-10-25 08:45:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iIIwBV0pZP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nSMHFLUi",
      "display_url" : "pastebin.com\/raw.php?i=nSMH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393648046170316800",
  "text" : "http:\/\/t.co\/iIIwBV0pZP Emails: 73 Keywords: 0.19 #infoleak",
  "id" : 393648046170316800,
  "created_at" : "2013-10-25 07:59:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y3T51crvKB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0TqFFzCE",
      "display_url" : "pastebin.com\/raw.php?i=0TqF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393640738300256256",
  "text" : "http:\/\/t.co\/Y3T51crvKB Hashes: 194 Keywords: 0.22 #infoleak",
  "id" : 393640738300256256,
  "created_at" : "2013-10-25 07:30:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qOmnzK8sKg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ysqFa8j4",
      "display_url" : "pastebin.com\/raw.php?i=ysqF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393640348477440000",
  "text" : "http:\/\/t.co\/qOmnzK8sKg Emails: 462 Keywords: 0.33 #infoleak",
  "id" : 393640348477440000,
  "created_at" : "2013-10-25 07:29:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IaB9FYs692",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PJVL1WEY",
      "display_url" : "pastebin.com\/raw.php?i=PJVL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393632506542424065",
  "text" : "http:\/\/t.co\/IaB9FYs692 Hashes: 33 Keywords: -0.03 #infoleak",
  "id" : 393632506542424065,
  "created_at" : "2013-10-25 06:57:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a2IopMMNfa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JHzKr9FQ",
      "display_url" : "pastebin.com\/raw.php?i=JHzK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393627756040163328",
  "text" : "http:\/\/t.co\/a2IopMMNfa Emails: 999 Keywords: 0.19 #infoleak",
  "id" : 393627756040163328,
  "created_at" : "2013-10-25 06:39:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zyNzHeVxoC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iwrYjuFg",
      "display_url" : "pastebin.com\/raw.php?i=iwrY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393625934902743040",
  "text" : "http:\/\/t.co\/zyNzHeVxoC Emails: 439 Keywords: 0.33 #infoleak",
  "id" : 393625934902743040,
  "created_at" : "2013-10-25 06:31:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XMSwTZz2mM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YGdFXRpV",
      "display_url" : "pastebin.com\/raw.php?i=YGdF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393621970819895296",
  "text" : "http:\/\/t.co\/XMSwTZz2mM Possible cisco configuration #infoleak",
  "id" : 393621970819895296,
  "created_at" : "2013-10-25 06:16:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SDSEbDRKJE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5zfrVNkE",
      "display_url" : "pastebin.com\/raw.php?i=5zfr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393603308834656257",
  "text" : "http:\/\/t.co\/SDSEbDRKJE Hashes: 65 Keywords: 0.11 #infoleak",
  "id" : 393603308834656257,
  "created_at" : "2013-10-25 05:01:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XTJajRYKej",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pEY7P2b5",
      "display_url" : "pastebin.com\/raw.php?i=pEY7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393581433257598976",
  "text" : "http:\/\/t.co\/XTJajRYKej Emails: 243 Keywords: 0.08 #infoleak",
  "id" : 393581433257598976,
  "created_at" : "2013-10-25 03:35:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NdJ8Ja7mq3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WMf6eSGY",
      "display_url" : "pastebin.com\/raw.php?i=WMf6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393579881490948096",
  "text" : "http:\/\/t.co\/NdJ8Ja7mq3 Emails: 243 Keywords: 0.08 #infoleak",
  "id" : 393579881490948096,
  "created_at" : "2013-10-25 03:28:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zjvHWNTrnr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KwCyux3i",
      "display_url" : "pastebin.com\/raw.php?i=KwCy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393562733590749184",
  "text" : "http:\/\/t.co\/zjvHWNTrnr Emails: 527 Keywords: 0.33 #infoleak",
  "id" : 393562733590749184,
  "created_at" : "2013-10-25 02:20:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1naj86PbFH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c3EEmyVn",
      "display_url" : "pastebin.com\/raw.php?i=c3EE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393560770635501568",
  "text" : "http:\/\/t.co\/1naj86PbFH Found possible Google API key(s) #infoleak",
  "id" : 393560770635501568,
  "created_at" : "2013-10-25 02:12:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ooPolE6ovh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8Bfe4q0h",
      "display_url" : "pastebin.com\/raw.php?i=8Bfe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393554307200471040",
  "text" : "http:\/\/t.co\/ooPolE6ovh Possible cisco configuration #infoleak",
  "id" : 393554307200471040,
  "created_at" : "2013-10-25 01:47:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a0WTQKMXSC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3iGzqw3m",
      "display_url" : "pastebin.com\/raw.php?i=3iGz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393553268623683585",
  "text" : "http:\/\/t.co\/a0WTQKMXSC Possible cisco configuration #infoleak",
  "id" : 393553268623683585,
  "created_at" : "2013-10-25 01:43:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IQYnngKd4s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G4nrGzcw",
      "display_url" : "pastebin.com\/raw.php?i=G4nr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393546509704105985",
  "text" : "http:\/\/t.co\/IQYnngKd4s Hashes: 228 Keywords: -0.14 #infoleak",
  "id" : 393546509704105985,
  "created_at" : "2013-10-25 01:16:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D1ijhpL693",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bq2ERGHp",
      "display_url" : "pastebin.com\/raw.php?i=Bq2E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393542878648999936",
  "text" : "http:\/\/t.co\/D1ijhpL693 Emails: 413 Keywords: 0.33 #infoleak",
  "id" : 393542878648999936,
  "created_at" : "2013-10-25 01:01:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KAONYLOy5c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EQfiLk1t",
      "display_url" : "pastebin.com\/raw.php?i=EQfi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393525523264983040",
  "text" : "http:\/\/t.co\/KAONYLOy5c Possible cisco configuration #infoleak",
  "id" : 393525523264983040,
  "created_at" : "2013-10-24 23:52:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7o95VTPNSA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5ceebyvk",
      "display_url" : "pastebin.com\/raw.php?i=5cee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393518736021262336",
  "text" : "http:\/\/t.co\/7o95VTPNSA Possible cisco configuration #infoleak",
  "id" : 393518736021262336,
  "created_at" : "2013-10-24 23:25:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/696yEHFBju",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jY9hN69D",
      "display_url" : "pastebin.com\/raw.php?i=jY9h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393517917024686081",
  "text" : "http:\/\/t.co\/696yEHFBju Emails: 230 Keywords: 0.11 #infoleak",
  "id" : 393517917024686081,
  "created_at" : "2013-10-24 23:22:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t7kiVibmJe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hRRhrSHN",
      "display_url" : "pastebin.com\/raw.php?i=hRRh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393517668503785472",
  "text" : "http:\/\/t.co\/t7kiVibmJe Emails: 21 Keywords: 0.19 #infoleak",
  "id" : 393517668503785472,
  "created_at" : "2013-10-24 23:21:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5Tqlxs7lO7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s5cYKTqa",
      "display_url" : "pastebin.com\/raw.php?i=s5cY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393508769381904384",
  "text" : "http:\/\/t.co\/5Tqlxs7lO7 Possible cisco configuration #infoleak",
  "id" : 393508769381904384,
  "created_at" : "2013-10-24 22:46:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1Xd9aDLnAK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7evr8qtG",
      "display_url" : "pastebin.com\/raw.php?i=7evr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393503480901431297",
  "text" : "http:\/\/t.co\/1Xd9aDLnAK Hashes: 40 Keywords: 0.22 #infoleak",
  "id" : 393503480901431297,
  "created_at" : "2013-10-24 22:25:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MzsVEbDEzd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t0pUCxjU",
      "display_url" : "pastebin.com\/raw.php?i=t0pU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393502693429219328",
  "text" : "http:\/\/t.co\/MzsVEbDEzd Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 393502693429219328,
  "created_at" : "2013-10-24 22:22:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m6gM9om369",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZSrVsEwE",
      "display_url" : "pastebin.com\/raw.php?i=ZSrV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393495337509195777",
  "text" : "http:\/\/t.co\/m6gM9om369 Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 393495337509195777,
  "created_at" : "2013-10-24 21:52:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lP8VmQOzmV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K82wsE3c",
      "display_url" : "pastebin.com\/raw.php?i=K82w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393493917179445248",
  "text" : "http:\/\/t.co\/lP8VmQOzmV Emails: 111 Hashes: 138 E\/H: 0.8 Keywords: -0.03 #infoleak",
  "id" : 393493917179445248,
  "created_at" : "2013-10-24 21:47:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/75tjPGcPPv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nWGcEpn0",
      "display_url" : "pastebin.com\/raw.php?i=nWGc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393491356422656000",
  "text" : "http:\/\/t.co\/75tjPGcPPv Emails: 20 Hashes: 1 E\/H: 20.0 Keywords: 0.22 #infoleak",
  "id" : 393491356422656000,
  "created_at" : "2013-10-24 21:37:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9Yt2drsEXX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x6ncZP2Q",
      "display_url" : "pastebin.com\/raw.php?i=x6nc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393463635546099712",
  "text" : "http:\/\/t.co\/9Yt2drsEXX Emails: 62 Keywords: 0.0 #infoleak",
  "id" : 393463635546099712,
  "created_at" : "2013-10-24 19:46:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EM4iU9YGTd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UpP0kdKf",
      "display_url" : "pastebin.com\/raw.php?i=UpP0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393460288067874817",
  "text" : "http:\/\/t.co\/EM4iU9YGTd Possible cisco configuration #infoleak",
  "id" : 393460288067874817,
  "created_at" : "2013-10-24 19:33:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wzk372o3U6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JHLwdLes",
      "display_url" : "pastebin.com\/raw.php?i=JHLw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393452229467725824",
  "text" : "http:\/\/t.co\/Wzk372o3U6 Found possible Google API key(s) #infoleak",
  "id" : 393452229467725824,
  "created_at" : "2013-10-24 19:01:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FdeVfqmJ1K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wwSDYix9",
      "display_url" : "pastebin.com\/raw.php?i=wwSD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393449066853445632",
  "text" : "http:\/\/t.co\/FdeVfqmJ1K Emails: 29 Keywords: -0.14 #infoleak",
  "id" : 393449066853445632,
  "created_at" : "2013-10-24 18:49:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Clzv7DdzCf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xethbmRa",
      "display_url" : "pastebin.com\/raw.php?i=xeth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393350259532775424",
  "text" : "http:\/\/t.co\/Clzv7DdzCf Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 393350259532775424,
  "created_at" : "2013-10-24 12:16:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jMxV8II12j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aRHMRp34",
      "display_url" : "pastebin.com\/raw.php?i=aRHM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393345444798947329",
  "text" : "http:\/\/t.co\/jMxV8II12j Emails: 293 Keywords: 0.11 #infoleak",
  "id" : 393345444798947329,
  "created_at" : "2013-10-24 11:57:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YvfKdT9mnF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LezbfXJD",
      "display_url" : "pastebin.com\/raw.php?i=Lezb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393306904937504769",
  "text" : "http:\/\/t.co\/YvfKdT9mnF Possible cisco configuration #infoleak",
  "id" : 393306904937504769,
  "created_at" : "2013-10-24 09:24:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V392NOBsGx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ax3gPnfW",
      "display_url" : "pastebin.com\/raw.php?i=Ax3g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393306089418006529",
  "text" : "http:\/\/t.co\/V392NOBsGx Possible cisco configuration #infoleak",
  "id" : 393306089418006529,
  "created_at" : "2013-10-24 09:20:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BGydHmUStE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iEeSS9sj",
      "display_url" : "pastebin.com\/raw.php?i=iEeS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393305060739801089",
  "text" : "http:\/\/t.co\/BGydHmUStE Possible cisco configuration #infoleak",
  "id" : 393305060739801089,
  "created_at" : "2013-10-24 09:16:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LemEDZcz3c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jXBPunTq",
      "display_url" : "pastebin.com\/raw.php?i=jXBP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393294210905800705",
  "text" : "http:\/\/t.co\/LemEDZcz3c Found possible Google API key(s) #infoleak",
  "id" : 393294210905800705,
  "created_at" : "2013-10-24 08:33:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pnuR5uKASD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VPBhUcZ6",
      "display_url" : "pastebin.com\/raw.php?i=VPBh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393291227644166144",
  "text" : "http:\/\/t.co\/pnuR5uKASD Emails: 24 Keywords: 0.11 #infoleak",
  "id" : 393291227644166144,
  "created_at" : "2013-10-24 08:21:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EECMdHK5BY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HdgJ1Na6",
      "display_url" : "pastebin.com\/raw.php?i=HdgJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393282535058186240",
  "text" : "http:\/\/t.co\/EECMdHK5BY Keywords: 0.55 #infoleak",
  "id" : 393282535058186240,
  "created_at" : "2013-10-24 07:47:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y6FOwCHi3Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5jiPZQ4Z",
      "display_url" : "pastebin.com\/raw.php?i=5jiP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393262542253871104",
  "text" : "http:\/\/t.co\/Y6FOwCHi3Y Emails: 39 Keywords: 0.0 #infoleak",
  "id" : 393262542253871104,
  "created_at" : "2013-10-24 06:27:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lqOuWwZqo4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3eC3FmCT",
      "display_url" : "pastebin.com\/raw.php?i=3eC3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393252050961575936",
  "text" : "http:\/\/t.co\/lqOuWwZqo4 Keywords: 0.55 #infoleak",
  "id" : 393252050961575936,
  "created_at" : "2013-10-24 05:46:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yqUCaWvzio",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JY4Tpx3q",
      "display_url" : "pastebin.com\/raw.php?i=JY4T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393248480363167744",
  "text" : "http:\/\/t.co\/yqUCaWvzio Hashes: 33 Keywords: -0.03 #infoleak",
  "id" : 393248480363167744,
  "created_at" : "2013-10-24 05:31:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CxT7g9n4zf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HhXmrjDJ",
      "display_url" : "pastebin.com\/raw.php?i=HhXm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393246959844081664",
  "text" : "http:\/\/t.co\/CxT7g9n4zf Found possible Google API key(s) #infoleak",
  "id" : 393246959844081664,
  "created_at" : "2013-10-24 05:25:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2dTRSv9p9i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M9ak882P",
      "display_url" : "pastebin.com\/raw.php?i=M9ak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393246611599413248",
  "text" : "http:\/\/t.co\/2dTRSv9p9i Emails: 947 Keywords: 0.22 #infoleak",
  "id" : 393246611599413248,
  "created_at" : "2013-10-24 05:24:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eKptsLBIlA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GS8SD1p8",
      "display_url" : "pastebin.com\/raw.php?i=GS8S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393245166913323008",
  "text" : "http:\/\/t.co\/eKptsLBIlA Found possible Google API key(s) #infoleak",
  "id" : 393245166913323008,
  "created_at" : "2013-10-24 05:18:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KroDp39D1h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w5TTG8tJ",
      "display_url" : "pastebin.com\/raw.php?i=w5TT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393233193802805249",
  "text" : "http:\/\/t.co\/KroDp39D1h Emails: 1318 Keywords: 0.22 #infoleak",
  "id" : 393233193802805249,
  "created_at" : "2013-10-24 04:31:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7sU098x7a4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dvp9JCmj",
      "display_url" : "pastebin.com\/raw.php?i=Dvp9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393228106481139712",
  "text" : "http:\/\/t.co\/7sU098x7a4 Emails: 16510 Hashes: 4 E\/H: 4127.5 Keywords: 0.3 #infoleak",
  "id" : 393228106481139712,
  "created_at" : "2013-10-24 04:11:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YsRlXPMBdx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AaiFybmi",
      "display_url" : "pastebin.com\/raw.php?i=AaiF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393202384039460864",
  "text" : "http:\/\/t.co\/YsRlXPMBdx Emails: 702 Keywords: 0.0 #infoleak",
  "id" : 393202384039460864,
  "created_at" : "2013-10-24 02:28:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zVxl13m31U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qLdEDg56",
      "display_url" : "pastebin.com\/raw.php?i=qLdE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393201770114985984",
  "text" : "http:\/\/t.co\/zVxl13m31U Emails: 74 Keywords: 0.22 #infoleak",
  "id" : 393201770114985984,
  "created_at" : "2013-10-24 02:26:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OrbCo6M4xB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BrZ8b2rr",
      "display_url" : "pastebin.com\/raw.php?i=BrZ8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393199513587810305",
  "text" : "http:\/\/t.co\/OrbCo6M4xB Emails: 702 Keywords: 0.0 #infoleak",
  "id" : 393199513587810305,
  "created_at" : "2013-10-24 02:17:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/seLuwMpl0T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PsYNaU7L",
      "display_url" : "pastebin.com\/raw.php?i=PsYN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393197474220756992",
  "text" : "http:\/\/t.co\/seLuwMpl0T Emails: 667 Keywords: 0.19 #infoleak",
  "id" : 393197474220756992,
  "created_at" : "2013-10-24 02:09:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qOGZeHGR9j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PFP6DD5K",
      "display_url" : "pastebin.com\/raw.php?i=PFP6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393115100225097728",
  "text" : "http:\/\/t.co\/qOGZeHGR9j Hashes: 137 Keywords: 0.33 #infoleak",
  "id" : 393115100225097728,
  "created_at" : "2013-10-23 20:41:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S9k6i6xO0R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yVeGpfaE",
      "display_url" : "pastebin.com\/raw.php?i=yVeG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393107708636704768",
  "text" : "http:\/\/t.co\/S9k6i6xO0R Emails: 79 Hashes: 79 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 393107708636704768,
  "created_at" : "2013-10-23 20:12:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ejkvYNkO5a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FZxeq92p",
      "display_url" : "pastebin.com\/raw.php?i=FZxe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393106550744555520",
  "text" : "http:\/\/t.co\/ejkvYNkO5a Emails: 491 Keywords: 0.08 #infoleak",
  "id" : 393106550744555520,
  "created_at" : "2013-10-23 20:07:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IEByIRTGph",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2BrMrtVH",
      "display_url" : "pastebin.com\/raw.php?i=2BrM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393103578170015744",
  "text" : "http:\/\/t.co\/IEByIRTGph Hashes: 106 Keywords: 0.22 #infoleak",
  "id" : 393103578170015744,
  "created_at" : "2013-10-23 19:56:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dsawMvIW52",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WQTimhSz",
      "display_url" : "pastebin.com\/raw.php?i=WQTi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393101971860627456",
  "text" : "http:\/\/t.co\/dsawMvIW52 Hashes: 124 Keywords: 0.22 #infoleak",
  "id" : 393101971860627456,
  "created_at" : "2013-10-23 19:49:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/33F385ckcU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gp72eEcv",
      "display_url" : "pastebin.com\/raw.php?i=Gp72\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393101565671636992",
  "text" : "http:\/\/t.co\/33F385ckcU Emails: 79 Hashes: 79 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 393101565671636992,
  "created_at" : "2013-10-23 19:48:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XrQgPYdJ2t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TccTHQPS",
      "display_url" : "pastebin.com\/raw.php?i=TccT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393095344373776384",
  "text" : "http:\/\/t.co\/XrQgPYdJ2t Hashes: 104 Keywords: 0.08 #infoleak",
  "id" : 393095344373776384,
  "created_at" : "2013-10-23 19:23:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CsgXNB0aSs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zV1aYtju",
      "display_url" : "pastebin.com\/raw.php?i=zV1a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393077806915006464",
  "text" : "http:\/\/t.co\/CsgXNB0aSs Emails: 150 Keywords: 0.0 #infoleak",
  "id" : 393077806915006464,
  "created_at" : "2013-10-23 18:13:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GGKxbK9geI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FGm0fFq6",
      "display_url" : "pastebin.com\/raw.php?i=FGm0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393066283601633280",
  "text" : "http:\/\/t.co\/GGKxbK9geI Emails: 240 Keywords: 0.11 #infoleak",
  "id" : 393066283601633280,
  "created_at" : "2013-10-23 17:27:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/42jz0hqn6P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sywaTQ5n",
      "display_url" : "pastebin.com\/raw.php?i=sywa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393066114172727296",
  "text" : "http:\/\/t.co\/42jz0hqn6P Emails: 33 Hashes: 26 E\/H: 1.27 Keywords: 0.02 #infoleak",
  "id" : 393066114172727296,
  "created_at" : "2013-10-23 17:27:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8XWDCEJUvO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CB7JXC9g",
      "display_url" : "pastebin.com\/raw.php?i=CB7J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393065827760480256",
  "text" : "http:\/\/t.co\/8XWDCEJUvO Emails: 74 Keywords: 0.22 #infoleak",
  "id" : 393065827760480256,
  "created_at" : "2013-10-23 17:26:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UsuGs4jysp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jSyAz6QJ",
      "display_url" : "pastebin.com\/raw.php?i=jSyA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393022855505387520",
  "text" : "http:\/\/t.co\/UsuGs4jysp Emails: 232 Hashes: 5 E\/H: 46.4 Keywords: 0.33 #infoleak",
  "id" : 393022855505387520,
  "created_at" : "2013-10-23 14:35:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5KOvbiJwul",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Kugn2p8z",
      "display_url" : "pastebin.com\/raw.php?i=Kugn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392999215636312064",
  "text" : "http:\/\/t.co\/5KOvbiJwul Possible cisco configuration #infoleak",
  "id" : 392999215636312064,
  "created_at" : "2013-10-23 13:01:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w7R8Fl59n8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EspgtXMm",
      "display_url" : "pastebin.com\/raw.php?i=Espg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392987981411151874",
  "text" : "http:\/\/t.co\/w7R8Fl59n8 Found possible Google API key(s) #infoleak",
  "id" : 392987981411151874,
  "created_at" : "2013-10-23 12:16:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/etzWTxZFF5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZVsERRUC",
      "display_url" : "pastebin.com\/raw.php?i=ZVsE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392987939023503360",
  "text" : "http:\/\/t.co\/etzWTxZFF5 Emails: 33 Hashes: 31 E\/H: 1.06 Keywords: 0.44 #infoleak",
  "id" : 392987939023503360,
  "created_at" : "2013-10-23 12:16:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rBLMh7prSu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wvFnnsUa",
      "display_url" : "pastebin.com\/raw.php?i=wvFn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392969613849280513",
  "text" : "http:\/\/t.co\/rBLMh7prSu Found possible Google API key(s) #infoleak",
  "id" : 392969613849280513,
  "created_at" : "2013-10-23 11:03:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mJe3oHdcpx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=53y62rLC",
      "display_url" : "pastebin.com\/raw.php?i=53y6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392964752420253696",
  "text" : "http:\/\/t.co\/mJe3oHdcpx Hashes: 295 Keywords: 0.0 #infoleak",
  "id" : 392964752420253696,
  "created_at" : "2013-10-23 10:44:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kn14Vx09Va",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UfygcB72",
      "display_url" : "pastebin.com\/raw.php?i=Ufyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392924775162458113",
  "text" : "http:\/\/t.co\/kn14Vx09Va Emails: 38 Keywords: 0.11 #infoleak",
  "id" : 392924775162458113,
  "created_at" : "2013-10-23 08:05:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1akwy129ek",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NSqpC2J3",
      "display_url" : "pastebin.com\/raw.php?i=NSqp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392924410975248384",
  "text" : "http:\/\/t.co\/1akwy129ek Emails: 38 Keywords: 0.11 #infoleak",
  "id" : 392924410975248384,
  "created_at" : "2013-10-23 08:04:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lThZBTYHlV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2B4hYAcd",
      "display_url" : "pastebin.com\/raw.php?i=2B4h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392922890607140865",
  "text" : "http:\/\/t.co\/lThZBTYHlV Possible cisco configuration #infoleak",
  "id" : 392922890607140865,
  "created_at" : "2013-10-23 07:58:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/00Gqhtbueh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LbHmk1tj",
      "display_url" : "pastebin.com\/raw.php?i=LbHm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392918205296939008",
  "text" : "http:\/\/t.co\/00Gqhtbueh Found possible Google API key(s) #infoleak",
  "id" : 392918205296939008,
  "created_at" : "2013-10-23 07:39:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JM6ZJexrEu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KRNQy5L4",
      "display_url" : "pastebin.com\/raw.php?i=KRNQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392913611586158592",
  "text" : "http:\/\/t.co\/JM6ZJexrEu Emails: 38 Keywords: 0.11 #infoleak",
  "id" : 392913611586158592,
  "created_at" : "2013-10-23 07:21:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U28j9GjlXQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5YLsSejd",
      "display_url" : "pastebin.com\/raw.php?i=5YLs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392898667025149953",
  "text" : "http:\/\/t.co\/U28j9GjlXQ Hashes: 304 Keywords: 0.11 #infoleak",
  "id" : 392898667025149953,
  "created_at" : "2013-10-23 06:21:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6aDgBHpnWG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h8ZZUBwU",
      "display_url" : "pastebin.com\/raw.php?i=h8ZZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392897759457452032",
  "text" : "http:\/\/t.co\/6aDgBHpnWG Emails: 38 Keywords: 0.11 #infoleak",
  "id" : 392897759457452032,
  "created_at" : "2013-10-23 06:18:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rIipwgd6CY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AWRPy10T",
      "display_url" : "pastebin.com\/raw.php?i=AWRP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392897370121195520",
  "text" : "http:\/\/t.co\/rIipwgd6CY Found possible Google API key(s) #infoleak",
  "id" : 392897370121195520,
  "created_at" : "2013-10-23 06:16:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OXpPJUO0kX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YFuLsz5U",
      "display_url" : "pastebin.com\/raw.php?i=YFuL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392897149077164032",
  "text" : "http:\/\/t.co\/OXpPJUO0kX Emails: 38 Keywords: 0.11 #infoleak",
  "id" : 392897149077164032,
  "created_at" : "2013-10-23 06:15:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qdeWnXk2gv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5nRSgRLq",
      "display_url" : "pastebin.com\/raw.php?i=5nRS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392890173031067648",
  "text" : "http:\/\/t.co\/qdeWnXk2gv Found possible Google API key(s) #infoleak",
  "id" : 392890173031067648,
  "created_at" : "2013-10-23 05:48:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sqXW1RTVRP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NF2M5SVu",
      "display_url" : "pastebin.com\/raw.php?i=NF2M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392776917159378944",
  "text" : "http:\/\/t.co\/sqXW1RTVRP Hashes: 77 Keywords: -0.03 #infoleak",
  "id" : 392776917159378944,
  "created_at" : "2013-10-22 22:18:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DfZY04DNTB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jniC87r8",
      "display_url" : "pastebin.com\/raw.php?i=jniC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392775848471715840",
  "text" : "http:\/\/t.co\/DfZY04DNTB Hashes: 45 Keywords: 0.08 #infoleak",
  "id" : 392775848471715840,
  "created_at" : "2013-10-22 22:13:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1SewNg84MH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zfC2VTKj",
      "display_url" : "pastebin.com\/raw.php?i=zfC2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392699122219630592",
  "text" : "http:\/\/t.co\/1SewNg84MH Emails: 33 Keywords: 0.0 #infoleak",
  "id" : 392699122219630592,
  "created_at" : "2013-10-22 17:09:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JJR6TuVy8U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KapqLFHE",
      "display_url" : "pastebin.com\/raw.php?i=Kapq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392687621412888576",
  "text" : "http:\/\/t.co\/JJR6TuVy8U Emails: 17183 Keywords: -0.03 #infoleak",
  "id" : 392687621412888576,
  "created_at" : "2013-10-22 16:23:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z5WKZVmapu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T23rsnHK",
      "display_url" : "pastebin.com\/raw.php?i=T23r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392681662930112512",
  "text" : "http:\/\/t.co\/z5WKZVmapu Found possible Google API key(s) #infoleak",
  "id" : 392681662930112512,
  "created_at" : "2013-10-22 15:59:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gXVCdeJsmN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qJ0WaWCw",
      "display_url" : "pastebin.com\/raw.php?i=qJ0W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392678807284367360",
  "text" : "http:\/\/t.co\/gXVCdeJsmN Emails: 593 Keywords: 0.0 #infoleak",
  "id" : 392678807284367360,
  "created_at" : "2013-10-22 15:48:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/spBZov88Wi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EirkTH4W",
      "display_url" : "pastebin.com\/raw.php?i=Eirk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392664615240232960",
  "text" : "http:\/\/t.co\/spBZov88Wi Possible cisco configuration #infoleak",
  "id" : 392664615240232960,
  "created_at" : "2013-10-22 14:51:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oDFYtjn42e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RNcz6qFz",
      "display_url" : "pastebin.com\/raw.php?i=RNcz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392663918239166464",
  "text" : "http:\/\/t.co\/oDFYtjn42e Emails: 2 Hashes: 436 E\/H: 0.0 Keywords: -0.06 #infoleak",
  "id" : 392663918239166464,
  "created_at" : "2013-10-22 14:49:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EZNM6xmJRP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Pcusuzs0",
      "display_url" : "pastebin.com\/raw.php?i=Pcus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392663594677964801",
  "text" : "http:\/\/t.co\/EZNM6xmJRP Found possible Google API key(s) #infoleak",
  "id" : 392663594677964801,
  "created_at" : "2013-10-22 14:47:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0RVjNgnSwF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qu9PxqW2",
      "display_url" : "pastebin.com\/raw.php?i=Qu9P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392663114337906688",
  "text" : "http:\/\/t.co\/0RVjNgnSwF Emails: 141 Hashes: 1 E\/H: 141.0 Keywords: 0.11 #infoleak",
  "id" : 392663114337906688,
  "created_at" : "2013-10-22 14:45:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZJ7xkz9bMz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cWwEhgp4",
      "display_url" : "pastebin.com\/raw.php?i=cWwE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392655393974779905",
  "text" : "http:\/\/t.co\/ZJ7xkz9bMz Keywords: 0.55 #infoleak",
  "id" : 392655393974779905,
  "created_at" : "2013-10-22 14:15:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zo1S3Ga5Ra",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JbgYPhRK",
      "display_url" : "pastebin.com\/raw.php?i=JbgY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392647485933383680",
  "text" : "http:\/\/t.co\/zo1S3Ga5Ra Emails: 32 Keywords: -0.03 #infoleak",
  "id" : 392647485933383680,
  "created_at" : "2013-10-22 13:43:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o1KvFQwula",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=77ztazCw",
      "display_url" : "pastebin.com\/raw.php?i=77zt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392391702083665920",
  "text" : "http:\/\/t.co\/o1KvFQwula Hashes: 48 Keywords: 0.19 #infoleak",
  "id" : 392391702083665920,
  "created_at" : "2013-10-21 20:47:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZwXwZg1VcC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E3uGL4Be",
      "display_url" : "pastebin.com\/raw.php?i=E3uG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392385345100066816",
  "text" : "http:\/\/t.co\/ZwXwZg1VcC Emails: 3 Hashes: 71 E\/H: 0.04 Keywords: 0.22 #infoleak",
  "id" : 392385345100066816,
  "created_at" : "2013-10-21 20:22:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KaKbrfy0Jr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KGsnsdVr",
      "display_url" : "pastebin.com\/raw.php?i=KGsn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392381987874283520",
  "text" : "http:\/\/t.co\/KaKbrfy0Jr Emails: 57 Keywords: 0.0 #infoleak",
  "id" : 392381987874283520,
  "created_at" : "2013-10-21 20:08:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FlSSB8Knha",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1K81hUac",
      "display_url" : "pastebin.com\/raw.php?i=1K81\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392380482442108928",
  "text" : "http:\/\/t.co\/FlSSB8Knha Emails: 101 Keywords: 0.22 #infoleak",
  "id" : 392380482442108928,
  "created_at" : "2013-10-21 20:02:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e6pdVle6y2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dr1vASLY",
      "display_url" : "pastebin.com\/raw.php?i=dr1v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392370269441888256",
  "text" : "http:\/\/t.co\/e6pdVle6y2 Emails: 4096 Keywords: 0.0 #infoleak",
  "id" : 392370269441888256,
  "created_at" : "2013-10-21 19:22:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UcfbNI4h3L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y7Tky9y1",
      "display_url" : "pastebin.com\/raw.php?i=y7Tk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392354079961145344",
  "text" : "http:\/\/t.co\/UcfbNI4h3L Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 392354079961145344,
  "created_at" : "2013-10-21 18:17:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BQVoPAsMJy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vcJVfqbX",
      "display_url" : "pastebin.com\/raw.php?i=vcJV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392341458851594240",
  "text" : "http:\/\/t.co\/BQVoPAsMJy Emails: 98 Keywords: 0.0 #infoleak",
  "id" : 392341458851594240,
  "created_at" : "2013-10-21 17:27:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rZxaaG03iL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UyhfzAjN",
      "display_url" : "pastebin.com\/raw.php?i=Uyhf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392339747751727105",
  "text" : "http:\/\/t.co\/rZxaaG03iL Emails: 196 Keywords: 0.11 #infoleak",
  "id" : 392339747751727105,
  "created_at" : "2013-10-21 17:20:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sIVtEgusEF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ScMKJ0Aw",
      "display_url" : "pastebin.com\/raw.php?i=ScMK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392336629190258688",
  "text" : "http:\/\/t.co\/sIVtEgusEF Emails: 98 Keywords: 0.11 #infoleak",
  "id" : 392336629190258688,
  "created_at" : "2013-10-21 17:08:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KkyKUU7i7j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wPLY4sQK",
      "display_url" : "pastebin.com\/raw.php?i=wPLY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392336112594612224",
  "text" : "http:\/\/t.co\/KkyKUU7i7j Emails: 187 Keywords: 0.0 #infoleak",
  "id" : 392336112594612224,
  "created_at" : "2013-10-21 17:06:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g0zhfTFPei",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B0Pk6GzD",
      "display_url" : "pastebin.com\/raw.php?i=B0Pk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392335495750885376",
  "text" : "http:\/\/t.co\/g0zhfTFPei Hashes: 168 Keywords: 0.55 #infoleak",
  "id" : 392335495750885376,
  "created_at" : "2013-10-21 17:04:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sEi225UGW5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nJ1cAiGE",
      "display_url" : "pastebin.com\/raw.php?i=nJ1c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392332275657883648",
  "text" : "http:\/\/t.co\/sEi225UGW5 Found possible Google API key(s) #infoleak",
  "id" : 392332275657883648,
  "created_at" : "2013-10-21 16:51:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gxhwUxcl5k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tJRdVMxs",
      "display_url" : "pastebin.com\/raw.php?i=tJRd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392331767203389440",
  "text" : "http:\/\/t.co\/gxhwUxcl5k Emails: 2783 Keywords: -0.03 #infoleak",
  "id" : 392331767203389440,
  "created_at" : "2013-10-21 16:49:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tcwZGKw9sz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SZNaEKcq",
      "display_url" : "pastebin.com\/raw.php?i=SZNa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392105575095361536",
  "text" : "http:\/\/t.co\/tcwZGKw9sz Emails: 57 Keywords: 0.11 #infoleak",
  "id" : 392105575095361536,
  "created_at" : "2013-10-21 01:50:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jzGaxkqgIS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ScnAJvAk",
      "display_url" : "pastebin.com\/raw.php?i=ScnA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392094675756015616",
  "text" : "http:\/\/t.co\/jzGaxkqgIS Emails: 98 Keywords: 0.0 #infoleak",
  "id" : 392094675756015616,
  "created_at" : "2013-10-21 01:07:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/syVakOkceE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YUwa4aYm",
      "display_url" : "pastebin.com\/raw.php?i=YUwa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392083182981349376",
  "text" : "http:\/\/t.co\/syVakOkceE Hashes: 35 Keywords: 0.0 #infoleak",
  "id" : 392083182981349376,
  "created_at" : "2013-10-21 00:21:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3pMfpQdIjz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xcUntJay",
      "display_url" : "pastebin.com\/raw.php?i=xcUn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392083001720307712",
  "text" : "http:\/\/t.co\/3pMfpQdIjz Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 392083001720307712,
  "created_at" : "2013-10-21 00:20:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ph9uMRaL3F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MkuiqzPr",
      "display_url" : "pastebin.com\/raw.php?i=Mkui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391958962716672000",
  "text" : "http:\/\/t.co\/Ph9uMRaL3F Emails: 357 Keywords: -0.03 #infoleak",
  "id" : 391958962716672000,
  "created_at" : "2013-10-20 16:07:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t3CX07TsVN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LmFHdhU8",
      "display_url" : "pastebin.com\/raw.php?i=LmFH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391952445389025280",
  "text" : "http:\/\/t.co\/t3CX07TsVN Emails: 1119 Keywords: 0.0 #infoleak",
  "id" : 391952445389025280,
  "created_at" : "2013-10-20 15:41:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B8THPVQ70F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XpEUjJ4P",
      "display_url" : "pastebin.com\/raw.php?i=XpEU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391943738089431040",
  "text" : "http:\/\/t.co\/B8THPVQ70F Found possible Google API key(s) #infoleak",
  "id" : 391943738089431040,
  "created_at" : "2013-10-20 15:07:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1MVfqLy6uS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xUdiejZ3",
      "display_url" : "pastebin.com\/raw.php?i=xUdi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391936569155657729",
  "text" : "http:\/\/t.co\/1MVfqLy6uS Possible cisco configuration #infoleak",
  "id" : 391936569155657729,
  "created_at" : "2013-10-20 14:38:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ICrVmnswI9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A6CCqUDn",
      "display_url" : "pastebin.com\/raw.php?i=A6CC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391904963376320512",
  "text" : "http:\/\/t.co\/ICrVmnswI9 Emails: 5220 Keywords: 0.11 #infoleak",
  "id" : 391904963376320512,
  "created_at" : "2013-10-20 12:33:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wFwrbGCBA3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=httA1nfM",
      "display_url" : "pastebin.com\/raw.php?i=httA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391891782205599744",
  "text" : "http:\/\/t.co\/wFwrbGCBA3 Found possible Google API key(s) #infoleak",
  "id" : 391891782205599744,
  "created_at" : "2013-10-20 11:40:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EgG87B8iKM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WWayEFKp",
      "display_url" : "pastebin.com\/raw.php?i=WWay\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391891240418934784",
  "text" : "http:\/\/t.co\/EgG87B8iKM Hashes: 3 Keywords: 0.66 #infoleak",
  "id" : 391891240418934784,
  "created_at" : "2013-10-20 11:38:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BzS2NDDg2k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cTRBRzfW",
      "display_url" : "pastebin.com\/raw.php?i=cTRB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391882517285855232",
  "text" : "http:\/\/t.co\/BzS2NDDg2k Emails: 77 Hashes: 1 E\/H: 77.0 Keywords: 0.41 #infoleak",
  "id" : 391882517285855232,
  "created_at" : "2013-10-20 11:04:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YBS0RiucTN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vCARgVup",
      "display_url" : "pastebin.com\/raw.php?i=vCAR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391875796291162112",
  "text" : "http:\/\/t.co\/YBS0RiucTN Emails: 1083 Keywords: 0.52 #infoleak",
  "id" : 391875796291162112,
  "created_at" : "2013-10-20 10:37:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mozmlex5ZN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZR1JLKUL",
      "display_url" : "pastebin.com\/raw.php?i=ZR1J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391872592052637696",
  "text" : "http:\/\/t.co\/Mozmlex5ZN Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 391872592052637696,
  "created_at" : "2013-10-20 10:24:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KfkJbHBm4Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ChZeqRCQ",
      "display_url" : "pastebin.com\/raw.php?i=ChZe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391868109478301697",
  "text" : "http:\/\/t.co\/KfkJbHBm4Z Emails: 53 Keywords: 0.0 #infoleak",
  "id" : 391868109478301697,
  "created_at" : "2013-10-20 10:06:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/thZI8JvbN8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jx198Z5w",
      "display_url" : "pastebin.com\/raw.php?i=Jx19\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391855741612457984",
  "text" : "http:\/\/t.co\/thZI8JvbN8 Emails: 590 Hashes: 590 E\/H: 1.0 Keywords: -0.03 #infoleak",
  "id" : 391855741612457984,
  "created_at" : "2013-10-20 09:17:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0CBGLAc9Hv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2cpsqtMa",
      "display_url" : "pastebin.com\/raw.php?i=2cps\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391850957224435713",
  "text" : "http:\/\/t.co\/0CBGLAc9Hv Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 391850957224435713,
  "created_at" : "2013-10-20 08:58:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LweCHL6NeN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JpXfCbvP",
      "display_url" : "pastebin.com\/raw.php?i=JpXf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391846850451353600",
  "text" : "http:\/\/t.co\/LweCHL6NeN Emails: 99 Hashes: 192 E\/H: 0.52 Keywords: 0.11 #infoleak",
  "id" : 391846850451353600,
  "created_at" : "2013-10-20 08:42:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hzA170fNjQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GsdBYSJt",
      "display_url" : "pastebin.com\/raw.php?i=GsdB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391843839738011648",
  "text" : "http:\/\/t.co\/hzA170fNjQ Emails: 28 Hashes: 27 E\/H: 1.04 Keywords: 0.0 #infoleak",
  "id" : 391843839738011648,
  "created_at" : "2013-10-20 08:30:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/huh6NRwjBg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jPqfAunk",
      "display_url" : "pastebin.com\/raw.php?i=jPqf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391841919476576256",
  "text" : "http:\/\/t.co\/huh6NRwjBg Emails: 98 Hashes: 99 E\/H: 0.99 Keywords: 0.11 #infoleak",
  "id" : 391841919476576256,
  "created_at" : "2013-10-20 08:22:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7n9vVTHwUq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0SRdCeQZ",
      "display_url" : "pastebin.com\/raw.php?i=0SRd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391841800983302144",
  "text" : "http:\/\/t.co\/7n9vVTHwUq Found possible Google API key(s) #infoleak",
  "id" : 391841800983302144,
  "created_at" : "2013-10-20 08:22:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q8pX1qJyJE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uAHw1rTw",
      "display_url" : "pastebin.com\/raw.php?i=uAHw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391840277486252032",
  "text" : "http:\/\/t.co\/q8pX1qJyJE Emails: 184 Hashes: 183 E\/H: 1.01 Keywords: 0.11 #infoleak",
  "id" : 391840277486252032,
  "created_at" : "2013-10-20 08:16:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qNgBxN2RvD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hEZ0eFeb",
      "display_url" : "pastebin.com\/raw.php?i=hEZ0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391836399566995456",
  "text" : "http:\/\/t.co\/qNgBxN2RvD Emails: 41 Hashes: 44 E\/H: 0.93 Keywords: 0.0 #infoleak",
  "id" : 391836399566995456,
  "created_at" : "2013-10-20 08:00:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PibGlB033A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xh9NfG7W",
      "display_url" : "pastebin.com\/raw.php?i=Xh9N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391835822770515968",
  "text" : "http:\/\/t.co\/PibGlB033A Emails: 32 Hashes: 34 E\/H: 0.94 Keywords: 0.11 #infoleak",
  "id" : 391835822770515968,
  "created_at" : "2013-10-20 07:58:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J38TaQWGLF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0WSTPfps",
      "display_url" : "pastebin.com\/raw.php?i=0WST\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391826161157689344",
  "text" : "http:\/\/t.co\/J38TaQWGLF Emails: 21 Hashes: 20 E\/H: 1.05 Keywords: 0.0 #infoleak",
  "id" : 391826161157689344,
  "created_at" : "2013-10-20 07:20:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OjAHKueFqs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4FcsmKmG",
      "display_url" : "pastebin.com\/raw.php?i=4Fcs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391825654930370561",
  "text" : "http:\/\/t.co\/OjAHKueFqs Hashes: 2 Keywords: 0.55 #infoleak",
  "id" : 391825654930370561,
  "created_at" : "2013-10-20 07:18:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/83d3YTST2C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r3D26PwU",
      "display_url" : "pastebin.com\/raw.php?i=r3D2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391820582649462784",
  "text" : "http:\/\/t.co\/83d3YTST2C Found possible Google API key(s) #infoleak",
  "id" : 391820582649462784,
  "created_at" : "2013-10-20 06:58:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fr46ZEbfn0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EsMw7uXt",
      "display_url" : "pastebin.com\/raw.php?i=EsMw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391819473780346881",
  "text" : "http:\/\/t.co\/fr46ZEbfn0 Emails: 117 Hashes: 117 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 391819473780346881,
  "created_at" : "2013-10-20 06:53:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GLPSxk4VrQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jwguVgiU",
      "display_url" : "pastebin.com\/raw.php?i=jwgu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391817930536521728",
  "text" : "http:\/\/t.co\/GLPSxk4VrQ Hashes: 42 Keywords: 0.22 #infoleak",
  "id" : 391817930536521728,
  "created_at" : "2013-10-20 06:47:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3whGTcxW4h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B9RdC9Vd",
      "display_url" : "pastebin.com\/raw.php?i=B9Rd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391805869219786752",
  "text" : "http:\/\/t.co\/3whGTcxW4h Found possible Google API key(s) #infoleak",
  "id" : 391805869219786752,
  "created_at" : "2013-10-20 05:59:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZWVRncVAdw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iaZcxPWn",
      "display_url" : "pastebin.com\/raw.php?i=iaZc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391779835518787584",
  "text" : "http:\/\/t.co\/ZWVRncVAdw Emails: 41 Hashes: 142 E\/H: 0.29 Keywords: 0.08 #infoleak",
  "id" : 391779835518787584,
  "created_at" : "2013-10-20 04:16:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EaVnZwZ7co",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T76D1egY",
      "display_url" : "pastebin.com\/raw.php?i=T76D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391761394569207808",
  "text" : "http:\/\/t.co\/EaVnZwZ7co Hashes: 2543 Keywords: 0.11 #infoleak",
  "id" : 391761394569207808,
  "created_at" : "2013-10-20 03:02:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MtGSlYRD6L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z9bxA9NU",
      "display_url" : "pastebin.com\/raw.php?i=z9bx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391760814568263680",
  "text" : "http:\/\/t.co\/MtGSlYRD6L Hashes: 790 Keywords: 0.22 #infoleak",
  "id" : 391760814568263680,
  "created_at" : "2013-10-20 03:00:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QmIYEObnJp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tkGk489e",
      "display_url" : "pastebin.com\/raw.php?i=tkGk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391755865889316865",
  "text" : "http:\/\/t.co\/QmIYEObnJp Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 391755865889316865,
  "created_at" : "2013-10-20 02:40:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kdBCA82mLk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6aUuyTvw",
      "display_url" : "pastebin.com\/raw.php?i=6aUu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391754818529685504",
  "text" : "http:\/\/t.co\/kdBCA82mLk Keywords: 0.55 #infoleak",
  "id" : 391754818529685504,
  "created_at" : "2013-10-20 02:36:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xaYIQuf5cg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R4naRNWD",
      "display_url" : "pastebin.com\/raw.php?i=R4na\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391747662061387776",
  "text" : "http:\/\/t.co\/xaYIQuf5cg Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 391747662061387776,
  "created_at" : "2013-10-20 02:08:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LmbPk5VOS6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CAtwzVce",
      "display_url" : "pastebin.com\/raw.php?i=CAtw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391747653853134848",
  "text" : "http:\/\/t.co\/LmbPk5VOS6 Keywords: 0.55 #infoleak",
  "id" : 391747653853134848,
  "created_at" : "2013-10-20 02:08:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KzbCvIg8Rb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PJGEuqQi",
      "display_url" : "pastebin.com\/raw.php?i=PJGE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391747449489858560",
  "text" : "http:\/\/t.co\/KzbCvIg8Rb Found possible Google API key(s) #infoleak",
  "id" : 391747449489858560,
  "created_at" : "2013-10-20 02:07:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UBrlsWfcnD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dqp13aE4",
      "display_url" : "pastebin.com\/raw.php?i=dqp1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391745151099367424",
  "text" : "http:\/\/t.co\/UBrlsWfcnD Keywords: 0.55 #infoleak",
  "id" : 391745151099367424,
  "created_at" : "2013-10-20 01:58:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5b0VKQTBtA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RpMJGbGE",
      "display_url" : "pastebin.com\/raw.php?i=RpMJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391741165646512128",
  "text" : "http:\/\/t.co\/5b0VKQTBtA Found possible Google API key(s) #infoleak",
  "id" : 391741165646512128,
  "created_at" : "2013-10-20 01:42:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r0hri2Yzmq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7dmmY7VZ",
      "display_url" : "pastebin.com\/raw.php?i=7dmm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391721067447730176",
  "text" : "http:\/\/t.co\/r0hri2Yzmq Emails: 65 Keywords: 0.0 #infoleak",
  "id" : 391721067447730176,
  "created_at" : "2013-10-20 00:22:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MppBY770vx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XW36A9AE",
      "display_url" : "pastebin.com\/raw.php?i=XW36\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391719819025723392",
  "text" : "http:\/\/t.co\/MppBY770vx Found possible Google API key(s) #infoleak",
  "id" : 391719819025723392,
  "created_at" : "2013-10-20 00:17:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ad8m4ispkB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yw7uWi4M",
      "display_url" : "pastebin.com\/raw.php?i=yw7u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391714176491466752",
  "text" : "http:\/\/t.co\/ad8m4ispkB Emails: 1 Hashes: 1 E\/H: 1.0 Keywords: 0.63 #infoleak",
  "id" : 391714176491466752,
  "created_at" : "2013-10-19 23:55:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n8GextlHQN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qPeeSKTr",
      "display_url" : "pastebin.com\/raw.php?i=qPee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391706281028775936",
  "text" : "http:\/\/t.co\/n8GextlHQN Hashes: 48 Keywords: 0.08 #infoleak",
  "id" : 391706281028775936,
  "created_at" : "2013-10-19 23:23:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6jlvnG2XqS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6hQCME5s",
      "display_url" : "pastebin.com\/raw.php?i=6hQC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391705108406210560",
  "text" : "http:\/\/t.co\/6jlvnG2XqS Emails: 141 Hashes: 141 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 391705108406210560,
  "created_at" : "2013-10-19 23:19:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gpoJ8yg0EY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q7Q9u8sG",
      "display_url" : "pastebin.com\/raw.php?i=Q7Q9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391696051058384896",
  "text" : "http:\/\/t.co\/gpoJ8yg0EY Found possible Google API key(s) #infoleak",
  "id" : 391696051058384896,
  "created_at" : "2013-10-19 22:43:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uDPljxMZUk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=671mft09",
      "display_url" : "pastebin.com\/raw.php?i=671m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391694056872366080",
  "text" : "http:\/\/t.co\/uDPljxMZUk Emails: 30 Keywords: -0.14 #infoleak",
  "id" : 391694056872366080,
  "created_at" : "2013-10-19 22:35:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PysVpvYNFc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uS38wPjB",
      "display_url" : "pastebin.com\/raw.php?i=uS38\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391681376757358592",
  "text" : "http:\/\/t.co\/PysVpvYNFc Hashes: 191 Keywords: 0.11 #infoleak",
  "id" : 391681376757358592,
  "created_at" : "2013-10-19 21:44:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ezJrMNObNW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rLiWYTVr",
      "display_url" : "pastebin.com\/raw.php?i=rLiW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391680698743926784",
  "text" : "http:\/\/t.co\/ezJrMNObNW Emails: 98 Keywords: 0.0 #infoleak",
  "id" : 391680698743926784,
  "created_at" : "2013-10-19 21:42:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C1W5pkC7oN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wq6mtUSq",
      "display_url" : "pastebin.com\/raw.php?i=wq6m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391679963528589312",
  "text" : "http:\/\/t.co\/C1W5pkC7oN Emails: 98 Keywords: 0.0 #infoleak",
  "id" : 391679963528589312,
  "created_at" : "2013-10-19 21:39:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sAFcdkLV8L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S8QZL4wF",
      "display_url" : "pastebin.com\/raw.php?i=S8QZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391669677757181952",
  "text" : "http:\/\/t.co\/sAFcdkLV8L Emails: 66 Hashes: 66 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 391669677757181952,
  "created_at" : "2013-10-19 20:58:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ADogtyQSM9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HwR1Xhq1",
      "display_url" : "pastebin.com\/raw.php?i=HwR1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391654475586215936",
  "text" : "http:\/\/t.co\/ADogtyQSM9 Keywords: 0.55 #infoleak",
  "id" : 391654475586215936,
  "created_at" : "2013-10-19 19:57:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NbSP6e6tGx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f9Nqtpvc",
      "display_url" : "pastebin.com\/raw.php?i=f9Nq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391527407758229506",
  "text" : "http:\/\/t.co\/NbSP6e6tGx Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 391527407758229506,
  "created_at" : "2013-10-19 11:33:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WEa3vAUycP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xNg50YbK",
      "display_url" : "pastebin.com\/raw.php?i=xNg5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391526340374953984",
  "text" : "http:\/\/t.co\/WEa3vAUycP Emails: 53 Hashes: 54 E\/H: 0.98 Keywords: 0.08 #infoleak",
  "id" : 391526340374953984,
  "created_at" : "2013-10-19 11:28:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n7kPPKo10E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pypW2igf",
      "display_url" : "pastebin.com\/raw.php?i=pypW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391525855828004865",
  "text" : "http:\/\/t.co\/n7kPPKo10E Emails: 31 Hashes: 31 E\/H: 1.0 Keywords: -0.03 #infoleak",
  "id" : 391525855828004865,
  "created_at" : "2013-10-19 11:26:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9AsnyCnQ6r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bd8f1VjY",
      "display_url" : "pastebin.com\/raw.php?i=bd8f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391507830672334848",
  "text" : "http:\/\/t.co\/9AsnyCnQ6r Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 391507830672334848,
  "created_at" : "2013-10-19 10:15:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/expvvFRvFe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZmhmneFQ",
      "display_url" : "pastebin.com\/raw.php?i=Zmhm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391501856993579008",
  "text" : "http:\/\/t.co\/expvvFRvFe Hashes: 533 Keywords: 0.08 #infoleak",
  "id" : 391501856993579008,
  "created_at" : "2013-10-19 09:51:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qW3NbqL3k9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=duxmZnBu",
      "display_url" : "pastebin.com\/raw.php?i=duxm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391499695740026881",
  "text" : "http:\/\/t.co\/qW3NbqL3k9 Hashes: 63 Keywords: 0.22 #infoleak",
  "id" : 391499695740026881,
  "created_at" : "2013-10-19 09:42:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eEgi5ZjqSI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6Kkjsymg",
      "display_url" : "pastebin.com\/raw.php?i=6Kkj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391485066372579328",
  "text" : "http:\/\/t.co\/eEgi5ZjqSI Emails: 1019 Keywords: 0.22 #infoleak",
  "id" : 391485066372579328,
  "created_at" : "2013-10-19 08:44:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P66fB8sYCV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X1wpVyUx",
      "display_url" : "pastebin.com\/raw.php?i=X1wp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391480203479764993",
  "text" : "http:\/\/t.co\/P66fB8sYCV Emails: 281 Hashes: 321 E\/H: 0.88 Keywords: 0.22 #infoleak",
  "id" : 391480203479764993,
  "created_at" : "2013-10-19 08:25:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9pOVcKHA2R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tVMhBSNg",
      "display_url" : "pastebin.com\/raw.php?i=tVMh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391477984743272448",
  "text" : "http:\/\/t.co\/9pOVcKHA2R Found possible Google API key(s) #infoleak",
  "id" : 391477984743272448,
  "created_at" : "2013-10-19 08:16:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hMQyJtktyW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tVDukXtD",
      "display_url" : "pastebin.com\/raw.php?i=tVDu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391468232873222144",
  "text" : "http:\/\/t.co\/hMQyJtktyW Found possible Google API key(s) #infoleak",
  "id" : 391468232873222144,
  "created_at" : "2013-10-19 07:37:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BoCrkGSes7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mYwPZeHS",
      "display_url" : "pastebin.com\/raw.php?i=mYwP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391463326305095680",
  "text" : "http:\/\/t.co\/BoCrkGSes7 Found possible Google API key(s) #infoleak",
  "id" : 391463326305095680,
  "created_at" : "2013-10-19 07:18:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2NJrKy3fw5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NVuDARGg",
      "display_url" : "pastebin.com\/raw.php?i=NVuD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391438099919544320",
  "text" : "http:\/\/t.co\/2NJrKy3fw5 Emails: 254 Hashes: 254 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 391438099919544320,
  "created_at" : "2013-10-19 05:38:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lOmocW6zYy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FbGKaNxg",
      "display_url" : "pastebin.com\/raw.php?i=FbGK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391435632922198018",
  "text" : "http:\/\/t.co\/lOmocW6zYy Emails: 2083 Hashes: 2085 E\/H: 1.0 Keywords: 0.3 #infoleak",
  "id" : 391435632922198018,
  "created_at" : "2013-10-19 05:28:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xV7wyJqPru",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hxxGYmN6",
      "display_url" : "pastebin.com\/raw.php?i=hxxG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391433462793519104",
  "text" : "http:\/\/t.co\/xV7wyJqPru Found possible Google API key(s) #infoleak",
  "id" : 391433462793519104,
  "created_at" : "2013-10-19 05:19:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JSV9k9EpoO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AmajMBsN",
      "display_url" : "pastebin.com\/raw.php?i=Amaj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391430091189649408",
  "text" : "http:\/\/t.co\/JSV9k9EpoO Emails: 317 Hashes: 317 E\/H: 1.0 Keywords: 0.0 #infoleak",
  "id" : 391430091189649408,
  "created_at" : "2013-10-19 05:06:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ojj6R4ZjKo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QtRv5DCJ",
      "display_url" : "pastebin.com\/raw.php?i=QtRv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391392703788769280",
  "text" : "http:\/\/t.co\/Ojj6R4ZjKo Emails: 21 Keywords: 0.11 #infoleak",
  "id" : 391392703788769280,
  "created_at" : "2013-10-19 02:37:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pazvybVvSw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MrzdKbRA",
      "display_url" : "pastebin.com\/raw.php?i=Mrzd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391374183734603777",
  "text" : "http:\/\/t.co\/pazvybVvSw Emails: 613 Keywords: 0.11 #infoleak",
  "id" : 391374183734603777,
  "created_at" : "2013-10-19 01:24:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wpE5HEEwN2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hTNciEUh",
      "display_url" : "pastebin.com\/raw.php?i=hTNc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391373437194608640",
  "text" : "http:\/\/t.co\/wpE5HEEwN2 Emails: 613 Keywords: 0.11 #infoleak",
  "id" : 391373437194608640,
  "created_at" : "2013-10-19 01:21:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/akNS0WRk1x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3XziLfem",
      "display_url" : "pastebin.com\/raw.php?i=3Xzi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391364153656356864",
  "text" : "http:\/\/t.co\/akNS0WRk1x Emails: 505 Hashes: 503 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 391364153656356864,
  "created_at" : "2013-10-19 00:44:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NeTMQhrc1y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=phgjmgcK",
      "display_url" : "pastebin.com\/raw.php?i=phgj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391337679402459136",
  "text" : "http:\/\/t.co\/NeTMQhrc1y Emails: 726 Hashes: 729 E\/H: 1.0 Keywords: 0.3 #infoleak",
  "id" : 391337679402459136,
  "created_at" : "2013-10-18 22:59:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZWfkM3hPc5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EW0n0qFS",
      "display_url" : "pastebin.com\/raw.php?i=EW0n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391334812645982208",
  "text" : "http:\/\/t.co\/ZWfkM3hPc5 Emails: 98 Keywords: 0.0 #infoleak",
  "id" : 391334812645982208,
  "created_at" : "2013-10-18 22:47:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7U6c9g6NLv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TEbsAfmB",
      "display_url" : "pastebin.com\/raw.php?i=TEbs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391327631813009408",
  "text" : "http:\/\/t.co\/7U6c9g6NLv Emails: 1 Hashes: 59 E\/H: 0.02 Keywords: 0.33 #infoleak",
  "id" : 391327631813009408,
  "created_at" : "2013-10-18 22:19:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KnEVv8uzrm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N00E0ec2",
      "display_url" : "pastebin.com\/raw.php?i=N00E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391315433237667840",
  "text" : "http:\/\/t.co\/KnEVv8uzrm Hashes: 156 Keywords: 0.11 #infoleak",
  "id" : 391315433237667840,
  "created_at" : "2013-10-18 21:30:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bz6n2vqqnp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xaYy3k3q",
      "display_url" : "pastebin.com\/raw.php?i=xaYy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391294048499032064",
  "text" : "http:\/\/t.co\/bz6n2vqqnp Hashes: 245 Keywords: 0.11 #infoleak",
  "id" : 391294048499032064,
  "created_at" : "2013-10-18 20:05:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jclpTEcbCF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JD2sM7PQ",
      "display_url" : "pastebin.com\/raw.php?i=JD2s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391293488806887424",
  "text" : "http:\/\/t.co\/jclpTEcbCF Hashes: 239 Keywords: 0.11 #infoleak",
  "id" : 391293488806887424,
  "created_at" : "2013-10-18 20:03:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mp06l5JnxH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LY6qe7M9",
      "display_url" : "pastebin.com\/raw.php?i=LY6q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391289130346225664",
  "text" : "http:\/\/t.co\/Mp06l5JnxH Emails: 332 Keywords: 0.11 #infoleak",
  "id" : 391289130346225664,
  "created_at" : "2013-10-18 19:46:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YH6V9LgJh6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v7YwFL1S",
      "display_url" : "pastebin.com\/raw.php?i=v7Yw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391279395337273344",
  "text" : "http:\/\/t.co\/YH6V9LgJh6 Hashes: 216 Keywords: -0.03 #infoleak",
  "id" : 391279395337273344,
  "created_at" : "2013-10-18 19:07:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0KetCImpSI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZnhnCFUS",
      "display_url" : "pastebin.com\/raw.php?i=Znhn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391265775261978624",
  "text" : "http:\/\/t.co\/0KetCImpSI Emails: 138 Keywords: 0.11 #infoleak",
  "id" : 391265775261978624,
  "created_at" : "2013-10-18 18:13:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0yRXyLoyxh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yPwu6uTx",
      "display_url" : "pastebin.com\/raw.php?i=yPwu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391262836053118976",
  "text" : "http:\/\/t.co\/0yRXyLoyxh Emails: 676 Keywords: 0.22 #infoleak",
  "id" : 391262836053118976,
  "created_at" : "2013-10-18 18:01:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bTj54v1lEp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kvY4YFWe",
      "display_url" : "pastebin.com\/raw.php?i=kvY4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391244587496259584",
  "text" : "http:\/\/t.co\/bTj54v1lEp Emails: 892 Keywords: 0.33 #infoleak",
  "id" : 391244587496259584,
  "created_at" : "2013-10-18 16:49:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XlGCwaM7gl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HyPEPyzX",
      "display_url" : "pastebin.com\/raw.php?i=HyPE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391241773432848384",
  "text" : "http:\/\/t.co\/XlGCwaM7gl Emails: 892 Keywords: 0.22 #infoleak",
  "id" : 391241773432848384,
  "created_at" : "2013-10-18 16:38:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OmjnWzvarW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PtUcrEV4",
      "display_url" : "pastebin.com\/raw.php?i=PtUc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391233269460525056",
  "text" : "http:\/\/t.co\/OmjnWzvarW Emails: 1 Hashes: 129 E\/H: 0.01 Keywords: 0.22 #infoleak",
  "id" : 391233269460525056,
  "created_at" : "2013-10-18 16:04:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zc0ktL4fxa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vaGXSmdQ",
      "display_url" : "pastebin.com\/raw.php?i=vaGX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391226702329675776",
  "text" : "http:\/\/t.co\/zc0ktL4fxa Emails: 261 Keywords: 0.0 #infoleak",
  "id" : 391226702329675776,
  "created_at" : "2013-10-18 15:38:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WQJGSUpX7o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H4rg91PH",
      "display_url" : "pastebin.com\/raw.php?i=H4rg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391224858480082944",
  "text" : "http:\/\/t.co\/WQJGSUpX7o Hashes: 1300 Keywords: 0.0 #infoleak",
  "id" : 391224858480082944,
  "created_at" : "2013-10-18 15:30:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T3Gz2CF9Xy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tpaiWsU9",
      "display_url" : "pastebin.com\/raw.php?i=tpai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391220918195732480",
  "text" : "http:\/\/t.co\/T3Gz2CF9Xy Emails: 56 Keywords: 0.0 #infoleak",
  "id" : 391220918195732480,
  "created_at" : "2013-10-18 15:15:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ave8B1WYB5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bnTuxgDz",
      "display_url" : "pastebin.com\/raw.php?i=bnTu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391219309139083266",
  "text" : "http:\/\/t.co\/Ave8B1WYB5 Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 391219309139083266,
  "created_at" : "2013-10-18 15:08:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PPw5xcUxsu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=veWF3NzV",
      "display_url" : "pastebin.com\/raw.php?i=veWF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391203305826684930",
  "text" : "http:\/\/t.co\/PPw5xcUxsu Hashes: 215 Keywords: 0.11 #infoleak",
  "id" : 391203305826684930,
  "created_at" : "2013-10-18 14:05:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wpr6n11a0e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fRAh5bvS",
      "display_url" : "pastebin.com\/raw.php?i=fRAh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391171614651318272",
  "text" : "http:\/\/t.co\/Wpr6n11a0e Emails: 116 Keywords: 0.0 #infoleak",
  "id" : 391171614651318272,
  "created_at" : "2013-10-18 11:59:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3f8xUIrmrC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hqmFDury",
      "display_url" : "pastebin.com\/raw.php?i=hqmF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391112206370091009",
  "text" : "http:\/\/t.co\/3f8xUIrmrC Emails: 4519 Keywords: 0.3 #infoleak",
  "id" : 391112206370091009,
  "created_at" : "2013-10-18 08:03:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9qGUcoIIIG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QBArLTCq",
      "display_url" : "pastebin.com\/raw.php?i=QBAr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391107588437204993",
  "text" : "http:\/\/t.co\/9qGUcoIIIG Possible cisco configuration #infoleak",
  "id" : 391107588437204993,
  "created_at" : "2013-10-18 07:44:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ONMTtABjl7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aW9TbTA6",
      "display_url" : "pastebin.com\/raw.php?i=aW9T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390899169499824128",
  "text" : "http:\/\/t.co\/ONMTtABjl7 Emails: 175 Keywords: 0.33 #infoleak",
  "id" : 390899169499824128,
  "created_at" : "2013-10-17 17:56:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WiBXbZk0Ah",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9kwvi2h7",
      "display_url" : "pastebin.com\/raw.php?i=9kwv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390898428852842496",
  "text" : "http:\/\/t.co\/WiBXbZk0Ah Possible cisco configuration #infoleak",
  "id" : 390898428852842496,
  "created_at" : "2013-10-17 17:53:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/38flx5nvnn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bSGezsFd",
      "display_url" : "pastebin.com\/raw.php?i=bSGe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390898340193263617",
  "text" : "http:\/\/t.co\/38flx5nvnn Emails: 6293 Keywords: 0.11 #infoleak",
  "id" : 390898340193263617,
  "created_at" : "2013-10-17 17:53:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bHhCznqxYb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BKWLMGru",
      "display_url" : "pastebin.com\/raw.php?i=BKWL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390869966792032256",
  "text" : "http:\/\/t.co\/bHhCznqxYb Emails: 949 Keywords: 0.22 #infoleak",
  "id" : 390869966792032256,
  "created_at" : "2013-10-17 16:00:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TlMotQRVqZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FK8rkChb",
      "display_url" : "pastebin.com\/raw.php?i=FK8r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390863366614695936",
  "text" : "http:\/\/t.co\/TlMotQRVqZ Possible cisco configuration #infoleak",
  "id" : 390863366614695936,
  "created_at" : "2013-10-17 15:34:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qkyx7MCtSO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TD22T5hi",
      "display_url" : "pastebin.com\/raw.php?i=TD22\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390856954261676032",
  "text" : "http:\/\/t.co\/Qkyx7MCtSO Emails: 113 Keywords: 0.0 #infoleak",
  "id" : 390856954261676032,
  "created_at" : "2013-10-17 15:08:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sEXOnTgPiF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=61VzdHCW",
      "display_url" : "pastebin.com\/raw.php?i=61Vz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390854080287215616",
  "text" : "http:\/\/t.co\/sEXOnTgPiF Emails: 3470 Keywords: 0.11 #infoleak",
  "id" : 390854080287215616,
  "created_at" : "2013-10-17 14:57:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mOQdAbFkFw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=siu8xRfn",
      "display_url" : "pastebin.com\/raw.php?i=siu8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390848887453257728",
  "text" : "http:\/\/t.co\/mOQdAbFkFw Emails: 28 Keywords: -0.14 #infoleak",
  "id" : 390848887453257728,
  "created_at" : "2013-10-17 14:36:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pczv6hIcPP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XfQqt0RE",
      "display_url" : "pastebin.com\/raw.php?i=XfQq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390848678866350081",
  "text" : "http:\/\/t.co\/pczv6hIcPP Emails: 653 Keywords: 0.08 #infoleak",
  "id" : 390848678866350081,
  "created_at" : "2013-10-17 14:36:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i201Nv8Eun",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JkFz42dD",
      "display_url" : "pastebin.com\/raw.php?i=JkFz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390791735196282880",
  "text" : "http:\/\/t.co\/i201Nv8Eun Emails: 99 Keywords: 0.0 #infoleak",
  "id" : 390791735196282880,
  "created_at" : "2013-10-17 10:49:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2XT6ZrIgTM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BXVJwALJ",
      "display_url" : "pastebin.com\/raw.php?i=BXVJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390779207275397120",
  "text" : "http:\/\/t.co\/2XT6ZrIgTM Hashes: 51 Keywords: 0.0 #infoleak",
  "id" : 390779207275397120,
  "created_at" : "2013-10-17 09:59:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XIVst8i4A7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Kv2fsetm",
      "display_url" : "pastebin.com\/raw.php?i=Kv2f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390776993689530368",
  "text" : "http:\/\/t.co\/XIVst8i4A7 Hashes: 41 Keywords: 0.11 #infoleak",
  "id" : 390776993689530368,
  "created_at" : "2013-10-17 09:51:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W65yPhM8Z6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sfdrJuYg",
      "display_url" : "pastebin.com\/raw.php?i=sfdr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390776617787994113",
  "text" : "http:\/\/t.co\/W65yPhM8Z6 Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 390776617787994113,
  "created_at" : "2013-10-17 09:49:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/swBNLX58L3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UJj5jBZ0",
      "display_url" : "pastebin.com\/raw.php?i=UJj5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390774732821655552",
  "text" : "http:\/\/t.co\/swBNLX58L3 Found possible Google API key(s) #infoleak",
  "id" : 390774732821655552,
  "created_at" : "2013-10-17 09:42:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nNlmkMuVhz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mkmnsCqF",
      "display_url" : "pastebin.com\/raw.php?i=mkmn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390774682724487168",
  "text" : "http:\/\/t.co\/nNlmkMuVhz Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 390774682724487168,
  "created_at" : "2013-10-17 09:41:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UoRRmo4SjM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2MpWn5w5",
      "display_url" : "pastebin.com\/raw.php?i=2MpW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390770869012025344",
  "text" : "http:\/\/t.co\/UoRRmo4SjM Found possible Google API key(s) #infoleak",
  "id" : 390770869012025344,
  "created_at" : "2013-10-17 09:26:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tWeDuInjBI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PWdj0eZJ",
      "display_url" : "pastebin.com\/raw.php?i=PWdj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390750916867260416",
  "text" : "http:\/\/t.co\/tWeDuInjBI Emails: 1 Hashes: 45 E\/H: 0.02 Keywords: 0.08 #infoleak",
  "id" : 390750916867260416,
  "created_at" : "2013-10-17 08:07:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Nz5zASNMf0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ratBPCde",
      "display_url" : "pastebin.com\/raw.php?i=ratB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390742292727738368",
  "text" : "http:\/\/t.co\/Nz5zASNMf0 Keywords: 0.63 #infoleak",
  "id" : 390742292727738368,
  "created_at" : "2013-10-17 07:33:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QnWJrBhVBa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t9VShL01",
      "display_url" : "pastebin.com\/raw.php?i=t9VS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390732838556811264",
  "text" : "http:\/\/t.co\/QnWJrBhVBa Hashes: 60 Keywords: 0.22 #infoleak",
  "id" : 390732838556811264,
  "created_at" : "2013-10-17 06:55:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EnN7sYHZAg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tZWjUwZU",
      "display_url" : "pastebin.com\/raw.php?i=tZWj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390731734087892992",
  "text" : "http:\/\/t.co\/EnN7sYHZAg Emails: 25 Keywords: 0.08 #infoleak",
  "id" : 390731734087892992,
  "created_at" : "2013-10-17 06:51:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/prmVvoZn0u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rqBLtCMA",
      "display_url" : "pastebin.com\/raw.php?i=rqBL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390731304792498176",
  "text" : "http:\/\/t.co\/prmVvoZn0u Emails: 25 Keywords: 0.08 #infoleak",
  "id" : 390731304792498176,
  "created_at" : "2013-10-17 06:49:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z9rnvAi8Yb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gSW4ecs0",
      "display_url" : "pastebin.com\/raw.php?i=gSW4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390645772091666432",
  "text" : "http:\/\/t.co\/Z9rnvAi8Yb Emails: 73 Keywords: -0.03 #infoleak",
  "id" : 390645772091666432,
  "created_at" : "2013-10-17 01:09:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JblQgaHjSr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ctuXpdSv",
      "display_url" : "pastebin.com\/raw.php?i=ctuX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390645090408202240",
  "text" : "http:\/\/t.co\/JblQgaHjSr Emails: 98 Keywords: 0.0 #infoleak",
  "id" : 390645090408202240,
  "created_at" : "2013-10-17 01:07:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wuX4Syp5GO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zbq2skWv",
      "display_url" : "pastebin.com\/raw.php?i=zbq2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390644892403507201",
  "text" : "http:\/\/t.co\/wuX4Syp5GO Emails: 99 Keywords: 0.0 #infoleak",
  "id" : 390644892403507201,
  "created_at" : "2013-10-17 01:06:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YqSGGnXdbE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V3nCBzdL",
      "display_url" : "pastebin.com\/raw.php?i=V3nC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390640660392312832",
  "text" : "http:\/\/t.co\/YqSGGnXdbE Emails: 31 Keywords: 0.11 #infoleak",
  "id" : 390640660392312832,
  "created_at" : "2013-10-17 00:49:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aM2hcT7yx7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mFgTJ2iM",
      "display_url" : "pastebin.com\/raw.php?i=mFgT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390640584102522880",
  "text" : "http:\/\/t.co\/aM2hcT7yx7 Emails: 30 Keywords: -0.03 #infoleak",
  "id" : 390640584102522880,
  "created_at" : "2013-10-17 00:49:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7hhoXHw2mV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A25VhmUL",
      "display_url" : "pastebin.com\/raw.php?i=A25V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390637628468391936",
  "text" : "http:\/\/t.co\/7hhoXHw2mV Hashes: 64 Keywords: 0.0 #infoleak",
  "id" : 390637628468391936,
  "created_at" : "2013-10-17 00:37:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4oQo3lZN0n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9ABKP7u2",
      "display_url" : "pastebin.com\/raw.php?i=9ABK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390629143156912128",
  "text" : "http:\/\/t.co\/4oQo3lZN0n Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 390629143156912128,
  "created_at" : "2013-10-17 00:03:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v2sQjPbqsk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mrFhKijt",
      "display_url" : "pastebin.com\/raw.php?i=mrFh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390621711907168256",
  "text" : "http:\/\/t.co\/v2sQjPbqsk Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 390621711907168256,
  "created_at" : "2013-10-16 23:34:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F3zHyTixg1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TdWCxq2q",
      "display_url" : "pastebin.com\/raw.php?i=TdWC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390621443571990528",
  "text" : "http:\/\/t.co\/F3zHyTixg1 Emails: 75 Keywords: 0.0 #infoleak",
  "id" : 390621443571990528,
  "created_at" : "2013-10-16 23:33:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n0oQ6mVCbO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xSxmPuSM",
      "display_url" : "pastebin.com\/raw.php?i=xSxm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390598376774840321",
  "text" : "http:\/\/t.co\/n0oQ6mVCbO Hashes: 33 Keywords: 0.11 #infoleak",
  "id" : 390598376774840321,
  "created_at" : "2013-10-16 22:01:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Et3rVdxoda",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qW1QDJp1",
      "display_url" : "pastebin.com\/raw.php?i=qW1Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390574223422681088",
  "text" : "http:\/\/t.co\/Et3rVdxoda Emails: 713 Keywords: -0.03 #infoleak",
  "id" : 390574223422681088,
  "created_at" : "2013-10-16 20:25:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LDrrd5UrGZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=23hbSnzZ",
      "display_url" : "pastebin.com\/raw.php?i=23hb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390568416626475008",
  "text" : "http:\/\/t.co\/LDrrd5UrGZ Hashes: 37 Keywords: 0.08 #infoleak",
  "id" : 390568416626475008,
  "created_at" : "2013-10-16 20:02:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vqsYBOiLfQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XzxmVbL6",
      "display_url" : "pastebin.com\/raw.php?i=Xzxm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390546383205179392",
  "text" : "http:\/\/t.co\/vqsYBOiLfQ Hashes: 121 Keywords: -0.17 #infoleak",
  "id" : 390546383205179392,
  "created_at" : "2013-10-16 18:34:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LAAhi3Pz8e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0UEuRame",
      "display_url" : "pastebin.com\/raw.php?i=0UEu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390538665015115776",
  "text" : "http:\/\/t.co\/LAAhi3Pz8e Hashes: 492 Keywords: 0.22 #infoleak",
  "id" : 390538665015115776,
  "created_at" : "2013-10-16 18:04:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/scsz3uj5lQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=73Xqu1S1",
      "display_url" : "pastebin.com\/raw.php?i=73Xq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390537191228981249",
  "text" : "http:\/\/t.co\/scsz3uj5lQ Emails: 126 Keywords: 0.19 #infoleak",
  "id" : 390537191228981249,
  "created_at" : "2013-10-16 17:58:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bCS3rJBzyy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2G0UDcnc",
      "display_url" : "pastebin.com\/raw.php?i=2G0U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390532113369677824",
  "text" : "http:\/\/t.co\/bCS3rJBzyy Emails: 122 Hashes: 147 E\/H: 0.83 Keywords: 0.33 #infoleak",
  "id" : 390532113369677824,
  "created_at" : "2013-10-16 17:38:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VUvMNq5NNW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S1dH28CV",
      "display_url" : "pastebin.com\/raw.php?i=S1dH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390527125713088512",
  "text" : "http:\/\/t.co\/VUvMNq5NNW Emails: 218 Keywords: 0.33 #infoleak",
  "id" : 390527125713088512,
  "created_at" : "2013-10-16 17:18:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oLmYbc29uI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=phe4eRFX",
      "display_url" : "pastebin.com\/raw.php?i=phe4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390526782845116416",
  "text" : "http:\/\/t.co\/oLmYbc29uI Emails: 49 Keywords: 0.0 #infoleak",
  "id" : 390526782845116416,
  "created_at" : "2013-10-16 17:16:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MgrHXRr5Tf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6X2LZZ4h",
      "display_url" : "pastebin.com\/raw.php?i=6X2L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390521490137174016",
  "text" : "http:\/\/t.co\/MgrHXRr5Tf Emails: 118 Hashes: 43 E\/H: 2.74 Keywords: 0.44 #infoleak",
  "id" : 390521490137174016,
  "created_at" : "2013-10-16 16:55:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j8D0LiEDod",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uXauPYbG",
      "display_url" : "pastebin.com\/raw.php?i=uXau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390516972665847808",
  "text" : "http:\/\/t.co\/j8D0LiEDod Emails: 27 Keywords: 0.22 #infoleak",
  "id" : 390516972665847808,
  "created_at" : "2013-10-16 16:37:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MyyPO9j3R3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ephzTT4i",
      "display_url" : "pastebin.com\/raw.php?i=ephz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390511497324924928",
  "text" : "http:\/\/t.co\/MyyPO9j3R3 Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 390511497324924928,
  "created_at" : "2013-10-16 16:16:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MaoOy5mZ3p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nHcYHYeP",
      "display_url" : "pastebin.com\/raw.php?i=nHcY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390505081889910784",
  "text" : "http:\/\/t.co\/MaoOy5mZ3p Hashes: 46 Keywords: -0.17 #infoleak",
  "id" : 390505081889910784,
  "created_at" : "2013-10-16 15:50:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4H4fklVKaX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pmMiEFSC",
      "display_url" : "pastebin.com\/raw.php?i=pmMi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390498290061438976",
  "text" : "http:\/\/t.co\/4H4fklVKaX Emails: 180 Keywords: 0.33 #infoleak",
  "id" : 390498290061438976,
  "created_at" : "2013-10-16 15:23:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bu497gVBMn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QzeJQ1BH",
      "display_url" : "pastebin.com\/raw.php?i=QzeJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390464874188668928",
  "text" : "http:\/\/t.co\/bu497gVBMn Emails: 100 Hashes: 200 E\/H: 0.5 Keywords: -0.03 #infoleak",
  "id" : 390464874188668928,
  "created_at" : "2013-10-16 13:10:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BsfboRmGmP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7vXPiBRC",
      "display_url" : "pastebin.com\/raw.php?i=7vXP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390454420015575040",
  "text" : "http:\/\/t.co\/BsfboRmGmP Emails: 40 Keywords: 0.11 #infoleak",
  "id" : 390454420015575040,
  "created_at" : "2013-10-16 12:29:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g7EUW9rF5Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mwiFxGPc",
      "display_url" : "pastebin.com\/raw.php?i=mwiF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390450620785647616",
  "text" : "http:\/\/t.co\/g7EUW9rF5Z Emails: 638 Hashes: 1 E\/H: 638.0 Keywords: 0.19 #infoleak",
  "id" : 390450620785647616,
  "created_at" : "2013-10-16 12:14:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yo7BuErtrH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bQHwemz3",
      "display_url" : "pastebin.com\/raw.php?i=bQHw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390441588716863489",
  "text" : "http:\/\/t.co\/yo7BuErtrH Emails: 14 Hashes: 15 E\/H: 0.93 Keywords: 0.55 #infoleak",
  "id" : 390441588716863489,
  "created_at" : "2013-10-16 11:38:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tCRDjEDV95",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4QHDzUmb",
      "display_url" : "pastebin.com\/raw.php?i=4QHD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390432969972011009",
  "text" : "http:\/\/t.co\/tCRDjEDV95 Emails: 6 Hashes: 57 E\/H: 0.11 Keywords: 0.11 #infoleak",
  "id" : 390432969972011009,
  "created_at" : "2013-10-16 11:04:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RfZ0oyBumW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CFf3h3sx",
      "display_url" : "pastebin.com\/raw.php?i=CFf3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390431198712848384",
  "text" : "http:\/\/t.co\/RfZ0oyBumW Emails: 11 Hashes: 399 E\/H: 0.03 Keywords: 0.33 #infoleak",
  "id" : 390431198712848384,
  "created_at" : "2013-10-16 10:57:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HGcs5ItcWv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ubPRPtB6",
      "display_url" : "pastebin.com\/raw.php?i=ubPR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390425421927292928",
  "text" : "http:\/\/t.co\/HGcs5ItcWv Emails: 3 Hashes: 160 E\/H: 0.02 Keywords: 0.22 #infoleak",
  "id" : 390425421927292928,
  "created_at" : "2013-10-16 10:34:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NajlEPS83I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8T6YeMti",
      "display_url" : "pastebin.com\/raw.php?i=8T6Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390415715007606784",
  "text" : "http:\/\/t.co\/NajlEPS83I Emails: 311 Keywords: 0.11 #infoleak",
  "id" : 390415715007606784,
  "created_at" : "2013-10-16 09:55:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IuJrFeWbiD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d538weRJ",
      "display_url" : "pastebin.com\/raw.php?i=d538\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390390151806873600",
  "text" : "http:\/\/t.co\/IuJrFeWbiD Keywords: 0.55 #infoleak",
  "id" : 390390151806873600,
  "created_at" : "2013-10-16 08:13:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KYX5hMqvLG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yZGrtFTf",
      "display_url" : "pastebin.com\/raw.php?i=yZGr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390389805864849409",
  "text" : "http:\/\/t.co\/KYX5hMqvLG Possible cisco configuration #infoleak",
  "id" : 390389805864849409,
  "created_at" : "2013-10-16 08:12:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N4TWpoeKYO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FKWbxYY5",
      "display_url" : "pastebin.com\/raw.php?i=FKWb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390369138578685952",
  "text" : "http:\/\/t.co\/N4TWpoeKYO Emails: 1 Hashes: 38 E\/H: 0.03 Keywords: 0.08 #infoleak",
  "id" : 390369138578685952,
  "created_at" : "2013-10-16 06:50:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5TZclS3KI1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Vz8iMgBS",
      "display_url" : "pastebin.com\/raw.php?i=Vz8i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390337045396471808",
  "text" : "http:\/\/t.co\/5TZclS3KI1 Emails: 67 Keywords: 0.0 #infoleak",
  "id" : 390337045396471808,
  "created_at" : "2013-10-16 04:42:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QOGMivOtJ6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MA55W5Z7",
      "display_url" : "pastebin.com\/raw.php?i=MA55\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390336581275377665",
  "text" : "http:\/\/t.co\/QOGMivOtJ6 Emails: 68 Keywords: 0.0 #infoleak",
  "id" : 390336581275377665,
  "created_at" : "2013-10-16 04:41:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hwBSd2OQru",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9gqX2jcp",
      "display_url" : "pastebin.com\/raw.php?i=9gqX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390326305729691648",
  "text" : "http:\/\/t.co\/hwBSd2OQru Emails: 37 Keywords: 0.0 #infoleak",
  "id" : 390326305729691648,
  "created_at" : "2013-10-16 04:00:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6IUG8urgeo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PAd7TjRy",
      "display_url" : "pastebin.com\/raw.php?i=PAd7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390326024463863809",
  "text" : "http:\/\/t.co\/6IUG8urgeo Emails: 38 Keywords: -0.14 #infoleak",
  "id" : 390326024463863809,
  "created_at" : "2013-10-16 03:59:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZFMJ67ooEk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yewTQuRW",
      "display_url" : "pastebin.com\/raw.php?i=yewT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390310405370683392",
  "text" : "http:\/\/t.co\/ZFMJ67ooEk Emails: 20 Keywords: 0.08 #infoleak",
  "id" : 390310405370683392,
  "created_at" : "2013-10-16 02:57:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IVQAf9V4Ot",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NFpz8hQC",
      "display_url" : "pastebin.com\/raw.php?i=NFpz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390305719956013056",
  "text" : "http:\/\/t.co\/IVQAf9V4Ot Emails: 88 Keywords: -0.03 #infoleak",
  "id" : 390305719956013056,
  "created_at" : "2013-10-16 02:38:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xBNREwabaN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A68DFbXn",
      "display_url" : "pastebin.com\/raw.php?i=A68D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390294004119523329",
  "text" : "http:\/\/t.co\/xBNREwabaN Hashes: 372 Keywords: 0.11 #infoleak",
  "id" : 390294004119523329,
  "created_at" : "2013-10-16 01:51:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6zWxrP0t8y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FaALQy9s",
      "display_url" : "pastebin.com\/raw.php?i=FaAL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390283223621566464",
  "text" : "http:\/\/t.co\/6zWxrP0t8y Emails: 21 Keywords: -0.14 #infoleak",
  "id" : 390283223621566464,
  "created_at" : "2013-10-16 01:09:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f67NCRhg01",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k4bCt9pY",
      "display_url" : "pastebin.com\/raw.php?i=k4bC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390250449418215424",
  "text" : "http:\/\/t.co\/f67NCRhg01 Emails: 148 Hashes: 90 E\/H: 1.64 Keywords: 0.0 #infoleak",
  "id" : 390250449418215424,
  "created_at" : "2013-10-15 22:58:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kr9l74dcQr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n9Wmz6Db",
      "display_url" : "pastebin.com\/raw.php?i=n9Wm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390243416291811328",
  "text" : "http:\/\/t.co\/Kr9l74dcQr Emails: 1494 Keywords: 0.08 #infoleak",
  "id" : 390243416291811328,
  "created_at" : "2013-10-15 22:30:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xn1nP487ZL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TQAaetVt",
      "display_url" : "pastebin.com\/raw.php?i=TQAa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390238850842238976",
  "text" : "http:\/\/t.co\/Xn1nP487ZL Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.44 #infoleak",
  "id" : 390238850842238976,
  "created_at" : "2013-10-15 22:12:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oRlUowzJuk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qu8tag64",
      "display_url" : "pastebin.com\/raw.php?i=qu8t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390234615035596800",
  "text" : "http:\/\/t.co\/oRlUowzJuk Emails: 51 Hashes: 1 E\/H: 51.0 Keywords: 0.33 #infoleak",
  "id" : 390234615035596800,
  "created_at" : "2013-10-15 21:55:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QkcJwxXOlh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RhbH4g6w",
      "display_url" : "pastebin.com\/raw.php?i=RhbH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390226662094155776",
  "text" : "http:\/\/t.co\/QkcJwxXOlh Emails: 2549 Keywords: -0.03 #infoleak",
  "id" : 390226662094155776,
  "created_at" : "2013-10-15 21:24:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VASxYgI0zr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7FuVjbZ3",
      "display_url" : "pastebin.com\/raw.php?i=7FuV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390217390195089408",
  "text" : "http:\/\/t.co\/VASxYgI0zr Emails: 50 Keywords: 0.22 #infoleak",
  "id" : 390217390195089408,
  "created_at" : "2013-10-15 20:47:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kj6hrpNEbU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mysmYY6Y",
      "display_url" : "pastebin.com\/raw.php?i=mysm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390208208834265088",
  "text" : "http:\/\/t.co\/kj6hrpNEbU Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 390208208834265088,
  "created_at" : "2013-10-15 20:11:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OQg55SCxcx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MGrbcKa3",
      "display_url" : "pastebin.com\/raw.php?i=MGrb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390206065586868224",
  "text" : "http:\/\/t.co\/OQg55SCxcx Emails: 1 Hashes: 31 E\/H: 0.03 Keywords: 0.22 #infoleak",
  "id" : 390206065586868224,
  "created_at" : "2013-10-15 20:02:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6B6SWraJeg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2xY6EzG9",
      "display_url" : "pastebin.com\/raw.php?i=2xY6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390201724658393088",
  "text" : "http:\/\/t.co\/6B6SWraJeg Possible cisco configuration #infoleak",
  "id" : 390201724658393088,
  "created_at" : "2013-10-15 19:45:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S9qzEhLYlI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EJx2hZv9",
      "display_url" : "pastebin.com\/raw.php?i=EJx2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390200623439691776",
  "text" : "http:\/\/t.co\/S9qzEhLYlI Emails: 22 Hashes: 22 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 390200623439691776,
  "created_at" : "2013-10-15 19:40:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qt5NLpbkzo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jXU5Nyv0",
      "display_url" : "pastebin.com\/raw.php?i=jXU5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390199055684358144",
  "text" : "http:\/\/t.co\/Qt5NLpbkzo Emails: 301 Keywords: 0.11 #infoleak",
  "id" : 390199055684358144,
  "created_at" : "2013-10-15 19:34:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Pf51uwVOXi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rtqXG00U",
      "display_url" : "pastebin.com\/raw.php?i=rtqX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390195713050570752",
  "text" : "http:\/\/t.co\/Pf51uwVOXi Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 390195713050570752,
  "created_at" : "2013-10-15 19:21:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PUlDo4VGQb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=har2XBeM",
      "display_url" : "pastebin.com\/raw.php?i=har2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390190643483385856",
  "text" : "http:\/\/t.co\/PUlDo4VGQb Emails: 744 Keywords: 0.0 #infoleak",
  "id" : 390190643483385856,
  "created_at" : "2013-10-15 19:01:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T4PipBhpjj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WAzzwfq2",
      "display_url" : "pastebin.com\/raw.php?i=WAzz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390181710614118400",
  "text" : "http:\/\/t.co\/T4PipBhpjj Emails: 1 Hashes: 51 E\/H: 0.02 Keywords: 0.08 #infoleak",
  "id" : 390181710614118400,
  "created_at" : "2013-10-15 18:25:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l40qKiZKZl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cjZ4T6xb",
      "display_url" : "pastebin.com\/raw.php?i=cjZ4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390169238993780736",
  "text" : "http:\/\/t.co\/l40qKiZKZl Emails: 1 Hashes: 49 E\/H: 0.02 Keywords: 0.08 #infoleak",
  "id" : 390169238993780736,
  "created_at" : "2013-10-15 17:36:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fHEaAK4PYM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7ujNgMrd",
      "display_url" : "pastebin.com\/raw.php?i=7ujN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390168426708090880",
  "text" : "http:\/\/t.co\/fHEaAK4PYM Emails: 1 Hashes: 46 E\/H: 0.02 Keywords: 0.08 #infoleak",
  "id" : 390168426708090880,
  "created_at" : "2013-10-15 17:32:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6rB24P40u2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bj0h0iL3",
      "display_url" : "pastebin.com\/raw.php?i=bj0h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390135616643403776",
  "text" : "http:\/\/t.co\/6rB24P40u2 Emails: 467 Keywords: 0.11 #infoleak",
  "id" : 390135616643403776,
  "created_at" : "2013-10-15 15:22:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1h6v4LCtvd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=55s8vFVR",
      "display_url" : "pastebin.com\/raw.php?i=55s8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390120839300919296",
  "text" : "http:\/\/t.co\/1h6v4LCtvd Emails: 1 Hashes: 47 E\/H: 0.02 Keywords: 0.08 #infoleak",
  "id" : 390120839300919296,
  "created_at" : "2013-10-15 14:23:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XonYkxQ6CV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4SamXK38",
      "display_url" : "pastebin.com\/raw.php?i=4Sam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390106652797452288",
  "text" : "http:\/\/t.co\/XonYkxQ6CV Emails: 15 Hashes: 16 E\/H: 0.94 Keywords: 0.55 #infoleak",
  "id" : 390106652797452288,
  "created_at" : "2013-10-15 13:27:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IHEjcUSAwo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YqbMhTWT",
      "display_url" : "pastebin.com\/raw.php?i=YqbM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390091444246953984",
  "text" : "http:\/\/t.co\/IHEjcUSAwo Hashes: 36 Keywords: 0.0 #infoleak",
  "id" : 390091444246953984,
  "created_at" : "2013-10-15 12:27:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kczSYatxtf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aMGsEtLe",
      "display_url" : "pastebin.com\/raw.php?i=aMGs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390084204337561600",
  "text" : "http:\/\/t.co\/kczSYatxtf Emails: 202 Hashes: 12 E\/H: 16.83 Keywords: 0.33 #infoleak",
  "id" : 390084204337561600,
  "created_at" : "2013-10-15 11:58:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7hhsTwoEJ0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DVXtNpg1",
      "display_url" : "pastebin.com\/raw.php?i=DVXt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390061490520076288",
  "text" : "http:\/\/t.co\/7hhsTwoEJ0 Hashes: 38 Keywords: 0.0 #infoleak",
  "id" : 390061490520076288,
  "created_at" : "2013-10-15 10:28:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d6J6lQLLET",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NyErQi2N",
      "display_url" : "pastebin.com\/raw.php?i=NyEr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390058364652122113",
  "text" : "http:\/\/t.co\/d6J6lQLLET Hashes: 36 Keywords: 0.11 #infoleak",
  "id" : 390058364652122113,
  "created_at" : "2013-10-15 10:15:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kZAIl1RCfm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dPCSsZ2H",
      "display_url" : "pastebin.com\/raw.php?i=dPCS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390025856577318912",
  "text" : "http:\/\/t.co\/kZAIl1RCfm Found possible Google API key(s) #infoleak",
  "id" : 390025856577318912,
  "created_at" : "2013-10-15 08:06:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mO6kwP6VbU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xsr9mAq0",
      "display_url" : "pastebin.com\/raw.php?i=Xsr9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390005978554327040",
  "text" : "http:\/\/t.co\/mO6kwP6VbU Emails: 97 Hashes: 1 E\/H: 97.0 Keywords: 0.88 #infoleak",
  "id" : 390005978554327040,
  "created_at" : "2013-10-15 06:47:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ScFTWd6t8a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s9RSJF3H",
      "display_url" : "pastebin.com\/raw.php?i=s9RS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389966389823279104",
  "text" : "http:\/\/t.co\/ScFTWd6t8a Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 389966389823279104,
  "created_at" : "2013-10-15 04:10:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M6wJtXXY4v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ssmju1iB",
      "display_url" : "pastebin.com\/raw.php?i=Ssmj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389958629563961344",
  "text" : "http:\/\/t.co\/M6wJtXXY4v Emails: 47 Hashes: 78 E\/H: 0.6 Keywords: 0.3 #infoleak",
  "id" : 389958629563961344,
  "created_at" : "2013-10-15 03:39:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uBE91qBYI7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TEmB58t6",
      "display_url" : "pastebin.com\/raw.php?i=TEmB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389954970209886208",
  "text" : "http:\/\/t.co\/uBE91qBYI7 Emails: 6543 Keywords: 0.22 #infoleak",
  "id" : 389954970209886208,
  "created_at" : "2013-10-15 03:24:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VqdZqzuNFt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rdcLRfrR",
      "display_url" : "pastebin.com\/raw.php?i=rdcL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389947216682418176",
  "text" : "http:\/\/t.co\/VqdZqzuNFt Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 389947216682418176,
  "created_at" : "2013-10-15 02:53:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HPcfKvI5TB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MZtfaDyt",
      "display_url" : "pastebin.com\/raw.php?i=MZtf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389935725472268288",
  "text" : "http:\/\/t.co\/HPcfKvI5TB Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 389935725472268288,
  "created_at" : "2013-10-15 02:08:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sOjEVI4wSP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UpFbA40h",
      "display_url" : "pastebin.com\/raw.php?i=UpFb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389931288213196800",
  "text" : "http:\/\/t.co\/sOjEVI4wSP Emails: 77 Keywords: 0.33 #infoleak",
  "id" : 389931288213196800,
  "created_at" : "2013-10-15 01:50:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SivC0GAKJa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Sxb0FYsr",
      "display_url" : "pastebin.com\/raw.php?i=Sxb0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389920017057185792",
  "text" : "http:\/\/t.co\/SivC0GAKJa Emails: 138 Keywords: 0.11 #infoleak",
  "id" : 389920017057185792,
  "created_at" : "2013-10-15 01:05:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0L3Wjf2fj1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qrbBtf1p",
      "display_url" : "pastebin.com\/raw.php?i=qrbB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389919812769427457",
  "text" : "http:\/\/t.co\/0L3Wjf2fj1 Emails: 1861 Keywords: 0.22 #infoleak",
  "id" : 389919812769427457,
  "created_at" : "2013-10-15 01:05:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MVEgHiKreH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XHh81zq4",
      "display_url" : "pastebin.com\/raw.php?i=XHh8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389895492437413888",
  "text" : "http:\/\/t.co\/MVEgHiKreH Emails: 64 Keywords: 0.33 #infoleak",
  "id" : 389895492437413888,
  "created_at" : "2013-10-14 23:28:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WdioqdhLGn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z9i9yZX3",
      "display_url" : "pastebin.com\/raw.php?i=z9i9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389895417258713089",
  "text" : "http:\/\/t.co\/WdioqdhLGn Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 389895417258713089,
  "created_at" : "2013-10-14 23:28:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pqNkt5Y56t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=adiyHLBF",
      "display_url" : "pastebin.com\/raw.php?i=adiy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389872515973009408",
  "text" : "http:\/\/t.co\/pqNkt5Y56t Found possible Google API key(s) #infoleak",
  "id" : 389872515973009408,
  "created_at" : "2013-10-14 21:57:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bazz9yXVrQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sn0NZVb2",
      "display_url" : "pastebin.com\/raw.php?i=sn0N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389870850993704960",
  "text" : "http:\/\/t.co\/Bazz9yXVrQ Emails: 228 Keywords: 0.22 #infoleak",
  "id" : 389870850993704960,
  "created_at" : "2013-10-14 21:50:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ci24DX2vZa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mrgQPtFp",
      "display_url" : "pastebin.com\/raw.php?i=mrgQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389869841831563264",
  "text" : "http:\/\/t.co\/ci24DX2vZa Emails: 154 Keywords: 0.11 #infoleak",
  "id" : 389869841831563264,
  "created_at" : "2013-10-14 21:46:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xyRBUkeLpH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1DHA9wRc",
      "display_url" : "pastebin.com\/raw.php?i=1DHA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389861986768388097",
  "text" : "http:\/\/t.co\/xyRBUkeLpH Hashes: 100 Keywords: -0.14 #infoleak",
  "id" : 389861986768388097,
  "created_at" : "2013-10-14 21:15:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F1SvYrhd3y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MgDq6yuY",
      "display_url" : "pastebin.com\/raw.php?i=MgDq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389855829752819712",
  "text" : "http:\/\/t.co\/F1SvYrhd3y Emails: 81 Keywords: 0.0 #infoleak",
  "id" : 389855829752819712,
  "created_at" : "2013-10-14 20:50:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h1NPpwfyPp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Lx0ZnBmS",
      "display_url" : "pastebin.com\/raw.php?i=Lx0Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389832776243228673",
  "text" : "http:\/\/t.co\/h1NPpwfyPp Emails: 355 Keywords: 0.11 #infoleak",
  "id" : 389832776243228673,
  "created_at" : "2013-10-14 19:19:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wbFHgaHNjv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rNWwHT7y",
      "display_url" : "pastebin.com\/raw.php?i=rNWw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389829599464783872",
  "text" : "http:\/\/t.co\/wbFHgaHNjv Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 389829599464783872,
  "created_at" : "2013-10-14 19:06:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0OO98pcCdW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eEQSXwj9",
      "display_url" : "pastebin.com\/raw.php?i=eEQS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389827566640852992",
  "text" : "http:\/\/t.co\/0OO98pcCdW Emails: 3334 Keywords: 0.44 #infoleak",
  "id" : 389827566640852992,
  "created_at" : "2013-10-14 18:58:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jtyKVUonIb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8G1zb20f",
      "display_url" : "pastebin.com\/raw.php?i=8G1z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389827270992736258",
  "text" : "http:\/\/t.co\/jtyKVUonIb Emails: 1085 Keywords: 0.22 #infoleak",
  "id" : 389827270992736258,
  "created_at" : "2013-10-14 18:57:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QqSZUwpdTl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vKEcLqcf",
      "display_url" : "pastebin.com\/raw.php?i=vKEc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389826878863060992",
  "text" : "http:\/\/t.co\/QqSZUwpdTl Emails: 48 Keywords: 0.11 #infoleak",
  "id" : 389826878863060992,
  "created_at" : "2013-10-14 18:55:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ocT0jbi8Mm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7JvHvJAP",
      "display_url" : "pastebin.com\/raw.php?i=7JvH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389817876875841536",
  "text" : "http:\/\/t.co\/ocT0jbi8Mm Emails: 121 Keywords: 0.11 #infoleak",
  "id" : 389817876875841536,
  "created_at" : "2013-10-14 18:19:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6ZuocGcfWm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u79csHpC",
      "display_url" : "pastebin.com\/raw.php?i=u79c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389813214579810305",
  "text" : "http:\/\/t.co\/6ZuocGcfWm Emails: 1164 Keywords: 0.11 #infoleak",
  "id" : 389813214579810305,
  "created_at" : "2013-10-14 18:01:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dbYb8qQfce",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7t21Lc7Q",
      "display_url" : "pastebin.com\/raw.php?i=7t21\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389809402691469312",
  "text" : "http:\/\/t.co\/dbYb8qQfce Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 389809402691469312,
  "created_at" : "2013-10-14 17:46:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3188zeBB2f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ttcM4HTk",
      "display_url" : "pastebin.com\/raw.php?i=ttcM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389793636482691072",
  "text" : "http:\/\/t.co\/3188zeBB2f Keywords: 0.55 #infoleak",
  "id" : 389793636482691072,
  "created_at" : "2013-10-14 16:43:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nHbZgTFHMq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JLvQ8hQm",
      "display_url" : "pastebin.com\/raw.php?i=JLvQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389788504537841664",
  "text" : "http:\/\/t.co\/nHbZgTFHMq Possible cisco configuration #infoleak",
  "id" : 389788504537841664,
  "created_at" : "2013-10-14 16:23:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tkeGe8Xq2Q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yDz5DuLA",
      "display_url" : "pastebin.com\/raw.php?i=yDz5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389770003324473344",
  "text" : "http:\/\/t.co\/tkeGe8Xq2Q Emails: 75 Keywords: 0.11 #infoleak",
  "id" : 389770003324473344,
  "created_at" : "2013-10-14 15:09:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Szv3eP07Ay",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uWLbt9pR",
      "display_url" : "pastebin.com\/raw.php?i=uWLb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389763039236329473",
  "text" : "http:\/\/t.co\/Szv3eP07Ay Emails: 485 Keywords: 0.11 #infoleak",
  "id" : 389763039236329473,
  "created_at" : "2013-10-14 14:42:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BA3dhYORBW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mWU1eawU",
      "display_url" : "pastebin.com\/raw.php?i=mWU1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389759531594440705",
  "text" : "http:\/\/t.co\/BA3dhYORBW Emails: 1254 Hashes: 6 E\/H: 209.0 Keywords: 0.3 #infoleak",
  "id" : 389759531594440705,
  "created_at" : "2013-10-14 14:28:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QraAaXPEah",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wiSawwyX",
      "display_url" : "pastebin.com\/raw.php?i=wiSa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389755442978496512",
  "text" : "http:\/\/t.co\/QraAaXPEah Emails: 56 Keywords: 0.11 #infoleak",
  "id" : 389755442978496512,
  "created_at" : "2013-10-14 14:11:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tsdmaJI9Uv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yzEngQGQ",
      "display_url" : "pastebin.com\/raw.php?i=yzEn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389750710784360449",
  "text" : "http:\/\/t.co\/tsdmaJI9Uv Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 389750710784360449,
  "created_at" : "2013-10-14 13:53:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vmBV9zuIPv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E696bH9x",
      "display_url" : "pastebin.com\/raw.php?i=E696\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389747502800310272",
  "text" : "http:\/\/t.co\/vmBV9zuIPv Emails: 35 Keywords: 0.22 #infoleak",
  "id" : 389747502800310272,
  "created_at" : "2013-10-14 13:40:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cHjFGb1w2y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TxCk0vAf",
      "display_url" : "pastebin.com\/raw.php?i=TxCk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389747132548132864",
  "text" : "http:\/\/t.co\/cHjFGb1w2y Hashes: 169 Keywords: -0.03 #infoleak",
  "id" : 389747132548132864,
  "created_at" : "2013-10-14 13:38:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RZ219ab6HM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LTJYbZHR",
      "display_url" : "pastebin.com\/raw.php?i=LTJY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389744759842942976",
  "text" : "http:\/\/t.co\/RZ219ab6HM Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 389744759842942976,
  "created_at" : "2013-10-14 13:29:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tLFCjGskQn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B8kv2FRJ",
      "display_url" : "pastebin.com\/raw.php?i=B8kv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389713543106289664",
  "text" : "http:\/\/t.co\/tLFCjGskQn Hashes: 71 Keywords: 0.11 #infoleak",
  "id" : 389713543106289664,
  "created_at" : "2013-10-14 11:25:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pC6D49hBIL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G636zDMx",
      "display_url" : "pastebin.com\/raw.php?i=G636\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389663817816240128",
  "text" : "http:\/\/t.co\/pC6D49hBIL Hashes: 30 Keywords: -0.03 #infoleak",
  "id" : 389663817816240128,
  "created_at" : "2013-10-14 08:07:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CDqDtkDd7G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v0y2TLBp",
      "display_url" : "pastebin.com\/raw.php?i=v0y2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389653572092059649",
  "text" : "http:\/\/t.co\/CDqDtkDd7G Emails: 6 Hashes: 34 E\/H: 0.18 Keywords: 0.08 #infoleak",
  "id" : 389653572092059649,
  "created_at" : "2013-10-14 07:27:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3AxXZ41Erq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xg6BWT1t",
      "display_url" : "pastebin.com\/raw.php?i=Xg6B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389625828402663424",
  "text" : "http:\/\/t.co\/3AxXZ41Erq Emails: 614 Keywords: 0.44 #infoleak",
  "id" : 389625828402663424,
  "created_at" : "2013-10-14 05:36:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y8w9Y4Vdii",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3XTLLEcv",
      "display_url" : "pastebin.com\/raw.php?i=3XTL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389625507714592768",
  "text" : "http:\/\/t.co\/Y8w9Y4Vdii Emails: 332 Keywords: 0.3 #infoleak",
  "id" : 389625507714592768,
  "created_at" : "2013-10-14 05:35:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CdTcjGopza",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tQXBsFFF",
      "display_url" : "pastebin.com\/raw.php?i=tQXB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389624457435705344",
  "text" : "http:\/\/t.co\/CdTcjGopza Emails: 33 Hashes: 30 E\/H: 1.1 Keywords: 0.08 #infoleak",
  "id" : 389624457435705344,
  "created_at" : "2013-10-14 05:31:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LQNm9Tey3r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K5HRLKZs",
      "display_url" : "pastebin.com\/raw.php?i=K5HR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389623454665670656",
  "text" : "http:\/\/t.co\/LQNm9Tey3r Emails: 33 Hashes: 30 E\/H: 1.1 Keywords: 0.08 #infoleak",
  "id" : 389623454665670656,
  "created_at" : "2013-10-14 05:27:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9BuYRzjVxb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qeiUNYVS",
      "display_url" : "pastebin.com\/raw.php?i=qeiU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389609584421138432",
  "text" : "http:\/\/t.co\/9BuYRzjVxb Hashes: 89 Keywords: -0.03 #infoleak",
  "id" : 389609584421138432,
  "created_at" : "2013-10-14 04:32:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dzU407onPG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hj1pQj5Y",
      "display_url" : "pastebin.com\/raw.php?i=Hj1p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389595346357075968",
  "text" : "http:\/\/t.co\/dzU407onPG Hashes: 89 Keywords: -0.03 #infoleak",
  "id" : 389595346357075968,
  "created_at" : "2013-10-14 03:35:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J5WUEZcl61",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=prafLi5c",
      "display_url" : "pastebin.com\/raw.php?i=praf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389578399464689664",
  "text" : "http:\/\/t.co\/J5WUEZcl61 Emails: 188 Keywords: 0.19 #infoleak",
  "id" : 389578399464689664,
  "created_at" : "2013-10-14 02:28:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xhZY9Cg23V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QJ9eBYXY",
      "display_url" : "pastebin.com\/raw.php?i=QJ9e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389566452220440577",
  "text" : "http:\/\/t.co\/xhZY9Cg23V Keywords: 0.55 #infoleak",
  "id" : 389566452220440577,
  "created_at" : "2013-10-14 01:40:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/phAexbfwmE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9wCWCFUH",
      "display_url" : "pastebin.com\/raw.php?i=9wCW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389565113394425856",
  "text" : "http:\/\/t.co\/phAexbfwmE Hashes: 57 Keywords: 0.44 #infoleak",
  "id" : 389565113394425856,
  "created_at" : "2013-10-14 01:35:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jwCCH8SrUb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RUsDURaS",
      "display_url" : "pastebin.com\/raw.php?i=RUsD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389395279285194752",
  "text" : "http:\/\/t.co\/jwCCH8SrUb Emails: 49 Keywords: 0.44 #infoleak",
  "id" : 389395279285194752,
  "created_at" : "2013-10-13 14:20:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yA1WIPfsnU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vxjsSa5q",
      "display_url" : "pastebin.com\/raw.php?i=vxjs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389371242785955841",
  "text" : "http:\/\/t.co\/yA1WIPfsnU Hashes: 493 Keywords: -0.14 #infoleak",
  "id" : 389371242785955841,
  "created_at" : "2013-10-13 12:45:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HNVR25aYlH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0Md65MWA",
      "display_url" : "pastebin.com\/raw.php?i=0Md6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389355058543878144",
  "text" : "http:\/\/t.co\/HNVR25aYlH Keywords: 0.55 #infoleak",
  "id" : 389355058543878144,
  "created_at" : "2013-10-13 11:40:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wZnwOieat4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qKCAEfLW",
      "display_url" : "pastebin.com\/raw.php?i=qKCA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389353410492760064",
  "text" : "http:\/\/t.co\/wZnwOieat4 Emails: 44 Keywords: 0.66 #infoleak",
  "id" : 389353410492760064,
  "created_at" : "2013-10-13 11:34:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9Urky9Kbda",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1Je4K32L",
      "display_url" : "pastebin.com\/raw.php?i=1Je4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389319921525460992",
  "text" : "http:\/\/t.co\/9Urky9Kbda Emails: 78 Keywords: 0.44 #infoleak",
  "id" : 389319921525460992,
  "created_at" : "2013-10-13 09:21:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L2eMzUj8VD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iXPB1QYf",
      "display_url" : "pastebin.com\/raw.php?i=iXPB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389317602977140736",
  "text" : "http:\/\/t.co\/L2eMzUj8VD Emails: 3928 Keywords: 0.19 #infoleak",
  "id" : 389317602977140736,
  "created_at" : "2013-10-13 09:12:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7RsUKEd9zd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cbc69Pk4",
      "display_url" : "pastebin.com\/raw.php?i=Cbc6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389313722751000577",
  "text" : "http:\/\/t.co\/7RsUKEd9zd Hashes: 553 Keywords: 0.0 #infoleak",
  "id" : 389313722751000577,
  "created_at" : "2013-10-13 08:56:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XHnWRUbAkL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0TN22xmB",
      "display_url" : "pastebin.com\/raw.php?i=0TN2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389307628754440192",
  "text" : "http:\/\/t.co\/XHnWRUbAkL Keywords: 0.55 #infoleak",
  "id" : 389307628754440192,
  "created_at" : "2013-10-13 08:32:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Vw1llP0QsP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2zT0nQD7",
      "display_url" : "pastebin.com\/raw.php?i=2zT0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389298065082839040",
  "text" : "http:\/\/t.co\/Vw1llP0QsP Found possible Google API key(s) #infoleak",
  "id" : 389298065082839040,
  "created_at" : "2013-10-13 07:54:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LRrOyHzKds",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KvXkBgju",
      "display_url" : "pastebin.com\/raw.php?i=KvXk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389295405881516033",
  "text" : "http:\/\/t.co\/LRrOyHzKds Found possible Google API key(s) #infoleak",
  "id" : 389295405881516033,
  "created_at" : "2013-10-13 07:43:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nbE3hR5A2s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=21Je4UUN",
      "display_url" : "pastebin.com\/raw.php?i=21Je\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389294025716412416",
  "text" : "http:\/\/t.co\/nbE3hR5A2s Found possible Google API key(s) #infoleak",
  "id" : 389294025716412416,
  "created_at" : "2013-10-13 07:38:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8YWysxktX1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tX4nKtRP",
      "display_url" : "pastebin.com\/raw.php?i=tX4n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389287635576840192",
  "text" : "http:\/\/t.co\/8YWysxktX1 Possible cisco configuration #infoleak",
  "id" : 389287635576840192,
  "created_at" : "2013-10-13 07:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HLZ1shKjh2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cLKuFf1L",
      "display_url" : "pastebin.com\/raw.php?i=cLKu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389281055313653761",
  "text" : "http:\/\/t.co\/HLZ1shKjh2 Emails: 3 Hashes: 34 E\/H: 0.09 Keywords: 0.44 #infoleak",
  "id" : 389281055313653761,
  "created_at" : "2013-10-13 06:46:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M8gK82QVmZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=45kMG6wS",
      "display_url" : "pastebin.com\/raw.php?i=45kM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389272989734150144",
  "text" : "http:\/\/t.co\/M8gK82QVmZ Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 389272989734150144,
  "created_at" : "2013-10-13 06:14:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nOvhhypK4h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w3J85d0z",
      "display_url" : "pastebin.com\/raw.php?i=w3J8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389262184292704256",
  "text" : "http:\/\/t.co\/nOvhhypK4h Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 389262184292704256,
  "created_at" : "2013-10-13 05:31:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lPvRW0t0qk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QStTXaxg",
      "display_url" : "pastebin.com\/raw.php?i=QStT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389261734789144576",
  "text" : "http:\/\/t.co\/lPvRW0t0qk Emails: 37 Keywords: 0.0 #infoleak",
  "id" : 389261734789144576,
  "created_at" : "2013-10-13 05:30:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T1Ky4pAAU7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VfHg5cSN",
      "display_url" : "pastebin.com\/raw.php?i=VfHg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389240690409893888",
  "text" : "http:\/\/t.co\/T1Ky4pAAU7 Emails: 3 Hashes: 34 E\/H: 0.09 Keywords: 0.44 #infoleak",
  "id" : 389240690409893888,
  "created_at" : "2013-10-13 04:06:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fE3vxhSrhw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VhF7utQF",
      "display_url" : "pastebin.com\/raw.php?i=VhF7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389224364136079360",
  "text" : "http:\/\/t.co\/fE3vxhSrhw Emails: 59 Keywords: 0.11 #infoleak",
  "id" : 389224364136079360,
  "created_at" : "2013-10-13 03:01:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H5VxfSCycX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X6RnvRaW",
      "display_url" : "pastebin.com\/raw.php?i=X6Rn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389222299850665985",
  "text" : "http:\/\/t.co\/H5VxfSCycX Emails: 851 Keywords: 0.22 #infoleak",
  "id" : 389222299850665985,
  "created_at" : "2013-10-13 02:53:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9rJHZhbY8K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jUGLay3t",
      "display_url" : "pastebin.com\/raw.php?i=jUGL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389221994496921602",
  "text" : "http:\/\/t.co\/9rJHZhbY8K Emails: 1483 Keywords: 0.11 #infoleak",
  "id" : 389221994496921602,
  "created_at" : "2013-10-13 02:52:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zUYSBZKcAw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KA466sU2",
      "display_url" : "pastebin.com\/raw.php?i=KA46\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389221521723387904",
  "text" : "http:\/\/t.co\/zUYSBZKcAw Emails: 78 Keywords: 0.44 #infoleak",
  "id" : 389221521723387904,
  "created_at" : "2013-10-13 02:50:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p5xIrpMHX8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9Av3bsJs",
      "display_url" : "pastebin.com\/raw.php?i=9Av3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389208226719215616",
  "text" : "http:\/\/t.co\/p5xIrpMHX8 Emails: 45 Keywords: 0.44 #infoleak",
  "id" : 389208226719215616,
  "created_at" : "2013-10-13 01:57:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qOjRqKG0lm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3N8QzWXX",
      "display_url" : "pastebin.com\/raw.php?i=3N8Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389196110218014720",
  "text" : "http:\/\/t.co\/qOjRqKG0lm Emails: 24 Keywords: -0.14 #infoleak",
  "id" : 389196110218014720,
  "created_at" : "2013-10-13 01:09:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XW4OLQvAdb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Js3b6uqC",
      "display_url" : "pastebin.com\/raw.php?i=Js3b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389162891435184128",
  "text" : "http:\/\/t.co\/XW4OLQvAdb Emails: 39 Keywords: -0.03 #infoleak",
  "id" : 389162891435184128,
  "created_at" : "2013-10-12 22:57:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1VRP0Qaupo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WcHKmqEY",
      "display_url" : "pastebin.com\/raw.php?i=WcHK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389155317226799104",
  "text" : "http:\/\/t.co\/1VRP0Qaupo Hashes: 64 Keywords: 0.0 #infoleak",
  "id" : 389155317226799104,
  "created_at" : "2013-10-12 22:27:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EMOzx6XwHv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k4RvTeex",
      "display_url" : "pastebin.com\/raw.php?i=k4Rv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389148051752755200",
  "text" : "http:\/\/t.co\/EMOzx6XwHv Keywords: 0.55 #infoleak",
  "id" : 389148051752755200,
  "created_at" : "2013-10-12 21:58:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/faJVA0zl4F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pMZqtVHK",
      "display_url" : "pastebin.com\/raw.php?i=pMZq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389147126774517761",
  "text" : "http:\/\/t.co\/faJVA0zl4F Emails: 23 Keywords: 0.33 #infoleak",
  "id" : 389147126774517761,
  "created_at" : "2013-10-12 21:54:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CTnUYA0QqB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zk88ukbY",
      "display_url" : "pastebin.com\/raw.php?i=zk88\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389129708777906176",
  "text" : "http:\/\/t.co\/CTnUYA0QqB Emails: 424 Keywords: 0.33 #infoleak",
  "id" : 389129708777906176,
  "created_at" : "2013-10-12 20:45:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TyDWg6tvpb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QFsufqRJ",
      "display_url" : "pastebin.com\/raw.php?i=QFsu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389119139899392000",
  "text" : "http:\/\/t.co\/TyDWg6tvpb Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 389119139899392000,
  "created_at" : "2013-10-12 20:03:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1rn2ACJoz2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UaH79iET",
      "display_url" : "pastebin.com\/raw.php?i=UaH7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389110131314548736",
  "text" : "http:\/\/t.co\/1rn2ACJoz2 Emails: 219 Keywords: 0.11 #infoleak",
  "id" : 389110131314548736,
  "created_at" : "2013-10-12 19:27:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TbrvSBoVAd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FTkrKWWh",
      "display_url" : "pastebin.com\/raw.php?i=FTkr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389107570809384960",
  "text" : "http:\/\/t.co\/TbrvSBoVAd Emails: 1682 Keywords: 0.11 #infoleak",
  "id" : 389107570809384960,
  "created_at" : "2013-10-12 19:17:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZxBmcveP7a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=frmSBEZn",
      "display_url" : "pastebin.com\/raw.php?i=frmS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389107472532639747",
  "text" : "http:\/\/t.co\/ZxBmcveP7a Emails: 131 Keywords: 0.33 #infoleak",
  "id" : 389107472532639747,
  "created_at" : "2013-10-12 19:17:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WXVIhSnTc9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QS2cnFTr",
      "display_url" : "pastebin.com\/raw.php?i=QS2c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389104225285705728",
  "text" : "http:\/\/t.co\/WXVIhSnTc9 Emails: 52 Hashes: 1 E\/H: 52.0 Keywords: 0.33 #infoleak",
  "id" : 389104225285705728,
  "created_at" : "2013-10-12 19:04:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T55R3OmAhe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QD6C4c3s",
      "display_url" : "pastebin.com\/raw.php?i=QD6C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389083430803079168",
  "text" : "http:\/\/t.co\/T55R3OmAhe Emails: 188 Keywords: 0.11 #infoleak",
  "id" : 389083430803079168,
  "created_at" : "2013-10-12 17:41:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hr4t8BBCWz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vrv0mPe8",
      "display_url" : "pastebin.com\/raw.php?i=vrv0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389082862101602304",
  "text" : "http:\/\/t.co\/Hr4t8BBCWz Emails: 818 Keywords: 0.11 #infoleak",
  "id" : 389082862101602304,
  "created_at" : "2013-10-12 17:39:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iXUXVbyjCz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rXf7Hutx",
      "display_url" : "pastebin.com\/raw.php?i=rXf7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389081403779842049",
  "text" : "http:\/\/t.co\/iXUXVbyjCz Emails: 88 Keywords: 0.3 #infoleak",
  "id" : 389081403779842049,
  "created_at" : "2013-10-12 17:33:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OC9ixxo5j1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D30WyW40",
      "display_url" : "pastebin.com\/raw.php?i=D30W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389069131376377856",
  "text" : "http:\/\/t.co\/OC9ixxo5j1 Emails: 698 Keywords: 0.11 #infoleak",
  "id" : 389069131376377856,
  "created_at" : "2013-10-12 16:44:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ox3HW4bhMa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TaDMMpXu",
      "display_url" : "pastebin.com\/raw.php?i=TaDM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389064838388801536",
  "text" : "http:\/\/t.co\/Ox3HW4bhMa Emails: 914 Hashes: 5 E\/H: 182.8 Keywords: 0.11 #infoleak",
  "id" : 389064838388801536,
  "created_at" : "2013-10-12 16:27:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nW0lKLCSzN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uEUMKvxt",
      "display_url" : "pastebin.com\/raw.php?i=uEUM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389061971619741696",
  "text" : "http:\/\/t.co\/nW0lKLCSzN Emails: 440 Keywords: 0.66 #infoleak",
  "id" : 389061971619741696,
  "created_at" : "2013-10-12 16:16:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ovyIIQqizX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xnyexjtn",
      "display_url" : "pastebin.com\/raw.php?i=Xnye\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389061628777357313",
  "text" : "http:\/\/t.co\/ovyIIQqizX Emails: 1026 Keywords: 0.22 #infoleak",
  "id" : 389061628777357313,
  "created_at" : "2013-10-12 16:14:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QRYrCNDV9H",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4s8HWA3Q",
      "display_url" : "pastebin.com\/raw.php?i=4s8H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389048626506240001",
  "text" : "http:\/\/t.co\/QRYrCNDV9H Emails: 43 Keywords: 0.22 #infoleak",
  "id" : 389048626506240001,
  "created_at" : "2013-10-12 15:23:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C3vmspKLq8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JfHN2pgt",
      "display_url" : "pastebin.com\/raw.php?i=JfHN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388796001038782465",
  "text" : "http:\/\/t.co\/C3vmspKLq8 Emails: 40 Keywords: 0.22 #infoleak",
  "id" : 388796001038782465,
  "created_at" : "2013-10-11 22:39:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UNfgw1N3eZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ztYkjRB9",
      "display_url" : "pastebin.com\/raw.php?i=ztYk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388768520709746688",
  "text" : "http:\/\/t.co\/UNfgw1N3eZ Hashes: 701 Keywords: 0.0 #infoleak",
  "id" : 388768520709746688,
  "created_at" : "2013-10-11 20:50:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qzIU7CcMIV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jAbf6nMw",
      "display_url" : "pastebin.com\/raw.php?i=jAbf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388767420795457537",
  "text" : "http:\/\/t.co\/qzIU7CcMIV Emails: 1721 Keywords: 0.22 #infoleak",
  "id" : 388767420795457537,
  "created_at" : "2013-10-11 20:45:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j51eX4F63s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5gK0PxbZ",
      "display_url" : "pastebin.com\/raw.php?i=5gK0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388762108185161729",
  "text" : "http:\/\/t.co\/j51eX4F63s Hashes: 1963 Keywords: 0.0 #infoleak",
  "id" : 388762108185161729,
  "created_at" : "2013-10-11 20:24:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Vl9pflNAUN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MMTXwVrX",
      "display_url" : "pastebin.com\/raw.php?i=MMTX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388740656996167681",
  "text" : "http:\/\/t.co\/Vl9pflNAUN Hashes: 112 Keywords: 0.0 #infoleak",
  "id" : 388740656996167681,
  "created_at" : "2013-10-11 18:59:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jKmCo6EVvB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a0Lz2NQ5",
      "display_url" : "pastebin.com\/raw.php?i=a0Lz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388714041557786625",
  "text" : "http:\/\/t.co\/jKmCo6EVvB Emails: 400 Keywords: 0.0 #infoleak",
  "id" : 388714041557786625,
  "created_at" : "2013-10-11 17:13:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pEtTF66FnS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bGBUFhCg",
      "display_url" : "pastebin.com\/raw.php?i=bGBU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388713471308615680",
  "text" : "http:\/\/t.co\/pEtTF66FnS Hashes: 448 Keywords: 0.11 #infoleak",
  "id" : 388713471308615680,
  "created_at" : "2013-10-11 17:11:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j3FqorufG7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NdNmUAwv",
      "display_url" : "pastebin.com\/raw.php?i=NdNm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388685480872509440",
  "text" : "http:\/\/t.co\/j3FqorufG7 Emails: 102 Keywords: 0.0 #infoleak",
  "id" : 388685480872509440,
  "created_at" : "2013-10-11 15:20:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ElegqnOeZC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BV0mJi2t",
      "display_url" : "pastebin.com\/raw.php?i=BV0m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387994913776078848",
  "text" : "http:\/\/t.co\/ElegqnOeZC Emails: 139 Hashes: 406 E\/H: 0.34 Keywords: 0.41 #infoleak",
  "id" : 387994913776078848,
  "created_at" : "2013-10-09 17:36:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QxILedURPi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fbh18Xga",
      "display_url" : "pastebin.com\/raw.php?i=fbh1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387957069997162496",
  "text" : "http:\/\/t.co\/QxILedURPi Hashes: 52 Keywords: 0.08 #infoleak",
  "id" : 387957069997162496,
  "created_at" : "2013-10-09 15:05:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kO9A6gPEVm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JKcuxGQr",
      "display_url" : "pastebin.com\/raw.php?i=JKcu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387952984514383872",
  "text" : "http:\/\/t.co\/kO9A6gPEVm Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 387952984514383872,
  "created_at" : "2013-10-09 14:49:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u8zhln9o4X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qZ0cBBkb",
      "display_url" : "pastebin.com\/raw.php?i=qZ0c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387912154999185408",
  "text" : "http:\/\/t.co\/u8zhln9o4X Emails: 73 Keywords: 0.0 #infoleak",
  "id" : 387912154999185408,
  "created_at" : "2013-10-09 12:07:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zDBJXer2VN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g3kNYQGL",
      "display_url" : "pastebin.com\/raw.php?i=g3kN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387904833002295296",
  "text" : "http:\/\/t.co\/zDBJXer2VN Emails: 141 Hashes: 203 E\/H: 0.69 Keywords: 0.33 #infoleak",
  "id" : 387904833002295296,
  "created_at" : "2013-10-09 11:38:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wRoQ2qKn3N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0W5rnjeU",
      "display_url" : "pastebin.com\/raw.php?i=0W5r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387886569291403264",
  "text" : "http:\/\/t.co\/wRoQ2qKn3N Emails: 8966 Keywords: 0.3 #infoleak",
  "id" : 387886569291403264,
  "created_at" : "2013-10-09 10:25:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OQSlykGGKc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gBVepYaB",
      "display_url" : "pastebin.com\/raw.php?i=gBVe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387870531141521408",
  "text" : "http:\/\/t.co\/OQSlykGGKc Emails: 1019 Keywords: 0.22 #infoleak",
  "id" : 387870531141521408,
  "created_at" : "2013-10-09 09:21:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WTeIgwyPKP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TRemceXr",
      "display_url" : "pastebin.com\/raw.php?i=TRem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387866073959510016",
  "text" : "http:\/\/t.co\/WTeIgwyPKP Emails: 644 Keywords: 0.11 #infoleak",
  "id" : 387866073959510016,
  "created_at" : "2013-10-09 09:04:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DKEejkwyGr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QMMTdsVS",
      "display_url" : "pastebin.com\/raw.php?i=QMMT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387864505188773888",
  "text" : "http:\/\/t.co\/DKEejkwyGr Keywords: 0.55 #infoleak",
  "id" : 387864505188773888,
  "created_at" : "2013-10-09 08:57:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tJG7D351VI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tYcSzidZ",
      "display_url" : "pastebin.com\/raw.php?i=tYcS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387842316947312641",
  "text" : "http:\/\/t.co\/tJG7D351VI Keywords: 0.77 #infoleak",
  "id" : 387842316947312641,
  "created_at" : "2013-10-09 07:29:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rtq2AQ1iAk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6uL9L9yv",
      "display_url" : "pastebin.com\/raw.php?i=6uL9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387789273539149824",
  "text" : "http:\/\/t.co\/rtq2AQ1iAk Possible cisco configuration #infoleak",
  "id" : 387789273539149824,
  "created_at" : "2013-10-09 03:59:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YlqiQWo2VS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NNBZBexD",
      "display_url" : "pastebin.com\/raw.php?i=NNBZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387776446514876417",
  "text" : "http:\/\/t.co\/YlqiQWo2VS Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 387776446514876417,
  "created_at" : "2013-10-09 03:08:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TjKEnrpGrQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TgATm5ym",
      "display_url" : "pastebin.com\/raw.php?i=TgAT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387762438201823232",
  "text" : "http:\/\/t.co\/TjKEnrpGrQ Keywords: 0.55 #infoleak",
  "id" : 387762438201823232,
  "created_at" : "2013-10-09 02:12:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YSMMqmIYkx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zvKDPZn4",
      "display_url" : "pastebin.com\/raw.php?i=zvKD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387759479703764992",
  "text" : "http:\/\/t.co\/YSMMqmIYkx Hashes: 54 Keywords: 0.33 #infoleak",
  "id" : 387759479703764992,
  "created_at" : "2013-10-09 02:00:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0rv7925NWy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2wTHiDnh",
      "display_url" : "pastebin.com\/raw.php?i=2wTH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387752976145993728",
  "text" : "http:\/\/t.co\/0rv7925NWy Emails: 188 Keywords: 0.11 #infoleak",
  "id" : 387752976145993728,
  "created_at" : "2013-10-09 01:34:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9nIoI8mrTN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1p54b83H",
      "display_url" : "pastebin.com\/raw.php?i=1p54\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387750119581691904",
  "text" : "http:\/\/t.co\/9nIoI8mrTN Emails: 7 Hashes: 2 E\/H: 3.5 Keywords: 0.66 #infoleak",
  "id" : 387750119581691904,
  "created_at" : "2013-10-09 01:23:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WdxTZhqf9Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ijCeZBSL",
      "display_url" : "pastebin.com\/raw.php?i=ijCe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387742287855648769",
  "text" : "http:\/\/t.co\/WdxTZhqf9Y Possible cisco configuration #infoleak",
  "id" : 387742287855648769,
  "created_at" : "2013-10-09 00:52:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vMHJVYqrcm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PZmg3ccC",
      "display_url" : "pastebin.com\/raw.php?i=PZmg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387718963234615296",
  "text" : "http:\/\/t.co\/vMHJVYqrcm Emails: 82 Keywords: 0.22 #infoleak",
  "id" : 387718963234615296,
  "created_at" : "2013-10-08 23:19:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TsDTQ87xlW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EBMeEQAE",
      "display_url" : "pastebin.com\/raw.php?i=EBMe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387715348222312448",
  "text" : "http:\/\/t.co\/TsDTQ87xlW Emails: 213 Keywords: 0.0 #infoleak",
  "id" : 387715348222312448,
  "created_at" : "2013-10-08 23:05:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AfXdb1siBO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6dFqVCYx",
      "display_url" : "pastebin.com\/raw.php?i=6dFq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387709041842982912",
  "text" : "http:\/\/t.co\/AfXdb1siBO Emails: 73 Keywords: 0.0 #infoleak",
  "id" : 387709041842982912,
  "created_at" : "2013-10-08 22:40:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bZY6dWjPq5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Vc7KArmM",
      "display_url" : "pastebin.com\/raw.php?i=Vc7K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387707318148014080",
  "text" : "http:\/\/t.co\/bZY6dWjPq5 Emails: 93 Keywords: 0.0 #infoleak",
  "id" : 387707318148014080,
  "created_at" : "2013-10-08 22:33:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cu38WqdxW7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N8fGGCRi",
      "display_url" : "pastebin.com\/raw.php?i=N8fG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387703729669292032",
  "text" : "http:\/\/t.co\/cu38WqdxW7 Emails: 56 Keywords: 0.0 #infoleak",
  "id" : 387703729669292032,
  "created_at" : "2013-10-08 22:19:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tmKdHepd37",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0Wrm8RZA",
      "display_url" : "pastebin.com\/raw.php?i=0Wrm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387699236189790208",
  "text" : "http:\/\/t.co\/tmKdHepd37 Possible cisco configuration #infoleak",
  "id" : 387699236189790208,
  "created_at" : "2013-10-08 22:01:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9dEQuoJCeW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MfKCVZrz",
      "display_url" : "pastebin.com\/raw.php?i=MfKC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387699082040733696",
  "text" : "http:\/\/t.co\/9dEQuoJCeW Emails: 640 Keywords: 0.22 #infoleak",
  "id" : 387699082040733696,
  "created_at" : "2013-10-08 22:00:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5H8cG5WMQr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wWjrBwGz",
      "display_url" : "pastebin.com\/raw.php?i=wWjr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387694464015536128",
  "text" : "http:\/\/t.co\/5H8cG5WMQr Keywords: 0.66 #infoleak",
  "id" : 387694464015536128,
  "created_at" : "2013-10-08 21:42:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OOVak4V177",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UrxyP9eA",
      "display_url" : "pastebin.com\/raw.php?i=Urxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387681551804153856",
  "text" : "http:\/\/t.co\/OOVak4V177 Keywords: 0.55 #infoleak",
  "id" : 387681551804153856,
  "created_at" : "2013-10-08 20:50:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O4T5zN4I6K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T7wHhadD",
      "display_url" : "pastebin.com\/raw.php?i=T7wH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387666622590099456",
  "text" : "http:\/\/t.co\/O4T5zN4I6K Found possible Google API key(s) #infoleak",
  "id" : 387666622590099456,
  "created_at" : "2013-10-08 19:51:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OC1ovQgw3V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FPFq0uUN",
      "display_url" : "pastebin.com\/raw.php?i=FPFq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387666555414130688",
  "text" : "http:\/\/t.co\/OC1ovQgw3V Emails: 109 Keywords: 0.0 #infoleak",
  "id" : 387666555414130688,
  "created_at" : "2013-10-08 19:51:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4wh7jmZAOe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y0U1Fung",
      "display_url" : "pastebin.com\/raw.php?i=y0U1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387634751634280448",
  "text" : "http:\/\/t.co\/4wh7jmZAOe Hashes: 34 Keywords: 0.0 #infoleak",
  "id" : 387634751634280448,
  "created_at" : "2013-10-08 17:45:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lMMJEbTzhV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NU6gkeLD",
      "display_url" : "pastebin.com\/raw.php?i=NU6g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387627819372511232",
  "text" : "http:\/\/t.co\/lMMJEbTzhV Emails: 3 Hashes: 50 E\/H: 0.06 Keywords: 0.22 #infoleak",
  "id" : 387627819372511232,
  "created_at" : "2013-10-08 17:17:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qv7iYZR1IS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QiLQjrBa",
      "display_url" : "pastebin.com\/raw.php?i=QiLQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387624816963895296",
  "text" : "http:\/\/t.co\/Qv7iYZR1IS Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 387624816963895296,
  "created_at" : "2013-10-08 17:05:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZkWKZOVg7O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3tB18Cy1",
      "display_url" : "pastebin.com\/raw.php?i=3tB1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387619605654417408",
  "text" : "http:\/\/t.co\/ZkWKZOVg7O Emails: 6 Hashes: 229 E\/H: 0.03 Keywords: 0.33 #infoleak",
  "id" : 387619605654417408,
  "created_at" : "2013-10-08 16:44:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jKRfISUzy7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UWPQkj19",
      "display_url" : "pastebin.com\/raw.php?i=UWPQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387618322197405697",
  "text" : "http:\/\/t.co\/jKRfISUzy7 Emails: 239 Keywords: -0.14 #infoleak",
  "id" : 387618322197405697,
  "created_at" : "2013-10-08 16:39:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ji3NPk3qTP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j1qeEaep",
      "display_url" : "pastebin.com\/raw.php?i=j1qe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387606688263450624",
  "text" : "http:\/\/t.co\/ji3NPk3qTP Emails: 4 Hashes: 60 E\/H: 0.07 Keywords: 0.11 #infoleak",
  "id" : 387606688263450624,
  "created_at" : "2013-10-08 15:53:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2H22AC75vG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GurhdQEV",
      "display_url" : "pastebin.com\/raw.php?i=Gurh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387603202394189824",
  "text" : "http:\/\/t.co\/2H22AC75vG Hashes: 56 Keywords: 0.11 #infoleak",
  "id" : 387603202394189824,
  "created_at" : "2013-10-08 15:39:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OnV0Z7yQrZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VKLJLMnH",
      "display_url" : "pastebin.com\/raw.php?i=VKLJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387587737416507392",
  "text" : "http:\/\/t.co\/OnV0Z7yQrZ Emails: 162 Keywords: 0.0 #infoleak",
  "id" : 387587737416507392,
  "created_at" : "2013-10-08 14:38:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OvcBTgxirS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HbzJExBW",
      "display_url" : "pastebin.com\/raw.php?i=HbzJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387572633954316288",
  "text" : "http:\/\/t.co\/OvcBTgxirS Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 387572633954316288,
  "created_at" : "2013-10-08 13:38:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RZ0R7JF7aJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9BTymH3z",
      "display_url" : "pastebin.com\/raw.php?i=9BTy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387567350741860352",
  "text" : "http:\/\/t.co\/RZ0R7JF7aJ Emails: 68 Keywords: 0.22 #infoleak",
  "id" : 387567350741860352,
  "created_at" : "2013-10-08 13:17:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yCD7301Hu3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kh1iQ00C",
      "display_url" : "pastebin.com\/raw.php?i=kh1i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387558847998464000",
  "text" : "http:\/\/t.co\/yCD7301Hu3 Emails: 1393 Hashes: 1818 E\/H: 0.77 Keywords: 0.19 #infoleak",
  "id" : 387558847998464000,
  "created_at" : "2013-10-08 12:43:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7Aph2NLSM0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gUfqzuDi",
      "display_url" : "pastebin.com\/raw.php?i=gUfq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387557571055218689",
  "text" : "http:\/\/t.co\/7Aph2NLSM0 Emails: 4 Hashes: 43 E\/H: 0.09 Keywords: 0.66 #infoleak",
  "id" : 387557571055218689,
  "created_at" : "2013-10-08 12:38:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zVuyc7mNX6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4KLHmRsj",
      "display_url" : "pastebin.com\/raw.php?i=4KLH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387557406692999168",
  "text" : "http:\/\/t.co\/zVuyc7mNX6 Emails: 4 Hashes: 43 E\/H: 0.09 Keywords: 0.27 #infoleak",
  "id" : 387557406692999168,
  "created_at" : "2013-10-08 12:37:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2JsxZcFtR9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vyL1wavG",
      "display_url" : "pastebin.com\/raw.php?i=vyL1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387554851502059520",
  "text" : "http:\/\/t.co\/2JsxZcFtR9 Emails: 1 Hashes: 47 E\/H: 0.02 Keywords: 0.08 #infoleak",
  "id" : 387554851502059520,
  "created_at" : "2013-10-08 12:27:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4u5JM1GdKd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JbYuuMke",
      "display_url" : "pastebin.com\/raw.php?i=JbYu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387554204757151744",
  "text" : "http:\/\/t.co\/4u5JM1GdKd Emails: 2998 Keywords: 0.33 #infoleak",
  "id" : 387554204757151744,
  "created_at" : "2013-10-08 12:24:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yVP8n4GfUX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7WvYJDhH",
      "display_url" : "pastebin.com\/raw.php?i=7WvY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387553558205169665",
  "text" : "http:\/\/t.co\/yVP8n4GfUX Emails: 2997 Keywords: 0.22 #infoleak",
  "id" : 387553558205169665,
  "created_at" : "2013-10-08 12:22:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/80UVMhzAFQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JQcNZcxM",
      "display_url" : "pastebin.com\/raw.php?i=JQcN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387552921409163265",
  "text" : "http:\/\/t.co\/80UVMhzAFQ Emails: 3000 Keywords: 0.19 #infoleak",
  "id" : 387552921409163265,
  "created_at" : "2013-10-08 12:19:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YSIZvUFuLd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ys6riwU8",
      "display_url" : "pastebin.com\/raw.php?i=ys6r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387531669575454720",
  "text" : "http:\/\/t.co\/YSIZvUFuLd Keywords: 0.55 #infoleak",
  "id" : 387531669575454720,
  "created_at" : "2013-10-08 10:55:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RwIsfNEXHY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=767gDr8j",
      "display_url" : "pastebin.com\/raw.php?i=767g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387530449808941056",
  "text" : "http:\/\/t.co\/RwIsfNEXHY Emails: 143 Keywords: 0.33 #infoleak",
  "id" : 387530449808941056,
  "created_at" : "2013-10-08 10:50:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/czrnX0T4Mv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YPuakFRE",
      "display_url" : "pastebin.com\/raw.php?i=YPua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387510898627072000",
  "text" : "http:\/\/t.co\/czrnX0T4Mv Emails: 135 Keywords: 0.33 #infoleak",
  "id" : 387510898627072000,
  "created_at" : "2013-10-08 09:32:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/32qHoyd5wZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZE6WP0Fd",
      "display_url" : "pastebin.com\/raw.php?i=ZE6W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387507388464394240",
  "text" : "http:\/\/t.co\/32qHoyd5wZ Possible cisco configuration #infoleak",
  "id" : 387507388464394240,
  "created_at" : "2013-10-08 09:18:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UgeKDJLx9a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PE7TJHLA",
      "display_url" : "pastebin.com\/raw.php?i=PE7T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387501106764337152",
  "text" : "http:\/\/t.co\/UgeKDJLx9a Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 387501106764337152,
  "created_at" : "2013-10-08 08:53:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gkbPZ9XFjj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CBbEJKxx",
      "display_url" : "pastebin.com\/raw.php?i=CBbE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387492368586252289",
  "text" : "http:\/\/t.co\/gkbPZ9XFjj Hashes: 732 Keywords: -0.03 #infoleak",
  "id" : 387492368586252289,
  "created_at" : "2013-10-08 08:19:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nroxQBRjbO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tt9DwNPp",
      "display_url" : "pastebin.com\/raw.php?i=Tt9D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387488985624215552",
  "text" : "http:\/\/t.co\/nroxQBRjbO Emails: 46 Keywords: 0.33 #infoleak",
  "id" : 387488985624215552,
  "created_at" : "2013-10-08 08:05:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hpjJGU7oo8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7X0qLMJt",
      "display_url" : "pastebin.com\/raw.php?i=7X0q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387468680193245184",
  "text" : "http:\/\/t.co\/hpjJGU7oo8 Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 387468680193245184,
  "created_at" : "2013-10-08 06:45:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rFdwg9uRaZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iF7YSTt2",
      "display_url" : "pastebin.com\/raw.php?i=iF7Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387460981640556544",
  "text" : "http:\/\/t.co\/rFdwg9uRaZ Emails: 26 Keywords: -0.14 #infoleak",
  "id" : 387460981640556544,
  "created_at" : "2013-10-08 06:14:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ALoDdSRFI4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iWN2bxJu",
      "display_url" : "pastebin.com\/raw.php?i=iWN2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387452466289057792",
  "text" : "http:\/\/t.co\/ALoDdSRFI4 Emails: 43 Keywords: 0.33 #infoleak",
  "id" : 387452466289057792,
  "created_at" : "2013-10-08 05:40:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QQdVtAXSJt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x4keYvcm",
      "display_url" : "pastebin.com\/raw.php?i=x4ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387452303617171456",
  "text" : "http:\/\/t.co\/QQdVtAXSJt Emails: 43 Keywords: 0.33 #infoleak",
  "id" : 387452303617171456,
  "created_at" : "2013-10-08 05:40:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tKhE9mHHQ4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UyE5G6uh",
      "display_url" : "pastebin.com\/raw.php?i=UyE5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387433805687955456",
  "text" : "http:\/\/t.co\/tKhE9mHHQ4 Emails: 8066 Keywords: 0.19 #infoleak",
  "id" : 387433805687955456,
  "created_at" : "2013-10-08 04:26:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LTDif4ps1D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wt4fbQDR",
      "display_url" : "pastebin.com\/raw.php?i=wt4f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387429511454666752",
  "text" : "http:\/\/t.co\/LTDif4ps1D Emails: 27 Keywords: -0.14 #infoleak",
  "id" : 387429511454666752,
  "created_at" : "2013-10-08 04:09:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BoN0kCBA9C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SCzXYL6u",
      "display_url" : "pastebin.com\/raw.php?i=SCzX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387429010092724224",
  "text" : "http:\/\/t.co\/BoN0kCBA9C Keywords: 0.66 #infoleak",
  "id" : 387429010092724224,
  "created_at" : "2013-10-08 04:07:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/En9obljKMx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KnZpvfun",
      "display_url" : "pastebin.com\/raw.php?i=KnZp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387410813561999360",
  "text" : "http:\/\/t.co\/En9obljKMx Emails: 306 Keywords: 0.11 #infoleak",
  "id" : 387410813561999360,
  "created_at" : "2013-10-08 02:55:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8yhegxO4jQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TVB7qSqy",
      "display_url" : "pastebin.com\/raw.php?i=TVB7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387401389090934784",
  "text" : "http:\/\/t.co\/8yhegxO4jQ Hashes: 511 Keywords: 0.0 #infoleak",
  "id" : 387401389090934784,
  "created_at" : "2013-10-08 02:17:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VeTmRw3t5Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9TxvKsEU",
      "display_url" : "pastebin.com\/raw.php?i=9Txv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387399797398728705",
  "text" : "http:\/\/t.co\/VeTmRw3t5Y Emails: 143 Keywords: 0.33 #infoleak",
  "id" : 387399797398728705,
  "created_at" : "2013-10-08 02:11:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vQWhAnyk1s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NhkXsfbF",
      "display_url" : "pastebin.com\/raw.php?i=NhkX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387242758139695104",
  "text" : "http:\/\/t.co\/vQWhAnyk1s Emails: 24 Keywords: -0.03 #infoleak",
  "id" : 387242758139695104,
  "created_at" : "2013-10-07 15:47:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1zy2hi65ay",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7KAqzzsy",
      "display_url" : "pastebin.com\/raw.php?i=7KAq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387242705241133056",
  "text" : "http:\/\/t.co\/1zy2hi65ay Emails: 294 Keywords: 0.22 #infoleak",
  "id" : 387242705241133056,
  "created_at" : "2013-10-07 15:47:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7Wvw5HSy7G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GSHhQzgE",
      "display_url" : "pastebin.com\/raw.php?i=GSHh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387238169168461824",
  "text" : "http:\/\/t.co\/7Wvw5HSy7G Emails: 197 Keywords: 0.11 #infoleak",
  "id" : 387238169168461824,
  "created_at" : "2013-10-07 15:29:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LVWYcSpCwe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f3Vj2BEJ",
      "display_url" : "pastebin.com\/raw.php?i=f3Vj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387233996972625920",
  "text" : "http:\/\/t.co\/LVWYcSpCwe Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 387233996972625920,
  "created_at" : "2013-10-07 15:12:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XUIpm8Ce0B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DP6kemFn",
      "display_url" : "pastebin.com\/raw.php?i=DP6k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387232434682490881",
  "text" : "http:\/\/t.co\/XUIpm8Ce0B Emails: 135 Keywords: 0.33 #infoleak",
  "id" : 387232434682490881,
  "created_at" : "2013-10-07 15:06:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wqdr2WWiHu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TXJFpg0D",
      "display_url" : "pastebin.com\/raw.php?i=TXJF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387214937522573312",
  "text" : "http:\/\/t.co\/wqdr2WWiHu Emails: 721 Keywords: 0.44 #infoleak",
  "id" : 387214937522573312,
  "created_at" : "2013-10-07 13:56:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nqVxEFsyLg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hcZeRiJf",
      "display_url" : "pastebin.com\/raw.php?i=hcZe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387192692297322499",
  "text" : "http:\/\/t.co\/nqVxEFsyLg Emails: 242 Keywords: 0.22 #infoleak",
  "id" : 387192692297322499,
  "created_at" : "2013-10-07 12:28:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Dq1fXnMdQi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sMDaSfnX",
      "display_url" : "pastebin.com\/raw.php?i=sMDa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387190337879306240",
  "text" : "http:\/\/t.co\/Dq1fXnMdQi Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 387190337879306240,
  "created_at" : "2013-10-07 12:19:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fc1yGmndWu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8Z1zSZKs",
      "display_url" : "pastebin.com\/raw.php?i=8Z1z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387189374296653824",
  "text" : "http:\/\/t.co\/Fc1yGmndWu Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 387189374296653824,
  "created_at" : "2013-10-07 12:15:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lasvNYa9Kl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tMSiDHiX",
      "display_url" : "pastebin.com\/raw.php?i=tMSi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387167468067635200",
  "text" : "http:\/\/t.co\/lasvNYa9Kl Hashes: 60 Keywords: 0.22 #infoleak",
  "id" : 387167468067635200,
  "created_at" : "2013-10-07 10:48:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pLJnxOxEBL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mYVAruGZ",
      "display_url" : "pastebin.com\/raw.php?i=mYVA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387155854618673152",
  "text" : "http:\/\/t.co\/pLJnxOxEBL Emails: 20 Keywords: 0.22 #infoleak",
  "id" : 387155854618673152,
  "created_at" : "2013-10-07 10:02:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DbHSFgSmLq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BUB3gqDW",
      "display_url" : "pastebin.com\/raw.php?i=BUB3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387033473401094144",
  "text" : "http:\/\/t.co\/DbHSFgSmLq Emails: 25 Keywords: 0.19 #infoleak",
  "id" : 387033473401094144,
  "created_at" : "2013-10-07 01:55:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lfpaCDyrxU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cg8utezp",
      "display_url" : "pastebin.com\/raw.php?i=cg8u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387032715821731841",
  "text" : "http:\/\/t.co\/lfpaCDyrxU Emails: 68 Keywords: 0.33 #infoleak",
  "id" : 387032715821731841,
  "created_at" : "2013-10-07 01:52:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tA2L3AaU4r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nMLJpd1G",
      "display_url" : "pastebin.com\/raw.php?i=nMLJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387030503175356416",
  "text" : "http:\/\/t.co\/tA2L3AaU4r Hashes: 2 Keywords: 0.55 #infoleak",
  "id" : 387030503175356416,
  "created_at" : "2013-10-07 01:43:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yu3XKd74K2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kV3QrMLS",
      "display_url" : "pastebin.com\/raw.php?i=kV3Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387025665377058817",
  "text" : "http:\/\/t.co\/Yu3XKd74K2 Emails: 47 Keywords: 0.11 #infoleak",
  "id" : 387025665377058817,
  "created_at" : "2013-10-07 01:24:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pj6051ClV3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G7SJ0sMx",
      "display_url" : "pastebin.com\/raw.php?i=G7SJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387024681225551872",
  "text" : "http:\/\/t.co\/pj6051ClV3 Emails: 47 Keywords: 0.11 #infoleak",
  "id" : 387024681225551872,
  "created_at" : "2013-10-07 01:20:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CnEkPNYiVb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sCpSY9qj",
      "display_url" : "pastebin.com\/raw.php?i=sCpS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387003863657508864",
  "text" : "http:\/\/t.co\/CnEkPNYiVb Emails: 3091 Hashes: 11 E\/H: 281.0 Keywords: 0.19 #infoleak",
  "id" : 387003863657508864,
  "created_at" : "2013-10-06 23:58:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/faC54DJdZI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EdnpTXNp",
      "display_url" : "pastebin.com\/raw.php?i=Ednp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386997199218810880",
  "text" : "http:\/\/t.co\/faC54DJdZI Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 386997199218810880,
  "created_at" : "2013-10-06 23:31:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o7VCYORk5q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eu6tMEFC",
      "display_url" : "pastebin.com\/raw.php?i=eu6t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386976700900196352",
  "text" : "http:\/\/t.co\/o7VCYORk5q Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 386976700900196352,
  "created_at" : "2013-10-06 22:10:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XpcD7lUF88",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bqb1dubr",
      "display_url" : "pastebin.com\/raw.php?i=Bqb1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386976353204961282",
  "text" : "http:\/\/t.co\/XpcD7lUF88 Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 386976353204961282,
  "created_at" : "2013-10-06 22:08:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TwNJ63Lu0T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kxinB5Ng",
      "display_url" : "pastebin.com\/raw.php?i=kxin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386976259915272192",
  "text" : "http:\/\/t.co\/TwNJ63Lu0T Emails: 466 Keywords: -0.03 #infoleak",
  "id" : 386976259915272192,
  "created_at" : "2013-10-06 22:08:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jomOPWi5px",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VRw8pTCn",
      "display_url" : "pastebin.com\/raw.php?i=VRw8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386974355952922626",
  "text" : "http:\/\/t.co\/jomOPWi5px Emails: 21 Keywords: 0.19 #infoleak",
  "id" : 386974355952922626,
  "created_at" : "2013-10-06 22:00:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5a0AeUIgS5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iY7Yb8sB",
      "display_url" : "pastebin.com\/raw.php?i=iY7Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386972479895257088",
  "text" : "http:\/\/t.co\/5a0AeUIgS5 Possible cisco configuration #infoleak",
  "id" : 386972479895257088,
  "created_at" : "2013-10-06 21:53:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/coE9Lw4bJR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T2kdP8Wi",
      "display_url" : "pastebin.com\/raw.php?i=T2kd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386972024762937344",
  "text" : "http:\/\/t.co\/coE9Lw4bJR Emails: 1 Hashes: 4519 E\/H: 0.0 Keywords: 0.41 #infoleak",
  "id" : 386972024762937344,
  "created_at" : "2013-10-06 21:51:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/05VBWOC2Ur",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gsj3Ee4P",
      "display_url" : "pastebin.com\/raw.php?i=Gsj3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386966386544627712",
  "text" : "http:\/\/t.co\/05VBWOC2Ur Emails: 66 Keywords: -0.14 #infoleak",
  "id" : 386966386544627712,
  "created_at" : "2013-10-06 21:29:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NoieOH42Qp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T16EqkkB",
      "display_url" : "pastebin.com\/raw.php?i=T16E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386962870568644608",
  "text" : "http:\/\/t.co\/NoieOH42Qp Emails: 1 Hashes: 9911 E\/H: 0.0 Keywords: 0.3 #infoleak",
  "id" : 386962870568644608,
  "created_at" : "2013-10-06 21:15:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VUYkbk7ng7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=52DF2vtd",
      "display_url" : "pastebin.com\/raw.php?i=52DF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386953784514998272",
  "text" : "http:\/\/t.co\/VUYkbk7ng7 Emails: 3886 Keywords: -0.03 #infoleak",
  "id" : 386953784514998272,
  "created_at" : "2013-10-06 20:39:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1ToaRCrove",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y1qrsgxQ",
      "display_url" : "pastebin.com\/raw.php?i=Y1qr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386951292376997888",
  "text" : "http:\/\/t.co\/1ToaRCrove Hashes: 37 Keywords: 0.0 #infoleak",
  "id" : 386951292376997888,
  "created_at" : "2013-10-06 20:29:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RmNWUllxyE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GbL8VLU9",
      "display_url" : "pastebin.com\/raw.php?i=GbL8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386946789619691520",
  "text" : "http:\/\/t.co\/RmNWUllxyE Hashes: 50 Keywords: 0.11 #infoleak",
  "id" : 386946789619691520,
  "created_at" : "2013-10-06 20:11:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YX6BC7qbie",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y4PqZmMi",
      "display_url" : "pastebin.com\/raw.php?i=Y4Pq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386946041406160896",
  "text" : "http:\/\/t.co\/YX6BC7qbie Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 386946041406160896,
  "created_at" : "2013-10-06 20:08:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wcfXaSDxDY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=knLqtV59",
      "display_url" : "pastebin.com\/raw.php?i=knLq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386931903598567424",
  "text" : "http:\/\/t.co\/wcfXaSDxDY Keywords: 0.66 #infoleak",
  "id" : 386931903598567424,
  "created_at" : "2013-10-06 19:12:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/POR4v41R93",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PBNzfhrR",
      "display_url" : "pastebin.com\/raw.php?i=PBNz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386925064328712192",
  "text" : "http:\/\/t.co\/POR4v41R93 Emails: 43 Keywords: 0.33 #infoleak",
  "id" : 386925064328712192,
  "created_at" : "2013-10-06 18:44:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6kI0xOnfCJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nNR2iCsJ",
      "display_url" : "pastebin.com\/raw.php?i=nNR2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386924549645676544",
  "text" : "http:\/\/t.co\/6kI0xOnfCJ Emails: 43 Keywords: 0.33 #infoleak",
  "id" : 386924549645676544,
  "created_at" : "2013-10-06 18:42:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RYj0SzRe0I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SgfCe3yD",
      "display_url" : "pastebin.com\/raw.php?i=SgfC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386924422621171713",
  "text" : "http:\/\/t.co\/RYj0SzRe0I Emails: 43 Keywords: 0.33 #infoleak",
  "id" : 386924422621171713,
  "created_at" : "2013-10-06 18:42:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uXsg0pE8qT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J7RCMy8H",
      "display_url" : "pastebin.com\/raw.php?i=J7RC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386921268529729536",
  "text" : "http:\/\/t.co\/uXsg0pE8qT Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 386921268529729536,
  "created_at" : "2013-10-06 18:29:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JglOzbc34U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EBkRzEME",
      "display_url" : "pastebin.com\/raw.php?i=EBkR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386920197908488192",
  "text" : "http:\/\/t.co\/JglOzbc34U Emails: 25 Keywords: 0.08 #infoleak",
  "id" : 386920197908488192,
  "created_at" : "2013-10-06 18:25:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yVcj6AEkIb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8hdCvnyK",
      "display_url" : "pastebin.com\/raw.php?i=8hdC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386903911027580928",
  "text" : "http:\/\/t.co\/yVcj6AEkIb Emails: 5 Keywords: 0.55 #infoleak",
  "id" : 386903911027580928,
  "created_at" : "2013-10-06 17:20:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jXzeO4Wu9Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bHBnzB0h",
      "display_url" : "pastebin.com\/raw.php?i=bHBn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386897408468070400",
  "text" : "http:\/\/t.co\/jXzeO4Wu9Z Emails: 571 Hashes: 18 E\/H: 31.72 Keywords: 0.08 #infoleak",
  "id" : 386897408468070400,
  "created_at" : "2013-10-06 16:55:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VjzZ9iQYBG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PEG6aygy",
      "display_url" : "pastebin.com\/raw.php?i=PEG6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386879601621757952",
  "text" : "http:\/\/t.co\/VjzZ9iQYBG Emails: 62 Keywords: 0.0 #infoleak",
  "id" : 386879601621757952,
  "created_at" : "2013-10-06 15:44:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mOZkHtorEB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xh12v6Qj",
      "display_url" : "pastebin.com\/raw.php?i=xh12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386626759459749888",
  "text" : "http:\/\/t.co\/mOZkHtorEB Emails: 37 Keywords: 0.22 #infoleak",
  "id" : 386626759459749888,
  "created_at" : "2013-10-05 22:59:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t7sa284vcx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ejqWHgHK",
      "display_url" : "pastebin.com\/raw.php?i=ejqW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386615048543547392",
  "text" : "http:\/\/t.co\/t7sa284vcx Emails: 133 Keywords: -0.03 #infoleak",
  "id" : 386615048543547392,
  "created_at" : "2013-10-05 22:13:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KsjkNWcQj8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vt0e5WDa",
      "display_url" : "pastebin.com\/raw.php?i=vt0e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386611167763771392",
  "text" : "http:\/\/t.co\/KsjkNWcQj8 Hashes: 3 Keywords: 0.66 #infoleak",
  "id" : 386611167763771392,
  "created_at" : "2013-10-05 21:57:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jJoq1fta0M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yznt149w",
      "display_url" : "pastebin.com\/raw.php?i=yznt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386608011180924928",
  "text" : "http:\/\/t.co\/jJoq1fta0M Hashes: 1 Keywords: 0.55 #infoleak",
  "id" : 386608011180924928,
  "created_at" : "2013-10-05 21:45:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EbWyyxHQay",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xfWdQs8j",
      "display_url" : "pastebin.com\/raw.php?i=xfWd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386606240375128064",
  "text" : "http:\/\/t.co\/EbWyyxHQay Hashes: 224 Keywords: 0.11 #infoleak",
  "id" : 386606240375128064,
  "created_at" : "2013-10-05 21:38:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IuNiqd5fgl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Wtx7ETzD",
      "display_url" : "pastebin.com\/raw.php?i=Wtx7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386604436170084352",
  "text" : "http:\/\/t.co\/IuNiqd5fgl Hashes: 62 Keywords: 0.08 #infoleak",
  "id" : 386604436170084352,
  "created_at" : "2013-10-05 21:30:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fMfTFR7xjJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q71Fys4e",
      "display_url" : "pastebin.com\/raw.php?i=q71F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386560080759361536",
  "text" : "http:\/\/t.co\/fMfTFR7xjJ Hashes: 166 Keywords: 0.11 #infoleak",
  "id" : 386560080759361536,
  "created_at" : "2013-10-05 18:34:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xXMS0RvDMS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F7bxCUac",
      "display_url" : "pastebin.com\/raw.php?i=F7bx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386555768910012416",
  "text" : "http:\/\/t.co\/xXMS0RvDMS Found possible Google API key(s) #infoleak",
  "id" : 386555768910012416,
  "created_at" : "2013-10-05 18:17:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9s4mPhUW3W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y0PRKb9S",
      "display_url" : "pastebin.com\/raw.php?i=y0PR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386541857938751488",
  "text" : "http:\/\/t.co\/9s4mPhUW3W Hashes: 252 Keywords: 0.0 #infoleak",
  "id" : 386541857938751488,
  "created_at" : "2013-10-05 17:22:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/myEYt9PV5i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j1ghuT8F",
      "display_url" : "pastebin.com\/raw.php?i=j1gh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386518342548209664",
  "text" : "http:\/\/t.co\/myEYt9PV5i Found possible Google API key(s) #infoleak",
  "id" : 386518342548209664,
  "created_at" : "2013-10-05 15:48:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KAwUOZQgOL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aRDLbpny",
      "display_url" : "pastebin.com\/raw.php?i=aRDL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386512046671396864",
  "text" : "http:\/\/t.co\/KAwUOZQgOL Emails: 223 Keywords: 0.0 #infoleak",
  "id" : 386512046671396864,
  "created_at" : "2013-10-05 15:23:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JxScCB9Vf3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wrCBwbFB",
      "display_url" : "pastebin.com\/raw.php?i=wrCB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386510430438322176",
  "text" : "http:\/\/t.co\/JxScCB9Vf3 Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 386510430438322176,
  "created_at" : "2013-10-05 15:17:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rEPUmb0DR6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GJ8Uyic6",
      "display_url" : "pastebin.com\/raw.php?i=GJ8U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386509152761036800",
  "text" : "http:\/\/t.co\/rEPUmb0DR6 Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 386509152761036800,
  "created_at" : "2013-10-05 15:12:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jx6hCkwvGa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UURBfQzZ",
      "display_url" : "pastebin.com\/raw.php?i=UURB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386504102353453057",
  "text" : "http:\/\/t.co\/jx6hCkwvGa Hashes: 1620 Keywords: 0.0 #infoleak",
  "id" : 386504102353453057,
  "created_at" : "2013-10-05 14:52:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CFolpfy0Wc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xNHR7aH4",
      "display_url" : "pastebin.com\/raw.php?i=xNHR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386502521436389376",
  "text" : "http:\/\/t.co\/CFolpfy0Wc Found possible Google API key(s) #infoleak",
  "id" : 386502521436389376,
  "created_at" : "2013-10-05 14:45:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7WUYYnUT9L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wsQhkVAg",
      "display_url" : "pastebin.com\/raw.php?i=wsQh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386500718196031488",
  "text" : "http:\/\/t.co\/7WUYYnUT9L Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 386500718196031488,
  "created_at" : "2013-10-05 14:38:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IuqjbEwE3i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bvizRSrv",
      "display_url" : "pastebin.com\/raw.php?i=bviz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386500049204559873",
  "text" : "http:\/\/t.co\/IuqjbEwE3i Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 386500049204559873,
  "created_at" : "2013-10-05 14:36:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KM5DSEjjTN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R7H1QVfH",
      "display_url" : "pastebin.com\/raw.php?i=R7H1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386498790456184832",
  "text" : "http:\/\/t.co\/KM5DSEjjTN Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 386498790456184832,
  "created_at" : "2013-10-05 14:31:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CgaQtRpN21",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T9SJzg6z",
      "display_url" : "pastebin.com\/raw.php?i=T9SJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386497859056455680",
  "text" : "http:\/\/t.co\/CgaQtRpN21 Keywords: 0.55 #infoleak",
  "id" : 386497859056455680,
  "created_at" : "2013-10-05 14:27:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZzruC7qPyB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=csXCEnSn",
      "display_url" : "pastebin.com\/raw.php?i=csXC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386497171970719744",
  "text" : "http:\/\/t.co\/ZzruC7qPyB Hashes: 330 Keywords: 0.0 #infoleak",
  "id" : 386497171970719744,
  "created_at" : "2013-10-05 14:24:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w5gtI8s3NQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a6C8sHur",
      "display_url" : "pastebin.com\/raw.php?i=a6C8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386495323658416128",
  "text" : "http:\/\/t.co\/w5gtI8s3NQ Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 386495323658416128,
  "created_at" : "2013-10-05 14:17:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bqjL6HgUaN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gEzN4eYP",
      "display_url" : "pastebin.com\/raw.php?i=gEzN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386495175922446336",
  "text" : "http:\/\/t.co\/bqjL6HgUaN Hashes: 516 Keywords: 0.0 #infoleak",
  "id" : 386495175922446336,
  "created_at" : "2013-10-05 14:16:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bLqWvaYY1I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mZjENZt7",
      "display_url" : "pastebin.com\/raw.php?i=mZjE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386490908641742848",
  "text" : "http:\/\/t.co\/bLqWvaYY1I Emails: 76 Keywords: 0.44 #infoleak",
  "id" : 386490908641742848,
  "created_at" : "2013-10-05 13:59:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qbueP4WKbp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RL9J5wir",
      "display_url" : "pastebin.com\/raw.php?i=RL9J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386481380340690945",
  "text" : "http:\/\/t.co\/qbueP4WKbp Emails: 3888 Hashes: 9057 E\/H: 0.43 Keywords: 0.44 #infoleak",
  "id" : 386481380340690945,
  "created_at" : "2013-10-05 13:21:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rYWywMGfNl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qtZ6U2Zs",
      "display_url" : "pastebin.com\/raw.php?i=qtZ6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386399852118016000",
  "text" : "http:\/\/t.co\/rYWywMGfNl Emails: 199 Keywords: 0.44 #infoleak",
  "id" : 386399852118016000,
  "created_at" : "2013-10-05 07:57:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xWQ1RTset4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xRukMi65",
      "display_url" : "pastebin.com\/raw.php?i=xRuk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386321528335237120",
  "text" : "http:\/\/t.co\/xWQ1RTset4 Hashes: 62 Keywords: -0.14 #infoleak",
  "id" : 386321528335237120,
  "created_at" : "2013-10-05 02:46:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D8U8mTgXgL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BviCRqXe",
      "display_url" : "pastebin.com\/raw.php?i=BviC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386319022892916736",
  "text" : "http:\/\/t.co\/D8U8mTgXgL Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 386319022892916736,
  "created_at" : "2013-10-05 02:36:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OD4G58uYTd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bRPmySjS",
      "display_url" : "pastebin.com\/raw.php?i=bRPm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386318645615288320",
  "text" : "http:\/\/t.co\/OD4G58uYTd Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 386318645615288320,
  "created_at" : "2013-10-05 02:35:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e2voQVJ3W0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s4bR9Hki",
      "display_url" : "pastebin.com\/raw.php?i=s4bR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386309955063521281",
  "text" : "http:\/\/t.co\/e2voQVJ3W0 Hashes: 1333 Keywords: 0.0 #infoleak",
  "id" : 386309955063521281,
  "created_at" : "2013-10-05 02:00:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/McmJ2XCjT6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BSMGVZJ1",
      "display_url" : "pastebin.com\/raw.php?i=BSMG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386303019769270273",
  "text" : "http:\/\/t.co\/McmJ2XCjT6 Keywords: 0.66 #infoleak",
  "id" : 386303019769270273,
  "created_at" : "2013-10-05 01:33:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f49CAg4dl5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y7uVBbDW",
      "display_url" : "pastebin.com\/raw.php?i=Y7uV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386288413734760448",
  "text" : "http:\/\/t.co\/f49CAg4dl5 Keywords: 0.55 #infoleak",
  "id" : 386288413734760448,
  "created_at" : "2013-10-05 00:35:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sZHR9A5o3U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hKywm1bH",
      "display_url" : "pastebin.com\/raw.php?i=hKyw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386287991179599872",
  "text" : "http:\/\/t.co\/sZHR9A5o3U Keywords: 0.55 #infoleak",
  "id" : 386287991179599872,
  "created_at" : "2013-10-05 00:33:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XZv6pY4dVb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6bxEApaa",
      "display_url" : "pastebin.com\/raw.php?i=6bxE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386285788033327104",
  "text" : "http:\/\/t.co\/XZv6pY4dVb Keywords: 0.55 #infoleak",
  "id" : 386285788033327104,
  "created_at" : "2013-10-05 00:24:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oullfTAaeN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0FytemE4",
      "display_url" : "pastebin.com\/raw.php?i=0Fyt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386283142069231616",
  "text" : "http:\/\/t.co\/oullfTAaeN Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 386283142069231616,
  "created_at" : "2013-10-05 00:14:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jPfdEuRSPB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wYy9iJn0",
      "display_url" : "pastebin.com\/raw.php?i=wYy9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386275698416951296",
  "text" : "http:\/\/t.co\/jPfdEuRSPB Keywords: 0.55 #infoleak",
  "id" : 386275698416951296,
  "created_at" : "2013-10-04 23:44:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kh3Nd9sCGJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CxaeLtWH",
      "display_url" : "pastebin.com\/raw.php?i=Cxae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386255680027365376",
  "text" : "http:\/\/t.co\/Kh3Nd9sCGJ Hashes: 226 Keywords: 0.11 #infoleak",
  "id" : 386255680027365376,
  "created_at" : "2013-10-04 22:25:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UjhpnezRPb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tmAUed8u",
      "display_url" : "pastebin.com\/raw.php?i=tmAU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386253006062120960",
  "text" : "http:\/\/t.co\/UjhpnezRPb Keywords: 0.55 #infoleak",
  "id" : 386253006062120960,
  "created_at" : "2013-10-04 22:14:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i4R64iJZax",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nZ9AxaiQ",
      "display_url" : "pastebin.com\/raw.php?i=nZ9A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386245790668042242",
  "text" : "http:\/\/t.co\/i4R64iJZax Emails: 58 Hashes: 58 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 386245790668042242,
  "created_at" : "2013-10-04 21:45:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/79FCdjvCzR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DXFT6JFj",
      "display_url" : "pastebin.com\/raw.php?i=DXFT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386244325769629696",
  "text" : "http:\/\/t.co\/79FCdjvCzR Keywords: 0.55 #infoleak",
  "id" : 386244325769629696,
  "created_at" : "2013-10-04 21:39:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LkCveldrOL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6Rhb2vjW",
      "display_url" : "pastebin.com\/raw.php?i=6Rhb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386233525306793984",
  "text" : "http:\/\/t.co\/LkCveldrOL Keywords: 0.55 #infoleak",
  "id" : 386233525306793984,
  "created_at" : "2013-10-04 20:57:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N11JxOMjEb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xXvt4MPZ",
      "display_url" : "pastebin.com\/raw.php?i=xXvt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386233045784616960",
  "text" : "http:\/\/t.co\/N11JxOMjEb Keywords: 0.55 #infoleak",
  "id" : 386233045784616960,
  "created_at" : "2013-10-04 20:55:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4IFO63lRTa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1P7XaWHX",
      "display_url" : "pastebin.com\/raw.php?i=1P7X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386227564504571904",
  "text" : "http:\/\/t.co\/4IFO63lRTa Emails: 646 Keywords: 0.11 #infoleak",
  "id" : 386227564504571904,
  "created_at" : "2013-10-04 20:33:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NdedCC6ByS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z2wRc5id",
      "display_url" : "pastebin.com\/raw.php?i=z2wR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386227186337722368",
  "text" : "http:\/\/t.co\/NdedCC6ByS Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 386227186337722368,
  "created_at" : "2013-10-04 20:31:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rN5QmPb1mJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wKLUHZMT",
      "display_url" : "pastebin.com\/raw.php?i=wKLU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386221986092818432",
  "text" : "http:\/\/t.co\/rN5QmPb1mJ Keywords: 0.77 #infoleak",
  "id" : 386221986092818432,
  "created_at" : "2013-10-04 20:11:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qLIfSR6qj4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XS9p9rZx",
      "display_url" : "pastebin.com\/raw.php?i=XS9p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386189631357603841",
  "text" : "http:\/\/t.co\/qLIfSR6qj4 Hashes: 54 Keywords: 0.16 #infoleak",
  "id" : 386189631357603841,
  "created_at" : "2013-10-04 18:02:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mb3WeJNCWW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ydszefwe",
      "display_url" : "pastebin.com\/raw.php?i=Ydsz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386187460964651008",
  "text" : "http:\/\/t.co\/Mb3WeJNCWW Possible cisco configuration #infoleak",
  "id" : 386187460964651008,
  "created_at" : "2013-10-04 17:54:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K76DWETFg6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LJAihhtQ",
      "display_url" : "pastebin.com\/raw.php?i=LJAi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386184783639756800",
  "text" : "http:\/\/t.co\/K76DWETFg6 Emails: 405 Keywords: 0.11 #infoleak",
  "id" : 386184783639756800,
  "created_at" : "2013-10-04 17:43:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PXIhaDGlUT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3aQsPd5w",
      "display_url" : "pastebin.com\/raw.php?i=3aQs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386180620323282944",
  "text" : "http:\/\/t.co\/PXIhaDGlUT Emails: 545 Keywords: 0.33 #infoleak",
  "id" : 386180620323282944,
  "created_at" : "2013-10-04 17:26:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8ttY5Bugo5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hWkKU4QR",
      "display_url" : "pastebin.com\/raw.php?i=hWkK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386178632873308160",
  "text" : "http:\/\/t.co\/8ttY5Bugo5 Hashes: 55 Keywords: 0.22 #infoleak",
  "id" : 386178632873308160,
  "created_at" : "2013-10-04 17:18:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TInWbJGb7W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wdZND2YR",
      "display_url" : "pastebin.com\/raw.php?i=wdZN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386172367682035713",
  "text" : "http:\/\/t.co\/TInWbJGb7W Emails: 31 Keywords: -0.03 #infoleak",
  "id" : 386172367682035713,
  "created_at" : "2013-10-04 16:54:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MmZ3G777GB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=USHJ2Daw",
      "display_url" : "pastebin.com\/raw.php?i=USHJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386170776702836737",
  "text" : "http:\/\/t.co\/MmZ3G777GB Emails: 1447 Keywords: 0.33 #infoleak",
  "id" : 386170776702836737,
  "created_at" : "2013-10-04 16:47:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CbGZKWvi7e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gFiG2xuk",
      "display_url" : "pastebin.com\/raw.php?i=gFiG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386156420694962176",
  "text" : "http:\/\/t.co\/CbGZKWvi7e Keywords: 0.63 #infoleak",
  "id" : 386156420694962176,
  "created_at" : "2013-10-04 15:50:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E6z0Isq695",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wAFFuqnH",
      "display_url" : "pastebin.com\/raw.php?i=wAFF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386152423061864448",
  "text" : "http:\/\/t.co\/E6z0Isq695 Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 386152423061864448,
  "created_at" : "2013-10-04 15:34:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G01Y5rizvi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4PYQWhjK",
      "display_url" : "pastebin.com\/raw.php?i=4PYQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386150764919267328",
  "text" : "http:\/\/t.co\/G01Y5rizvi Emails: 29 Keywords: -0.03 #infoleak",
  "id" : 386150764919267328,
  "created_at" : "2013-10-04 15:28:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IKU1ATw8HJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JRdBybZZ",
      "display_url" : "pastebin.com\/raw.php?i=JRdB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386150653447254016",
  "text" : "http:\/\/t.co\/IKU1ATw8HJ Hashes: 176 Keywords: 0.08 #infoleak",
  "id" : 386150653447254016,
  "created_at" : "2013-10-04 15:27:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jc6eJefAMj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jFdM8Qwb",
      "display_url" : "pastebin.com\/raw.php?i=jFdM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386149142545702913",
  "text" : "http:\/\/t.co\/jc6eJefAMj Emails: 27 Keywords: -0.06 #infoleak",
  "id" : 386149142545702913,
  "created_at" : "2013-10-04 15:21:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TLmtImew1C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vZyjdx1p",
      "display_url" : "pastebin.com\/raw.php?i=vZyj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386076612292128769",
  "text" : "http:\/\/t.co\/TLmtImew1C Found possible Google API key(s) #infoleak",
  "id" : 386076612292128769,
  "created_at" : "2013-10-04 10:33:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0Z1qZxzF4f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cmVdxjc8",
      "display_url" : "pastebin.com\/raw.php?i=cmVd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386050036041146368",
  "text" : "http:\/\/t.co\/0Z1qZxzF4f Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 386050036041146368,
  "created_at" : "2013-10-04 08:47:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YjxFuXSoXm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4BCydicw",
      "display_url" : "pastebin.com\/raw.php?i=4BCy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386043558701985792",
  "text" : "http:\/\/t.co\/YjxFuXSoXm Emails: 119 Keywords: 0.44 #infoleak",
  "id" : 386043558701985792,
  "created_at" : "2013-10-04 08:22:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OfKSNt8bOp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FNDNkzpE",
      "display_url" : "pastebin.com\/raw.php?i=FNDN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386022100453957632",
  "text" : "http:\/\/t.co\/OfKSNt8bOp Emails: 28 Keywords: 0.11 #infoleak",
  "id" : 386022100453957632,
  "created_at" : "2013-10-04 06:56:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sKjuvMM6hc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZrkvB77z",
      "display_url" : "pastebin.com\/raw.php?i=Zrkv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386007554834169856",
  "text" : "http:\/\/t.co\/sKjuvMM6hc Emails: 26 Keywords: 0.08 #infoleak",
  "id" : 386007554834169856,
  "created_at" : "2013-10-04 05:59:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iszKnSGEX7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bf9QTvU5",
      "display_url" : "pastebin.com\/raw.php?i=bf9Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385978763483164672",
  "text" : "http:\/\/t.co\/iszKnSGEX7 Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 385978763483164672,
  "created_at" : "2013-10-04 04:04:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/waIIiEXVfK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JY4iJbET",
      "display_url" : "pastebin.com\/raw.php?i=JY4i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385962785454039040",
  "text" : "http:\/\/t.co\/waIIiEXVfK Emails: 92 Keywords: 0.0 #infoleak",
  "id" : 385962785454039040,
  "created_at" : "2013-10-04 03:01:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AaqiUeOhct",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HE3k2g7z",
      "display_url" : "pastebin.com\/raw.php?i=HE3k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385947693001871360",
  "text" : "http:\/\/t.co\/AaqiUeOhct Found possible Google API key(s) #infoleak",
  "id" : 385947693001871360,
  "created_at" : "2013-10-04 02:01:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9c3dsGa5v6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UUWfiyZp",
      "display_url" : "pastebin.com\/raw.php?i=UUWf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385940944966520832",
  "text" : "http:\/\/t.co\/9c3dsGa5v6 Emails: 133 Keywords: -0.03 #infoleak",
  "id" : 385940944966520832,
  "created_at" : "2013-10-04 01:34:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Nn6MYputWB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kLyWeahb",
      "display_url" : "pastebin.com\/raw.php?i=kLyW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385935272237481984",
  "text" : "http:\/\/t.co\/Nn6MYputWB Keywords: 0.66 #infoleak",
  "id" : 385935272237481984,
  "created_at" : "2013-10-04 01:11:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/owTNmwZxuq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kcFRuipV",
      "display_url" : "pastebin.com\/raw.php?i=kcFR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385930631630159872",
  "text" : "http:\/\/t.co\/owTNmwZxuq Keywords: 0.66 #infoleak",
  "id" : 385930631630159872,
  "created_at" : "2013-10-04 00:53:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rKpssWbJid",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GmXAbJBv",
      "display_url" : "pastebin.com\/raw.php?i=GmXA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385929383258509312",
  "text" : "http:\/\/t.co\/rKpssWbJid Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 385929383258509312,
  "created_at" : "2013-10-04 00:48:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EroIic6cSX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ub9PniKA",
      "display_url" : "pastebin.com\/raw.php?i=Ub9P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385921217959448576",
  "text" : "http:\/\/t.co\/EroIic6cSX Keywords: 0.55 #infoleak",
  "id" : 385921217959448576,
  "created_at" : "2013-10-04 00:16:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PlMPBh7JYy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=71tT1CZE",
      "display_url" : "pastebin.com\/raw.php?i=71tT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385896572669526016",
  "text" : "http:\/\/t.co\/PlMPBh7JYy Keywords: 0.66 #infoleak",
  "id" : 385896572669526016,
  "created_at" : "2013-10-03 22:38:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h5Bs5Tq3KT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F0HmUfBX",
      "display_url" : "pastebin.com\/raw.php?i=F0Hm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385885784982560768",
  "text" : "http:\/\/t.co\/h5Bs5Tq3KT Emails: 114 Keywords: 0.22 #infoleak",
  "id" : 385885784982560768,
  "created_at" : "2013-10-03 21:55:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kp3ip1UfUB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1eQiHzXZ",
      "display_url" : "pastebin.com\/raw.php?i=1eQi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385870000109547521",
  "text" : "http:\/\/t.co\/kp3ip1UfUB Keywords: 0.55 #infoleak",
  "id" : 385870000109547521,
  "created_at" : "2013-10-03 20:52:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NqZkeycLpq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cd1Au3bH",
      "display_url" : "pastebin.com\/raw.php?i=Cd1A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385869059541045249",
  "text" : "http:\/\/t.co\/NqZkeycLpq Emails: 188 Keywords: 0.11 #infoleak",
  "id" : 385869059541045249,
  "created_at" : "2013-10-03 20:48:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rI6rFjkGtK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ma2VC9X8",
      "display_url" : "pastebin.com\/raw.php?i=Ma2V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385865988152893440",
  "text" : "http:\/\/t.co\/rI6rFjkGtK Hashes: 435 Keywords: 0.02 #infoleak",
  "id" : 385865988152893440,
  "created_at" : "2013-10-03 20:36:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f5pcHEltHM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dd6HvviD",
      "display_url" : "pastebin.com\/raw.php?i=dd6H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385863403484348417",
  "text" : "http:\/\/t.co\/f5pcHEltHM Possible cisco configuration #infoleak",
  "id" : 385863403484348417,
  "created_at" : "2013-10-03 20:26:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wu7FvmYq2J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EHdJeTAr",
      "display_url" : "pastebin.com\/raw.php?i=EHdJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385862772350664704",
  "text" : "http:\/\/t.co\/Wu7FvmYq2J Emails: 73 Hashes: 2 E\/H: 36.5 Keywords: 0.41 #infoleak",
  "id" : 385862772350664704,
  "created_at" : "2013-10-03 20:23:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4IGnc7JwCR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3mUBUNfN",
      "display_url" : "pastebin.com\/raw.php?i=3mUB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385854787024977920",
  "text" : "http:\/\/t.co\/4IGnc7JwCR Emails: 99 Keywords: 0.0 #infoleak",
  "id" : 385854787024977920,
  "created_at" : "2013-10-03 19:52:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o3xuJkPRVv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0LcJjCu8",
      "display_url" : "pastebin.com\/raw.php?i=0LcJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385853498669027328",
  "text" : "http:\/\/t.co\/o3xuJkPRVv Emails: 99 Keywords: 0.0 #infoleak",
  "id" : 385853498669027328,
  "created_at" : "2013-10-03 19:46:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9JA0wRS8G5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RK55SFaQ",
      "display_url" : "pastebin.com\/raw.php?i=RK55\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385851880930148352",
  "text" : "http:\/\/t.co\/9JA0wRS8G5 Emails: 99 Keywords: 0.0 #infoleak",
  "id" : 385851880930148352,
  "created_at" : "2013-10-03 19:40:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C961xpDNiR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7MAegCxh",
      "display_url" : "pastebin.com\/raw.php?i=7MAe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385846256087474177",
  "text" : "http:\/\/t.co\/C961xpDNiR Hashes: 32 Keywords: 0.22 #infoleak",
  "id" : 385846256087474177,
  "created_at" : "2013-10-03 19:18:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nEPIqgfMOq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=edVpBNhk",
      "display_url" : "pastebin.com\/raw.php?i=edVp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385844419011690496",
  "text" : "http:\/\/t.co\/nEPIqgfMOq Keywords: 0.55 #infoleak",
  "id" : 385844419011690496,
  "created_at" : "2013-10-03 19:10:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DOKSaLyTtm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VQ1GHqh2",
      "display_url" : "pastebin.com\/raw.php?i=VQ1G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385839733227540480",
  "text" : "http:\/\/t.co\/DOKSaLyTtm Hashes: 37 Keywords: 0.0 #infoleak",
  "id" : 385839733227540480,
  "created_at" : "2013-10-03 18:52:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LQAOjB1wa6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yS0kXQYa",
      "display_url" : "pastebin.com\/raw.php?i=yS0k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385835314310172673",
  "text" : "http:\/\/t.co\/LQAOjB1wa6 Emails: 415 Hashes: 412 E\/H: 1.01 Keywords: 0.3 #infoleak",
  "id" : 385835314310172673,
  "created_at" : "2013-10-03 18:34:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/szJXl1yUvt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TkLDNLeA",
      "display_url" : "pastebin.com\/raw.php?i=TkLD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385824492481552384",
  "text" : "http:\/\/t.co\/szJXl1yUvt Emails: 478 Keywords: 0.3 #infoleak",
  "id" : 385824492481552384,
  "created_at" : "2013-10-03 17:51:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yfNxRqyC8Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b8WQ6s1T",
      "display_url" : "pastebin.com\/raw.php?i=b8WQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385821216797229056",
  "text" : "http:\/\/t.co\/yfNxRqyC8Y Emails: 72 Keywords: 0.44 #infoleak",
  "id" : 385821216797229056,
  "created_at" : "2013-10-03 17:38:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Oi1mChph9a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nAvkdzhB",
      "display_url" : "pastebin.com\/raw.php?i=nAvk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385818949364891648",
  "text" : "http:\/\/t.co\/Oi1mChph9a Hashes: 32 Keywords: 0.22 #infoleak",
  "id" : 385818949364891648,
  "created_at" : "2013-10-03 17:29:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FRYPZu2hob",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YamRLPxx",
      "display_url" : "pastebin.com\/raw.php?i=YamR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385816906252308481",
  "text" : "http:\/\/t.co\/FRYPZu2hob Emails: 99 Keywords: 0.0 #infoleak",
  "id" : 385816906252308481,
  "created_at" : "2013-10-03 17:21:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "frite",
      "screen_name" : "fr1t3",
      "indices" : [ 0, 6 ],
      "id_str" : "164760816",
      "id" : 164760816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385461895475388416",
  "geo" : { },
  "id_str" : "385815051275235330",
  "in_reply_to_user_id" : 164760816,
  "text" : "@fr1t3 Always glad to help!",
  "id" : 385815051275235330,
  "in_reply_to_status_id" : 385461895475388416,
  "created_at" : "2013-10-03 17:14:10 +0000",
  "in_reply_to_screen_name" : "fr1t3",
  "in_reply_to_user_id_str" : "164760816",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ep7IDb2SGB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2W3jEmjf",
      "display_url" : "pastebin.com\/raw.php?i=2W3j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385805067959271424",
  "text" : "http:\/\/t.co\/Ep7IDb2SGB Emails: 10 Hashes: 10 E\/H: 1.0 Keywords: 0.77 #infoleak",
  "id" : 385805067959271424,
  "created_at" : "2013-10-03 16:34:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wrFJgK04kd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dCG9Wiqq",
      "display_url" : "pastebin.com\/raw.php?i=dCG9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385792561018720256",
  "text" : "http:\/\/t.co\/wrFJgK04kd Emails: 23 Hashes: 8 E\/H: 2.88 Keywords: 0.3 #infoleak",
  "id" : 385792561018720256,
  "created_at" : "2013-10-03 15:44:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HEzHCcW002",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CHiSN9sg",
      "display_url" : "pastebin.com\/raw.php?i=CHiS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385788783121027073",
  "text" : "http:\/\/t.co\/HEzHCcW002 Hashes: 116 Keywords: -0.28 #infoleak",
  "id" : 385788783121027073,
  "created_at" : "2013-10-03 15:29:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VrWYmywZmP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SZBhL4Kf",
      "display_url" : "pastebin.com\/raw.php?i=SZBh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385785109997035520",
  "text" : "http:\/\/t.co\/VrWYmywZmP Emails: 169 Hashes: 336 E\/H: 0.5 Keywords: 0.19 #infoleak",
  "id" : 385785109997035520,
  "created_at" : "2013-10-03 15:15:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sTl4btJFQ3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K8aYffki",
      "display_url" : "pastebin.com\/raw.php?i=K8aY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385771799117447169",
  "text" : "http:\/\/t.co\/sTl4btJFQ3 Possible cisco configuration #infoleak",
  "id" : 385771799117447169,
  "created_at" : "2013-10-03 14:22:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RP4zWSUQjb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1p6XKfHv",
      "display_url" : "pastebin.com\/raw.php?i=1p6X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385771494279614464",
  "text" : "http:\/\/t.co\/RP4zWSUQjb Possible cisco configuration #infoleak",
  "id" : 385771494279614464,
  "created_at" : "2013-10-03 14:21:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AGRHpRfG8t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4Hf37D9H",
      "display_url" : "pastebin.com\/raw.php?i=4Hf3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385767594831007744",
  "text" : "http:\/\/t.co\/AGRHpRfG8t Emails: 5000 Keywords: 0.19 #infoleak",
  "id" : 385767594831007744,
  "created_at" : "2013-10-03 14:05:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MCtnNpODvT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=StPn6rTd",
      "display_url" : "pastebin.com\/raw.php?i=StPn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385762917594836992",
  "text" : "http:\/\/t.co\/MCtnNpODvT Emails: 100 Hashes: 103 E\/H: 0.97 Keywords: 0.44 #infoleak",
  "id" : 385762917594836992,
  "created_at" : "2013-10-03 13:47:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Sol3s8XWUN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eRXfMAAL",
      "display_url" : "pastebin.com\/raw.php?i=eRXf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385761514101039106",
  "text" : "http:\/\/t.co\/Sol3s8XWUN Hashes: 162 Keywords: 0.0 #infoleak",
  "id" : 385761514101039106,
  "created_at" : "2013-10-03 13:41:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nP1Jp26oy3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rTmzjR1n",
      "display_url" : "pastebin.com\/raw.php?i=rTmz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385746518533091329",
  "text" : "http:\/\/t.co\/nP1Jp26oy3 Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 385746518533091329,
  "created_at" : "2013-10-03 12:41:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hyXwCnuCAD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=APv3tEWz",
      "display_url" : "pastebin.com\/raw.php?i=APv3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385734977645576192",
  "text" : "http:\/\/t.co\/hyXwCnuCAD Hashes: 72 Keywords: 0.22 #infoleak",
  "id" : 385734977645576192,
  "created_at" : "2013-10-03 11:55:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ep18KeDfiN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bqczTv46",
      "display_url" : "pastebin.com\/raw.php?i=bqcz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385715070560264192",
  "text" : "http:\/\/t.co\/ep18KeDfiN Emails: 74 Keywords: 0.0 #infoleak",
  "id" : 385715070560264192,
  "created_at" : "2013-10-03 10:36:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BDSfVbaPdq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bZWvSH3E",
      "display_url" : "pastebin.com\/raw.php?i=bZWv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385691936419373056",
  "text" : "http:\/\/t.co\/BDSfVbaPdq Emails: 80 Keywords: 0.44 #infoleak",
  "id" : 385691936419373056,
  "created_at" : "2013-10-03 09:04:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2WlOWalcYU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cf9LvjqX",
      "display_url" : "pastebin.com\/raw.php?i=cf9L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385685988070014980",
  "text" : "http:\/\/t.co\/2WlOWalcYU Keywords: 0.66 #infoleak",
  "id" : 385685988070014980,
  "created_at" : "2013-10-03 08:41:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wfnURMnhRe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PeGe8Aur",
      "display_url" : "pastebin.com\/raw.php?i=PeGe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385646397258596352",
  "text" : "http:\/\/t.co\/wfnURMnhRe Emails: 45 Keywords: 0.11 #infoleak",
  "id" : 385646397258596352,
  "created_at" : "2013-10-03 06:04:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GSdxhcLCXP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3d01qH2Y",
      "display_url" : "pastebin.com\/raw.php?i=3d01\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385607032650203137",
  "text" : "http:\/\/t.co\/GSdxhcLCXP Emails: 104 Hashes: 101 E\/H: 1.03 Keywords: 0.55 #infoleak",
  "id" : 385607032650203137,
  "created_at" : "2013-10-03 03:27:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7poNrzoZ4l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c8hW95wm",
      "display_url" : "pastebin.com\/raw.php?i=c8hW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385605990617341952",
  "text" : "http:\/\/t.co\/7poNrzoZ4l Hashes: 56 Keywords: 0.11 #infoleak",
  "id" : 385605990617341952,
  "created_at" : "2013-10-03 03:23:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uSyxFlPeuu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HSbTDwtK",
      "display_url" : "pastebin.com\/raw.php?i=HSbT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385592222491475968",
  "text" : "http:\/\/t.co\/uSyxFlPeuu Hashes: 238 Keywords: -0.03 #infoleak",
  "id" : 385592222491475968,
  "created_at" : "2013-10-03 02:28:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2NMxmg17I0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Pgmg6meC",
      "display_url" : "pastebin.com\/raw.php?i=Pgmg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385584814142660608",
  "text" : "http:\/\/t.co\/2NMxmg17I0 Emails: 122 Keywords: 0.0 #infoleak",
  "id" : 385584814142660608,
  "created_at" : "2013-10-03 01:59:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eSWgw3qVAa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pDNz4LCw",
      "display_url" : "pastebin.com\/raw.php?i=pDNz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385555888066416640",
  "text" : "http:\/\/t.co\/eSWgw3qVAa Emails: 36 Hashes: 2 E\/H: 18.0 Keywords: 0.19 #infoleak",
  "id" : 385555888066416640,
  "created_at" : "2013-10-03 00:04:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XGSsytcg8k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XJYwdUcM",
      "display_url" : "pastebin.com\/raw.php?i=XJYw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385547495347978240",
  "text" : "http:\/\/t.co\/XGSsytcg8k Hashes: 46 Keywords: 0.11 #infoleak",
  "id" : 385547495347978240,
  "created_at" : "2013-10-02 23:31:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w7jLqpLmV2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nYyi2UD1",
      "display_url" : "pastebin.com\/raw.php?i=nYyi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385544130798948352",
  "text" : "http:\/\/t.co\/w7jLqpLmV2 Emails: 25 Keywords: -0.09 #infoleak",
  "id" : 385544130798948352,
  "created_at" : "2013-10-02 23:17:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s9mvRFluix",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9ti89bdt",
      "display_url" : "pastebin.com\/raw.php?i=9ti8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385543035422928896",
  "text" : "http:\/\/t.co\/s9mvRFluix Emails: 43 Keywords: 0.05 #infoleak",
  "id" : 385543035422928896,
  "created_at" : "2013-10-02 23:13:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m8Nn5RWKQ5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jVg6J1KA",
      "display_url" : "pastebin.com\/raw.php?i=jVg6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385519458128625665",
  "text" : "http:\/\/t.co\/m8Nn5RWKQ5 Keywords: 0.55 #infoleak",
  "id" : 385519458128625665,
  "created_at" : "2013-10-02 21:39:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eq0EzlFKq9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kkpDet3A",
      "display_url" : "pastebin.com\/raw.php?i=kkpD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385517394392670208",
  "text" : "http:\/\/t.co\/eq0EzlFKq9 Keywords: 0.55 #infoleak",
  "id" : 385517394392670208,
  "created_at" : "2013-10-02 21:31:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v8GImNHaU7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FRJr4H7Y",
      "display_url" : "pastebin.com\/raw.php?i=FRJr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385516237192560640",
  "text" : "http:\/\/t.co\/v8GImNHaU7 Keywords: 0.55 #infoleak",
  "id" : 385516237192560640,
  "created_at" : "2013-10-02 21:26:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1giunIr622",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9B4eRRfM",
      "display_url" : "pastebin.com\/raw.php?i=9B4e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385514457415163904",
  "text" : "http:\/\/t.co\/1giunIr622 Keywords: 0.55 #infoleak",
  "id" : 385514457415163904,
  "created_at" : "2013-10-02 21:19:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/twAgVSsFxa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y4MBr4ek",
      "display_url" : "pastebin.com\/raw.php?i=y4MB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385513731423100929",
  "text" : "http:\/\/t.co\/twAgVSsFxa Keywords: 0.55 #infoleak",
  "id" : 385513731423100929,
  "created_at" : "2013-10-02 21:16:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Uiq9nUf3RW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BfKQY9qy",
      "display_url" : "pastebin.com\/raw.php?i=BfKQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385513057620742144",
  "text" : "http:\/\/t.co\/Uiq9nUf3RW Keywords: 0.55 #infoleak",
  "id" : 385513057620742144,
  "created_at" : "2013-10-02 21:14:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QS5tGg7rJi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vinQduiP",
      "display_url" : "pastebin.com\/raw.php?i=vinQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385512569697366016",
  "text" : "http:\/\/t.co\/QS5tGg7rJi Emails: 5 Keywords: 0.55 #infoleak",
  "id" : 385512569697366016,
  "created_at" : "2013-10-02 21:12:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w8FLfYmzrb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nRUpVLV0",
      "display_url" : "pastebin.com\/raw.php?i=nRUp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385512185369067520",
  "text" : "http:\/\/t.co\/w8FLfYmzrb Keywords: 0.55 #infoleak",
  "id" : 385512185369067520,
  "created_at" : "2013-10-02 21:10:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XGvYRTyG8P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=npZqxJL8",
      "display_url" : "pastebin.com\/raw.php?i=npZq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385511208167550976",
  "text" : "http:\/\/t.co\/XGvYRTyG8P Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 385511208167550976,
  "created_at" : "2013-10-02 21:06:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xTOZqp9wZC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=edBnCT3s",
      "display_url" : "pastebin.com\/raw.php?i=edBn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385510939266539520",
  "text" : "http:\/\/t.co\/xTOZqp9wZC Keywords: 0.55 #infoleak",
  "id" : 385510939266539520,
  "created_at" : "2013-10-02 21:05:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zTp39ywqJx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GdXFiqd3",
      "display_url" : "pastebin.com\/raw.php?i=GdXF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385504129524572160",
  "text" : "http:\/\/t.co\/zTp39ywqJx Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 385504129524572160,
  "created_at" : "2013-10-02 20:38:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5Q910RRofW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bVFDcpfU",
      "display_url" : "pastebin.com\/raw.php?i=bVFD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385500161499090946",
  "text" : "http:\/\/t.co\/5Q910RRofW Keywords: 0.55 #infoleak",
  "id" : 385500161499090946,
  "created_at" : "2013-10-02 20:22:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sBbTvKanfH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WP4vaQcK",
      "display_url" : "pastebin.com\/raw.php?i=WP4v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385499711735484416",
  "text" : "http:\/\/t.co\/sBbTvKanfH Keywords: 0.55 #infoleak",
  "id" : 385499711735484416,
  "created_at" : "2013-10-02 20:21:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ym6rWCH7GC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iERDu68g",
      "display_url" : "pastebin.com\/raw.php?i=iERD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385481882424459264",
  "text" : "http:\/\/t.co\/ym6rWCH7GC Emails: 109 Keywords: 0.0 #infoleak",
  "id" : 385481882424459264,
  "created_at" : "2013-10-02 19:10:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sp1C55saMW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WwrBf9Hd",
      "display_url" : "pastebin.com\/raw.php?i=WwrB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385450801423847424",
  "text" : "http:\/\/t.co\/sp1C55saMW Emails: 119 Keywords: 0.0 #infoleak",
  "id" : 385450801423847424,
  "created_at" : "2013-10-02 17:06:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fJvFsm3UCp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D0ZxgudE",
      "display_url" : "pastebin.com\/raw.php?i=D0Zx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385442591556116481",
  "text" : "http:\/\/t.co\/fJvFsm3UCp Emails: 72 Keywords: 0.44 #infoleak",
  "id" : 385442591556116481,
  "created_at" : "2013-10-02 16:34:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3Zo2sME9ar",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=geqqVYf0",
      "display_url" : "pastebin.com\/raw.php?i=geqq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385438577191948288",
  "text" : "http:\/\/t.co\/3Zo2sME9ar Emails: 1 Hashes: 470 E\/H: 0.0 Keywords: 0.19 #infoleak",
  "id" : 385438577191948288,
  "created_at" : "2013-10-02 16:18:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7qoK1K7Ddh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hJ4Yaj4Q",
      "display_url" : "pastebin.com\/raw.php?i=hJ4Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385433104669630464",
  "text" : "http:\/\/t.co\/7qoK1K7Ddh Hashes: 513 Keywords: 0.11 #infoleak",
  "id" : 385433104669630464,
  "created_at" : "2013-10-02 15:56:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kejqQ50ElU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eb4LCydz",
      "display_url" : "pastebin.com\/raw.php?i=eb4L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385433024298381312",
  "text" : "http:\/\/t.co\/kejqQ50ElU Emails: 9 Hashes: 8 E\/H: 1.13 Keywords: 0.55 #infoleak",
  "id" : 385433024298381312,
  "created_at" : "2013-10-02 15:56:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cv7o1O9HBZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pBkeajzY",
      "display_url" : "pastebin.com\/raw.php?i=pBke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385430582131322880",
  "text" : "http:\/\/t.co\/cv7o1O9HBZ Emails: 634 Keywords: 0.0 #infoleak",
  "id" : 385430582131322880,
  "created_at" : "2013-10-02 15:46:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pNHmPxtYzP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pkVZV2wy",
      "display_url" : "pastebin.com\/raw.php?i=pkVZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385428977633865729",
  "text" : "http:\/\/t.co\/pNHmPxtYzP Hashes: 601 Keywords: 0.0 #infoleak",
  "id" : 385428977633865729,
  "created_at" : "2013-10-02 15:40:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gDvVPcyrQq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Pz4akW4t",
      "display_url" : "pastebin.com\/raw.php?i=Pz4a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385428262878318594",
  "text" : "http:\/\/t.co\/gDvVPcyrQq Hashes: 31 Keywords: 0.0 #infoleak",
  "id" : 385428262878318594,
  "created_at" : "2013-10-02 15:37:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8PwkZVOCiH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UzHjup3B",
      "display_url" : "pastebin.com\/raw.php?i=UzHj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385422390412324864",
  "text" : "http:\/\/t.co\/8PwkZVOCiH Emails: 2 Hashes: 6 E\/H: 0.33 Keywords: 0.55 #infoleak",
  "id" : 385422390412324864,
  "created_at" : "2013-10-02 15:13:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/itfy9bLHg4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gh4eQe0q",
      "display_url" : "pastebin.com\/raw.php?i=Gh4e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385407024873226241",
  "text" : "http:\/\/t.co\/itfy9bLHg4 Possible cisco configuration #infoleak",
  "id" : 385407024873226241,
  "created_at" : "2013-10-02 14:12:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wkR0XFzImS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vPvYMnGT",
      "display_url" : "pastebin.com\/raw.php?i=vPvY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385388659567898625",
  "text" : "http:\/\/t.co\/wkR0XFzImS Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 385388659567898625,
  "created_at" : "2013-10-02 12:59:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SCLUMG4sXw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QMPFf0X4",
      "display_url" : "pastebin.com\/raw.php?i=QMPF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385387543841079297",
  "text" : "http:\/\/t.co\/SCLUMG4sXw Hashes: 30 Keywords: 0.22 #infoleak",
  "id" : 385387543841079297,
  "created_at" : "2013-10-02 12:55:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/goD2v7KR4I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=01cyr52Q",
      "display_url" : "pastebin.com\/raw.php?i=01cy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385370328228048896",
  "text" : "http:\/\/t.co\/goD2v7KR4I Emails: 7 Hashes: 2 E\/H: 3.5 Keywords: 0.66 #infoleak",
  "id" : 385370328228048896,
  "created_at" : "2013-10-02 11:47:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cnoAc0ssz4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UYhDPdra",
      "display_url" : "pastebin.com\/raw.php?i=UYhD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385352524326117376",
  "text" : "http:\/\/t.co\/cnoAc0ssz4 Emails: 10 Hashes: 67 E\/H: 0.15 Keywords: -0.14 #infoleak",
  "id" : 385352524326117376,
  "created_at" : "2013-10-02 10:36:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CKzCPPoCnV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=85Cjqg3H",
      "display_url" : "pastebin.com\/raw.php?i=85Cj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385342562950590464",
  "text" : "http:\/\/t.co\/CKzCPPoCnV Hashes: 62 Keywords: 0.0 #infoleak",
  "id" : 385342562950590464,
  "created_at" : "2013-10-02 09:56:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q0ODNYxTwf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=10GY0re9",
      "display_url" : "pastebin.com\/raw.php?i=10GY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385342450505506816",
  "text" : "http:\/\/t.co\/q0ODNYxTwf Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 385342450505506816,
  "created_at" : "2013-10-02 09:56:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1yfLcLUqD5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NbvwiSLb",
      "display_url" : "pastebin.com\/raw.php?i=Nbvw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385342101216452609",
  "text" : "http:\/\/t.co\/1yfLcLUqD5 Emails: 21 Keywords: -0.14 #infoleak",
  "id" : 385342101216452609,
  "created_at" : "2013-10-02 09:54:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2T3tf9D53b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2nMr4XHB",
      "display_url" : "pastebin.com\/raw.php?i=2nMr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385338227428560896",
  "text" : "http:\/\/t.co\/2T3tf9D53b Emails: 18 Hashes: 220 E\/H: 0.08 Keywords: 0.22 #infoleak",
  "id" : 385338227428560896,
  "created_at" : "2013-10-02 09:39:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LHswO1Ue7S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QJuhvs4L",
      "display_url" : "pastebin.com\/raw.php?i=QJuh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385336204503162882",
  "text" : "http:\/\/t.co\/LHswO1Ue7S Emails: 6 Hashes: 146 E\/H: 0.04 Keywords: 0.22 #infoleak",
  "id" : 385336204503162882,
  "created_at" : "2013-10-02 09:31:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rD8TEy4b4M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PbTtK5WQ",
      "display_url" : "pastebin.com\/raw.php?i=PbTt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385330617782509568",
  "text" : "http:\/\/t.co\/rD8TEy4b4M Emails: 119 Keywords: 0.0 #infoleak",
  "id" : 385330617782509568,
  "created_at" : "2013-10-02 09:09:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1xyF8YAnQG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TTBkQvRt",
      "display_url" : "pastebin.com\/raw.php?i=TTBk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385309090928267265",
  "text" : "http:\/\/t.co\/1xyF8YAnQG Keywords: 0.55 #infoleak",
  "id" : 385309090928267265,
  "created_at" : "2013-10-02 07:43:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mDki22eHqo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N4xrjWFb",
      "display_url" : "pastebin.com\/raw.php?i=N4xr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385303792020758528",
  "text" : "http:\/\/t.co\/mDki22eHqo Hashes: 855 Keywords: 0.33 #infoleak",
  "id" : 385303792020758528,
  "created_at" : "2013-10-02 07:22:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bTHqxPdftg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BR5nQ93X",
      "display_url" : "pastebin.com\/raw.php?i=BR5n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385295541170475008",
  "text" : "http:\/\/t.co\/bTHqxPdftg Hashes: 235 Keywords: 0.11 #infoleak",
  "id" : 385295541170475008,
  "created_at" : "2013-10-02 06:49:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pQeiWBDczy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JJ4LP3FA",
      "display_url" : "pastebin.com\/raw.php?i=JJ4L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385273172263571456",
  "text" : "http:\/\/t.co\/pQeiWBDczy Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 385273172263571456,
  "created_at" : "2013-10-02 05:20:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fv5mso29uP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UyEqB76m",
      "display_url" : "pastebin.com\/raw.php?i=UyEq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385270851504836609",
  "text" : "http:\/\/t.co\/Fv5mso29uP Emails: 40 Keywords: 0.11 #infoleak",
  "id" : 385270851504836609,
  "created_at" : "2013-10-02 05:11:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RCk8gp1SaI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nzPFkY5k",
      "display_url" : "pastebin.com\/raw.php?i=nzPF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385256431315730433",
  "text" : "http:\/\/t.co\/RCk8gp1SaI Emails: 74 Keywords: 0.44 #infoleak",
  "id" : 385256431315730433,
  "created_at" : "2013-10-02 04:14:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3tFwu328lF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nA0BF1QE",
      "display_url" : "pastebin.com\/raw.php?i=nA0B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385213417255997440",
  "text" : "http:\/\/t.co\/3tFwu328lF Keywords: 0.55 #infoleak",
  "id" : 385213417255997440,
  "created_at" : "2013-10-02 01:23:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ml8Av3zc3S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JgBuEvNt",
      "display_url" : "pastebin.com\/raw.php?i=JgBu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385200220671197185",
  "text" : "http:\/\/t.co\/ml8Av3zc3S Hashes: 37 Keywords: 0.0 #infoleak",
  "id" : 385200220671197185,
  "created_at" : "2013-10-02 00:31:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3Ci17UdzBv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KgHdx3yf",
      "display_url" : "pastebin.com\/raw.php?i=KgHd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385191393515163649",
  "text" : "http:\/\/t.co\/3Ci17UdzBv Found possible Google API key(s) #infoleak",
  "id" : 385191393515163649,
  "created_at" : "2013-10-01 23:55:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KxOgm7qFze",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hXRv4LXQ",
      "display_url" : "pastebin.com\/raw.php?i=hXRv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385187153702973440",
  "text" : "http:\/\/t.co\/KxOgm7qFze Found possible Google API key(s) #infoleak",
  "id" : 385187153702973440,
  "created_at" : "2013-10-01 23:39:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GecYVZ73S9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BGnX75Xn",
      "display_url" : "pastebin.com\/raw.php?i=BGnX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385180156886659074",
  "text" : "http:\/\/t.co\/GecYVZ73S9 Emails: 877 Keywords: 0.22 #infoleak",
  "id" : 385180156886659074,
  "created_at" : "2013-10-01 23:11:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IJvtlgBR5F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XJu54ZR2",
      "display_url" : "pastebin.com\/raw.php?i=XJu5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385177123087859712",
  "text" : "http:\/\/t.co\/IJvtlgBR5F Emails: 42 Keywords: 0.19 #infoleak",
  "id" : 385177123087859712,
  "created_at" : "2013-10-01 22:59:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3mLqRwtflT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eT5JxKut",
      "display_url" : "pastebin.com\/raw.php?i=eT5J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385164951343468544",
  "text" : "http:\/\/t.co\/3mLqRwtflT Hashes: 31 Keywords: 0.0 #infoleak",
  "id" : 385164951343468544,
  "created_at" : "2013-10-01 22:10:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JJoSOo4IFB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=APZgVnW4",
      "display_url" : "pastebin.com\/raw.php?i=APZg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385161973417009153",
  "text" : "http:\/\/t.co\/JJoSOo4IFB Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 385161973417009153,
  "created_at" : "2013-10-01 21:59:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/suaAFyDZ0t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SPETL0vg",
      "display_url" : "pastebin.com\/raw.php?i=SPET\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385161859042525184",
  "text" : "http:\/\/t.co\/suaAFyDZ0t Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 385161859042525184,
  "created_at" : "2013-10-01 21:58:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VW0pUS3yy2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8EyVjjU8",
      "display_url" : "pastebin.com\/raw.php?i=8EyV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385157041318133760",
  "text" : "http:\/\/t.co\/VW0pUS3yy2 Emails: 877 Keywords: 0.22 #infoleak",
  "id" : 385157041318133760,
  "created_at" : "2013-10-01 21:39:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vQuqH7XV18",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NgXfXDn6",
      "display_url" : "pastebin.com\/raw.php?i=NgXf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385153194210246656",
  "text" : "http:\/\/t.co\/vQuqH7XV18 Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 385153194210246656,
  "created_at" : "2013-10-01 21:24:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jttf8J5itr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=waASY54f",
      "display_url" : "pastebin.com\/raw.php?i=waAS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385146545558925314",
  "text" : "http:\/\/t.co\/jttf8J5itr Emails: 3 Hashes: 1 E\/H: 3.0 Keywords: 0.55 #infoleak",
  "id" : 385146545558925314,
  "created_at" : "2013-10-01 20:57:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SZcayfODHL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=be2qzbBT",
      "display_url" : "pastebin.com\/raw.php?i=be2q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385145117322932224",
  "text" : "http:\/\/t.co\/SZcayfODHL Emails: 9 Hashes: 8 E\/H: 1.13 Keywords: 0.55 #infoleak",
  "id" : 385145117322932224,
  "created_at" : "2013-10-01 20:52:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VTra6Zbvgf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FPe4yAL3",
      "display_url" : "pastebin.com\/raw.php?i=FPe4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385133657549074432",
  "text" : "http:\/\/t.co\/VTra6Zbvgf Hashes: 76 Keywords: 0.11 #infoleak",
  "id" : 385133657549074432,
  "created_at" : "2013-10-01 20:06:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Phc4av77oa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HSCUWGq1",
      "display_url" : "pastebin.com\/raw.php?i=HSCU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385123507790569473",
  "text" : "http:\/\/t.co\/Phc4av77oa Emails: 1 Hashes: 32 E\/H: 0.03 Keywords: 0.11 #infoleak",
  "id" : 385123507790569473,
  "created_at" : "2013-10-01 19:26:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c3iRG57jW9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=asDZbHuL",
      "display_url" : "pastebin.com\/raw.php?i=asDZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385117369342771200",
  "text" : "http:\/\/t.co\/c3iRG57jW9 Emails: 33 Keywords: 0.22 #infoleak",
  "id" : 385117369342771200,
  "created_at" : "2013-10-01 19:01:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WsPWDZi2wI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BKzzpKHQ",
      "display_url" : "pastebin.com\/raw.php?i=BKzz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385115770625085440",
  "text" : "http:\/\/t.co\/WsPWDZi2wI Emails: 1 Hashes: 32 E\/H: 0.03 Keywords: 0.11 #infoleak",
  "id" : 385115770625085440,
  "created_at" : "2013-10-01 18:55:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/houUcTcE0O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5htyM5MD",
      "display_url" : "pastebin.com\/raw.php?i=5hty\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385114502519205888",
  "text" : "http:\/\/t.co\/houUcTcE0O Emails: 272 Keywords: 0.0 #infoleak",
  "id" : 385114502519205888,
  "created_at" : "2013-10-01 18:50:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QVaUmh7gpr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c7uKMa9W",
      "display_url" : "pastebin.com\/raw.php?i=c7uK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385113043761258496",
  "text" : "http:\/\/t.co\/QVaUmh7gpr Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.55 #infoleak",
  "id" : 385113043761258496,
  "created_at" : "2013-10-01 18:44:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6fSCZb5wom",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ubUnDyHw",
      "display_url" : "pastebin.com\/raw.php?i=ubUn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385083716092960768",
  "text" : "http:\/\/t.co\/6fSCZb5wom Possible cisco configuration #infoleak",
  "id" : 385083716092960768,
  "created_at" : "2013-10-01 16:48:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wHLi1JE4EG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rDaiE7af",
      "display_url" : "pastebin.com\/raw.php?i=rDai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385066571481112576",
  "text" : "http:\/\/t.co\/wHLi1JE4EG Hashes: 392 Keywords: 0.11 #infoleak",
  "id" : 385066571481112576,
  "created_at" : "2013-10-01 15:39:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zGcSAeLel5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TSHAAr8B",
      "display_url" : "pastebin.com\/raw.php?i=TSHA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385058213973868546",
  "text" : "http:\/\/t.co\/zGcSAeLel5 Hashes: 391 Keywords: 0.11 #infoleak",
  "id" : 385058213973868546,
  "created_at" : "2013-10-01 15:06:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TFiWTMwGlH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j55pYxz4",
      "display_url" : "pastebin.com\/raw.php?i=j55p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385057983958233088",
  "text" : "http:\/\/t.co\/TFiWTMwGlH Emails: 1274 Keywords: 0.11 #infoleak",
  "id" : 385057983958233088,
  "created_at" : "2013-10-01 15:05:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ugsiMHDnok",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J7k3Setp",
      "display_url" : "pastebin.com\/raw.php?i=J7k3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385057289238900737",
  "text" : "http:\/\/t.co\/ugsiMHDnok Hashes: 340 Keywords: 0.11 #infoleak",
  "id" : 385057289238900737,
  "created_at" : "2013-10-01 15:03:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7HfcilFEBq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jybdyhjm",
      "display_url" : "pastebin.com\/raw.php?i=Jybd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385053239927775233",
  "text" : "http:\/\/t.co\/7HfcilFEBq Emails: 72 Keywords: 0.0 #infoleak",
  "id" : 385053239927775233,
  "created_at" : "2013-10-01 14:47:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0cK0d4VRYc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qWJ2cYwU",
      "display_url" : "pastebin.com\/raw.php?i=qWJ2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385049850150002689",
  "text" : "http:\/\/t.co\/0cK0d4VRYc Keywords: 0.66 #infoleak",
  "id" : 385049850150002689,
  "created_at" : "2013-10-01 14:33:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Og0DEP6GtF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FAYFCnN1",
      "display_url" : "pastebin.com\/raw.php?i=FAYF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385041873334595584",
  "text" : "http:\/\/t.co\/Og0DEP6GtF Hashes: 597 Keywords: 0.0 #infoleak",
  "id" : 385041873334595584,
  "created_at" : "2013-10-01 14:01:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uFanRSSJ3Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HKeBU8df",
      "display_url" : "pastebin.com\/raw.php?i=HKeB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385036361704542209",
  "text" : "http:\/\/t.co\/uFanRSSJ3Z Keywords: 0.55 #infoleak",
  "id" : 385036361704542209,
  "created_at" : "2013-10-01 13:39:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TgMJpPs5HM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dJuJDheg",
      "display_url" : "pastebin.com\/raw.php?i=dJuJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385014110661771264",
  "text" : "http:\/\/t.co\/TgMJpPs5HM Emails: 1104 Keywords: 0.11 #infoleak",
  "id" : 385014110661771264,
  "created_at" : "2013-10-01 12:11:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tPUKhHAqSb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3tdVnXSB",
      "display_url" : "pastebin.com\/raw.php?i=3tdV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385010496337743872",
  "text" : "http:\/\/t.co\/tPUKhHAqSb Emails: 500 Keywords: 0.0 #infoleak",
  "id" : 385010496337743872,
  "created_at" : "2013-10-01 11:57:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H5imbT4BCz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wqGzMLSZ",
      "display_url" : "pastebin.com\/raw.php?i=wqGz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385004092105302016",
  "text" : "http:\/\/t.co\/H5imbT4BCz Emails: 500 Keywords: 0.0 #infoleak",
  "id" : 385004092105302016,
  "created_at" : "2013-10-01 11:31:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bPW2SQJxy8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5AjkVL7V",
      "display_url" : "pastebin.com\/raw.php?i=5Ajk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384976813933359104",
  "text" : "http:\/\/t.co\/bPW2SQJxy8 Hashes: 63 Keywords: 0.19 #infoleak",
  "id" : 384976813933359104,
  "created_at" : "2013-10-01 09:43:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IDYEFMShnf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qm7Tka4R",
      "display_url" : "pastebin.com\/raw.php?i=Qm7T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384976491471052801",
  "text" : "http:\/\/t.co\/IDYEFMShnf Emails: 772 Hashes: 392 E\/H: 1.97 Keywords: 0.19 #infoleak",
  "id" : 384976491471052801,
  "created_at" : "2013-10-01 09:42:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xCxLdknNkT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WuiVBnDP",
      "display_url" : "pastebin.com\/raw.php?i=WuiV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384971504812695552",
  "text" : "http:\/\/t.co\/xCxLdknNkT Hashes: 130 Keywords: 0.08 #infoleak",
  "id" : 384971504812695552,
  "created_at" : "2013-10-01 09:22:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w65cd6T4CU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U659vGvN",
      "display_url" : "pastebin.com\/raw.php?i=U659\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384954930831716352",
  "text" : "http:\/\/t.co\/w65cd6T4CU Emails: 91 Hashes: 88 E\/H: 1.03 Keywords: 0.33 #infoleak",
  "id" : 384954930831716352,
  "created_at" : "2013-10-01 08:16:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
} ]
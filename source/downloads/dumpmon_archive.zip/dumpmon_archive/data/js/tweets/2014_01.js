Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AdYTxuEhZ5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T9e0Hni3",
      "display_url" : "pastebin.com\/raw.php?i=T9e0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429506641386409986",
  "text" : "http:\/\/t.co\/AdYTxuEhZ5 Possible cisco configuration #infoleak",
  "id" : 429506641386409986,
  "created_at" : "2014-02-01 06:48:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U3Zh0wRrQd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H2NNYdxu",
      "display_url" : "pastebin.com\/raw.php?i=H2NN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429485338528993280",
  "text" : "http:\/\/t.co\/U3Zh0wRrQd Emails: 105 Keywords: -0.03 #infoleak",
  "id" : 429485338528993280,
  "created_at" : "2014-02-01 05:24:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3dWGe4IK8J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pn2Q4f6e",
      "display_url" : "pastebin.com\/raw.php?i=pn2Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429472713887842305",
  "text" : "http:\/\/t.co\/3dWGe4IK8J Keywords: 0.55 #infoleak",
  "id" : 429472713887842305,
  "created_at" : "2014-02-01 04:34:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uBWKBBVW7A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5SHEYJEB",
      "display_url" : "pastebin.com\/raw.php?i=5SHE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429467532953526272",
  "text" : "http:\/\/t.co\/uBWKBBVW7A Emails: 75 Keywords: 0.0 #infoleak",
  "id" : 429467532953526272,
  "created_at" : "2014-02-01 04:13:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZUlZhfq13m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LueeCPwP",
      "display_url" : "pastebin.com\/raw.php?i=Luee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429466993289216000",
  "text" : "http:\/\/t.co\/ZUlZhfq13m Found possible Google API key(s) #infoleak",
  "id" : 429466993289216000,
  "created_at" : "2014-02-01 04:11:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zoePTmC4ys",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZPHPk7Y6",
      "display_url" : "pastebin.com\/raw.php?i=ZPHP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429285809703776256",
  "text" : "http:\/\/t.co\/zoePTmC4ys Emails: 30 Keywords: -0.03 #infoleak",
  "id" : 429285809703776256,
  "created_at" : "2014-01-31 16:11:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ICC9hSIwnA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uRQDGQns",
      "display_url" : "pastebin.com\/raw.php?i=uRQD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429235940700065792",
  "text" : "http:\/\/t.co\/ICC9hSIwnA Emails: 25 Keywords: -0.14 #infoleak",
  "id" : 429235940700065792,
  "created_at" : "2014-01-31 12:53:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X1RKNOjvfE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gmeusvyz",
      "display_url" : "pastebin.com\/raw.php?i=gmeu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429200956664737793",
  "text" : "http:\/\/t.co\/X1RKNOjvfE Found possible Google API key(s) #infoleak",
  "id" : 429200956664737793,
  "created_at" : "2014-01-31 10:34:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fZN7D4X8fI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aCqfJKqX",
      "display_url" : "pastebin.com\/raw.php?i=aCqf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429197204654272512",
  "text" : "http:\/\/t.co\/fZN7D4X8fI Hashes: 31 Keywords: 0.22 #infoleak",
  "id" : 429197204654272512,
  "created_at" : "2014-01-31 10:19:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vSXej76Lys",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sWHe5yh6",
      "display_url" : "pastebin.com\/raw.php?i=sWHe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429186142018076672",
  "text" : "http:\/\/t.co\/vSXej76Lys Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 429186142018076672,
  "created_at" : "2014-01-31 09:35:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JqrcmomPtS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s69ZwQAk",
      "display_url" : "pastebin.com\/raw.php?i=s69Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429173446921031680",
  "text" : "http:\/\/t.co\/JqrcmomPtS Hashes: 51 Keywords: 0.05 #infoleak",
  "id" : 429173446921031680,
  "created_at" : "2014-01-31 08:44:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TCDH7QcigL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2TsDinQP",
      "display_url" : "pastebin.com\/raw.php?i=2TsD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429156102714847232",
  "text" : "http:\/\/t.co\/TCDH7QcigL Hashes: 74 Keywords: 0.3 #infoleak",
  "id" : 429156102714847232,
  "created_at" : "2014-01-31 07:36:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/30qf40x1H4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dB6GFm9e",
      "display_url" : "pastebin.com\/raw.php?i=dB6G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429133969838190592",
  "text" : "http:\/\/t.co\/30qf40x1H4 Emails: 34 Keywords: 0.11 #infoleak",
  "id" : 429133969838190592,
  "created_at" : "2014-01-31 06:08:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/awxp73nrKY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6rhPkbBJ",
      "display_url" : "pastebin.com\/raw.php?i=6rhP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429133015092957184",
  "text" : "http:\/\/t.co\/awxp73nrKY Keywords: 0.55 #infoleak",
  "id" : 429133015092957184,
  "created_at" : "2014-01-31 06:04:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dydyPC0cT8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TaHmRFpC",
      "display_url" : "pastebin.com\/raw.php?i=TaHm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429129810070106112",
  "text" : "http:\/\/t.co\/dydyPC0cT8 Hashes: 194 Keywords: 0.05 #infoleak",
  "id" : 429129810070106112,
  "created_at" : "2014-01-31 05:51:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1RRQALYpo1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jq940wyc",
      "display_url" : "pastebin.com\/raw.php?i=Jq94\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428910272963543040",
  "text" : "http:\/\/t.co\/1RRQALYpo1 Emails: 596 Keywords: 0.11 #infoleak",
  "id" : 428910272963543040,
  "created_at" : "2014-01-30 15:19:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2oEyOCYSzG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZyRK87VA",
      "display_url" : "pastebin.com\/raw.php?i=ZyRK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428910101869494272",
  "text" : "http:\/\/t.co\/2oEyOCYSzG Found possible Google API key(s) #infoleak",
  "id" : 428910101869494272,
  "created_at" : "2014-01-30 15:18:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Rf47vkwr26",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LaanZk8f",
      "display_url" : "pastebin.com\/raw.php?i=Laan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428901841930186752",
  "text" : "http:\/\/t.co\/Rf47vkwr26 Emails: 2 Hashes: 43 E\/H: 0.05 Keywords: 0.3 #infoleak",
  "id" : 428901841930186752,
  "created_at" : "2014-01-30 14:45:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PYeJ4tMVFk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=45dR7MY2",
      "display_url" : "pastebin.com\/raw.php?i=45dR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428825303943634944",
  "text" : "http:\/\/t.co\/PYeJ4tMVFk Emails: 21 Hashes: 22 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 428825303943634944,
  "created_at" : "2014-01-30 09:41:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/akkV3ZNXAC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JGeaNU06",
      "display_url" : "pastebin.com\/raw.php?i=JGea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428817974300905472",
  "text" : "http:\/\/t.co\/akkV3ZNXAC Hashes: 52 Keywords: 0.33 #infoleak",
  "id" : 428817974300905472,
  "created_at" : "2014-01-30 09:12:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n8mQiaQuhy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ww1fuHdN",
      "display_url" : "pastebin.com\/raw.php?i=Ww1f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428814708196376576",
  "text" : "http:\/\/t.co\/n8mQiaQuhy Emails: 309 Keywords: 0.0 #infoleak",
  "id" : 428814708196376576,
  "created_at" : "2014-01-30 08:59:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xt2haWxDpW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TZvfWfP0",
      "display_url" : "pastebin.com\/raw.php?i=TZvf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428813466095190016",
  "text" : "http:\/\/t.co\/xt2haWxDpW Emails: 85 Keywords: 0.0 #infoleak",
  "id" : 428813466095190016,
  "created_at" : "2014-01-30 08:54:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6nv0ILBTF9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h9WHVfbS",
      "display_url" : "pastebin.com\/raw.php?i=h9WH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428779489019965440",
  "text" : "http:\/\/t.co\/6nv0ILBTF9 Found possible Google API key(s) #infoleak",
  "id" : 428779489019965440,
  "created_at" : "2014-01-30 06:39:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/soPulNAoWj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WmNbLb23",
      "display_url" : "pastebin.com\/raw.php?i=WmNb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428745473889804288",
  "text" : "http:\/\/t.co\/soPulNAoWj Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 428745473889804288,
  "created_at" : "2014-01-30 04:24:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6U6awAKsMY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vd4zsBz6",
      "display_url" : "pastebin.com\/raw.php?i=vd4z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428733088793772033",
  "text" : "http:\/\/t.co\/6U6awAKsMY Found possible Google API key(s) #infoleak",
  "id" : 428733088793772033,
  "created_at" : "2014-01-30 03:35:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a6lxRRjAle",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RKkh1CMC",
      "display_url" : "pastebin.com\/raw.php?i=RKkh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428728344155140096",
  "text" : "http:\/\/t.co\/a6lxRRjAle Keywords: 0.66 #infoleak",
  "id" : 428728344155140096,
  "created_at" : "2014-01-30 03:16:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HP5Ayovfjq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4kLkgkm2",
      "display_url" : "pastebin.com\/raw.php?i=4kLk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428720062006968320",
  "text" : "http:\/\/t.co\/HP5Ayovfjq Emails: 70 Hashes: 70 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 428720062006968320,
  "created_at" : "2014-01-30 02:43:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AKDPlqJdwa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=03EgnbY7",
      "display_url" : "pastebin.com\/raw.php?i=03Eg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428716902928494592",
  "text" : "http:\/\/t.co\/AKDPlqJdwa Emails: 435 Keywords: 0.0 #infoleak",
  "id" : 428716902928494592,
  "created_at" : "2014-01-30 02:30:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Nu6hL40Zbq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pwgW9H2X",
      "display_url" : "pastebin.com\/raw.php?i=pwgW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428712512180064256",
  "text" : "http:\/\/t.co\/Nu6hL40Zbq Found possible Google API key(s) #infoleak",
  "id" : 428712512180064256,
  "created_at" : "2014-01-30 02:13:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rD2smhqX6Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z7wAztG9",
      "display_url" : "pastebin.com\/raw.php?i=Z7wA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428706821772034048",
  "text" : "http:\/\/t.co\/rD2smhqX6Z Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 428706821772034048,
  "created_at" : "2014-01-30 01:50:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EwdIWb2ePn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Msz2Q8tc",
      "display_url" : "pastebin.com\/raw.php?i=Msz2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428703736714653696",
  "text" : "http:\/\/t.co\/EwdIWb2ePn Emails: 252 Hashes: 256 E\/H: 0.98 Keywords: 0.41 #infoleak",
  "id" : 428703736714653696,
  "created_at" : "2014-01-30 01:38:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3FQ3IG9w7p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qGZejKit",
      "display_url" : "pastebin.com\/raw.php?i=qGZe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428677035406274560",
  "text" : "http:\/\/t.co\/3FQ3IG9w7p Hashes: 41 Keywords: 0.3 #infoleak",
  "id" : 428677035406274560,
  "created_at" : "2014-01-29 23:52:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/orMHuRu9Uk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dWRTAsJY",
      "display_url" : "pastebin.com\/raw.php?i=dWRT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428594299656081408",
  "text" : "http:\/\/t.co\/orMHuRu9Uk Hashes: 42 Keywords: 0.0 #infoleak",
  "id" : 428594299656081408,
  "created_at" : "2014-01-29 18:23:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JJKi3lBJhR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YULXafBv",
      "display_url" : "pastebin.com\/raw.php?i=YULX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428593795500752896",
  "text" : "http:\/\/t.co\/JJKi3lBJhR Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 428593795500752896,
  "created_at" : "2014-01-29 18:21:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HHY8dfU6Vm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mBKAtAn9",
      "display_url" : "pastebin.com\/raw.php?i=mBKA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428587330698375168",
  "text" : "http:\/\/t.co\/HHY8dfU6Vm Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 428587330698375168,
  "created_at" : "2014-01-29 17:55:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Lf9tMb8t7r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6k9z7uwS",
      "display_url" : "pastebin.com\/raw.php?i=6k9z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428576293488054273",
  "text" : "http:\/\/t.co\/Lf9tMb8t7r Hashes: 65 Keywords: 0.0 #infoleak",
  "id" : 428576293488054273,
  "created_at" : "2014-01-29 17:12:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EsPyaY4oG9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wFekGx8e",
      "display_url" : "pastebin.com\/raw.php?i=wFek\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428574754505629697",
  "text" : "http:\/\/t.co\/EsPyaY4oG9 Hashes: 149 Keywords: 0.0 #infoleak",
  "id" : 428574754505629697,
  "created_at" : "2014-01-29 17:05:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s6OFi8IXld",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rsaqMXEg",
      "display_url" : "pastebin.com\/raw.php?i=rsaq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428573973463314432",
  "text" : "http:\/\/t.co\/s6OFi8IXld Emails: 465 Keywords: 0.33 #infoleak",
  "id" : 428573973463314432,
  "created_at" : "2014-01-29 17:02:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FRfvb8sHMl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9aMcUYaE",
      "display_url" : "pastebin.com\/raw.php?i=9aMc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428569084838420480",
  "text" : "http:\/\/t.co\/FRfvb8sHMl Emails: 92 Hashes: 532 E\/H: 0.17 Keywords: 0.33 #infoleak",
  "id" : 428569084838420480,
  "created_at" : "2014-01-29 16:43:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZR5R55pnXs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qZ67tDc0",
      "display_url" : "pastebin.com\/raw.php?i=qZ67\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428551420611026944",
  "text" : "http:\/\/t.co\/ZR5R55pnXs Hashes: 446 Keywords: 0.11 #infoleak",
  "id" : 428551420611026944,
  "created_at" : "2014-01-29 15:33:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kj9XLKkVp2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=37DMBLAm",
      "display_url" : "pastebin.com\/raw.php?i=37DM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428543732929945601",
  "text" : "http:\/\/t.co\/Kj9XLKkVp2 Emails: 4349 Hashes: 6 E\/H: 724.83 Keywords: 0.44 #infoleak",
  "id" : 428543732929945601,
  "created_at" : "2014-01-29 15:02:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d6MiCCzt5l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bj5usPg6",
      "display_url" : "pastebin.com\/raw.php?i=bj5u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428531757332172800",
  "text" : "http:\/\/t.co\/d6MiCCzt5l Emails: 177 Keywords: 0.0 #infoleak",
  "id" : 428531757332172800,
  "created_at" : "2014-01-29 14:15:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q4epnOxmGl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tBWMPisC",
      "display_url" : "pastebin.com\/raw.php?i=tBWM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428523296456310784",
  "text" : "http:\/\/t.co\/q4epnOxmGl Emails: 1 Hashes: 94 E\/H: 0.01 Keywords: 0.3 #infoleak",
  "id" : 428523296456310784,
  "created_at" : "2014-01-29 13:41:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FxPG1s36HR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QhhjRsF3",
      "display_url" : "pastebin.com\/raw.php?i=Qhhj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428508261654855680",
  "text" : "http:\/\/t.co\/FxPG1s36HR Hashes: 217 Keywords: 0.0 #infoleak",
  "id" : 428508261654855680,
  "created_at" : "2014-01-29 12:41:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BCo4Xq7dcI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R3H0mzcc",
      "display_url" : "pastebin.com\/raw.php?i=R3H0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428402626221203456",
  "text" : "http:\/\/t.co\/BCo4Xq7dcI Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 428402626221203456,
  "created_at" : "2014-01-29 05:42:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9jju0eEC4k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mQ5XbkTU",
      "display_url" : "pastebin.com\/raw.php?i=mQ5X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428398960965730304",
  "text" : "http:\/\/t.co\/9jju0eEC4k Emails: 199 Keywords: 0.11 #infoleak",
  "id" : 428398960965730304,
  "created_at" : "2014-01-29 05:27:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/njvmKjBNtY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8jdX6P1e",
      "display_url" : "pastebin.com\/raw.php?i=8jdX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428375818071339008",
  "text" : "http:\/\/t.co\/njvmKjBNtY Emails: 136 Hashes: 283 E\/H: 0.48 Keywords: 0.63 #infoleak",
  "id" : 428375818071339008,
  "created_at" : "2014-01-29 03:55:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ECTwGdpqPK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eh5WpUj4",
      "display_url" : "pastebin.com\/raw.php?i=eh5W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428370984622501890",
  "text" : "http:\/\/t.co\/ECTwGdpqPK Emails: 1455 Keywords: 0.11 #infoleak",
  "id" : 428370984622501890,
  "created_at" : "2014-01-29 03:36:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jAWJ9cORbv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MC7BdFMW",
      "display_url" : "pastebin.com\/raw.php?i=MC7B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428356430249209856",
  "text" : "http:\/\/t.co\/jAWJ9cORbv Found possible Google API key(s) #infoleak",
  "id" : 428356430249209856,
  "created_at" : "2014-01-29 02:38:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wvXpBLkFny",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yBdk3sjv",
      "display_url" : "pastebin.com\/raw.php?i=yBdk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428334508169912321",
  "text" : "http:\/\/t.co\/wvXpBLkFny Hashes: 510 Keywords: 0.0 #infoleak",
  "id" : 428334508169912321,
  "created_at" : "2014-01-29 01:11:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UGVbFrgPRJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AN7fgxvH",
      "display_url" : "pastebin.com\/raw.php?i=AN7f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428331797160529920",
  "text" : "http:\/\/t.co\/UGVbFrgPRJ Emails: 1581 Keywords: 0.11 #infoleak",
  "id" : 428331797160529920,
  "created_at" : "2014-01-29 01:00:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UtKLjE1C1m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n4n7gDgc",
      "display_url" : "pastebin.com\/raw.php?i=n4n7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428331560249487360",
  "text" : "http:\/\/t.co\/UtKLjE1C1m Hashes: 58 Keywords: -0.06 #infoleak",
  "id" : 428331560249487360,
  "created_at" : "2014-01-29 00:59:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4F7aBgHwGS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kLBH4kDv",
      "display_url" : "pastebin.com\/raw.php?i=kLBH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428297396074713088",
  "text" : "http:\/\/t.co\/4F7aBgHwGS Emails: 167 Hashes: 2 E\/H: 83.5 Keywords: 0.0 #infoleak",
  "id" : 428297396074713088,
  "created_at" : "2014-01-28 22:43:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kRGzkuLLph",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tnkt5AFF",
      "display_url" : "pastebin.com\/raw.php?i=Tnkt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428295023944151040",
  "text" : "http:\/\/t.co\/kRGzkuLLph Hashes: 80 Keywords: -0.17 #infoleak",
  "id" : 428295023944151040,
  "created_at" : "2014-01-28 22:34:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hPou3pw2ku",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1CDL74cv",
      "display_url" : "pastebin.com\/raw.php?i=1CDL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428282260366708736",
  "text" : "http:\/\/t.co\/hPou3pw2ku Emails: 43 Keywords: 0.19 #infoleak",
  "id" : 428282260366708736,
  "created_at" : "2014-01-28 21:43:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/39bNFj9YAL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YFK56mck",
      "display_url" : "pastebin.com\/raw.php?i=YFK5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428257597267800065",
  "text" : "http:\/\/t.co\/39bNFj9YAL Emails: 133 Keywords: 0.11 #infoleak",
  "id" : 428257597267800065,
  "created_at" : "2014-01-28 20:05:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8MrbO5Uiv5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hZt5i3d9",
      "display_url" : "pastebin.com\/raw.php?i=hZt5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428256104879890432",
  "text" : "http:\/\/t.co\/8MrbO5Uiv5 Found possible Google API key(s) #infoleak",
  "id" : 428256104879890432,
  "created_at" : "2014-01-28 19:59:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YJi8APNd7R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1ZtTy51X",
      "display_url" : "pastebin.com\/raw.php?i=1ZtT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428198993516978176",
  "text" : "http:\/\/t.co\/YJi8APNd7R Emails: 203 Keywords: 0.22 #infoleak",
  "id" : 428198993516978176,
  "created_at" : "2014-01-28 16:12:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lBYeRPEqhL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zLJDNDVW",
      "display_url" : "pastebin.com\/raw.php?i=zLJD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428049832054239232",
  "text" : "http:\/\/t.co\/lBYeRPEqhL Emails: 455 Keywords: -0.14 #infoleak",
  "id" : 428049832054239232,
  "created_at" : "2014-01-28 06:20:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HrQLMFRWLG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y1zhbBvP",
      "display_url" : "pastebin.com\/raw.php?i=y1zh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428037761170292737",
  "text" : "http:\/\/t.co\/HrQLMFRWLG Emails: 80 Keywords: 0.33 #infoleak",
  "id" : 428037761170292737,
  "created_at" : "2014-01-28 05:32:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QZRx74sm1E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hzpHj6DZ",
      "display_url" : "pastebin.com\/raw.php?i=hzpH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428014354118623232",
  "text" : "http:\/\/t.co\/QZRx74sm1E Hashes: 44 Keywords: 0.08 #infoleak",
  "id" : 428014354118623232,
  "created_at" : "2014-01-28 03:59:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/86M7QlCQMp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3EcEJrkE",
      "display_url" : "pastebin.com\/raw.php?i=3EcE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427994479237136384",
  "text" : "http:\/\/t.co\/86M7QlCQMp Emails: 22 Keywords: -0.06 #infoleak",
  "id" : 427994479237136384,
  "created_at" : "2014-01-28 02:40:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tzgEsAd2hR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dTWyBn2C",
      "display_url" : "pastebin.com\/raw.php?i=dTWy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427944596849455104",
  "text" : "http:\/\/t.co\/tzgEsAd2hR Emails: 3569 Keywords: 0.33 #infoleak",
  "id" : 427944596849455104,
  "created_at" : "2014-01-27 23:21:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4Vuz4xkTGW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=717Fxfxh",
      "display_url" : "pastebin.com\/raw.php?i=717F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427941465319145472",
  "text" : "http:\/\/t.co\/4Vuz4xkTGW Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 427941465319145472,
  "created_at" : "2014-01-27 23:09:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G3GljPaFCq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2h2bSa0y",
      "display_url" : "pastebin.com\/raw.php?i=2h2b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427930846733946881",
  "text" : "http:\/\/t.co\/G3GljPaFCq Hashes: 300 Keywords: 0.11 #infoleak",
  "id" : 427930846733946881,
  "created_at" : "2014-01-27 22:27:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hV4zyvUlZ4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BMMwY68H",
      "display_url" : "pastebin.com\/raw.php?i=BMMw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427926536184791041",
  "text" : "http:\/\/t.co\/hV4zyvUlZ4 Emails: 45 Keywords: 0.0 #infoleak",
  "id" : 427926536184791041,
  "created_at" : "2014-01-27 22:10:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LG9cq8UBFQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9kCqujnq",
      "display_url" : "pastebin.com\/raw.php?i=9kCq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427924548382490624",
  "text" : "http:\/\/t.co\/LG9cq8UBFQ Emails: 1247 Keywords: 0.0 #infoleak",
  "id" : 427924548382490624,
  "created_at" : "2014-01-27 22:02:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UIqSelgTkb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NBBpsfkS",
      "display_url" : "pastebin.com\/raw.php?i=NBBp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427924448579055617",
  "text" : "http:\/\/t.co\/UIqSelgTkb Emails: 339 Keywords: 0.0 #infoleak",
  "id" : 427924448579055617,
  "created_at" : "2014-01-27 22:01:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0KxSgvGBtN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RmXMgq58",
      "display_url" : "pastebin.com\/raw.php?i=RmXM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427922597951467520",
  "text" : "http:\/\/t.co\/0KxSgvGBtN Emails: 5 Hashes: 278 E\/H: 0.02 Keywords: -0.03 #infoleak",
  "id" : 427922597951467520,
  "created_at" : "2014-01-27 21:54:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PBhyBaSm5G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2C4Xsjd0",
      "display_url" : "pastebin.com\/raw.php?i=2C4X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427917505298837504",
  "text" : "http:\/\/t.co\/PBhyBaSm5G Hashes: 2045 Keywords: 0.08 #infoleak",
  "id" : 427917505298837504,
  "created_at" : "2014-01-27 21:34:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yi9cH1FjSC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zzkk3bpC",
      "display_url" : "pastebin.com\/raw.php?i=Zzkk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427917159667224576",
  "text" : "http:\/\/t.co\/Yi9cH1FjSC Emails: 146 Keywords: 0.08 #infoleak",
  "id" : 427917159667224576,
  "created_at" : "2014-01-27 21:32:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CDZlVfoCax",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UZu22Dh1",
      "display_url" : "pastebin.com\/raw.php?i=UZu2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427910957092712448",
  "text" : "http:\/\/t.co\/CDZlVfoCax Emails: 1 Hashes: 31 E\/H: 0.03 Keywords: 0.11 #infoleak",
  "id" : 427910957092712448,
  "created_at" : "2014-01-27 21:08:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uCcooZEv2v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u6dXqKqj",
      "display_url" : "pastebin.com\/raw.php?i=u6dX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427908024217264128",
  "text" : "http:\/\/t.co\/uCcooZEv2v Found possible Google API key(s) #infoleak",
  "id" : 427908024217264128,
  "created_at" : "2014-01-27 20:56:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VR0ekKKxQi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=na1CJUMm",
      "display_url" : "pastebin.com\/raw.php?i=na1C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427898922606927872",
  "text" : "http:\/\/t.co\/VR0ekKKxQi Emails: 10073 Keywords: 0.08 #infoleak",
  "id" : 427898922606927872,
  "created_at" : "2014-01-27 20:20:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O5KOZkwJLp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HHK3cTuS",
      "display_url" : "pastebin.com\/raw.php?i=HHK3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427897930914074624",
  "text" : "http:\/\/t.co\/O5KOZkwJLp Emails: 17869 Keywords: 0.08 #infoleak",
  "id" : 427897930914074624,
  "created_at" : "2014-01-27 20:16:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JQGPCrdBJf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=biTdnqts",
      "display_url" : "pastebin.com\/raw.php?i=biTd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427893349899452416",
  "text" : "http:\/\/t.co\/JQGPCrdBJf Emails: 13361 Keywords: 0.08 #infoleak",
  "id" : 427893349899452416,
  "created_at" : "2014-01-27 19:58:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lJz87OROp0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5ia02ZXC",
      "display_url" : "pastebin.com\/raw.php?i=5ia0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427891329591279616",
  "text" : "http:\/\/t.co\/lJz87OROp0 Emails: 13825 Keywords: -0.03 #infoleak",
  "id" : 427891329591279616,
  "created_at" : "2014-01-27 19:50:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/07otlN55Hq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4YkJxfKG",
      "display_url" : "pastebin.com\/raw.php?i=4YkJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427890820042080256",
  "text" : "http:\/\/t.co\/07otlN55Hq Emails: 11067 Keywords: -0.03 #infoleak",
  "id" : 427890820042080256,
  "created_at" : "2014-01-27 19:48:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/No4Siz7d3t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1LATGa61",
      "display_url" : "pastebin.com\/raw.php?i=1LAT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427887892661145600",
  "text" : "http:\/\/t.co\/No4Siz7d3t Emails: 100 Keywords: -0.03 #infoleak",
  "id" : 427887892661145600,
  "created_at" : "2014-01-27 19:36:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fKTndXcSOa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eETutWAj",
      "display_url" : "pastebin.com\/raw.php?i=eETu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427884376915849216",
  "text" : "http:\/\/t.co\/fKTndXcSOa Emails: 118 Keywords: 0.22 #infoleak",
  "id" : 427884376915849216,
  "created_at" : "2014-01-27 19:22:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rhOU053Svb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SaMZsHjr",
      "display_url" : "pastebin.com\/raw.php?i=SaMZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427883958689226752",
  "text" : "http:\/\/t.co\/rhOU053Svb Emails: 5742 Keywords: -0.03 #infoleak",
  "id" : 427883958689226752,
  "created_at" : "2014-01-27 19:21:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Vo5CoEmjsQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nQei320g",
      "display_url" : "pastebin.com\/raw.php?i=nQei\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427881715659321344",
  "text" : "http:\/\/t.co\/Vo5CoEmjsQ Found possible Google API key(s) #infoleak",
  "id" : 427881715659321344,
  "created_at" : "2014-01-27 19:12:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cr65ylsJqx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E1Wz3ZM0",
      "display_url" : "pastebin.com\/raw.php?i=E1Wz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427877740780335104",
  "text" : "http:\/\/t.co\/cr65ylsJqx Found possible Google API key(s) #infoleak",
  "id" : 427877740780335104,
  "created_at" : "2014-01-27 18:56:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gkWfPa80be",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uamM9qms",
      "display_url" : "pastebin.com\/raw.php?i=uamM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427872182673219584",
  "text" : "http:\/\/t.co\/gkWfPa80be Found possible Google API key(s) #infoleak",
  "id" : 427872182673219584,
  "created_at" : "2014-01-27 18:34:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dU68nWBZrk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QMNmPH0W",
      "display_url" : "pastebin.com\/raw.php?i=QMNm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427862225995325440",
  "text" : "http:\/\/t.co\/dU68nWBZrk Emails: 23 Keywords: 0.33 #infoleak",
  "id" : 427862225995325440,
  "created_at" : "2014-01-27 17:54:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gBNvZFMbRO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PN9xCKzb",
      "display_url" : "pastebin.com\/raw.php?i=PN9x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427851272411049984",
  "text" : "http:\/\/t.co\/gBNvZFMbRO Emails: 23 Keywords: 0.33 #infoleak",
  "id" : 427851272411049984,
  "created_at" : "2014-01-27 17:11:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D8W2EslidW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aB0HREG6",
      "display_url" : "pastebin.com\/raw.php?i=aB0H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427830553295863808",
  "text" : "http:\/\/t.co\/D8W2EslidW Emails: 89 Keywords: 0.0 #infoleak",
  "id" : 427830553295863808,
  "created_at" : "2014-01-27 15:48:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EM4Qp1XkMM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pGFNTwBL",
      "display_url" : "pastebin.com\/raw.php?i=pGFN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427608290348920832",
  "text" : "http:\/\/t.co\/EM4Qp1XkMM Emails: 1 Hashes: 2 E\/H: 0.5 Keywords: 0.55 #infoleak",
  "id" : 427608290348920832,
  "created_at" : "2014-01-27 01:05:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L3y6P3qKvx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TEX8fkxT",
      "display_url" : "pastebin.com\/raw.php?i=TEX8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427597072427012096",
  "text" : "http:\/\/t.co\/L3y6P3qKvx Emails: 66 Keywords: 0.11 #infoleak",
  "id" : 427597072427012096,
  "created_at" : "2014-01-27 00:21:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Uei9PlKaXp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VyyGsnFB",
      "display_url" : "pastebin.com\/raw.php?i=VyyG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427588005486800896",
  "text" : "http:\/\/t.co\/Uei9PlKaXp Emails: 81 Keywords: 0.0 #infoleak",
  "id" : 427588005486800896,
  "created_at" : "2014-01-26 23:44:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pAHSoLpxsr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mf0QVuGd",
      "display_url" : "pastebin.com\/raw.php?i=mf0Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427584172580802560",
  "text" : "http:\/\/t.co\/pAHSoLpxsr Hashes: 110 Keywords: -0.03 #infoleak",
  "id" : 427584172580802560,
  "created_at" : "2014-01-26 23:29:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EhcdwdAlMu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tCJJYb7b",
      "display_url" : "pastebin.com\/raw.php?i=tCJJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427583553057333248",
  "text" : "http:\/\/t.co\/EhcdwdAlMu Emails: 72 Keywords: 0.0 #infoleak",
  "id" : 427583553057333248,
  "created_at" : "2014-01-26 23:27:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QcnwMgujyO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fibPf07E",
      "display_url" : "pastebin.com\/raw.php?i=fibP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427583079234818048",
  "text" : "http:\/\/t.co\/QcnwMgujyO Emails: 36 Hashes: 1 E\/H: 36.0 Keywords: 0.19 #infoleak",
  "id" : 427583079234818048,
  "created_at" : "2014-01-26 23:25:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z1jn40LfsK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xuWSWm3P",
      "display_url" : "pastebin.com\/raw.php?i=xuWS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427551623145996288",
  "text" : "http:\/\/t.co\/z1jn40LfsK Keywords: 0.55 #infoleak",
  "id" : 427551623145996288,
  "created_at" : "2014-01-26 21:20:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dMN9ulsw5G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S5DWgavc",
      "display_url" : "pastebin.com\/raw.php?i=S5DW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427546898346430466",
  "text" : "http:\/\/t.co\/dMN9ulsw5G Emails: 4453 Hashes: 4452 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 427546898346430466,
  "created_at" : "2014-01-26 21:01:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dgh8vvkBb7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3QVwrEtY",
      "display_url" : "pastebin.com\/raw.php?i=3QVw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427538382172868608",
  "text" : "http:\/\/t.co\/dgh8vvkBb7 Emails: 383 Keywords: 0.11 #infoleak",
  "id" : 427538382172868608,
  "created_at" : "2014-01-26 20:27:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jk2jijrAlM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CtJcYd5s",
      "display_url" : "pastebin.com\/raw.php?i=CtJc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427531421620518914",
  "text" : "http:\/\/t.co\/jk2jijrAlM Emails: 1341 Keywords: 0.33 #infoleak",
  "id" : 427531421620518914,
  "created_at" : "2014-01-26 20:00:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PlqYZ8A5XT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vdjwXHT4",
      "display_url" : "pastebin.com\/raw.php?i=vdjw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427530753199468544",
  "text" : "http:\/\/t.co\/PlqYZ8A5XT Emails: 27 Keywords: -0.03 #infoleak",
  "id" : 427530753199468544,
  "created_at" : "2014-01-26 19:57:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tOhavK2vWF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hRw9tmew",
      "display_url" : "pastebin.com\/raw.php?i=hRw9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427518348402774016",
  "text" : "http:\/\/t.co\/tOhavK2vWF Emails: 242 Keywords: 0.0 #infoleak",
  "id" : 427518348402774016,
  "created_at" : "2014-01-26 19:08:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3eJJv5ZRjJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MKjbxVVx",
      "display_url" : "pastebin.com\/raw.php?i=MKjb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427507686205165568",
  "text" : "http:\/\/t.co\/3eJJv5ZRjJ Hashes: 153 Keywords: 0.19 #infoleak",
  "id" : 427507686205165568,
  "created_at" : "2014-01-26 18:25:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/elT9q4kaky",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZrbgF4zW",
      "display_url" : "pastebin.com\/raw.php?i=Zrbg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427397803417952256",
  "text" : "http:\/\/t.co\/elT9q4kaky Emails: 104 Keywords: 0.0 #infoleak",
  "id" : 427397803417952256,
  "created_at" : "2014-01-26 11:09:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k4tJh88mUv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JN2CzMqa",
      "display_url" : "pastebin.com\/raw.php?i=JN2C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427388193889988608",
  "text" : "http:\/\/t.co\/k4tJh88mUv Found possible Google API key(s) #infoleak",
  "id" : 427388193889988608,
  "created_at" : "2014-01-26 10:31:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D0k4sUFQe1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pDbQTbRT",
      "display_url" : "pastebin.com\/raw.php?i=pDbQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427385866852380672",
  "text" : "http:\/\/t.co\/D0k4sUFQe1 Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 427385866852380672,
  "created_at" : "2014-01-26 10:21:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/auU0vA9N3c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CRezAX1Q",
      "display_url" : "pastebin.com\/raw.php?i=CRez\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427378414379470848",
  "text" : "http:\/\/t.co\/auU0vA9N3c Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 427378414379470848,
  "created_at" : "2014-01-26 09:52:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VcZ6U1ubqB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W9PPxikP",
      "display_url" : "pastebin.com\/raw.php?i=W9PP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427375292940685312",
  "text" : "http:\/\/t.co\/VcZ6U1ubqB Emails: 4302 Keywords: -0.14 #infoleak",
  "id" : 427375292940685312,
  "created_at" : "2014-01-26 09:39:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/glomkYM9l1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NRJvFd0E",
      "display_url" : "pastebin.com\/raw.php?i=NRJv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427366660173881344",
  "text" : "http:\/\/t.co\/glomkYM9l1 Hashes: 212 Keywords: 0.11 #infoleak",
  "id" : 427366660173881344,
  "created_at" : "2014-01-26 09:05:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cwi7CRPl6j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HtS58gk6",
      "display_url" : "pastebin.com\/raw.php?i=HtS5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427276937816326144",
  "text" : "http:\/\/t.co\/cwi7CRPl6j Emails: 171 Keywords: 0.33 #infoleak",
  "id" : 427276937816326144,
  "created_at" : "2014-01-26 03:08:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KecRDX4T2X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KufBMSfV",
      "display_url" : "pastebin.com\/raw.php?i=KufB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427270853915459585",
  "text" : "http:\/\/t.co\/KecRDX4T2X Emails: 183 Keywords: 0.11 #infoleak",
  "id" : 427270853915459585,
  "created_at" : "2014-01-26 02:44:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JXvFpdtq8p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SfwDYQrx",
      "display_url" : "pastebin.com\/raw.php?i=SfwD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427266251698610176",
  "text" : "http:\/\/t.co\/JXvFpdtq8p Emails: 24 Keywords: 0.08 #infoleak",
  "id" : 427266251698610176,
  "created_at" : "2014-01-26 02:26:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K1tZY5pmyX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SFmF29iS",
      "display_url" : "pastebin.com\/raw.php?i=SFmF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427259735784452097",
  "text" : "http:\/\/t.co\/K1tZY5pmyX Found possible Google API key(s) #infoleak",
  "id" : 427259735784452097,
  "created_at" : "2014-01-26 02:00:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zmgIQrDSm4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GzZcV0nv",
      "display_url" : "pastebin.com\/raw.php?i=GzZc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427231003938021376",
  "text" : "http:\/\/t.co\/zmgIQrDSm4 Emails: 64 Keywords: 0.11 #infoleak",
  "id" : 427231003938021376,
  "created_at" : "2014-01-26 00:06:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wul0CytS3Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XuTR3Uyi",
      "display_url" : "pastebin.com\/raw.php?i=XuTR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427230240562110464",
  "text" : "http:\/\/t.co\/wul0CytS3Z Emails: 64 Keywords: 0.11 #infoleak",
  "id" : 427230240562110464,
  "created_at" : "2014-01-26 00:03:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TiVFqY5FHR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yHAa0MpU",
      "display_url" : "pastebin.com\/raw.php?i=yHAa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427228083951636480",
  "text" : "http:\/\/t.co\/TiVFqY5FHR Emails: 30 Keywords: 0.11 #infoleak",
  "id" : 427228083951636480,
  "created_at" : "2014-01-25 23:54:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e54gyi4p0G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y21zGPNm",
      "display_url" : "pastebin.com\/raw.php?i=y21z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427221277586116608",
  "text" : "http:\/\/t.co\/e54gyi4p0G Hashes: 34 Keywords: 0.22 #infoleak",
  "id" : 427221277586116608,
  "created_at" : "2014-01-25 23:27:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wHxZVOjsYS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ABgAv9xG",
      "display_url" : "pastebin.com\/raw.php?i=ABgA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427211578405289985",
  "text" : "http:\/\/t.co\/wHxZVOjsYS Emails: 49 Keywords: 0.11 #infoleak",
  "id" : 427211578405289985,
  "created_at" : "2014-01-25 22:49:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pjRaeoJ0ML",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ne9xkJQ7",
      "display_url" : "pastebin.com\/raw.php?i=Ne9x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427211355062411264",
  "text" : "http:\/\/t.co\/pjRaeoJ0ML Emails: 140 Keywords: 0.11 #infoleak",
  "id" : 427211355062411264,
  "created_at" : "2014-01-25 22:48:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2yIR8yL3jE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YiatP5Hi",
      "display_url" : "pastebin.com\/raw.php?i=Yiat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427208793441574912",
  "text" : "http:\/\/t.co\/2yIR8yL3jE Emails: 140 Keywords: 0.11 #infoleak",
  "id" : 427208793441574912,
  "created_at" : "2014-01-25 22:38:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fCsvo2od8G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UNaAYgJM",
      "display_url" : "pastebin.com\/raw.php?i=UNaA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427207694261301248",
  "text" : "http:\/\/t.co\/fCsvo2od8G Emails: 49 Keywords: 0.11 #infoleak",
  "id" : 427207694261301248,
  "created_at" : "2014-01-25 22:33:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tEkHts4a3X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bsZmmNw6",
      "display_url" : "pastebin.com\/raw.php?i=bsZm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427200334679658496",
  "text" : "http:\/\/t.co\/tEkHts4a3X Emails: 87 Keywords: -0.09 #infoleak",
  "id" : 427200334679658496,
  "created_at" : "2014-01-25 22:04:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/egUZrRT69W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UsSAmiuF",
      "display_url" : "pastebin.com\/raw.php?i=UsSA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427196907794866178",
  "text" : "http:\/\/t.co\/egUZrRT69W Found possible Google API key(s) #infoleak",
  "id" : 427196907794866178,
  "created_at" : "2014-01-25 21:50:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YEZRpAr6oJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5x7SBAmG",
      "display_url" : "pastebin.com\/raw.php?i=5x7S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427194166603300865",
  "text" : "http:\/\/t.co\/YEZRpAr6oJ Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 427194166603300865,
  "created_at" : "2014-01-25 21:40:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D0XfiOLPBC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w51m1bfx",
      "display_url" : "pastebin.com\/raw.php?i=w51m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427183151564070912",
  "text" : "http:\/\/t.co\/D0XfiOLPBC Emails: 104 Keywords: 0.0 #infoleak",
  "id" : 427183151564070912,
  "created_at" : "2014-01-25 20:56:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V4iZXS4wqr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=izUyGaeg",
      "display_url" : "pastebin.com\/raw.php?i=izUy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427183001336692736",
  "text" : "http:\/\/t.co\/V4iZXS4wqr Found possible Google API key(s) #infoleak",
  "id" : 427183001336692736,
  "created_at" : "2014-01-25 20:55:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UngxeHHNNJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BvzYkA2C",
      "display_url" : "pastebin.com\/raw.php?i=BvzY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427131342417973248",
  "text" : "http:\/\/t.co\/UngxeHHNNJ Emails: 67 Keywords: 0.22 #infoleak",
  "id" : 427131342417973248,
  "created_at" : "2014-01-25 17:30:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ftYIoFc3pZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qeiLCX8S",
      "display_url" : "pastebin.com\/raw.php?i=qeiL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427128516140732416",
  "text" : "http:\/\/t.co\/ftYIoFc3pZ Hashes: 128 Keywords: 0.22 #infoleak",
  "id" : 427128516140732416,
  "created_at" : "2014-01-25 17:19:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q3LPrR24NY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qP9ErQWU",
      "display_url" : "pastebin.com\/raw.php?i=qP9E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427127257962778624",
  "text" : "http:\/\/t.co\/Q3LPrR24NY Emails: 84 Keywords: 0.22 #infoleak",
  "id" : 427127257962778624,
  "created_at" : "2014-01-25 17:14:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tHyUfITYvb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mjNr7FnN",
      "display_url" : "pastebin.com\/raw.php?i=mjNr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427121166356979712",
  "text" : "http:\/\/t.co\/tHyUfITYvb Possible cisco configuration #infoleak",
  "id" : 427121166356979712,
  "created_at" : "2014-01-25 16:49:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mL4K9lsyBB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VuUSDRMx",
      "display_url" : "pastebin.com\/raw.php?i=VuUS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427099167362543617",
  "text" : "http:\/\/t.co\/mL4K9lsyBB Emails: 689 Hashes: 3 E\/H: 229.67 Keywords: 0.0 #infoleak",
  "id" : 427099167362543617,
  "created_at" : "2014-01-25 15:22:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1UWrKLLNaA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fQb2UwH0",
      "display_url" : "pastebin.com\/raw.php?i=fQb2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427038964193558528",
  "text" : "http:\/\/t.co\/1UWrKLLNaA Emails: 30 Keywords: 0.05 #infoleak",
  "id" : 427038964193558528,
  "created_at" : "2014-01-25 11:23:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Pma353qfPP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EwS54bBg",
      "display_url" : "pastebin.com\/raw.php?i=EwS5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427022363540983808",
  "text" : "http:\/\/t.co\/Pma353qfPP Emails: 1024 Keywords: 0.11 #infoleak",
  "id" : 427022363540983808,
  "created_at" : "2014-01-25 10:17:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UW4BgGMrTg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hsTNbQ6W",
      "display_url" : "pastebin.com\/raw.php?i=hsTN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427003616625307648",
  "text" : "http:\/\/t.co\/UW4BgGMrTg Found possible Google API key(s) #infoleak",
  "id" : 427003616625307648,
  "created_at" : "2014-01-25 09:02:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RcEbx9FnVM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=54VrDrWU",
      "display_url" : "pastebin.com\/raw.php?i=54Vr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426940837662969856",
  "text" : "http:\/\/t.co\/RcEbx9FnVM Found possible Google API key(s) #infoleak",
  "id" : 426940837662969856,
  "created_at" : "2014-01-25 04:53:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xiKuSOOIRm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fiCBD4Mg",
      "display_url" : "pastebin.com\/raw.php?i=fiCB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426899249201033216",
  "text" : "http:\/\/t.co\/xiKuSOOIRm Emails: 9 Keywords: 0.55 #infoleak",
  "id" : 426899249201033216,
  "created_at" : "2014-01-25 02:08:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZJekOlHh39",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZZLanQd0",
      "display_url" : "pastebin.com\/raw.php?i=ZZLa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426857963081322496",
  "text" : "http:\/\/t.co\/ZJekOlHh39 Hashes: 2 Keywords: 0.55 #infoleak",
  "id" : 426857963081322496,
  "created_at" : "2014-01-24 23:24:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pAckYkrCkt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QyrNC79X",
      "display_url" : "pastebin.com\/raw.php?i=QyrN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426857553629159424",
  "text" : "http:\/\/t.co\/pAckYkrCkt Emails: 28 Keywords: -0.14 #infoleak",
  "id" : 426857553629159424,
  "created_at" : "2014-01-24 23:22:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9xsKakedHY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KK4iWfQ2",
      "display_url" : "pastebin.com\/raw.php?i=KK4i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426840352822026240",
  "text" : "http:\/\/t.co\/9xsKakedHY Emails: 2 Hashes: 6 E\/H: 0.33 Keywords: 0.55 #infoleak",
  "id" : 426840352822026240,
  "created_at" : "2014-01-24 22:14:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FvASDXWJ0T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=26VbWiDa",
      "display_url" : "pastebin.com\/raw.php?i=26Vb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426834116080713728",
  "text" : "http:\/\/t.co\/FvASDXWJ0T Emails: 1 Hashes: 58 E\/H: 0.02 Keywords: 0.11 #infoleak",
  "id" : 426834116080713728,
  "created_at" : "2014-01-24 21:49:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OUp6phw3OR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X1yTW7Pr",
      "display_url" : "pastebin.com\/raw.php?i=X1yT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426834037508820992",
  "text" : "http:\/\/t.co\/OUp6phw3OR Emails: 92 Hashes: 5 E\/H: 18.4 Keywords: 0.0 #infoleak",
  "id" : 426834037508820992,
  "created_at" : "2014-01-24 21:48:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fBgzzduEz5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qLLa4ujm",
      "display_url" : "pastebin.com\/raw.php?i=qLLa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426833601628340224",
  "text" : "http:\/\/t.co\/fBgzzduEz5 Emails: 35 Keywords: 0.11 #infoleak",
  "id" : 426833601628340224,
  "created_at" : "2014-01-24 21:47:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aEVuc4gt6h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rjNiuF44",
      "display_url" : "pastebin.com\/raw.php?i=rjNi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426812673485836288",
  "text" : "http:\/\/t.co\/aEVuc4gt6h Emails: 294 Keywords: 0.0 #infoleak",
  "id" : 426812673485836288,
  "created_at" : "2014-01-24 20:24:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uBy7yTJAth",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0eAq0i7Z",
      "display_url" : "pastebin.com\/raw.php?i=0eAq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426804558065455104",
  "text" : "http:\/\/t.co\/uBy7yTJAth Emails: 4011 Keywords: 0.11 #infoleak",
  "id" : 426804558065455104,
  "created_at" : "2014-01-24 19:51:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AyczuH67Sf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B7z3D3vP",
      "display_url" : "pastebin.com\/raw.php?i=B7z3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426803323681787904",
  "text" : "http:\/\/t.co\/AyczuH67Sf Emails: 883 Keywords: 0.11 #infoleak",
  "id" : 426803323681787904,
  "created_at" : "2014-01-24 19:46:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IbMSIZN66q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wVvTBS3K",
      "display_url" : "pastebin.com\/raw.php?i=wVvT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426803070278701056",
  "text" : "http:\/\/t.co\/IbMSIZN66q Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 426803070278701056,
  "created_at" : "2014-01-24 19:45:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tnNskMT0fJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dKdwkdds",
      "display_url" : "pastebin.com\/raw.php?i=dKdw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426771317719715840",
  "text" : "http:\/\/t.co\/tnNskMT0fJ Emails: 1024 Keywords: 0.11 #infoleak",
  "id" : 426771317719715840,
  "created_at" : "2014-01-24 17:39:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wXwkyQccRW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BGbNhWnM",
      "display_url" : "pastebin.com\/raw.php?i=BGbN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426677217246986240",
  "text" : "http:\/\/t.co\/wXwkyQccRW Emails: 29 Keywords: 0.11 #infoleak",
  "id" : 426677217246986240,
  "created_at" : "2014-01-24 11:25:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1nZnAmKuXh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eL8p6bQY",
      "display_url" : "pastebin.com\/raw.php?i=eL8p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426674354823262208",
  "text" : "http:\/\/t.co\/1nZnAmKuXh Keywords: 0.55 #infoleak",
  "id" : 426674354823262208,
  "created_at" : "2014-01-24 11:14:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tb2uvX1Vmf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wb1K6TFW",
      "display_url" : "pastebin.com\/raw.php?i=wb1K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426672837919645696",
  "text" : "http:\/\/t.co\/tb2uvX1Vmf Hashes: 1597 Keywords: 0.11 #infoleak",
  "id" : 426672837919645696,
  "created_at" : "2014-01-24 11:08:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P0miegEw0T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gWcybg0d",
      "display_url" : "pastebin.com\/raw.php?i=gWcy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426644349384785920",
  "text" : "http:\/\/t.co\/P0miegEw0T Emails: 63 Hashes: 1 E\/H: 63.0 Keywords: 0.44 #infoleak",
  "id" : 426644349384785920,
  "created_at" : "2014-01-24 09:15:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tNimMW9c9L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C9LmTnKA",
      "display_url" : "pastebin.com\/raw.php?i=C9Lm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426638849515589632",
  "text" : "http:\/\/t.co\/tNimMW9c9L Hashes: 44 Keywords: 0.0 #infoleak",
  "id" : 426638849515589632,
  "created_at" : "2014-01-24 08:53:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YfDbnKtS0k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=689fwS9u",
      "display_url" : "pastebin.com\/raw.php?i=689f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426620578636640256",
  "text" : "http:\/\/t.co\/YfDbnKtS0k Found possible Google API key(s) #infoleak",
  "id" : 426620578636640256,
  "created_at" : "2014-01-24 07:40:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aWXY01h2dk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7iRrW8wF",
      "display_url" : "pastebin.com\/raw.php?i=7iRr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426620543815532544",
  "text" : "http:\/\/t.co\/aWXY01h2dk Emails: 1 Hashes: 46 E\/H: 0.02 Keywords: 0.22 #infoleak",
  "id" : 426620543815532544,
  "created_at" : "2014-01-24 07:40:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k48rwjTzXM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8THSVQWr",
      "display_url" : "pastebin.com\/raw.php?i=8THS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426603238008180736",
  "text" : "http:\/\/t.co\/k48rwjTzXM Emails: 8 Hashes: 208 E\/H: 0.04 Keywords: 0.11 #infoleak",
  "id" : 426603238008180736,
  "created_at" : "2014-01-24 06:31:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n3qJB8PMZt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i83emE4c",
      "display_url" : "pastebin.com\/raw.php?i=i83e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426582619111694337",
  "text" : "http:\/\/t.co\/n3qJB8PMZt Hashes: 36 Keywords: 0.11 #infoleak",
  "id" : 426582619111694337,
  "created_at" : "2014-01-24 05:09:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7luZI3ad0C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=exXnc4w4",
      "display_url" : "pastebin.com\/raw.php?i=exXn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426581220370034688",
  "text" : "http:\/\/t.co\/7luZI3ad0C Found possible Google API key(s) #infoleak",
  "id" : 426581220370034688,
  "created_at" : "2014-01-24 05:04:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D9FxRXmRni",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b9Jm7uLX",
      "display_url" : "pastebin.com\/raw.php?i=b9Jm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426568676142088192",
  "text" : "http:\/\/t.co\/D9FxRXmRni Emails: 28 Keywords: -0.14 #infoleak",
  "id" : 426568676142088192,
  "created_at" : "2014-01-24 04:14:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q4i7RTigca",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rt0DAqQ2",
      "display_url" : "pastebin.com\/raw.php?i=rt0D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426554405144371201",
  "text" : "http:\/\/t.co\/q4i7RTigca Emails: 132 Keywords: 0.0 #infoleak",
  "id" : 426554405144371201,
  "created_at" : "2014-01-24 03:17:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ps0DNzVjBS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7JEiF6qF",
      "display_url" : "pastebin.com\/raw.php?i=7JEi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426549304933638144",
  "text" : "http:\/\/t.co\/ps0DNzVjBS Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 426549304933638144,
  "created_at" : "2014-01-24 02:57:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IFB48l2A6X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Pum7WZgg",
      "display_url" : "pastebin.com\/raw.php?i=Pum7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426491616346398723",
  "text" : "http:\/\/t.co\/IFB48l2A6X Emails: 254 Hashes: 2 E\/H: 127.0 Keywords: -0.14 #infoleak",
  "id" : 426491616346398723,
  "created_at" : "2014-01-23 23:08:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3gxfRvzKJQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sMKmTeBW",
      "display_url" : "pastebin.com\/raw.php?i=sMKm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426473487545298944",
  "text" : "http:\/\/t.co\/3gxfRvzKJQ Hashes: 72 Keywords: 0.11 #infoleak",
  "id" : 426473487545298944,
  "created_at" : "2014-01-23 21:56:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FCoLqcSzMY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pTeDAsuV",
      "display_url" : "pastebin.com\/raw.php?i=pTeD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426470202612527104",
  "text" : "http:\/\/t.co\/FCoLqcSzMY Found possible Google API key(s) #infoleak",
  "id" : 426470202612527104,
  "created_at" : "2014-01-23 21:43:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2trY5hASrO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RVLv9pc6",
      "display_url" : "pastebin.com\/raw.php?i=RVLv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426469924882509824",
  "text" : "http:\/\/t.co\/2trY5hASrO Emails: 27 Keywords: -0.03 #infoleak",
  "id" : 426469924882509824,
  "created_at" : "2014-01-23 21:42:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AXKrxs8PA5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rUC746GQ",
      "display_url" : "pastebin.com\/raw.php?i=rUC7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426467103491649536",
  "text" : "http:\/\/t.co\/AXKrxs8PA5 Hashes: 34 Keywords: 0.22 #infoleak",
  "id" : 426467103491649536,
  "created_at" : "2014-01-23 21:30:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SyUBAyMv7V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fe6WZc67",
      "display_url" : "pastebin.com\/raw.php?i=Fe6W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426466306427076609",
  "text" : "http:\/\/t.co\/SyUBAyMv7V Hashes: 158 Keywords: 0.11 #infoleak",
  "id" : 426466306427076609,
  "created_at" : "2014-01-23 21:27:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Rsc2Kw89NJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5234e374",
      "display_url" : "pastebin.com\/raw.php?i=5234\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426464707159924736",
  "text" : "http:\/\/t.co\/Rsc2Kw89NJ Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 426464707159924736,
  "created_at" : "2014-01-23 21:21:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/siN4dCxklN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NJkACW4v",
      "display_url" : "pastebin.com\/raw.php?i=NJkA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426463575452819456",
  "text" : "http:\/\/t.co\/siN4dCxklN Hashes: 70 Keywords: 0.22 #infoleak",
  "id" : 426463575452819456,
  "created_at" : "2014-01-23 21:16:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LlFS2NXVB8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gHcjmQj1",
      "display_url" : "pastebin.com\/raw.php?i=gHcj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426449935391670272",
  "text" : "http:\/\/t.co\/LlFS2NXVB8 Emails: 1816 Keywords: 0.3 #infoleak",
  "id" : 426449935391670272,
  "created_at" : "2014-01-23 20:22:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jZWkvqc38C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AL5mxwEX",
      "display_url" : "pastebin.com\/raw.php?i=AL5m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426441310375931904",
  "text" : "http:\/\/t.co\/jZWkvqc38C Hashes: 70 Keywords: -0.03 #infoleak",
  "id" : 426441310375931904,
  "created_at" : "2014-01-23 19:48:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W68OuLq50x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JRv5gEui",
      "display_url" : "pastebin.com\/raw.php?i=JRv5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426440907097796608",
  "text" : "http:\/\/t.co\/W68OuLq50x Hashes: 70 Keywords: -0.03 #infoleak",
  "id" : 426440907097796608,
  "created_at" : "2014-01-23 19:46:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lzb0j0lEsR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wwekwswq",
      "display_url" : "pastebin.com\/raw.php?i=wwek\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426436882621161472",
  "text" : "http:\/\/t.co\/lzb0j0lEsR Hashes: 111 Keywords: 0.0 #infoleak",
  "id" : 426436882621161472,
  "created_at" : "2014-01-23 19:30:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/umtW41rrfe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G441NbpH",
      "display_url" : "pastebin.com\/raw.php?i=G441\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426435157252263936",
  "text" : "http:\/\/t.co\/umtW41rrfe Found possible Google API key(s) #infoleak",
  "id" : 426435157252263936,
  "created_at" : "2014-01-23 19:23:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hNgvu5XF30",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GgtE7KzB",
      "display_url" : "pastebin.com\/raw.php?i=GgtE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426432670919188480",
  "text" : "http:\/\/t.co\/hNgvu5XF30 Emails: 57 Keywords: 0.0 #infoleak",
  "id" : 426432670919188480,
  "created_at" : "2014-01-23 19:14:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aTJNakcs6S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CECc10SU",
      "display_url" : "pastebin.com\/raw.php?i=CECc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426425908551888896",
  "text" : "http:\/\/t.co\/aTJNakcs6S Emails: 36 Hashes: 1 E\/H: 36.0 Keywords: -0.03 #infoleak",
  "id" : 426425908551888896,
  "created_at" : "2014-01-23 18:47:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k2rob2U6Rb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=89fb4Zuf",
      "display_url" : "pastebin.com\/raw.php?i=89fb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426423294485467136",
  "text" : "http:\/\/t.co\/k2rob2U6Rb Emails: 2994 Keywords: 0.0 #infoleak",
  "id" : 426423294485467136,
  "created_at" : "2014-01-23 18:36:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PvdAVYEHL1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kmkxx1Dc",
      "display_url" : "pastebin.com\/raw.php?i=kmkx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426416064683970561",
  "text" : "http:\/\/t.co\/PvdAVYEHL1 Emails: 48 Keywords: 0.11 #infoleak",
  "id" : 426416064683970561,
  "created_at" : "2014-01-23 18:08:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7FtaeHryeZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wzjQBnJF",
      "display_url" : "pastebin.com\/raw.php?i=wzjQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426411249660743681",
  "text" : "http:\/\/t.co\/7FtaeHryeZ Emails: 101 Keywords: 0.0 #infoleak",
  "id" : 426411249660743681,
  "created_at" : "2014-01-23 17:48:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uLaDx7zLAA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vdfTh6cQ",
      "display_url" : "pastebin.com\/raw.php?i=vdfT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426409281882058752",
  "text" : "http:\/\/t.co\/uLaDx7zLAA Emails: 101 Keywords: 0.0 #infoleak",
  "id" : 426409281882058752,
  "created_at" : "2014-01-23 17:41:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J5OnvN7sX8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ABmJvQWa",
      "display_url" : "pastebin.com\/raw.php?i=ABmJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426408319796789248",
  "text" : "http:\/\/t.co\/J5OnvN7sX8 Emails: 4 Hashes: 32 E\/H: 0.13 Keywords: 0.19 #infoleak",
  "id" : 426408319796789248,
  "created_at" : "2014-01-23 17:37:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EOZDNHVoiX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EGz5VJsm",
      "display_url" : "pastebin.com\/raw.php?i=EGz5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426387847847759872",
  "text" : "http:\/\/t.co\/EOZDNHVoiX Emails: 6 Hashes: 41 E\/H: 0.15 Keywords: 0.33 #infoleak",
  "id" : 426387847847759872,
  "created_at" : "2014-01-23 16:15:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IJwYRLaWbE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FAGN0EMt",
      "display_url" : "pastebin.com\/raw.php?i=FAGN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426384013259857921",
  "text" : "http:\/\/t.co\/IJwYRLaWbE Hashes: 59 Keywords: 0.22 #infoleak",
  "id" : 426384013259857921,
  "created_at" : "2014-01-23 16:00:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2OwcPv8Pl7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pmMSdkVW",
      "display_url" : "pastebin.com\/raw.php?i=pmMS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426383489257066497",
  "text" : "http:\/\/t.co\/2OwcPv8Pl7 Emails: 4282 Keywords: 0.11 #infoleak",
  "id" : 426383489257066497,
  "created_at" : "2014-01-23 15:58:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4KoBVohKiw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ug2Xdejv",
      "display_url" : "pastebin.com\/raw.php?i=ug2X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426377767752437761",
  "text" : "http:\/\/t.co\/4KoBVohKiw Emails: 1780 Keywords: 0.33 #infoleak",
  "id" : 426377767752437761,
  "created_at" : "2014-01-23 15:35:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ph6AozJdp6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XnzuG6y5",
      "display_url" : "pastebin.com\/raw.php?i=Xnzu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426375440270249984",
  "text" : "http:\/\/t.co\/ph6AozJdp6 Keywords: 0.55 #infoleak",
  "id" : 426375440270249984,
  "created_at" : "2014-01-23 15:26:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j55Oorosw7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cTRyz2fa",
      "display_url" : "pastebin.com\/raw.php?i=cTRy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426360471289995264",
  "text" : "http:\/\/t.co\/j55Oorosw7 Emails: 286 Keywords: 0.11 #infoleak",
  "id" : 426360471289995264,
  "created_at" : "2014-01-23 14:27:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TMYHnVIOVR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4sP8N8w1",
      "display_url" : "pastebin.com\/raw.php?i=4sP8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426359013039550464",
  "text" : "http:\/\/t.co\/TMYHnVIOVR Emails: 154 Keywords: 0.0 #infoleak",
  "id" : 426359013039550464,
  "created_at" : "2014-01-23 14:21:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NsVeOBArt9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N87SncMp",
      "display_url" : "pastebin.com\/raw.php?i=N87S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426348044557504513",
  "text" : "http:\/\/t.co\/NsVeOBArt9 Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 426348044557504513,
  "created_at" : "2014-01-23 13:37:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/66OldSNERa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wpS71MHV",
      "display_url" : "pastebin.com\/raw.php?i=wpS7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426298251151560704",
  "text" : "http:\/\/t.co\/66OldSNERa Hashes: 48 Keywords: 0.22 #infoleak",
  "id" : 426298251151560704,
  "created_at" : "2014-01-23 10:19:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x99ruZ4jD0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NHtVyivJ",
      "display_url" : "pastebin.com\/raw.php?i=NHtV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426294169653366785",
  "text" : "http:\/\/t.co\/x99ruZ4jD0 Hashes: 31 Keywords: 0.0 #infoleak",
  "id" : 426294169653366785,
  "created_at" : "2014-01-23 10:03:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/upIw24nr7M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6JppwG9b",
      "display_url" : "pastebin.com\/raw.php?i=6Jpp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426293483851112448",
  "text" : "http:\/\/t.co\/upIw24nr7M Found possible Google API key(s) #infoleak",
  "id" : 426293483851112448,
  "created_at" : "2014-01-23 10:01:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nm2KiI19Sq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zTgPxUwc",
      "display_url" : "pastebin.com\/raw.php?i=zTgP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426278195826921472",
  "text" : "http:\/\/t.co\/nm2KiI19Sq Emails: 153 Hashes: 1 E\/H: 153.0 Keywords: 0.08 #infoleak",
  "id" : 426278195826921472,
  "created_at" : "2014-01-23 09:00:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qrz0lmPg8U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VNA2gRzF",
      "display_url" : "pastebin.com\/raw.php?i=VNA2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426277943283683328",
  "text" : "http:\/\/t.co\/qrz0lmPg8U Emails: 1 Hashes: 251 E\/H: 0.0 Keywords: 0.19 #infoleak",
  "id" : 426277943283683328,
  "created_at" : "2014-01-23 08:59:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TTCeRHVNBf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u4KTSmj5",
      "display_url" : "pastebin.com\/raw.php?i=u4KT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426276091209060353",
  "text" : "http:\/\/t.co\/TTCeRHVNBf Emails: 153 Hashes: 1 E\/H: 153.0 Keywords: 0.08 #infoleak",
  "id" : 426276091209060353,
  "created_at" : "2014-01-23 08:51:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5b3xEhJcoA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BVWZ4E4j",
      "display_url" : "pastebin.com\/raw.php?i=BVWZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426261085532864512",
  "text" : "http:\/\/t.co\/5b3xEhJcoA Emails: 253 Hashes: 253 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 426261085532864512,
  "created_at" : "2014-01-23 07:52:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9a9gIHfxCk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EkQiyVzm",
      "display_url" : "pastebin.com\/raw.php?i=EkQi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426254528116051968",
  "text" : "http:\/\/t.co\/9a9gIHfxCk Emails: 132 Keywords: 0.0 #infoleak",
  "id" : 426254528116051968,
  "created_at" : "2014-01-23 07:26:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ipoj1hq24c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5Ny7XJcB",
      "display_url" : "pastebin.com\/raw.php?i=5Ny7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426236200966295552",
  "text" : "http:\/\/t.co\/Ipoj1hq24c Emails: 171 Keywords: 0.0 #infoleak",
  "id" : 426236200966295552,
  "created_at" : "2014-01-23 06:13:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426217163876093953",
  "text" : "Back up and running! Have you organized your network cables recently?",
  "id" : 426217163876093953,
  "created_at" : "2014-01-23 04:57:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aeTrVxyAiN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V0sCwnCu",
      "display_url" : "pastebin.com\/raw.php?i=V0sC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426217010469433344",
  "text" : "http:\/\/t.co\/aeTrVxyAiN Emails: 149 Keywords: 0.08 #infoleak",
  "id" : 426217010469433344,
  "created_at" : "2014-01-23 04:57:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425697122160082944",
  "text" : "Be back soon! Just down for maintenance. :)",
  "id" : 425697122160082944,
  "created_at" : "2014-01-21 18:31:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h3YQGx6hjV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=thRACW6T",
      "display_url" : "pastebin.com\/raw.php?i=thRA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424893548568121345",
  "text" : "http:\/\/t.co\/h3YQGx6hjV Possible cisco configuration #infoleak",
  "id" : 424893548568121345,
  "created_at" : "2014-01-19 13:18:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C3LiczUj7L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EkWjKe60",
      "display_url" : "pastebin.com\/raw.php?i=EkWj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424888241481723904",
  "text" : "http:\/\/t.co\/C3LiczUj7L Emails: 337 Keywords: 0.11 #infoleak",
  "id" : 424888241481723904,
  "created_at" : "2014-01-19 12:57:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ztb4a5TIGh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TfyRKyNV",
      "display_url" : "pastebin.com\/raw.php?i=TfyR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424858650616659968",
  "text" : "http:\/\/t.co\/ztb4a5TIGh Emails: 349 Hashes: 574 E\/H: 0.61 Keywords: 0.63 #infoleak",
  "id" : 424858650616659968,
  "created_at" : "2014-01-19 10:59:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yGnvih9Aax",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yADS9UiY",
      "display_url" : "pastebin.com\/raw.php?i=yADS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424857608139182080",
  "text" : "http:\/\/t.co\/yGnvih9Aax Emails: 11007 Keywords: 0.19 #infoleak",
  "id" : 424857608139182080,
  "created_at" : "2014-01-19 10:55:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PdPn8CqZWp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PNRmy5EN",
      "display_url" : "pastebin.com\/raw.php?i=PNRm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424852018012753920",
  "text" : "http:\/\/t.co\/PdPn8CqZWp Keywords: 0.55 #infoleak",
  "id" : 424852018012753920,
  "created_at" : "2014-01-19 10:33:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RCX9QDeK8d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=byqNPyAf",
      "display_url" : "pastebin.com\/raw.php?i=byqN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424849639578144768",
  "text" : "http:\/\/t.co\/RCX9QDeK8d Emails: 1 Hashes: 45 E\/H: 0.02 Keywords: 0.22 #infoleak",
  "id" : 424849639578144768,
  "created_at" : "2014-01-19 10:23:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/riqFxruaDz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LVKNiGH2",
      "display_url" : "pastebin.com\/raw.php?i=LVKN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424738490622803969",
  "text" : "http:\/\/t.co\/riqFxruaDz Emails: 429 Keywords: 0.11 #infoleak",
  "id" : 424738490622803969,
  "created_at" : "2014-01-19 03:02:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kzpJkpFSn9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=skHAScRc",
      "display_url" : "pastebin.com\/raw.php?i=skHA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424727736859373568",
  "text" : "http:\/\/t.co\/kzpJkpFSn9 Emails: 339 Hashes: 7 E\/H: 48.43 Keywords: 0.19 #infoleak",
  "id" : 424727736859373568,
  "created_at" : "2014-01-19 02:19:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gaRdAukous",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9NdUwid6",
      "display_url" : "pastebin.com\/raw.php?i=9NdU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424720522731982848",
  "text" : "http:\/\/t.co\/gaRdAukous Keywords: 0.55 #infoleak",
  "id" : 424720522731982848,
  "created_at" : "2014-01-19 01:50:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/elSHCoNMaC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i6yNtp9s",
      "display_url" : "pastebin.com\/raw.php?i=i6yN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424719624052015104",
  "text" : "http:\/\/t.co\/elSHCoNMaC Emails: 623 Keywords: 0.22 #infoleak",
  "id" : 424719624052015104,
  "created_at" : "2014-01-19 01:47:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uopskFCvaD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WNxphZJV",
      "display_url" : "pastebin.com\/raw.php?i=WNxp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424713437566861312",
  "text" : "http:\/\/t.co\/uopskFCvaD Found possible Google API key(s) #infoleak",
  "id" : 424713437566861312,
  "created_at" : "2014-01-19 01:22:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E6lWuYxEps",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GGyyC2qX",
      "display_url" : "pastebin.com\/raw.php?i=GGyy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424699086625722368",
  "text" : "http:\/\/t.co\/E6lWuYxEps Emails: 91 Keywords: 0.11 #infoleak",
  "id" : 424699086625722368,
  "created_at" : "2014-01-19 00:25:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xako6Hm7r4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KkNzn3Zt",
      "display_url" : "pastebin.com\/raw.php?i=KkNz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424686911689457664",
  "text" : "http:\/\/t.co\/Xako6Hm7r4 Keywords: 0.55 #infoleak",
  "id" : 424686911689457664,
  "created_at" : "2014-01-18 23:37:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W2xZrtUJE6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KQ8TGpw9",
      "display_url" : "pastebin.com\/raw.php?i=KQ8T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424668466893705216",
  "text" : "http:\/\/t.co\/W2xZrtUJE6 Emails: 24 Keywords: 0.3 #infoleak",
  "id" : 424668466893705216,
  "created_at" : "2014-01-18 22:23:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eF4oqyPgJx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HvwYwxki",
      "display_url" : "pastebin.com\/raw.php?i=HvwY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424661527153483776",
  "text" : "http:\/\/t.co\/eF4oqyPgJx Emails: 140 Hashes: 4 E\/H: 35.0 Keywords: 0.22 #infoleak",
  "id" : 424661527153483776,
  "created_at" : "2014-01-18 21:56:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NcMtwh5xqR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dSAgMPb4",
      "display_url" : "pastebin.com\/raw.php?i=dSAg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424661025971896320",
  "text" : "http:\/\/t.co\/NcMtwh5xqR Possible cisco configuration #infoleak",
  "id" : 424661025971896320,
  "created_at" : "2014-01-18 21:54:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wLmEiD3nK0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GaCgkEG8",
      "display_url" : "pastebin.com\/raw.php?i=GaCg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424659602509021184",
  "text" : "http:\/\/t.co\/wLmEiD3nK0 Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 424659602509021184,
  "created_at" : "2014-01-18 21:48:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4jaSNAbG3Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FEd5LvJ9",
      "display_url" : "pastebin.com\/raw.php?i=FEd5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424655302399492096",
  "text" : "http:\/\/t.co\/4jaSNAbG3Z Emails: 327 Keywords: 0.0 #infoleak",
  "id" : 424655302399492096,
  "created_at" : "2014-01-18 21:31:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BtfzEqFic9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pMnKpBWK",
      "display_url" : "pastebin.com\/raw.php?i=pMnK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424655030281453568",
  "text" : "http:\/\/t.co\/BtfzEqFic9 Emails: 5 Keywords: 0.55 #infoleak",
  "id" : 424655030281453568,
  "created_at" : "2014-01-18 21:30:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wCxnJWQ3WQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CyBYwMn1",
      "display_url" : "pastebin.com\/raw.php?i=CyBY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424645724060413953",
  "text" : "http:\/\/t.co\/wCxnJWQ3WQ Emails: 3 Hashes: 33 E\/H: 0.09 Keywords: 0.11 #infoleak",
  "id" : 424645724060413953,
  "created_at" : "2014-01-18 20:53:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w9bUcAfiYF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bDHCYX2k",
      "display_url" : "pastebin.com\/raw.php?i=bDHC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424643640472776704",
  "text" : "http:\/\/t.co\/w9bUcAfiYF Emails: 149 Hashes: 158 E\/H: 0.94 Keywords: 0.08 #infoleak",
  "id" : 424643640472776704,
  "created_at" : "2014-01-18 20:45:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RBJWP69YDC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dYTLab1r",
      "display_url" : "pastebin.com\/raw.php?i=dYTL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424634393118793729",
  "text" : "http:\/\/t.co\/RBJWP69YDC Emails: 66 Keywords: 0.22 #infoleak",
  "id" : 424634393118793729,
  "created_at" : "2014-01-18 20:08:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sNuE005DmW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9S1461ay",
      "display_url" : "pastebin.com\/raw.php?i=9S14\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424631440156807168",
  "text" : "http:\/\/t.co\/sNuE005DmW Emails: 125 Keywords: 0.22 #infoleak",
  "id" : 424631440156807168,
  "created_at" : "2014-01-18 19:56:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3rlEWhdGYs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WHcdKAUK",
      "display_url" : "pastebin.com\/raw.php?i=WHcd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424616530559524864",
  "text" : "http:\/\/t.co\/3rlEWhdGYs Emails: 40 Keywords: 0.0 #infoleak",
  "id" : 424616530559524864,
  "created_at" : "2014-01-18 18:57:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5EPDWOxZ8B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=drfrBpVh",
      "display_url" : "pastebin.com\/raw.php?i=drfr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424614429414543360",
  "text" : "http:\/\/t.co\/5EPDWOxZ8B Emails: 82 Keywords: -0.03 #infoleak",
  "id" : 424614429414543360,
  "created_at" : "2014-01-18 18:49:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fC9U6e2FOT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fafvgmt7",
      "display_url" : "pastebin.com\/raw.php?i=fafv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424587218519216129",
  "text" : "http:\/\/t.co\/fC9U6e2FOT Emails: 3543 Keywords: 0.11 #infoleak",
  "id" : 424587218519216129,
  "created_at" : "2014-01-18 17:00:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1GtncFYvsk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YdkWYATv",
      "display_url" : "pastebin.com\/raw.php?i=YdkW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424585073933832192",
  "text" : "http:\/\/t.co\/1GtncFYvsk Emails: 396 Keywords: 0.22 #infoleak",
  "id" : 424585073933832192,
  "created_at" : "2014-01-18 16:52:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/88yE4NFqqu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UFD1Jfaz",
      "display_url" : "pastebin.com\/raw.php?i=UFD1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424580412329832448",
  "text" : "http:\/\/t.co\/88yE4NFqqu Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 424580412329832448,
  "created_at" : "2014-01-18 16:33:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lCDWq5XTog",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9dk8v3Ft",
      "display_url" : "pastebin.com\/raw.php?i=9dk8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424569801248215041",
  "text" : "http:\/\/t.co\/lCDWq5XTog Found possible Google API key(s) #infoleak",
  "id" : 424569801248215041,
  "created_at" : "2014-01-18 15:51:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2iC0aBOyjZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=USRtMgUe",
      "display_url" : "pastebin.com\/raw.php?i=USRt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424557526282035200",
  "text" : "http:\/\/t.co\/2iC0aBOyjZ Emails: 7 Hashes: 937 E\/H: 0.01 Keywords: 0.3 #infoleak",
  "id" : 424557526282035200,
  "created_at" : "2014-01-18 15:02:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/seA10kgxC1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M5PPGaeM",
      "display_url" : "pastebin.com\/raw.php?i=M5PP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424552992575336448",
  "text" : "http:\/\/t.co\/seA10kgxC1 Emails: 84 Keywords: 0.11 #infoleak",
  "id" : 424552992575336448,
  "created_at" : "2014-01-18 14:44:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/diXIInS8ED",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9bmf1Exf",
      "display_url" : "pastebin.com\/raw.php?i=9bmf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424522470826065920",
  "text" : "http:\/\/t.co\/diXIInS8ED Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 424522470826065920,
  "created_at" : "2014-01-18 12:43:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u3azK75YCO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=27bck88D",
      "display_url" : "pastebin.com\/raw.php?i=27bc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424522266932568064",
  "text" : "http:\/\/t.co\/u3azK75YCO Emails: 20 Keywords: 0.33 #infoleak",
  "id" : 424522266932568064,
  "created_at" : "2014-01-18 12:42:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MDRKxlWDLL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f6vSKAHt",
      "display_url" : "pastebin.com\/raw.php?i=f6vS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424513939875983361",
  "text" : "http:\/\/t.co\/MDRKxlWDLL Emails: 280 Keywords: 0.0 #infoleak",
  "id" : 424513939875983361,
  "created_at" : "2014-01-18 12:09:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0z7CQ6Y20O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=akwVNQxD",
      "display_url" : "pastebin.com\/raw.php?i=akwV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424511713069645824",
  "text" : "http:\/\/t.co\/0z7CQ6Y20O Emails: 486 Hashes: 239 E\/H: 2.03 Keywords: 0.11 #infoleak",
  "id" : 424511713069645824,
  "created_at" : "2014-01-18 12:00:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8FgwmEFSpM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DJgsXWmf",
      "display_url" : "pastebin.com\/raw.php?i=DJgs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424507656611438592",
  "text" : "http:\/\/t.co\/8FgwmEFSpM Found possible Google API key(s) #infoleak",
  "id" : 424507656611438592,
  "created_at" : "2014-01-18 11:44:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ntBT4E2KlS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Aa5sjrxf",
      "display_url" : "pastebin.com\/raw.php?i=Aa5s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424493484507013120",
  "text" : "http:\/\/t.co\/ntBT4E2KlS Emails: 310 Keywords: 0.0 #infoleak",
  "id" : 424493484507013120,
  "created_at" : "2014-01-18 10:48:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BDRpedQx6m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v4jZpTRW",
      "display_url" : "pastebin.com\/raw.php?i=v4jZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424489340597592064",
  "text" : "http:\/\/t.co\/BDRpedQx6m Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 424489340597592064,
  "created_at" : "2014-01-18 10:32:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oj7hxOqYHE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JwEnMHFg",
      "display_url" : "pastebin.com\/raw.php?i=JwEn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424484149714374656",
  "text" : "http:\/\/t.co\/oj7hxOqYHE Emails: 42 Keywords: 0.22 #infoleak",
  "id" : 424484149714374656,
  "created_at" : "2014-01-18 10:11:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EBcFvjhxUZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JjM52d20",
      "display_url" : "pastebin.com\/raw.php?i=JjM5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424479640816594945",
  "text" : "http:\/\/t.co\/EBcFvjhxUZ Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 424479640816594945,
  "created_at" : "2014-01-18 09:53:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2OYAoAc8tc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D6CrfqQr",
      "display_url" : "pastebin.com\/raw.php?i=D6Cr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424471365245083649",
  "text" : "http:\/\/t.co\/2OYAoAc8tc Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 424471365245083649,
  "created_at" : "2014-01-18 09:20:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wacD807uY0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HYbQmWNQ",
      "display_url" : "pastebin.com\/raw.php?i=HYbQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424452623379353600",
  "text" : "http:\/\/t.co\/wacD807uY0 Hashes: 1 Keywords: 0.55 #infoleak",
  "id" : 424452623379353600,
  "created_at" : "2014-01-18 08:06:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YocE6b4UKG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Nef0tHjg",
      "display_url" : "pastebin.com\/raw.php?i=Nef0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424438924841193472",
  "text" : "http:\/\/t.co\/YocE6b4UKG Emails: 107 Keywords: 0.0 #infoleak",
  "id" : 424438924841193472,
  "created_at" : "2014-01-18 07:11:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IT7YKXktjx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z9EGRqZq",
      "display_url" : "pastebin.com\/raw.php?i=Z9EG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424425475826388992",
  "text" : "http:\/\/t.co\/IT7YKXktjx Emails: 102 Keywords: 0.0 #infoleak",
  "id" : 424425475826388992,
  "created_at" : "2014-01-18 06:18:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UxR5tmA3Gj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5trij86N",
      "display_url" : "pastebin.com\/raw.php?i=5tri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424410283772108800",
  "text" : "http:\/\/t.co\/UxR5tmA3Gj Hashes: 2 Keywords: 0.55 #infoleak",
  "id" : 424410283772108800,
  "created_at" : "2014-01-18 05:17:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gAcHA69B1W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8esXsURA",
      "display_url" : "pastebin.com\/raw.php?i=8esX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424405554354597888",
  "text" : "http:\/\/t.co\/gAcHA69B1W Emails: 340 Hashes: 359 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 424405554354597888,
  "created_at" : "2014-01-18 04:59:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Rg0iw5sUBK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bT9FhH7i",
      "display_url" : "pastebin.com\/raw.php?i=bT9F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424369820478357505",
  "text" : "http:\/\/t.co\/Rg0iw5sUBK Emails: 24 Keywords: -0.03 #infoleak",
  "id" : 424369820478357505,
  "created_at" : "2014-01-18 02:37:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KMVRQXjiKP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K4RBhkCS",
      "display_url" : "pastebin.com\/raw.php?i=K4RB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424364393468399616",
  "text" : "http:\/\/t.co\/KMVRQXjiKP Hashes: 45 Keywords: 0.0 #infoleak",
  "id" : 424364393468399616,
  "created_at" : "2014-01-18 02:15:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K0XtHvoLiu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sn13mh4b",
      "display_url" : "pastebin.com\/raw.php?i=sn13\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424359078991626240",
  "text" : "http:\/\/t.co\/K0XtHvoLiu Hashes: 30 Keywords: 0.22 #infoleak",
  "id" : 424359078991626240,
  "created_at" : "2014-01-18 01:54:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G0datX9B5h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=04tHTNkP",
      "display_url" : "pastebin.com\/raw.php?i=04tH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424351610697834497",
  "text" : "http:\/\/t.co\/G0datX9B5h Emails: 57 Keywords: 0.3 #infoleak",
  "id" : 424351610697834497,
  "created_at" : "2014-01-18 01:24:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AR37LCKDdG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y9Z1Kmkx",
      "display_url" : "pastebin.com\/raw.php?i=Y9Z1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424339633690791937",
  "text" : "http:\/\/t.co\/AR37LCKDdG Emails: 26 Hashes: 5 E\/H: 5.2 Keywords: 0.22 #infoleak",
  "id" : 424339633690791937,
  "created_at" : "2014-01-18 00:37:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XVHa2w6cNX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AmEyitLF",
      "display_url" : "pastebin.com\/raw.php?i=AmEy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424336536377643008",
  "text" : "http:\/\/t.co\/XVHa2w6cNX Found possible Google API key(s) #infoleak",
  "id" : 424336536377643008,
  "created_at" : "2014-01-18 00:24:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jXUw7bnmZu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kCgy7X2R",
      "display_url" : "pastebin.com\/raw.php?i=kCgy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424330885442195456",
  "text" : "http:\/\/t.co\/jXUw7bnmZu Hashes: 220 Keywords: 0.0 #infoleak",
  "id" : 424330885442195456,
  "created_at" : "2014-01-18 00:02:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1Cy6KhHiU4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=77CdRVBd",
      "display_url" : "pastebin.com\/raw.php?i=77Cd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424328079947743232",
  "text" : "http:\/\/t.co\/1Cy6KhHiU4 Hashes: 109 Keywords: -0.03 #infoleak",
  "id" : 424328079947743232,
  "created_at" : "2014-01-17 23:51:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tmkq1kEVHN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NKRazVyr",
      "display_url" : "pastebin.com\/raw.php?i=NKRa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424323120724312064",
  "text" : "http:\/\/t.co\/Tmkq1kEVHN Hashes: 45 Keywords: 0.0 #infoleak",
  "id" : 424323120724312064,
  "created_at" : "2014-01-17 23:31:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G0vhiKfnMn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qqNfj0bU",
      "display_url" : "pastebin.com\/raw.php?i=qqNf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424322784617955328",
  "text" : "http:\/\/t.co\/G0vhiKfnMn Hashes: 45 Keywords: 0.0 #infoleak",
  "id" : 424322784617955328,
  "created_at" : "2014-01-17 23:30:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A3M52X6lXd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ypm6C5E7",
      "display_url" : "pastebin.com\/raw.php?i=Ypm6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424321410001948673",
  "text" : "http:\/\/t.co\/A3M52X6lXd Emails: 241 Keywords: 0.0 #infoleak",
  "id" : 424321410001948673,
  "created_at" : "2014-01-17 23:24:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P3ESor8ivk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rCCfAntd",
      "display_url" : "pastebin.com\/raw.php?i=rCCf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424320751076782080",
  "text" : "http:\/\/t.co\/P3ESor8ivk Emails: 268 Keywords: 0.0 #infoleak",
  "id" : 424320751076782080,
  "created_at" : "2014-01-17 23:22:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/64HitCIMYb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T8iPQVZf",
      "display_url" : "pastebin.com\/raw.php?i=T8iP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424313841132920832",
  "text" : "http:\/\/t.co\/64HitCIMYb Hashes: 2 Keywords: 0.66 #infoleak",
  "id" : 424313841132920832,
  "created_at" : "2014-01-17 22:54:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aqqCIMzeB9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MNQYYCi7",
      "display_url" : "pastebin.com\/raw.php?i=MNQY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424308828012695552",
  "text" : "http:\/\/t.co\/aqqCIMzeB9 Found possible Google API key(s) #infoleak",
  "id" : 424308828012695552,
  "created_at" : "2014-01-17 22:34:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VrAuRQn3cX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1EMyVkGP",
      "display_url" : "pastebin.com\/raw.php?i=1EMy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424308769317601280",
  "text" : "http:\/\/t.co\/VrAuRQn3cX Possible cisco configuration #infoleak",
  "id" : 424308769317601280,
  "created_at" : "2014-01-17 22:34:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jLf1PjWtK9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8WmrBK4B",
      "display_url" : "pastebin.com\/raw.php?i=8Wmr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424304923052765184",
  "text" : "http:\/\/t.co\/jLf1PjWtK9 Emails: 25 Keywords: 0.33 #infoleak",
  "id" : 424304923052765184,
  "created_at" : "2014-01-17 22:19:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pPtk8hbHju",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XJt3UPDd",
      "display_url" : "pastebin.com\/raw.php?i=XJt3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424294518288953344",
  "text" : "http:\/\/t.co\/pPtk8hbHju Found possible Google API key(s) #infoleak",
  "id" : 424294518288953344,
  "created_at" : "2014-01-17 21:37:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oeGrjA6sB7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KUzcPLLF",
      "display_url" : "pastebin.com\/raw.php?i=KUzc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424274894088441856",
  "text" : "http:\/\/t.co\/oeGrjA6sB7 Possible cisco configuration #infoleak",
  "id" : 424274894088441856,
  "created_at" : "2014-01-17 20:19:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sldZlyZTMo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5LeJVLqD",
      "display_url" : "pastebin.com\/raw.php?i=5LeJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424156803463520257",
  "text" : "http:\/\/t.co\/sldZlyZTMo Emails: 2411 Hashes: 4 E\/H: 602.75 Keywords: 0.44 #infoleak",
  "id" : 424156803463520257,
  "created_at" : "2014-01-17 12:30:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o13FMLhFCb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N39xiCe3",
      "display_url" : "pastebin.com\/raw.php?i=N39x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424156162510974976",
  "text" : "http:\/\/t.co\/o13FMLhFCb Emails: 2322 Keywords: 0.11 #infoleak",
  "id" : 424156162510974976,
  "created_at" : "2014-01-17 12:28:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nkRGrV0LYM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=38DjwqcW",
      "display_url" : "pastebin.com\/raw.php?i=38Dj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424110226116079617",
  "text" : "http:\/\/t.co\/nkRGrV0LYM Found possible Google API key(s) #infoleak",
  "id" : 424110226116079617,
  "created_at" : "2014-01-17 09:25:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jKtqQipCIi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4QkKiWBS",
      "display_url" : "pastebin.com\/raw.php?i=4QkK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424099471727677440",
  "text" : "http:\/\/t.co\/jKtqQipCIi Found possible Google API key(s) #infoleak",
  "id" : 424099471727677440,
  "created_at" : "2014-01-17 08:42:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oMnbJtJHxr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hk7rQzsJ",
      "display_url" : "pastebin.com\/raw.php?i=Hk7r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424078309484265472",
  "text" : "http:\/\/t.co\/oMnbJtJHxr Found possible Google API key(s) #infoleak",
  "id" : 424078309484265472,
  "created_at" : "2014-01-17 07:18:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kwu4VcD1x8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RLgBLC5C",
      "display_url" : "pastebin.com\/raw.php?i=RLgB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424059775861522433",
  "text" : "http:\/\/t.co\/kwu4VcD1x8 Emails: 112 Keywords: 0.0 #infoleak",
  "id" : 424059775861522433,
  "created_at" : "2014-01-17 06:05:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lkpcZc0lIE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sj4mrQDM",
      "display_url" : "pastebin.com\/raw.php?i=sj4m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424051416760455169",
  "text" : "http:\/\/t.co\/lkpcZc0lIE Emails: 31 Keywords: 0.08 #infoleak",
  "id" : 424051416760455169,
  "created_at" : "2014-01-17 05:31:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wFcc9Kpatl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3D8tN1Zp",
      "display_url" : "pastebin.com\/raw.php?i=3D8t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424043088206512128",
  "text" : "http:\/\/t.co\/wFcc9Kpatl Emails: 31 Keywords: -0.14 #infoleak",
  "id" : 424043088206512128,
  "created_at" : "2014-01-17 04:58:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kLQuyCKYIw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mPgLxvzq",
      "display_url" : "pastebin.com\/raw.php?i=mPgL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424040767762358272",
  "text" : "http:\/\/t.co\/kLQuyCKYIw Found possible Google API key(s) #infoleak",
  "id" : 424040767762358272,
  "created_at" : "2014-01-17 04:49:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wWfJ4vqIac",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hRMZaSmT",
      "display_url" : "pastebin.com\/raw.php?i=hRMZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424028248687656960",
  "text" : "http:\/\/t.co\/wWfJ4vqIac Emails: 73 Keywords: 0.33 #infoleak",
  "id" : 424028248687656960,
  "created_at" : "2014-01-17 03:59:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/526P3w3xes",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nkKtzsTp",
      "display_url" : "pastebin.com\/raw.php?i=nkKt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424023393248104449",
  "text" : "http:\/\/t.co\/526P3w3xes Emails: 3322 Keywords: 0.33 #infoleak",
  "id" : 424023393248104449,
  "created_at" : "2014-01-17 03:40:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4dXi8Gx1gF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eWpQnDh7",
      "display_url" : "pastebin.com\/raw.php?i=eWpQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424015293854150656",
  "text" : "http:\/\/t.co\/4dXi8Gx1gF Hashes: 409 Keywords: 0.05 #infoleak",
  "id" : 424015293854150656,
  "created_at" : "2014-01-17 03:08:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0Lw8eSQQ2S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W8jWqHBK",
      "display_url" : "pastebin.com\/raw.php?i=W8jW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424001582561124353",
  "text" : "http:\/\/t.co\/0Lw8eSQQ2S Hashes: 158 Keywords: 0.08 #infoleak",
  "id" : 424001582561124353,
  "created_at" : "2014-01-17 02:13:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oTwdkkCx3T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z8sLYqbj",
      "display_url" : "pastebin.com\/raw.php?i=z8sL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423999717349920768",
  "text" : "http:\/\/t.co\/oTwdkkCx3T Hashes: 39 Keywords: -0.03 #infoleak",
  "id" : 423999717349920768,
  "created_at" : "2014-01-17 02:06:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vWJxBYBpRn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jmMvWvGk",
      "display_url" : "pastebin.com\/raw.php?i=jmMv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423998653590536192",
  "text" : "http:\/\/t.co\/vWJxBYBpRn Emails: 2278 Keywords: -0.03 #infoleak",
  "id" : 423998653590536192,
  "created_at" : "2014-01-17 02:02:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m4wFCSNVwx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ry24KNuP",
      "display_url" : "pastebin.com\/raw.php?i=Ry24\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423993979412021248",
  "text" : "http:\/\/t.co\/m4wFCSNVwx Found possible Google API key(s) #infoleak",
  "id" : 423993979412021248,
  "created_at" : "2014-01-17 01:43:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ax7B9Co8xT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KFxEXuRk",
      "display_url" : "pastebin.com\/raw.php?i=KFxE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423993545318350848",
  "text" : "http:\/\/t.co\/Ax7B9Co8xT Emails: 1064 Keywords: 0.0 #infoleak",
  "id" : 423993545318350848,
  "created_at" : "2014-01-17 01:41:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yp2NQgl8Rx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CBvz08Rc",
      "display_url" : "pastebin.com\/raw.php?i=CBvz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423993306058473472",
  "text" : "http:\/\/t.co\/Yp2NQgl8Rx Emails: 31 Keywords: -0.14 #infoleak",
  "id" : 423993306058473472,
  "created_at" : "2014-01-17 01:40:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9Rz9cIG4VK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0r7AwjL6",
      "display_url" : "pastebin.com\/raw.php?i=0r7A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423972611026997248",
  "text" : "http:\/\/t.co\/9Rz9cIG4VK Found possible Google API key(s) #infoleak",
  "id" : 423972611026997248,
  "created_at" : "2014-01-17 00:18:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lpMKw0sWIM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8JD7M9JL",
      "display_url" : "pastebin.com\/raw.php?i=8JD7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423965324505927680",
  "text" : "http:\/\/t.co\/lpMKw0sWIM Emails: 1 Hashes: 58 E\/H: 0.02 Keywords: 0.11 #infoleak",
  "id" : 423965324505927680,
  "created_at" : "2014-01-16 23:49:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JlnM80uTqY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c9piGARx",
      "display_url" : "pastebin.com\/raw.php?i=c9pi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423958356047306752",
  "text" : "http:\/\/t.co\/JlnM80uTqY Emails: 3 Hashes: 11 E\/H: 0.27 Keywords: 0.66 #infoleak",
  "id" : 423958356047306752,
  "created_at" : "2014-01-16 23:22:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g2ewYZb8b0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hmcxuS2K",
      "display_url" : "pastebin.com\/raw.php?i=hmcx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423956436452782080",
  "text" : "http:\/\/t.co\/g2ewYZb8b0 Hashes: 122 Keywords: 0.22 #infoleak",
  "id" : 423956436452782080,
  "created_at" : "2014-01-16 23:14:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h7rcBiu1AL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gFY0z8Ye",
      "display_url" : "pastebin.com\/raw.php?i=gFY0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423953037862776832",
  "text" : "http:\/\/t.co\/h7rcBiu1AL Emails: 37 Keywords: 0.44 #infoleak",
  "id" : 423953037862776832,
  "created_at" : "2014-01-16 23:00:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vzIN5QCRgr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8XVY4UfN",
      "display_url" : "pastebin.com\/raw.php?i=8XVY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423952256010969088",
  "text" : "http:\/\/t.co\/vzIN5QCRgr Emails: 6917 Keywords: 0.0 #infoleak",
  "id" : 423952256010969088,
  "created_at" : "2014-01-16 22:57:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1BtoGlXHru",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bWqzJDCH",
      "display_url" : "pastebin.com\/raw.php?i=bWqz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423944466903212033",
  "text" : "http:\/\/t.co\/1BtoGlXHru Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 423944466903212033,
  "created_at" : "2014-01-16 22:26:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/epxM5bff4B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6DeZECmc",
      "display_url" : "pastebin.com\/raw.php?i=6DeZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423938211887325184",
  "text" : "http:\/\/t.co\/epxM5bff4B Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.55 #infoleak",
  "id" : 423938211887325184,
  "created_at" : "2014-01-16 22:02:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xj0ROX3c7y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PiYn6TYv",
      "display_url" : "pastebin.com\/raw.php?i=PiYn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423929051816812544",
  "text" : "http:\/\/t.co\/xj0ROX3c7y Emails: 3081 Keywords: 0.19 #infoleak",
  "id" : 423929051816812544,
  "created_at" : "2014-01-16 21:25:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xyIe8ugQyh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1NqBQTKQ",
      "display_url" : "pastebin.com\/raw.php?i=1NqB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423819098586230784",
  "text" : "http:\/\/t.co\/xyIe8ugQyh Emails: 74 Keywords: 0.0 #infoleak",
  "id" : 423819098586230784,
  "created_at" : "2014-01-16 14:08:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CaYNeYh4Tz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=92HYndV4",
      "display_url" : "pastebin.com\/raw.php?i=92HY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423818506870611968",
  "text" : "http:\/\/t.co\/CaYNeYh4Tz Possible cisco configuration #infoleak",
  "id" : 423818506870611968,
  "created_at" : "2014-01-16 14:06:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p3nkNjByoE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eCG5JaJb",
      "display_url" : "pastebin.com\/raw.php?i=eCG5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423795472499613697",
  "text" : "http:\/\/t.co\/p3nkNjByoE Emails: 66 Keywords: 0.11 #infoleak",
  "id" : 423795472499613697,
  "created_at" : "2014-01-16 12:34:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s0Y2aTWXMD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bdg5aEmw",
      "display_url" : "pastebin.com\/raw.php?i=Bdg5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423795206727536640",
  "text" : "http:\/\/t.co\/s0Y2aTWXMD Emails: 66 Keywords: 0.11 #infoleak",
  "id" : 423795206727536640,
  "created_at" : "2014-01-16 12:33:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/30xIkl3wo7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pUFHPKVb",
      "display_url" : "pastebin.com\/raw.php?i=pUFH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423739085161648129",
  "text" : "http:\/\/t.co\/30xIkl3wo7 Emails: 23 Keywords: -0.17 #infoleak",
  "id" : 423739085161648129,
  "created_at" : "2014-01-16 08:50:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lIiVBdziS7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5fjFkhN6",
      "display_url" : "pastebin.com\/raw.php?i=5fjF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423732707684659201",
  "text" : "http:\/\/t.co\/lIiVBdziS7 Emails: 44 Keywords: 0.0 #infoleak",
  "id" : 423732707684659201,
  "created_at" : "2014-01-16 08:25:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6Gix3F0I8b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=06BVh5Y1",
      "display_url" : "pastebin.com\/raw.php?i=06BV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423728306744074241",
  "text" : "http:\/\/t.co\/6Gix3F0I8b Hashes: 7536 Keywords: 0.11 #infoleak",
  "id" : 423728306744074241,
  "created_at" : "2014-01-16 08:07:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f4IZSiV5ml",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f8ESVfPb",
      "display_url" : "pastebin.com\/raw.php?i=f8ES\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423720083584602112",
  "text" : "http:\/\/t.co\/f4IZSiV5ml Emails: 32 Keywords: 0.11 #infoleak",
  "id" : 423720083584602112,
  "created_at" : "2014-01-16 07:35:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zfZCOl4IMQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Uqyi3yAv",
      "display_url" : "pastebin.com\/raw.php?i=Uqyi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423715471007830016",
  "text" : "http:\/\/t.co\/zfZCOl4IMQ Emails: 20 Hashes: 7 E\/H: 2.86 Keywords: 0.22 #infoleak",
  "id" : 423715471007830016,
  "created_at" : "2014-01-16 07:16:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/awhKZ6wy7E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WJWQp3k4",
      "display_url" : "pastebin.com\/raw.php?i=WJWQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423680818142134273",
  "text" : "http:\/\/t.co\/awhKZ6wy7E Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 423680818142134273,
  "created_at" : "2014-01-16 04:59:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yaUHsZsWQK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sSGHTtKg",
      "display_url" : "pastebin.com\/raw.php?i=sSGH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423637198080983040",
  "text" : "http:\/\/t.co\/yaUHsZsWQK Found possible Google API key(s) #infoleak",
  "id" : 423637198080983040,
  "created_at" : "2014-01-16 02:05:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0X9GOfsl3s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hmpw7GaL",
      "display_url" : "pastebin.com\/raw.php?i=Hmpw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423634556730613760",
  "text" : "http:\/\/t.co\/0X9GOfsl3s Hashes: 638 Keywords: 0.0 #infoleak",
  "id" : 423634556730613760,
  "created_at" : "2014-01-16 01:55:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fY5UgbbWNC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DQ7G0Vz0",
      "display_url" : "pastebin.com\/raw.php?i=DQ7G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423627516402610177",
  "text" : "http:\/\/t.co\/fY5UgbbWNC Emails: 8 Hashes: 40 E\/H: 0.2 Keywords: 0.33 #infoleak",
  "id" : 423627516402610177,
  "created_at" : "2014-01-16 01:27:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qrJfsNwEtd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9DrfZv9s",
      "display_url" : "pastebin.com\/raw.php?i=9Drf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423605189707198464",
  "text" : "http:\/\/t.co\/qrJfsNwEtd Hashes: 125 Keywords: -0.06 #infoleak",
  "id" : 423605189707198464,
  "created_at" : "2014-01-15 23:58:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LdOZmW5VnK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ut7uQWZB",
      "display_url" : "pastebin.com\/raw.php?i=Ut7u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423592494178107392",
  "text" : "http:\/\/t.co\/LdOZmW5VnK Emails: 53 Keywords: 0.0 #infoleak",
  "id" : 423592494178107392,
  "created_at" : "2014-01-15 23:08:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dgwsZWmyVS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j5h0sPaW",
      "display_url" : "pastebin.com\/raw.php?i=j5h0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423591089157591040",
  "text" : "http:\/\/t.co\/dgwsZWmyVS Emails: 1142 Hashes: 1143 E\/H: 1.0 Keywords: 0.88 #infoleak",
  "id" : 423591089157591040,
  "created_at" : "2014-01-15 23:02:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0ZO70ymreW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YRL2HE1r",
      "display_url" : "pastebin.com\/raw.php?i=YRL2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423579748258693120",
  "text" : "http:\/\/t.co\/0ZO70ymreW Possible cisco configuration #infoleak",
  "id" : 423579748258693120,
  "created_at" : "2014-01-15 22:17:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZMUoXe2y7E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z6eiayzY",
      "display_url" : "pastebin.com\/raw.php?i=z6ei\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423576435966484480",
  "text" : "http:\/\/t.co\/ZMUoXe2y7E Emails: 545 Hashes: 510 E\/H: 1.07 Keywords: 0.52 #infoleak",
  "id" : 423576435966484480,
  "created_at" : "2014-01-15 22:04:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fmsVftNndX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hPX5YaZ3",
      "display_url" : "pastebin.com\/raw.php?i=hPX5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423573932944281600",
  "text" : "http:\/\/t.co\/fmsVftNndX Emails: 1864 Hashes: 1 E\/H: 1864.0 Keywords: 0.19 #infoleak",
  "id" : 423573932944281600,
  "created_at" : "2014-01-15 21:54:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PcI1U6txbD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GQUYCENY",
      "display_url" : "pastebin.com\/raw.php?i=GQUY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423562799369842688",
  "text" : "http:\/\/t.co\/PcI1U6txbD Emails: 3 Hashes: 174 E\/H: 0.02 Keywords: -0.03 #infoleak",
  "id" : 423562799369842688,
  "created_at" : "2014-01-15 21:10:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xdf9V0kV2Q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tZYs70QJ",
      "display_url" : "pastebin.com\/raw.php?i=tZYs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423554793114591232",
  "text" : "http:\/\/t.co\/Xdf9V0kV2Q Emails: 91 Hashes: 532 E\/H: 0.17 Keywords: 0.33 #infoleak",
  "id" : 423554793114591232,
  "created_at" : "2014-01-15 20:38:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NMnWHQGmFl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7GUENifZ",
      "display_url" : "pastebin.com\/raw.php?i=7GUE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423554508392632320",
  "text" : "http:\/\/t.co\/NMnWHQGmFl Possible cisco configuration #infoleak",
  "id" : 423554508392632320,
  "created_at" : "2014-01-15 20:37:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eCo4B7LFxS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=He2XUvBW",
      "display_url" : "pastebin.com\/raw.php?i=He2X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423554472854302720",
  "text" : "http:\/\/t.co\/eCo4B7LFxS Emails: 433 Hashes: 434 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 423554472854302720,
  "created_at" : "2014-01-15 20:37:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qdY8Ok6tms",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9gYhpYMN",
      "display_url" : "pastebin.com\/raw.php?i=9gYh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423544317488005120",
  "text" : "http:\/\/t.co\/qdY8Ok6tms Possible cisco configuration #infoleak",
  "id" : 423544317488005120,
  "created_at" : "2014-01-15 19:56:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YZa8aS0BKH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DywCQmJC",
      "display_url" : "pastebin.com\/raw.php?i=DywC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423537974232350720",
  "text" : "http:\/\/t.co\/YZa8aS0BKH Emails: 91 Hashes: 532 E\/H: 0.17 Keywords: 0.33 #infoleak",
  "id" : 423537974232350720,
  "created_at" : "2014-01-15 19:31:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Btr2bNpGq8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=45xTM5Mt",
      "display_url" : "pastebin.com\/raw.php?i=45xT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423424127270002689",
  "text" : "http:\/\/t.co\/Btr2bNpGq8 Emails: 37 Keywords: 0.0 #infoleak",
  "id" : 423424127270002689,
  "created_at" : "2014-01-15 11:59:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JNxpQwnVqr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yGV39pAQ",
      "display_url" : "pastebin.com\/raw.php?i=yGV3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423353939182891009",
  "text" : "http:\/\/t.co\/JNxpQwnVqr Found possible Google API key(s) #infoleak",
  "id" : 423353939182891009,
  "created_at" : "2014-01-15 07:20:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BuapCqZVez",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uTxGfk9C",
      "display_url" : "pastebin.com\/raw.php?i=uTxG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423344094459359233",
  "text" : "http:\/\/t.co\/BuapCqZVez Hashes: 48 Keywords: 0.0 #infoleak",
  "id" : 423344094459359233,
  "created_at" : "2014-01-15 06:41:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yi4cZekTla",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GzdkLX8R",
      "display_url" : "pastebin.com\/raw.php?i=Gzdk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423320966513455105",
  "text" : "http:\/\/t.co\/Yi4cZekTla Hashes: 104 Keywords: 0.11 #infoleak",
  "id" : 423320966513455105,
  "created_at" : "2014-01-15 05:09:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4lc64b7aZm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RnUvGvcv",
      "display_url" : "pastebin.com\/raw.php?i=RnUv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423319780485906432",
  "text" : "http:\/\/t.co\/4lc64b7aZm Found possible Google API key(s) #infoleak",
  "id" : 423319780485906432,
  "created_at" : "2014-01-15 05:04:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7HoZfqmpmF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5b6PxErA",
      "display_url" : "pastebin.com\/raw.php?i=5b6P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423312427027931136",
  "text" : "http:\/\/t.co\/7HoZfqmpmF Hashes: 63 Keywords: 0.11 #infoleak",
  "id" : 423312427027931136,
  "created_at" : "2014-01-15 04:35:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V2WAOQFkPd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t1dwbcuP",
      "display_url" : "pastebin.com\/raw.php?i=t1dw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423311264530432000",
  "text" : "http:\/\/t.co\/V2WAOQFkPd Emails: 228 Keywords: 0.22 #infoleak",
  "id" : 423311264530432000,
  "created_at" : "2014-01-15 04:30:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OxtNyhIKS4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tBzWfCY3",
      "display_url" : "pastebin.com\/raw.php?i=tBzW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423302021362368512",
  "text" : "http:\/\/t.co\/OxtNyhIKS4 Found possible Google API key(s) #infoleak",
  "id" : 423302021362368512,
  "created_at" : "2014-01-15 03:54:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EvQMVXzF7t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QZhh3Mnt",
      "display_url" : "pastebin.com\/raw.php?i=QZhh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423291195121340416",
  "text" : "http:\/\/t.co\/EvQMVXzF7t Emails: 309 Keywords: 0.0 #infoleak",
  "id" : 423291195121340416,
  "created_at" : "2014-01-15 03:10:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bhJDI5JPWT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h5zrAbaY",
      "display_url" : "pastebin.com\/raw.php?i=h5zr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423289430627995648",
  "text" : "http:\/\/t.co\/bhJDI5JPWT Emails: 689 Hashes: 3 E\/H: 229.67 Keywords: 0.0 #infoleak",
  "id" : 423289430627995648,
  "created_at" : "2014-01-15 03:03:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/swl4x5BVrN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SP27C7ij",
      "display_url" : "pastebin.com\/raw.php?i=SP27\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423287776658722816",
  "text" : "http:\/\/t.co\/swl4x5BVrN Emails: 24 Keywords: 0.08 #infoleak",
  "id" : 423287776658722816,
  "created_at" : "2014-01-15 02:57:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qizif6Expu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eJ59uFXR",
      "display_url" : "pastebin.com\/raw.php?i=eJ59\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423285647613259776",
  "text" : "http:\/\/t.co\/Qizif6Expu Keywords: 0.66 #infoleak",
  "id" : 423285647613259776,
  "created_at" : "2014-01-15 02:48:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kvn0rZQAy0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BZ6S0XSP",
      "display_url" : "pastebin.com\/raw.php?i=BZ6S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423282969571098624",
  "text" : "http:\/\/t.co\/Kvn0rZQAy0 Keywords: 0.55 #infoleak",
  "id" : 423282969571098624,
  "created_at" : "2014-01-15 02:38:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YResRm3Wyc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0ZexCfKy",
      "display_url" : "pastebin.com\/raw.php?i=0Zex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423275711676157952",
  "text" : "http:\/\/t.co\/YResRm3Wyc Possible cisco configuration #infoleak",
  "id" : 423275711676157952,
  "created_at" : "2014-01-15 02:09:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4NcX6Znu0m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JjbQUfK2",
      "display_url" : "pastebin.com\/raw.php?i=JjbQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423275276382896128",
  "text" : "http:\/\/t.co\/4NcX6Znu0m Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 423275276382896128,
  "created_at" : "2014-01-15 02:07:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xE295yvCrC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=smy70biA",
      "display_url" : "pastebin.com\/raw.php?i=smy7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423274027600195584",
  "text" : "http:\/\/t.co\/xE295yvCrC Keywords: 0.66 #infoleak",
  "id" : 423274027600195584,
  "created_at" : "2014-01-15 02:02:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5NgG2cbkMP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y2xWQxLS",
      "display_url" : "pastebin.com\/raw.php?i=y2xW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423271164765417472",
  "text" : "http:\/\/t.co\/5NgG2cbkMP Emails: 2275 Keywords: -0.03 #infoleak",
  "id" : 423271164765417472,
  "created_at" : "2014-01-15 01:51:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bMxvzTiwzy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LikeELju",
      "display_url" : "pastebin.com\/raw.php?i=Like\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423270700846022657",
  "text" : "http:\/\/t.co\/bMxvzTiwzy Hashes: 40 Keywords: 0.33 #infoleak",
  "id" : 423270700846022657,
  "created_at" : "2014-01-15 01:49:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XGtZnrcrcU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7PFNrkPg",
      "display_url" : "pastebin.com\/raw.php?i=7PFN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423264061409591296",
  "text" : "http:\/\/t.co\/XGtZnrcrcU Keywords: 0.66 #infoleak",
  "id" : 423264061409591296,
  "created_at" : "2014-01-15 01:23:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/84d7YMy4qQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CVnjdBM8",
      "display_url" : "pastebin.com\/raw.php?i=CVnj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423263037143805952",
  "text" : "http:\/\/t.co\/84d7YMy4qQ Keywords: 0.55 #infoleak",
  "id" : 423263037143805952,
  "created_at" : "2014-01-15 01:19:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VVdB5jcFGT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CD4Yip4i",
      "display_url" : "pastebin.com\/raw.php?i=CD4Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423260842289668096",
  "text" : "http:\/\/t.co\/VVdB5jcFGT Emails: 4793 Hashes: 4008 E\/H: 1.2 Keywords: -0.03 #infoleak",
  "id" : 423260842289668096,
  "created_at" : "2014-01-15 01:10:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UiP6hqAxLe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H4MJjw3p",
      "display_url" : "pastebin.com\/raw.php?i=H4MJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423252497759600640",
  "text" : "http:\/\/t.co\/UiP6hqAxLe Emails: 5248 Hashes: 4509 E\/H: 1.16 Keywords: -0.03 #infoleak",
  "id" : 423252497759600640,
  "created_at" : "2014-01-15 00:37:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aJXdKz3Ret",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u5drvBEz",
      "display_url" : "pastebin.com\/raw.php?i=u5dr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423251755401351168",
  "text" : "http:\/\/t.co\/aJXdKz3Ret Keywords: 0.66 #infoleak",
  "id" : 423251755401351168,
  "created_at" : "2014-01-15 00:34:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JQ8MetmZOX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PzRw5iT6",
      "display_url" : "pastebin.com\/raw.php?i=PzRw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423251547460354048",
  "text" : "http:\/\/t.co\/JQ8MetmZOX Emails: 1124 Hashes: 1135 E\/H: 0.99 Keywords: -0.03 #infoleak",
  "id" : 423251547460354048,
  "created_at" : "2014-01-15 00:33:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PmFz3CPXcb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Um7s7uui",
      "display_url" : "pastebin.com\/raw.php?i=Um7s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423249991604260864",
  "text" : "http:\/\/t.co\/PmFz3CPXcb Emails: 3467 Hashes: 3467 E\/H: 1.0 Keywords: -0.03 #infoleak",
  "id" : 423249991604260864,
  "created_at" : "2014-01-15 00:27:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oXJnnu1bU1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fqGYrs09",
      "display_url" : "pastebin.com\/raw.php?i=fqGY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423248477817032704",
  "text" : "http:\/\/t.co\/oXJnnu1bU1 Emails: 222 Hashes: 223 E\/H: 1.0 Keywords: 0.08 #infoleak",
  "id" : 423248477817032704,
  "created_at" : "2014-01-15 00:21:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kIqUoQAwDk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T72eb1df",
      "display_url" : "pastebin.com\/raw.php?i=T72e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423247960135057408",
  "text" : "http:\/\/t.co\/kIqUoQAwDk Emails: 293 Hashes: 294 E\/H: 1.0 Keywords: 0.08 #infoleak",
  "id" : 423247960135057408,
  "created_at" : "2014-01-15 00:19:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q3yIVacaEe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4gGbBzBL",
      "display_url" : "pastebin.com\/raw.php?i=4gGb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423246947546173440",
  "text" : "http:\/\/t.co\/q3yIVacaEe Possible cisco configuration #infoleak",
  "id" : 423246947546173440,
  "created_at" : "2014-01-15 00:15:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RNd2xwhTJQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PMv9DNjL",
      "display_url" : "pastebin.com\/raw.php?i=PMv9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423239250822193154",
  "text" : "http:\/\/t.co\/RNd2xwhTJQ Keywords: 0.66 #infoleak",
  "id" : 423239250822193154,
  "created_at" : "2014-01-14 23:44:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dwQMB6PtxF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uD6zYFBD",
      "display_url" : "pastebin.com\/raw.php?i=uD6z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423229997763936256",
  "text" : "http:\/\/t.co\/dwQMB6PtxF Keywords: 0.66 #infoleak",
  "id" : 423229997763936256,
  "created_at" : "2014-01-14 23:07:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u6MkSyYY5I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uLeBudFk",
      "display_url" : "pastebin.com\/raw.php?i=uLeB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423228888810942464",
  "text" : "http:\/\/t.co\/u6MkSyYY5I Emails: 45 Keywords: 0.11 #infoleak",
  "id" : 423228888810942464,
  "created_at" : "2014-01-14 23:03:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4hPOOKIE02",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ADM7BhW2",
      "display_url" : "pastebin.com\/raw.php?i=ADM7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423223428582080512",
  "text" : "http:\/\/t.co\/4hPOOKIE02 Keywords: 0.66 #infoleak",
  "id" : 423223428582080512,
  "created_at" : "2014-01-14 22:41:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bcXzaBCuPf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AVAaVgZK",
      "display_url" : "pastebin.com\/raw.php?i=AVAa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423222881951027201",
  "text" : "http:\/\/t.co\/bcXzaBCuPf Hashes: 3719 Keywords: 0.0 #infoleak",
  "id" : 423222881951027201,
  "created_at" : "2014-01-14 22:39:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JwzdKcteAP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bNn8NeHM",
      "display_url" : "pastebin.com\/raw.php?i=bNn8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423221814936891392",
  "text" : "http:\/\/t.co\/JwzdKcteAP Emails: 2322 Hashes: 26 E\/H: 89.31 Keywords: 0.22 #infoleak",
  "id" : 423221814936891392,
  "created_at" : "2014-01-14 22:35:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E8gLCcfKe1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JwR65MGR",
      "display_url" : "pastebin.com\/raw.php?i=JwR6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423219798005133312",
  "text" : "http:\/\/t.co\/E8gLCcfKe1 Hashes: 127 Keywords: 0.44 #infoleak",
  "id" : 423219798005133312,
  "created_at" : "2014-01-14 22:27:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L24hFHr4qt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KU0653gX",
      "display_url" : "pastebin.com\/raw.php?i=KU06\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423209336861515776",
  "text" : "http:\/\/t.co\/L24hFHr4qt Emails: 31 Keywords: 0.3 #infoleak",
  "id" : 423209336861515776,
  "created_at" : "2014-01-14 21:45:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/krM9jnI5Rr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RQnn0bAs",
      "display_url" : "pastebin.com\/raw.php?i=RQnn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423208664036417536",
  "text" : "http:\/\/t.co\/krM9jnI5Rr Keywords: 0.66 #infoleak",
  "id" : 423208664036417536,
  "created_at" : "2014-01-14 21:43:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UpHykUeiqD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hUymacS3",
      "display_url" : "pastebin.com\/raw.php?i=hUym\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423202348719030273",
  "text" : "http:\/\/t.co\/UpHykUeiqD Emails: 20 Keywords: 0.22 #infoleak",
  "id" : 423202348719030273,
  "created_at" : "2014-01-14 21:17:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u4Zbz0MVzR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e3ES9BKr",
      "display_url" : "pastebin.com\/raw.php?i=e3ES\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423195228191735808",
  "text" : "http:\/\/t.co\/u4Zbz0MVzR Found possible Google API key(s) #infoleak",
  "id" : 423195228191735808,
  "created_at" : "2014-01-14 20:49:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Vlhqyr6muZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xQKwzfrB",
      "display_url" : "pastebin.com\/raw.php?i=xQKw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423186652534538240",
  "text" : "http:\/\/t.co\/Vlhqyr6muZ Hashes: 214 Keywords: 0.11 #infoleak",
  "id" : 423186652534538240,
  "created_at" : "2014-01-14 20:15:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RfrEBzv0NV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g11PGWJz",
      "display_url" : "pastebin.com\/raw.php?i=g11P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423181960320544768",
  "text" : "http:\/\/t.co\/RfrEBzv0NV Hashes: 30 Keywords: -0.03 #infoleak",
  "id" : 423181960320544768,
  "created_at" : "2014-01-14 19:56:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oyw3hM48sF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZAGPFU5u",
      "display_url" : "pastebin.com\/raw.php?i=ZAGP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423171261447958528",
  "text" : "http:\/\/t.co\/oyw3hM48sF Emails: 40 Keywords: 0.11 #infoleak",
  "id" : 423171261447958528,
  "created_at" : "2014-01-14 19:14:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IdNCAEvCAq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gCVEx6fk",
      "display_url" : "pastebin.com\/raw.php?i=gCVE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423167856910413824",
  "text" : "http:\/\/t.co\/IdNCAEvCAq Emails: 1261 Keywords: 0.33 #infoleak",
  "id" : 423167856910413824,
  "created_at" : "2014-01-14 19:00:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mWcIRmNuV2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pXJsa5QU",
      "display_url" : "pastebin.com\/raw.php?i=pXJs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423159899392991232",
  "text" : "http:\/\/t.co\/mWcIRmNuV2 Emails: 1249 Keywords: 0.0 #infoleak",
  "id" : 423159899392991232,
  "created_at" : "2014-01-14 18:29:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QBH9ZjkHHa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9vXNL3cZ",
      "display_url" : "pastebin.com\/raw.php?i=9vXN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423152188408352768",
  "text" : "http:\/\/t.co\/QBH9ZjkHHa Emails: 83 Keywords: 0.0 #infoleak",
  "id" : 423152188408352768,
  "created_at" : "2014-01-14 17:58:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u3SLSl7AXr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ln13ubVP",
      "display_url" : "pastebin.com\/raw.php?i=Ln13\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423150615095541761",
  "text" : "http:\/\/t.co\/u3SLSl7AXr Hashes: 40 Keywords: 0.33 #infoleak",
  "id" : 423150615095541761,
  "created_at" : "2014-01-14 17:52:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qqzgibXXwk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n2caf3md",
      "display_url" : "pastebin.com\/raw.php?i=n2ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423145066543075328",
  "text" : "http:\/\/t.co\/qqzgibXXwk Emails: 113 Keywords: 0.44 #infoleak",
  "id" : 423145066543075328,
  "created_at" : "2014-01-14 17:30:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XC2TThzlNH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pcqEd2tb",
      "display_url" : "pastebin.com\/raw.php?i=pcqE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423144597385011201",
  "text" : "http:\/\/t.co\/XC2TThzlNH Emails: 22 Hashes: 1 E\/H: 22.0 Keywords: 0.0 #infoleak",
  "id" : 423144597385011201,
  "created_at" : "2014-01-14 17:28:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kbwIPHR6Qi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Ra5q5Lr",
      "display_url" : "pastebin.com\/raw.php?i=7Ra5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423138059664642048",
  "text" : "http:\/\/t.co\/kbwIPHR6Qi Emails: 152 Keywords: 0.13 #infoleak",
  "id" : 423138059664642048,
  "created_at" : "2014-01-14 17:02:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m2xHoyXuCP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JAsnVxmU",
      "display_url" : "pastebin.com\/raw.php?i=JAsn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423132174011748352",
  "text" : "http:\/\/t.co\/m2xHoyXuCP Found possible Google API key(s) #infoleak",
  "id" : 423132174011748352,
  "created_at" : "2014-01-14 16:39:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bh8nm1nrHU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wb9CuqsS",
      "display_url" : "pastebin.com\/raw.php?i=wb9C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423117846114099202",
  "text" : "http:\/\/t.co\/Bh8nm1nrHU Found possible Google API key(s) #infoleak",
  "id" : 423117846114099202,
  "created_at" : "2014-01-14 15:42:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T5TbKWjtIe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4TqxyfWS",
      "display_url" : "pastebin.com\/raw.php?i=4Tqx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423117140166582273",
  "text" : "http:\/\/t.co\/T5TbKWjtIe Hashes: 867 Keywords: 0.11 #infoleak",
  "id" : 423117140166582273,
  "created_at" : "2014-01-14 15:39:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sN8pJKOcr6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zeEtyNvF",
      "display_url" : "pastebin.com\/raw.php?i=zeEt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423110127382568960",
  "text" : "http:\/\/t.co\/sN8pJKOcr6 Emails: 654 Keywords: 0.22 #infoleak",
  "id" : 423110127382568960,
  "created_at" : "2014-01-14 15:11:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xMkwfmeHhA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WRxDshqv",
      "display_url" : "pastebin.com\/raw.php?i=WRxD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423103062413017089",
  "text" : "http:\/\/t.co\/xMkwfmeHhA Hashes: 257 Keywords: 0.22 #infoleak",
  "id" : 423103062413017089,
  "created_at" : "2014-01-14 14:43:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ea45daPXjt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DjTeYD0h",
      "display_url" : "pastebin.com\/raw.php?i=DjTe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423087975988076545",
  "text" : "http:\/\/t.co\/ea45daPXjt Hashes: 48 Keywords: 0.33 #infoleak",
  "id" : 423087975988076545,
  "created_at" : "2014-01-14 13:43:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sNY3FYO1DE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vU4RvqER",
      "display_url" : "pastebin.com\/raw.php?i=vU4R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423086203890462720",
  "text" : "http:\/\/t.co\/sNY3FYO1DE Emails: 270 Keywords: 0.11 #infoleak",
  "id" : 423086203890462720,
  "created_at" : "2014-01-14 13:36:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bLGVQapyqv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DBwV0fht",
      "display_url" : "pastebin.com\/raw.php?i=DBwV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423077608989814785",
  "text" : "http:\/\/t.co\/bLGVQapyqv Hashes: 71 Keywords: 0.0 #infoleak",
  "id" : 423077608989814785,
  "created_at" : "2014-01-14 13:02:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n9W5mSo0gI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yegK2pH9",
      "display_url" : "pastebin.com\/raw.php?i=yegK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423065242847805440",
  "text" : "http:\/\/t.co\/n9W5mSo0gI Possible cisco configuration #infoleak",
  "id" : 423065242847805440,
  "created_at" : "2014-01-14 12:13:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zqi5yEQxor",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QE2Miudj",
      "display_url" : "pastebin.com\/raw.php?i=QE2M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423062918427471872",
  "text" : "http:\/\/t.co\/zqi5yEQxor Found possible Google API key(s) #infoleak",
  "id" : 423062918427471872,
  "created_at" : "2014-01-14 12:03:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l82KBQ0mlz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DktPhva1",
      "display_url" : "pastebin.com\/raw.php?i=DktP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423049723138686976",
  "text" : "http:\/\/t.co\/l82KBQ0mlz Hashes: 177 Keywords: 0.44 #infoleak",
  "id" : 423049723138686976,
  "created_at" : "2014-01-14 11:11:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h7RZL7wnSY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GiVni0vb",
      "display_url" : "pastebin.com\/raw.php?i=GiVn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423037990072778752",
  "text" : "http:\/\/t.co\/h7RZL7wnSY Possible cisco configuration #infoleak",
  "id" : 423037990072778752,
  "created_at" : "2014-01-14 10:24:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oJyNayfY0u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w2Z6jyMM",
      "display_url" : "pastebin.com\/raw.php?i=w2Z6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423034349173215232",
  "text" : "http:\/\/t.co\/oJyNayfY0u Possible cisco configuration #infoleak",
  "id" : 423034349173215232,
  "created_at" : "2014-01-14 10:10:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8L4OQYnTYZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PfjswHWc",
      "display_url" : "pastebin.com\/raw.php?i=Pfjs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423020882219376640",
  "text" : "http:\/\/t.co\/8L4OQYnTYZ Found possible Google API key(s) #infoleak",
  "id" : 423020882219376640,
  "created_at" : "2014-01-14 09:16:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8Kxd3zaDRX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1Sv6Svie",
      "display_url" : "pastebin.com\/raw.php?i=1Sv6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423019634510401536",
  "text" : "http:\/\/t.co\/8Kxd3zaDRX Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 423019634510401536,
  "created_at" : "2014-01-14 09:11:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oozxKKaRlj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yfJp6LYx",
      "display_url" : "pastebin.com\/raw.php?i=yfJp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422994530309132288",
  "text" : "http:\/\/t.co\/oozxKKaRlj Emails: 436 Keywords: 0.0 #infoleak",
  "id" : 422994530309132288,
  "created_at" : "2014-01-14 07:32:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sruVQyYPRV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ySLQ1G03",
      "display_url" : "pastebin.com\/raw.php?i=ySLQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422985579077197824",
  "text" : "http:\/\/t.co\/sruVQyYPRV Emails: 629 Hashes: 1 E\/H: 629.0 Keywords: 0.0 #infoleak",
  "id" : 422985579077197824,
  "created_at" : "2014-01-14 06:56:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FdKCYEB8Q4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iNLw2ZYb",
      "display_url" : "pastebin.com\/raw.php?i=iNLw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422982220941246464",
  "text" : "http:\/\/t.co\/FdKCYEB8Q4 Emails: 225 Keywords: 0.0 #infoleak",
  "id" : 422982220941246464,
  "created_at" : "2014-01-14 06:43:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HCSgqC2wmk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C41AnY48",
      "display_url" : "pastebin.com\/raw.php?i=C41A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422969070456041472",
  "text" : "http:\/\/t.co\/HCSgqC2wmk Emails: 148 Keywords: 0.22 #infoleak",
  "id" : 422969070456041472,
  "created_at" : "2014-01-14 05:50:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BP4FLsWNYA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pMCMPAEC",
      "display_url" : "pastebin.com\/raw.php?i=pMCM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422952260629311488",
  "text" : "http:\/\/t.co\/BP4FLsWNYA Hashes: 54 Keywords: 0.0 #infoleak",
  "id" : 422952260629311488,
  "created_at" : "2014-01-14 04:44:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6Zjsvskxv9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hU1QkUF4",
      "display_url" : "pastebin.com\/raw.php?i=hU1Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422951367016054784",
  "text" : "http:\/\/t.co\/6Zjsvskxv9 Keywords: 0.55 #infoleak",
  "id" : 422951367016054784,
  "created_at" : "2014-01-14 04:40:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CDhEEvYnWB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7zRvAMDi",
      "display_url" : "pastebin.com\/raw.php?i=7zRv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422944408682512385",
  "text" : "http:\/\/t.co\/CDhEEvYnWB Emails: 10332 Hashes: 79 E\/H: 130.78 Keywords: 0.33 #infoleak",
  "id" : 422944408682512385,
  "created_at" : "2014-01-14 04:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DvuxOQtI6M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y9Kn6d0h",
      "display_url" : "pastebin.com\/raw.php?i=Y9Kn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422942900943470594",
  "text" : "http:\/\/t.co\/DvuxOQtI6M Emails: 742 Keywords: 0.22 #infoleak",
  "id" : 422942900943470594,
  "created_at" : "2014-01-14 04:07:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1xoTV5f4fd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5q0E5Mbd",
      "display_url" : "pastebin.com\/raw.php?i=5q0E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422940799454560256",
  "text" : "http:\/\/t.co\/1xoTV5f4fd Possible cisco configuration #infoleak",
  "id" : 422940799454560256,
  "created_at" : "2014-01-14 03:58:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lHcerQ2kVC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J0mPGcHQ",
      "display_url" : "pastebin.com\/raw.php?i=J0mP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422940119734034432",
  "text" : "http:\/\/t.co\/lHcerQ2kVC Hashes: 225 Keywords: 0.11 #infoleak",
  "id" : 422940119734034432,
  "created_at" : "2014-01-14 03:55:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EwCoLuBNbf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bxZzchAT",
      "display_url" : "pastebin.com\/raw.php?i=bxZz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422936469053779968",
  "text" : "http:\/\/t.co\/EwCoLuBNbf Emails: 1664 Keywords: 0.22 #infoleak",
  "id" : 422936469053779968,
  "created_at" : "2014-01-14 03:41:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6cm4fFfcYG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B5Tp4b6R",
      "display_url" : "pastebin.com\/raw.php?i=B5Tp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422935892655755265",
  "text" : "http:\/\/t.co\/6cm4fFfcYG Hashes: 255 Keywords: 0.33 #infoleak",
  "id" : 422935892655755265,
  "created_at" : "2014-01-14 03:39:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mEapQcrg9q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FGYaB0um",
      "display_url" : "pastebin.com\/raw.php?i=FGYa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422924621625556993",
  "text" : "http:\/\/t.co\/mEapQcrg9q Emails: 52 Keywords: 0.0 #infoleak",
  "id" : 422924621625556993,
  "created_at" : "2014-01-14 02:54:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6xkY9069QA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PbEB0GJS",
      "display_url" : "pastebin.com\/raw.php?i=PbEB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422924584627605504",
  "text" : "http:\/\/t.co\/6xkY9069QA Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 422924584627605504,
  "created_at" : "2014-01-14 02:54:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x0T64RqTTR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pevjMSvU",
      "display_url" : "pastebin.com\/raw.php?i=pevj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422880593823535104",
  "text" : "http:\/\/t.co\/x0T64RqTTR Emails: 2256 Keywords: -0.03 #infoleak",
  "id" : 422880593823535104,
  "created_at" : "2014-01-13 23:59:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/42UIoP9Y8D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5Bsd14XK",
      "display_url" : "pastebin.com\/raw.php?i=5Bsd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422876016533467136",
  "text" : "http:\/\/t.co\/42UIoP9Y8D Emails: 43 Keywords: 0.16 #infoleak",
  "id" : 422876016533467136,
  "created_at" : "2014-01-13 23:41:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7je0MzwApf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YyYnUbE6",
      "display_url" : "pastebin.com\/raw.php?i=YyYn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422873099915112448",
  "text" : "http:\/\/t.co\/7je0MzwApf Emails: 230 Hashes: 266 E\/H: 0.86 Keywords: 0.22 #infoleak",
  "id" : 422873099915112448,
  "created_at" : "2014-01-13 23:29:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XBVuobV7BC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8J3jiiMh",
      "display_url" : "pastebin.com\/raw.php?i=8J3j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422866594876772352",
  "text" : "http:\/\/t.co\/XBVuobV7BC Found possible Google API key(s) #infoleak",
  "id" : 422866594876772352,
  "created_at" : "2014-01-13 23:03:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AVLghCsKbW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PChLGQmm",
      "display_url" : "pastebin.com\/raw.php?i=PChL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422866274939445248",
  "text" : "http:\/\/t.co\/AVLghCsKbW Found possible Google API key(s) #infoleak",
  "id" : 422866274939445248,
  "created_at" : "2014-01-13 23:02:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZqtikhO18M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tXWKe9YE",
      "display_url" : "pastebin.com\/raw.php?i=tXWK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422865687145504768",
  "text" : "http:\/\/t.co\/ZqtikhO18M Emails: 137 Keywords: 0.0 #infoleak",
  "id" : 422865687145504768,
  "created_at" : "2014-01-13 23:00:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q2raiy85oc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pYtgBxL4",
      "display_url" : "pastebin.com\/raw.php?i=pYtg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422855286047526912",
  "text" : "http:\/\/t.co\/q2raiy85oc Emails: 100 Hashes: 104 E\/H: 0.96 Keywords: 0.19 #infoleak",
  "id" : 422855286047526912,
  "created_at" : "2014-01-13 22:18:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0S2pjIK3Wu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m7VSV96e",
      "display_url" : "pastebin.com\/raw.php?i=m7VS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422842287177994240",
  "text" : "http:\/\/t.co\/0S2pjIK3Wu Emails: 104 Keywords: -0.14 #infoleak",
  "id" : 422842287177994240,
  "created_at" : "2014-01-13 21:27:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f3rFFQavvm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2AJcPyu7",
      "display_url" : "pastebin.com\/raw.php?i=2AJc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422842089190064128",
  "text" : "http:\/\/t.co\/f3rFFQavvm Hashes: 90 Keywords: -0.14 #infoleak",
  "id" : 422842089190064128,
  "created_at" : "2014-01-13 21:26:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5uQCUtQw4Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X0jUS0Gd",
      "display_url" : "pastebin.com\/raw.php?i=X0jU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422840231595753472",
  "text" : "http:\/\/t.co\/5uQCUtQw4Z Found possible Google API key(s) #infoleak",
  "id" : 422840231595753472,
  "created_at" : "2014-01-13 21:19:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LM0EkyB85k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uN2QLF33",
      "display_url" : "pastebin.com\/raw.php?i=uN2Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422833299724062720",
  "text" : "http:\/\/t.co\/LM0EkyB85k Hashes: 113 Keywords: 0.05 #infoleak",
  "id" : 422833299724062720,
  "created_at" : "2014-01-13 20:51:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l0NQcEjRL3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LpeKPYrp",
      "display_url" : "pastebin.com\/raw.php?i=LpeK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422832682888749056",
  "text" : "http:\/\/t.co\/l0NQcEjRL3 Emails: 20 Keywords: 0.27 #infoleak",
  "id" : 422832682888749056,
  "created_at" : "2014-01-13 20:49:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kMsTLVba8a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vNpgjPU5",
      "display_url" : "pastebin.com\/raw.php?i=vNpg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422832245250871298",
  "text" : "http:\/\/t.co\/kMsTLVba8a Found possible Google API key(s) #infoleak",
  "id" : 422832245250871298,
  "created_at" : "2014-01-13 20:47:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yv5Ec4L7VT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p2kGh60g",
      "display_url" : "pastebin.com\/raw.php?i=p2kG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422830951991742464",
  "text" : "http:\/\/t.co\/yv5Ec4L7VT Found possible Google API key(s) #infoleak",
  "id" : 422830951991742464,
  "created_at" : "2014-01-13 20:42:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fII80ySMSP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VSpzuAv0",
      "display_url" : "pastebin.com\/raw.php?i=VSpz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422826997190897664",
  "text" : "http:\/\/t.co\/fII80ySMSP Hashes: 134 Keywords: -0.2 #infoleak",
  "id" : 422826997190897664,
  "created_at" : "2014-01-13 20:26:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2PXmyfEh8n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2i7mrveq",
      "display_url" : "pastebin.com\/raw.php?i=2i7m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422819475365175296",
  "text" : "http:\/\/t.co\/2PXmyfEh8n Found possible Google API key(s) #infoleak",
  "id" : 422819475365175296,
  "created_at" : "2014-01-13 19:56:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rufNjNqA13",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CN69Tyjb",
      "display_url" : "pastebin.com\/raw.php?i=CN69\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422814218623008768",
  "text" : "http:\/\/t.co\/rufNjNqA13 Found possible Google API key(s) #infoleak",
  "id" : 422814218623008768,
  "created_at" : "2014-01-13 19:35:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NDmhXQkgDo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pe8htkp0",
      "display_url" : "pastebin.com\/raw.php?i=pe8h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422806825927323649",
  "text" : "http:\/\/t.co\/NDmhXQkgDo Found possible Google API key(s) #infoleak",
  "id" : 422806825927323649,
  "created_at" : "2014-01-13 19:06:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T0jN2hbDHv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=93qqqnQP",
      "display_url" : "pastebin.com\/raw.php?i=93qq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422805241382178816",
  "text" : "http:\/\/t.co\/T0jN2hbDHv Keywords: 0.55 #infoleak",
  "id" : 422805241382178816,
  "created_at" : "2014-01-13 18:59:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ypow2YyJX1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xse4KKak",
      "display_url" : "pastebin.com\/raw.php?i=Xse4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422796347876470784",
  "text" : "http:\/\/t.co\/ypow2YyJX1 Emails: 20 Keywords: 0.11 #infoleak",
  "id" : 422796347876470784,
  "created_at" : "2014-01-13 18:24:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F34lwF3ejb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vRxwwW67",
      "display_url" : "pastebin.com\/raw.php?i=vRxw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422791809983467520",
  "text" : "http:\/\/t.co\/F34lwF3ejb Emails: 53 Hashes: 51 E\/H: 1.04 Keywords: 0.33 #infoleak",
  "id" : 422791809983467520,
  "created_at" : "2014-01-13 18:06:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r37U1NUz3Q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pWRjV9G2",
      "display_url" : "pastebin.com\/raw.php?i=pWRj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422791470160941056",
  "text" : "http:\/\/t.co\/r37U1NUz3Q Emails: 608 Keywords: 0.33 #infoleak",
  "id" : 422791470160941056,
  "created_at" : "2014-01-13 18:05:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S7ZjE92b98",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TdmCX4qn",
      "display_url" : "pastebin.com\/raw.php?i=TdmC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422788848863543296",
  "text" : "http:\/\/t.co\/S7ZjE92b98 Hashes: 40 Keywords: 0.0 #infoleak",
  "id" : 422788848863543296,
  "created_at" : "2014-01-13 17:54:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z1o62uCW5v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CRsemPkx",
      "display_url" : "pastebin.com\/raw.php?i=CRse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422787513896271872",
  "text" : "http:\/\/t.co\/z1o62uCW5v Emails: 892 Keywords: 0.22 #infoleak",
  "id" : 422787513896271872,
  "created_at" : "2014-01-13 17:49:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i3WjuKDN88",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yhPtbr0s",
      "display_url" : "pastebin.com\/raw.php?i=yhPt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422785623565430784",
  "text" : "http:\/\/t.co\/i3WjuKDN88 Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 422785623565430784,
  "created_at" : "2014-01-13 17:42:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HU2HfRUzWO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hqJ7Rdhy",
      "display_url" : "pastebin.com\/raw.php?i=hqJ7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422779483049828353",
  "text" : "http:\/\/t.co\/HU2HfRUzWO Emails: 60 Keywords: 0.22 #infoleak",
  "id" : 422779483049828353,
  "created_at" : "2014-01-13 17:17:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tf7wgoihm1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TiC1KpAT",
      "display_url" : "pastebin.com\/raw.php?i=TiC1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422778165950304256",
  "text" : "http:\/\/t.co\/tf7wgoihm1 Emails: 2 Keywords: 0.66 #infoleak",
  "id" : 422778165950304256,
  "created_at" : "2014-01-13 17:12:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zmkB0f7SLc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x8w8ArUS",
      "display_url" : "pastebin.com\/raw.php?i=x8w8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422776895466266625",
  "text" : "http:\/\/t.co\/zmkB0f7SLc Emails: 23 Hashes: 8 E\/H: 2.88 Keywords: 0.3 #infoleak",
  "id" : 422776895466266625,
  "created_at" : "2014-01-13 17:07:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UpENhvHI7y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N7n0MYYY",
      "display_url" : "pastebin.com\/raw.php?i=N7n0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422775890536169472",
  "text" : "http:\/\/t.co\/UpENhvHI7y Emails: 2105 Keywords: 0.22 #infoleak",
  "id" : 422775890536169472,
  "created_at" : "2014-01-13 17:03:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e1Df4jQYkS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j5D8sAFL",
      "display_url" : "pastebin.com\/raw.php?i=j5D8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422773844533727232",
  "text" : "http:\/\/t.co\/e1Df4jQYkS Hashes: 81 Keywords: 0.08 #infoleak",
  "id" : 422773844533727232,
  "created_at" : "2014-01-13 16:55:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U5bQbehKTy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cgSNHey0",
      "display_url" : "pastebin.com\/raw.php?i=cgSN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422763406056124416",
  "text" : "http:\/\/t.co\/U5bQbehKTy Emails: 20 Keywords: 0.11 #infoleak",
  "id" : 422763406056124416,
  "created_at" : "2014-01-13 16:13:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MnYWeiTcmK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iHF4XsTd",
      "display_url" : "pastebin.com\/raw.php?i=iHF4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422757042957205504",
  "text" : "http:\/\/t.co\/MnYWeiTcmK Emails: 242 Keywords: 0.11 #infoleak",
  "id" : 422757042957205504,
  "created_at" : "2014-01-13 15:48:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iJ3j73BTdY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u3iZZRzA",
      "display_url" : "pastebin.com\/raw.php?i=u3iZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422692030058209280",
  "text" : "http:\/\/t.co\/iJ3j73BTdY Emails: 100 Keywords: -0.03 #infoleak",
  "id" : 422692030058209280,
  "created_at" : "2014-01-13 11:30:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nrO5gtI5yv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iJC9ayp1",
      "display_url" : "pastebin.com\/raw.php?i=iJC9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422690497816055810",
  "text" : "http:\/\/t.co\/nrO5gtI5yv Possible cisco configuration #infoleak",
  "id" : 422690497816055810,
  "created_at" : "2014-01-13 11:24:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xLPagxo2yW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TNNHWpM9",
      "display_url" : "pastebin.com\/raw.php?i=TNNH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422670706157944832",
  "text" : "http:\/\/t.co\/xLPagxo2yW Found possible Google API key(s) #infoleak",
  "id" : 422670706157944832,
  "created_at" : "2014-01-13 10:05:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wkMlkkKN8p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qLzNsinT",
      "display_url" : "pastebin.com\/raw.php?i=qLzN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422669894077792257",
  "text" : "http:\/\/t.co\/wkMlkkKN8p Emails: 337 Keywords: 0.0 #infoleak",
  "id" : 422669894077792257,
  "created_at" : "2014-01-13 10:02:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/68YjsxLCID",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j1rUxTcK",
      "display_url" : "pastebin.com\/raw.php?i=j1rU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422667840466870272",
  "text" : "http:\/\/t.co\/68YjsxLCID Found possible Google API key(s) #infoleak",
  "id" : 422667840466870272,
  "created_at" : "2014-01-13 09:54:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4AiWNhojl9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RiqV4XZZ",
      "display_url" : "pastebin.com\/raw.php?i=RiqV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422662857277181952",
  "text" : "http:\/\/t.co\/4AiWNhojl9 Emails: 148 Keywords: 0.0 #infoleak",
  "id" : 422662857277181952,
  "created_at" : "2014-01-13 09:34:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Rm4nm0qKUN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yhkniy7e",
      "display_url" : "pastebin.com\/raw.php?i=yhkn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422662452367458305",
  "text" : "http:\/\/t.co\/Rm4nm0qKUN Emails: 580 Hashes: 22 E\/H: 26.36 Keywords: 0.33 #infoleak",
  "id" : 422662452367458305,
  "created_at" : "2014-01-13 09:32:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MCU8oNcykh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ap4rndWi",
      "display_url" : "pastebin.com\/raw.php?i=ap4r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422659273282179072",
  "text" : "http:\/\/t.co\/MCU8oNcykh Emails: 4534 Hashes: 4834 E\/H: 0.94 Keywords: 0.44 #infoleak",
  "id" : 422659273282179072,
  "created_at" : "2014-01-13 09:19:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fqkOc6BTq4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XWph3ysk",
      "display_url" : "pastebin.com\/raw.php?i=XWph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422655736800231425",
  "text" : "http:\/\/t.co\/fqkOc6BTq4 Found possible Google API key(s) #infoleak",
  "id" : 422655736800231425,
  "created_at" : "2014-01-13 09:05:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t3FhX6OOFF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1UHZDAUa",
      "display_url" : "pastebin.com\/raw.php?i=1UHZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422654582943002624",
  "text" : "http:\/\/t.co\/t3FhX6OOFF Emails: 385 Keywords: 0.33 #infoleak",
  "id" : 422654582943002624,
  "created_at" : "2014-01-13 09:01:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ik127L5URq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gsyFUQ6F",
      "display_url" : "pastebin.com\/raw.php?i=gsyF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422623339484442624",
  "text" : "http:\/\/t.co\/ik127L5URq Emails: 184 Keywords: 0.0 #infoleak",
  "id" : 422623339484442624,
  "created_at" : "2014-01-13 06:57:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZtVw4Zt4s5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ztnwuvfd",
      "display_url" : "pastebin.com\/raw.php?i=ztnw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422607188591251458",
  "text" : "http:\/\/t.co\/ZtVw4Zt4s5 Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 422607188591251458,
  "created_at" : "2014-01-13 05:53:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eZVznXOnLY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FQzDAPdT",
      "display_url" : "pastebin.com\/raw.php?i=FQzD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422602358908936192",
  "text" : "http:\/\/t.co\/eZVznXOnLY Emails: 239 Hashes: 2 E\/H: 119.5 Keywords: 0.0 #infoleak",
  "id" : 422602358908936192,
  "created_at" : "2014-01-13 05:33:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O8JANsUwp4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7BW3z0L8",
      "display_url" : "pastebin.com\/raw.php?i=7BW3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422600609078857728",
  "text" : "http:\/\/t.co\/O8JANsUwp4 Emails: 293 Keywords: 0.0 #infoleak",
  "id" : 422600609078857728,
  "created_at" : "2014-01-13 05:26:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0vxlGEUbZq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JkpHHGcr",
      "display_url" : "pastebin.com\/raw.php?i=JkpH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422599814115622913",
  "text" : "http:\/\/t.co\/0vxlGEUbZq Emails: 243 Hashes: 2 E\/H: 121.5 Keywords: 0.0 #infoleak",
  "id" : 422599814115622913,
  "created_at" : "2014-01-13 05:23:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zqyh37OXSG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QhvJhaAa",
      "display_url" : "pastebin.com\/raw.php?i=QhvJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422599530714894336",
  "text" : "http:\/\/t.co\/zqyh37OXSG Emails: 127 Keywords: 0.0 #infoleak",
  "id" : 422599530714894336,
  "created_at" : "2014-01-13 05:22:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jmvwUmu6lf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wkXmxDgC",
      "display_url" : "pastebin.com\/raw.php?i=wkXm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422593379327700992",
  "text" : "http:\/\/t.co\/jmvwUmu6lf Emails: 2174 Hashes: 2173 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 422593379327700992,
  "created_at" : "2014-01-13 04:58:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZoHacl9BB8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4z1ZhSXN",
      "display_url" : "pastebin.com\/raw.php?i=4z1Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422592556614967297",
  "text" : "http:\/\/t.co\/ZoHacl9BB8 Hashes: 91 Keywords: 0.22 #infoleak",
  "id" : 422592556614967297,
  "created_at" : "2014-01-13 04:54:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WSKKdy0mjA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5VM8zZim",
      "display_url" : "pastebin.com\/raw.php?i=5VM8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422585775184551938",
  "text" : "http:\/\/t.co\/WSKKdy0mjA Emails: 253 Keywords: 0.08 #infoleak",
  "id" : 422585775184551938,
  "created_at" : "2014-01-13 04:27:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/REE7DSfIdD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C6Knbs5C",
      "display_url" : "pastebin.com\/raw.php?i=C6Kn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422585376713109504",
  "text" : "http:\/\/t.co\/REE7DSfIdD Emails: 253 Keywords: 0.08 #infoleak",
  "id" : 422585376713109504,
  "created_at" : "2014-01-13 04:26:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NdIMre0pyl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AiChGcdY",
      "display_url" : "pastebin.com\/raw.php?i=AiCh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422580705181200384",
  "text" : "http:\/\/t.co\/NdIMre0pyl Emails: 83 Keywords: 0.0 #infoleak",
  "id" : 422580705181200384,
  "created_at" : "2014-01-13 04:07:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ipzPWWeqqL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LX1gG4P9",
      "display_url" : "pastebin.com\/raw.php?i=LX1g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422570610175119360",
  "text" : "http:\/\/t.co\/ipzPWWeqqL Emails: 1474 Hashes: 1 E\/H: 1474.0 Keywords: 0.11 #infoleak",
  "id" : 422570610175119360,
  "created_at" : "2014-01-13 03:27:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vhhQ9I23IL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D1dBFEWr",
      "display_url" : "pastebin.com\/raw.php?i=D1dB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422566113730240512",
  "text" : "http:\/\/t.co\/vhhQ9I23IL Hashes: 36 Keywords: 0.22 #infoleak",
  "id" : 422566113730240512,
  "created_at" : "2014-01-13 03:09:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1yYsXSwEIN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hA1vVerX",
      "display_url" : "pastebin.com\/raw.php?i=hA1v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422541546622181376",
  "text" : "http:\/\/t.co\/1yYsXSwEIN Emails: 24 Keywords: 0.22 #infoleak",
  "id" : 422541546622181376,
  "created_at" : "2014-01-13 01:32:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GyzvslWXvg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qJMTj2dx",
      "display_url" : "pastebin.com\/raw.php?i=qJMT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422540896832208896",
  "text" : "http:\/\/t.co\/GyzvslWXvg Emails: 448 Keywords: 0.33 #infoleak",
  "id" : 422540896832208896,
  "created_at" : "2014-01-13 01:29:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/23bzozFVuf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8mQN6ZtA",
      "display_url" : "pastebin.com\/raw.php?i=8mQN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422535967690330112",
  "text" : "http:\/\/t.co\/23bzozFVuf Emails: 25 Keywords: 0.11 #infoleak",
  "id" : 422535967690330112,
  "created_at" : "2014-01-13 01:09:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k29bU2BPRO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YN4pGmU1",
      "display_url" : "pastebin.com\/raw.php?i=YN4p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422521438923259904",
  "text" : "http:\/\/t.co\/k29bU2BPRO Emails: 46 Keywords: 0.0 #infoleak",
  "id" : 422521438923259904,
  "created_at" : "2014-01-13 00:12:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y4AI1ENIG6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CMtkrZuH",
      "display_url" : "pastebin.com\/raw.php?i=CMtk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422520219320320000",
  "text" : "http:\/\/t.co\/Y4AI1ENIG6 Found possible Google API key(s) #infoleak",
  "id" : 422520219320320000,
  "created_at" : "2014-01-13 00:07:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aQiDECWyGX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wXp78A3G",
      "display_url" : "pastebin.com\/raw.php?i=wXp7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422518200606015489",
  "text" : "http:\/\/t.co\/aQiDECWyGX Hashes: 151 Keywords: -0.14 #infoleak",
  "id" : 422518200606015489,
  "created_at" : "2014-01-12 23:59:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/li2VhDep1K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yjfEMBXk",
      "display_url" : "pastebin.com\/raw.php?i=yjfE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422514501359915009",
  "text" : "http:\/\/t.co\/li2VhDep1K Hashes: 209 Keywords: -0.28 #infoleak",
  "id" : 422514501359915009,
  "created_at" : "2014-01-12 23:44:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T56szEXUrc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pEymdZGH",
      "display_url" : "pastebin.com\/raw.php?i=pEym\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422508255055589377",
  "text" : "http:\/\/t.co\/T56szEXUrc Found possible Google API key(s) #infoleak",
  "id" : 422508255055589377,
  "created_at" : "2014-01-12 23:19:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FVYyypKQZG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fEgpWY3w",
      "display_url" : "pastebin.com\/raw.php?i=fEgp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422506985406222336",
  "text" : "http:\/\/t.co\/FVYyypKQZG Hashes: 41 Keywords: 0.19 #infoleak",
  "id" : 422506985406222336,
  "created_at" : "2014-01-12 23:14:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FhGjqNGcKS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YZKvNEU7",
      "display_url" : "pastebin.com\/raw.php?i=YZKv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422505169415204864",
  "text" : "http:\/\/t.co\/FhGjqNGcKS Emails: 464 Keywords: 0.11 #infoleak",
  "id" : 422505169415204864,
  "created_at" : "2014-01-12 23:07:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v9hFPkFVTH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rahnuaF8",
      "display_url" : "pastebin.com\/raw.php?i=rahn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422496451881480192",
  "text" : "http:\/\/t.co\/v9hFPkFVTH Emails: 57 Keywords: 0.22 #infoleak",
  "id" : 422496451881480192,
  "created_at" : "2014-01-12 22:32:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/larQLI0w60",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t9AQYSv9",
      "display_url" : "pastebin.com\/raw.php?i=t9AQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422494634883825664",
  "text" : "http:\/\/t.co\/larQLI0w60 Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 422494634883825664,
  "created_at" : "2014-01-12 22:25:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wql39aE8Ls",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k0d4Jigw",
      "display_url" : "pastebin.com\/raw.php?i=k0d4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422466840774705152",
  "text" : "http:\/\/t.co\/Wql39aE8Ls Emails: 72 Keywords: 0.11 #infoleak",
  "id" : 422466840774705152,
  "created_at" : "2014-01-12 20:35:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hKKa0sW49w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ay2PgkZq",
      "display_url" : "pastebin.com\/raw.php?i=Ay2P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422464898577084416",
  "text" : "http:\/\/t.co\/hKKa0sW49w Emails: 1866 Keywords: 0.0 #infoleak",
  "id" : 422464898577084416,
  "created_at" : "2014-01-12 20:27:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CCLT9vmDL9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5dQwS4fL",
      "display_url" : "pastebin.com\/raw.php?i=5dQw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422456485403062273",
  "text" : "http:\/\/t.co\/CCLT9vmDL9 Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 422456485403062273,
  "created_at" : "2014-01-12 19:54:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q30EjnKb6i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BKAbe4a6",
      "display_url" : "pastebin.com\/raw.php?i=BKAb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422448962834952192",
  "text" : "http:\/\/t.co\/q30EjnKb6i Emails: 227 Keywords: 0.55 #infoleak",
  "id" : 422448962834952192,
  "created_at" : "2014-01-12 19:24:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OfqMwIE8fR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rsWkx8xA",
      "display_url" : "pastebin.com\/raw.php?i=rsWk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422425876278423552",
  "text" : "http:\/\/t.co\/OfqMwIE8fR Emails: 1574 Keywords: 0.08 #infoleak",
  "id" : 422425876278423552,
  "created_at" : "2014-01-12 17:52:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aCZ5Zh9Y5X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WbS3etUN",
      "display_url" : "pastebin.com\/raw.php?i=WbS3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422424774367662080",
  "text" : "http:\/\/t.co\/aCZ5Zh9Y5X Emails: 152 Keywords: 0.13 #infoleak",
  "id" : 422424774367662080,
  "created_at" : "2014-01-12 17:48:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5ZKl4uPh9X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZWhKwVBe",
      "display_url" : "pastebin.com\/raw.php?i=ZWhK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422424136342720512",
  "text" : "http:\/\/t.co\/5ZKl4uPh9X Emails: 157 Keywords: 0.19 #infoleak",
  "id" : 422424136342720512,
  "created_at" : "2014-01-12 17:45:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vtDb8M4bCj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZrqGGct8",
      "display_url" : "pastebin.com\/raw.php?i=ZrqG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422409781005938689",
  "text" : "http:\/\/t.co\/vtDb8M4bCj Emails: 1474 Hashes: 1 E\/H: 1474.0 Keywords: 0.11 #infoleak",
  "id" : 422409781005938689,
  "created_at" : "2014-01-12 16:48:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IbnbYKfO6e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Px15mVDL",
      "display_url" : "pastebin.com\/raw.php?i=Px15\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422407976897355776",
  "text" : "http:\/\/t.co\/IbnbYKfO6e Possible cisco configuration #infoleak",
  "id" : 422407976897355776,
  "created_at" : "2014-01-12 16:41:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l2cfhzye7L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9eDU3Wsh",
      "display_url" : "pastebin.com\/raw.php?i=9eDU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422404636046155776",
  "text" : "http:\/\/t.co\/l2cfhzye7L Emails: 153 Hashes: 61 E\/H: 2.51 Keywords: 0.22 #infoleak",
  "id" : 422404636046155776,
  "created_at" : "2014-01-12 16:28:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rTElomwZY1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4zGJH4U3",
      "display_url" : "pastebin.com\/raw.php?i=4zGJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422393225991553024",
  "text" : "http:\/\/t.co\/rTElomwZY1 Keywords: 0.55 #infoleak",
  "id" : 422393225991553024,
  "created_at" : "2014-01-12 15:42:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0NCThFTr70",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=L05ccNGJ",
      "display_url" : "pastebin.com\/raw.php?i=L05c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422389120975908864",
  "text" : "http:\/\/t.co\/0NCThFTr70 Found possible Google API key(s) #infoleak",
  "id" : 422389120975908864,
  "created_at" : "2014-01-12 15:26:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dRjE38hHJd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5rCTrzGt",
      "display_url" : "pastebin.com\/raw.php?i=5rCT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422357937260990464",
  "text" : "http:\/\/t.co\/dRjE38hHJd Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 422357937260990464,
  "created_at" : "2014-01-12 13:22:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TeLTTZ33sg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vzdTcKcx",
      "display_url" : "pastebin.com\/raw.php?i=vzdT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422330481586089984",
  "text" : "http:\/\/t.co\/TeLTTZ33sg Emails: 148 Keywords: 0.11 #infoleak",
  "id" : 422330481586089984,
  "created_at" : "2014-01-12 11:33:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EN6q836fgS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=05yJRF8i",
      "display_url" : "pastebin.com\/raw.php?i=05yJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422310531551096832",
  "text" : "http:\/\/t.co\/EN6q836fgS Keywords: 0.55 #infoleak",
  "id" : 422310531551096832,
  "created_at" : "2014-01-12 10:14:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iE6fIMcxXu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9g9BCaN0",
      "display_url" : "pastebin.com\/raw.php?i=9g9B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422305094596448256",
  "text" : "http:\/\/t.co\/iE6fIMcxXu Possible cisco configuration #infoleak",
  "id" : 422305094596448256,
  "created_at" : "2014-01-12 09:52:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CIDaWJ5oCn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MNEMEBqi",
      "display_url" : "pastebin.com\/raw.php?i=MNEM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422292463970050048",
  "text" : "http:\/\/t.co\/CIDaWJ5oCn Hashes: 2888 Keywords: 0.11 #infoleak",
  "id" : 422292463970050048,
  "created_at" : "2014-01-12 09:02:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JGR5bHMKTP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=64WUWH9Q",
      "display_url" : "pastebin.com\/raw.php?i=64WU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422222804004507648",
  "text" : "http:\/\/t.co\/JGR5bHMKTP Possible cisco configuration #infoleak",
  "id" : 422222804004507648,
  "created_at" : "2014-01-12 04:25:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CY9S5Aw2xS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7ve1LWgP",
      "display_url" : "pastebin.com\/raw.php?i=7ve1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422212942637961216",
  "text" : "http:\/\/t.co\/CY9S5Aw2xS Emails: 65 Keywords: 0.0 #infoleak",
  "id" : 422212942637961216,
  "created_at" : "2014-01-12 03:46:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zx2V2kd6i8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JvuVdGeW",
      "display_url" : "pastebin.com\/raw.php?i=JvuV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422212787184488449",
  "text" : "http:\/\/t.co\/Zx2V2kd6i8 Found possible Google API key(s) #infoleak",
  "id" : 422212787184488449,
  "created_at" : "2014-01-12 03:45:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yyf46EpCmm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jfWt6Bp4",
      "display_url" : "pastebin.com\/raw.php?i=jfWt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422207943769985024",
  "text" : "http:\/\/t.co\/yyf46EpCmm Keywords: 0.66 #infoleak",
  "id" : 422207943769985024,
  "created_at" : "2014-01-12 03:26:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9VhllP8YUE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EPyWqvfD",
      "display_url" : "pastebin.com\/raw.php?i=EPyW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422182088863793152",
  "text" : "http:\/\/t.co\/9VhllP8YUE Emails: 162 Keywords: 0.11 #infoleak",
  "id" : 422182088863793152,
  "created_at" : "2014-01-12 01:43:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IJsVKK6UlS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cgmCj3UV",
      "display_url" : "pastebin.com\/raw.php?i=cgmC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422177245747089408",
  "text" : "http:\/\/t.co\/IJsVKK6UlS Hashes: 1005 Keywords: 0.08 #infoleak",
  "id" : 422177245747089408,
  "created_at" : "2014-01-12 01:24:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hkbEi0HZdJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bwDa9aLJ",
      "display_url" : "pastebin.com\/raw.php?i=bwDa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422173910512046080",
  "text" : "http:\/\/t.co\/hkbEi0HZdJ Emails: 2236 Keywords: -0.03 #infoleak",
  "id" : 422173910512046080,
  "created_at" : "2014-01-12 01:11:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H3m2z7yttv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c8EgMBNT",
      "display_url" : "pastebin.com\/raw.php?i=c8Eg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422170956388257792",
  "text" : "http:\/\/t.co\/H3m2z7yttv Found possible Google API key(s) #infoleak",
  "id" : 422170956388257792,
  "created_at" : "2014-01-12 00:59:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x8ZdOyfPHQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1KENH836",
      "display_url" : "pastebin.com\/raw.php?i=1KEN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422167384070172672",
  "text" : "http:\/\/t.co\/x8ZdOyfPHQ Emails: 231 Keywords: 0.33 #infoleak",
  "id" : 422167384070172672,
  "created_at" : "2014-01-12 00:45:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nbSHgpCXAi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mk4PjyXq",
      "display_url" : "pastebin.com\/raw.php?i=Mk4P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422160412985929728",
  "text" : "http:\/\/t.co\/nbSHgpCXAi Emails: 303 Keywords: 0.11 #infoleak",
  "id" : 422160412985929728,
  "created_at" : "2014-01-12 00:17:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ikowYaJcjG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nBZEphL9",
      "display_url" : "pastebin.com\/raw.php?i=nBZE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422149377323302912",
  "text" : "http:\/\/t.co\/ikowYaJcjG Emails: 60 Keywords: 0.11 #infoleak",
  "id" : 422149377323302912,
  "created_at" : "2014-01-11 23:33:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RCYOJL4PSe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5a5uaK1a",
      "display_url" : "pastebin.com\/raw.php?i=5a5u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422144572035039232",
  "text" : "http:\/\/t.co\/RCYOJL4PSe Hashes: 73 Keywords: 0.0 #infoleak",
  "id" : 422144572035039232,
  "created_at" : "2014-01-11 23:14:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UGRNJNOkk3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rhUqQjK4",
      "display_url" : "pastebin.com\/raw.php?i=rhUq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422144091829182464",
  "text" : "http:\/\/t.co\/UGRNJNOkk3 Emails: 2601 Keywords: 0.08 #infoleak",
  "id" : 422144091829182464,
  "created_at" : "2014-01-11 23:12:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7KlPhvP6hj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UVHcrx6X",
      "display_url" : "pastebin.com\/raw.php?i=UVHc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422127191820750848",
  "text" : "http:\/\/t.co\/7KlPhvP6hj Emails: 848 Keywords: 0.0 #infoleak",
  "id" : 422127191820750848,
  "created_at" : "2014-01-11 22:05:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0ZTPr2TxEC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eZGvpRu1",
      "display_url" : "pastebin.com\/raw.php?i=eZGv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422121960898691072",
  "text" : "http:\/\/t.co\/0ZTPr2TxEC Found possible Google API key(s) #infoleak",
  "id" : 422121960898691072,
  "created_at" : "2014-01-11 21:44:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vVSD4tuOuZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qqUFMJUx",
      "display_url" : "pastebin.com\/raw.php?i=qqUF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422118904488407040",
  "text" : "http:\/\/t.co\/vVSD4tuOuZ Hashes: 56 Keywords: -0.03 #infoleak",
  "id" : 422118904488407040,
  "created_at" : "2014-01-11 21:32:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5bLtSyz5gC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=29FyJKju",
      "display_url" : "pastebin.com\/raw.php?i=29Fy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422113761252487168",
  "text" : "http:\/\/t.co\/5bLtSyz5gC Emails: 20 Keywords: 0.22 #infoleak",
  "id" : 422113761252487168,
  "created_at" : "2014-01-11 21:12:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xR8HgkZKFp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q69ciQav",
      "display_url" : "pastebin.com\/raw.php?i=Q69c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422111923891474432",
  "text" : "http:\/\/t.co\/xR8HgkZKFp Emails: 60 Keywords: 0.22 #infoleak",
  "id" : 422111923891474432,
  "created_at" : "2014-01-11 21:04:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JXnsLHy3MS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8m5cLfEW",
      "display_url" : "pastebin.com\/raw.php?i=8m5c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422111356699959296",
  "text" : "http:\/\/t.co\/JXnsLHy3MS Emails: 60 Keywords: 0.22 #infoleak",
  "id" : 422111356699959296,
  "created_at" : "2014-01-11 21:02:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BqomwIXvIS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=apmmRwXm",
      "display_url" : "pastebin.com\/raw.php?i=apmm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422110466555396096",
  "text" : "http:\/\/t.co\/BqomwIXvIS Emails: 243 Keywords: 0.11 #infoleak",
  "id" : 422110466555396096,
  "created_at" : "2014-01-11 20:59:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OSzbMaitMK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mYVE1Ps0",
      "display_url" : "pastebin.com\/raw.php?i=mYVE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422105154481954816",
  "text" : "http:\/\/t.co\/OSzbMaitMK Found possible Google API key(s) #infoleak",
  "id" : 422105154481954816,
  "created_at" : "2014-01-11 20:38:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v91PiP3fyy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xGtS0daq",
      "display_url" : "pastebin.com\/raw.php?i=xGtS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422091774954205184",
  "text" : "http:\/\/t.co\/v91PiP3fyy Keywords: 0.66 #infoleak",
  "id" : 422091774954205184,
  "created_at" : "2014-01-11 19:44:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mKsfrvnLeq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gJkuiJkS",
      "display_url" : "pastebin.com\/raw.php?i=gJku\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422086817332985856",
  "text" : "http:\/\/t.co\/mKsfrvnLeq Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 422086817332985856,
  "created_at" : "2014-01-11 19:25:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JnEb35NV7q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AKNnmsTc",
      "display_url" : "pastebin.com\/raw.php?i=AKNn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422086581227229184",
  "text" : "http:\/\/t.co\/JnEb35NV7q Emails: 2677 Keywords: 0.44 #infoleak",
  "id" : 422086581227229184,
  "created_at" : "2014-01-11 19:24:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OZ37kNUcrx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=36QKLNsg",
      "display_url" : "pastebin.com\/raw.php?i=36QK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422063027890835456",
  "text" : "http:\/\/t.co\/OZ37kNUcrx Emails: 23 Hashes: 8 E\/H: 2.88 Keywords: 0.3 #infoleak",
  "id" : 422063027890835456,
  "created_at" : "2014-01-11 17:50:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VyZIB9bJEX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ePj19qrV",
      "display_url" : "pastebin.com\/raw.php?i=ePj1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422056987170308096",
  "text" : "http:\/\/t.co\/VyZIB9bJEX Hashes: 38 Keywords: 0.0 #infoleak",
  "id" : 422056987170308096,
  "created_at" : "2014-01-11 17:26:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TcDT41ozW2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nHY25PkS",
      "display_url" : "pastebin.com\/raw.php?i=nHY2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422056913598042112",
  "text" : "http:\/\/t.co\/TcDT41ozW2 Found possible Google API key(s) #infoleak",
  "id" : 422056913598042112,
  "created_at" : "2014-01-11 17:26:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lMn2pG3EIC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xSsntWNq",
      "display_url" : "pastebin.com\/raw.php?i=xSsn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422055087171584000",
  "text" : "http:\/\/t.co\/lMn2pG3EIC Emails: 83 Keywords: 0.0 #infoleak",
  "id" : 422055087171584000,
  "created_at" : "2014-01-11 17:19:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4x4WCkWEf9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2LN3vQNZ",
      "display_url" : "pastebin.com\/raw.php?i=2LN3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422049071180701696",
  "text" : "http:\/\/t.co\/4x4WCkWEf9 Emails: 647 Hashes: 646 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 422049071180701696,
  "created_at" : "2014-01-11 16:55:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F4PR3yVgo0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=60UzvzPm",
      "display_url" : "pastebin.com\/raw.php?i=60Uz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422038294151438336",
  "text" : "http:\/\/t.co\/F4PR3yVgo0 Emails: 303 Keywords: 0.11 #infoleak",
  "id" : 422038294151438336,
  "created_at" : "2014-01-11 16:12:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vBzUIbUnkq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tcKsrDMD",
      "display_url" : "pastebin.com\/raw.php?i=tcKs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422029983180005376",
  "text" : "http:\/\/t.co\/vBzUIbUnkq Hashes: 184 Keywords: -0.14 #infoleak",
  "id" : 422029983180005376,
  "created_at" : "2014-01-11 15:39:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/USfIioVAN3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2Y2Svz3s",
      "display_url" : "pastebin.com\/raw.php?i=2Y2S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422028048762806273",
  "text" : "http:\/\/t.co\/USfIioVAN3 Hashes: 77 Keywords: 0.0 #infoleak",
  "id" : 422028048762806273,
  "created_at" : "2014-01-11 15:31:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BfM5Xx4akL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mD3Qc3YN",
      "display_url" : "pastebin.com\/raw.php?i=mD3Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422015384997208065",
  "text" : "http:\/\/t.co\/BfM5Xx4akL Found possible Google API key(s) #infoleak",
  "id" : 422015384997208065,
  "created_at" : "2014-01-11 14:41:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k9TV7sxZPH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SSYNWq4q",
      "display_url" : "pastebin.com\/raw.php?i=SSYN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422014891625418752",
  "text" : "http:\/\/t.co\/k9TV7sxZPH Keywords: 0.55 #infoleak",
  "id" : 422014891625418752,
  "created_at" : "2014-01-11 14:39:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vG8L8Jq3eS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CzbNnRV0",
      "display_url" : "pastebin.com\/raw.php?i=CzbN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422014749711151104",
  "text" : "http:\/\/t.co\/vG8L8Jq3eS Emails: 257 Keywords: 0.0 #infoleak",
  "id" : 422014749711151104,
  "created_at" : "2014-01-11 14:38:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RJnIw9xL3P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p4m3dKVj",
      "display_url" : "pastebin.com\/raw.php?i=p4m3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421987707317792769",
  "text" : "http:\/\/t.co\/RJnIw9xL3P Emails: 52 Keywords: 0.11 #infoleak",
  "id" : 421987707317792769,
  "created_at" : "2014-01-11 12:51:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xt1YzURVQv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SuSX8iwZ",
      "display_url" : "pastebin.com\/raw.php?i=SuSX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421974436669960193",
  "text" : "http:\/\/t.co\/Xt1YzURVQv Emails: 303 Keywords: 0.11 #infoleak",
  "id" : 421974436669960193,
  "created_at" : "2014-01-11 11:58:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JyjxdginEP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p25BDEhu",
      "display_url" : "pastebin.com\/raw.php?i=p25B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421961284012085248",
  "text" : "http:\/\/t.co\/JyjxdginEP Emails: 335 Keywords: 0.44 #infoleak",
  "id" : 421961284012085248,
  "created_at" : "2014-01-11 11:06:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3lXoYtm93U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QEN0BjfN",
      "display_url" : "pastebin.com\/raw.php?i=QEN0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421955661555965952",
  "text" : "http:\/\/t.co\/3lXoYtm93U Emails: 74 Keywords: 0.0 #infoleak",
  "id" : 421955661555965952,
  "created_at" : "2014-01-11 10:44:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Pb9Z5TQDBN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TTVeXXzr",
      "display_url" : "pastebin.com\/raw.php?i=TTVe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421954350731120641",
  "text" : "http:\/\/t.co\/Pb9Z5TQDBN Found possible Google API key(s) #infoleak",
  "id" : 421954350731120641,
  "created_at" : "2014-01-11 10:38:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nCAGEzRAMN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iQ4T1tCH",
      "display_url" : "pastebin.com\/raw.php?i=iQ4T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421897983274135552",
  "text" : "http:\/\/t.co\/nCAGEzRAMN Found possible Google API key(s) #infoleak",
  "id" : 421897983274135552,
  "created_at" : "2014-01-11 06:54:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hqvHlacjSb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xBNYxMbJ",
      "display_url" : "pastebin.com\/raw.php?i=xBNY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421881800135147520",
  "text" : "http:\/\/t.co\/hqvHlacjSb Emails: 12966 Keywords: 0.08 #infoleak",
  "id" : 421881800135147520,
  "created_at" : "2014-01-11 05:50:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/24H35KocSR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rntJcxte",
      "display_url" : "pastebin.com\/raw.php?i=rntJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421874174986960896",
  "text" : "http:\/\/t.co\/24H35KocSR Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 421874174986960896,
  "created_at" : "2014-01-11 05:20:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aMumogVEwf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Nu0aR2Fk",
      "display_url" : "pastebin.com\/raw.php?i=Nu0a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421873103602331650",
  "text" : "http:\/\/t.co\/aMumogVEwf Hashes: 59 Keywords: -0.03 #infoleak",
  "id" : 421873103602331650,
  "created_at" : "2014-01-11 05:16:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jeaxtRPvgC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y7X9njsX",
      "display_url" : "pastebin.com\/raw.php?i=Y7X9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421856940717641730",
  "text" : "http:\/\/t.co\/jeaxtRPvgC Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 421856940717641730,
  "created_at" : "2014-01-11 04:11:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KvqQaLq6XK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WLFfTvFk",
      "display_url" : "pastebin.com\/raw.php?i=WLFf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421842756869160961",
  "text" : "http:\/\/t.co\/KvqQaLq6XK Emails: 83 Keywords: 0.0 #infoleak",
  "id" : 421842756869160961,
  "created_at" : "2014-01-11 03:15:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w43pd3f61Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f4RNRJP3",
      "display_url" : "pastebin.com\/raw.php?i=f4RN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421828022270828544",
  "text" : "http:\/\/t.co\/w43pd3f61Z Emails: 1970 Hashes: 1995 E\/H: 0.99 Keywords: 0.33 #infoleak",
  "id" : 421828022270828544,
  "created_at" : "2014-01-11 02:16:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1ix8kPyl5s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iiGqSd72",
      "display_url" : "pastebin.com\/raw.php?i=iiGq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421819707079921664",
  "text" : "http:\/\/t.co\/1ix8kPyl5s Hashes: 56 Keywords: 0.11 #infoleak",
  "id" : 421819707079921664,
  "created_at" : "2014-01-11 01:43:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/69FKxNeInS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ALYbV1iq",
      "display_url" : "pastebin.com\/raw.php?i=ALYb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421819694014689280",
  "text" : "http:\/\/t.co\/69FKxNeInS Emails: 105 Hashes: 2 E\/H: 52.5 Keywords: 0.11 #infoleak",
  "id" : 421819694014689280,
  "created_at" : "2014-01-11 01:43:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0m6t4of0Nt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wPq5zEA7",
      "display_url" : "pastebin.com\/raw.php?i=wPq5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421810969719734272",
  "text" : "http:\/\/t.co\/0m6t4of0Nt Emails: 2224 Keywords: -0.03 #infoleak",
  "id" : 421810969719734272,
  "created_at" : "2014-01-11 01:09:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TbdZD5lmTE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BtQVcFLB",
      "display_url" : "pastebin.com\/raw.php?i=BtQV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421809668634071040",
  "text" : "http:\/\/t.co\/TbdZD5lmTE Emails: 1945 Keywords: 0.08 #infoleak",
  "id" : 421809668634071040,
  "created_at" : "2014-01-11 01:03:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MbGuinLg72",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=70U671cW",
      "display_url" : "pastebin.com\/raw.php?i=70U6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421804905381113856",
  "text" : "http:\/\/t.co\/MbGuinLg72 Emails: 93 Keywords: 0.41 #infoleak",
  "id" : 421804905381113856,
  "created_at" : "2014-01-11 00:45:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u2AyEt75D7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WLaE3AYv",
      "display_url" : "pastebin.com\/raw.php?i=WLaE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421799948351336448",
  "text" : "http:\/\/t.co\/u2AyEt75D7 Emails: 142 Keywords: 0.11 #infoleak",
  "id" : 421799948351336448,
  "created_at" : "2014-01-11 00:25:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7m62ZlhwSk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mwZp0vDg",
      "display_url" : "pastebin.com\/raw.php?i=mwZp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421746438805004288",
  "text" : "http:\/\/t.co\/7m62ZlhwSk Found possible Google API key(s) #infoleak",
  "id" : 421746438805004288,
  "created_at" : "2014-01-10 20:52:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aXUkWI1hnh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a1DTDXzB",
      "display_url" : "pastebin.com\/raw.php?i=a1DT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421744944856838144",
  "text" : "http:\/\/t.co\/aXUkWI1hnh Emails: 44 Keywords: 0.19 #infoleak",
  "id" : 421744944856838144,
  "created_at" : "2014-01-10 20:46:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0lCuxpVP7V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eZCrdYM4",
      "display_url" : "pastebin.com\/raw.php?i=eZCr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421740190596485120",
  "text" : "http:\/\/t.co\/0lCuxpVP7V Emails: 608 Keywords: 0.33 #infoleak",
  "id" : 421740190596485120,
  "created_at" : "2014-01-10 20:27:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FKY8VrTJR2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qLQggUA5",
      "display_url" : "pastebin.com\/raw.php?i=qLQg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421739916716830720",
  "text" : "http:\/\/t.co\/FKY8VrTJR2 Emails: 92 Hashes: 532 E\/H: 0.17 Keywords: 0.33 #infoleak",
  "id" : 421739916716830720,
  "created_at" : "2014-01-10 20:26:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SahdYkYKci",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LFFw7DD9",
      "display_url" : "pastebin.com\/raw.php?i=LFFw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421739138832809984",
  "text" : "http:\/\/t.co\/SahdYkYKci Emails: 66 Keywords: 0.11 #infoleak",
  "id" : 421739138832809984,
  "created_at" : "2014-01-10 20:23:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a42cZFRQvw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5M3JhxjR",
      "display_url" : "pastebin.com\/raw.php?i=5M3J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421738683583062016",
  "text" : "http:\/\/t.co\/a42cZFRQvw Found possible Google API key(s) #infoleak",
  "id" : 421738683583062016,
  "created_at" : "2014-01-10 20:21:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xjq1sIyjp1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w4snDx4j",
      "display_url" : "pastebin.com\/raw.php?i=w4sn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421738405261635584",
  "text" : "http:\/\/t.co\/xjq1sIyjp1 Emails: 53 Hashes: 51 E\/H: 1.04 Keywords: 0.33 #infoleak",
  "id" : 421738405261635584,
  "created_at" : "2014-01-10 20:20:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jpuyEhWSN6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T9WWtt3A",
      "display_url" : "pastebin.com\/raw.php?i=T9WW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421735570037936128",
  "text" : "http:\/\/t.co\/jpuyEhWSN6 Hashes: 51 Keywords: 0.22 #infoleak",
  "id" : 421735570037936128,
  "created_at" : "2014-01-10 20:09:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u81dRo9Wc3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AGNsM1gu",
      "display_url" : "pastebin.com\/raw.php?i=AGNs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421728719485431808",
  "text" : "http:\/\/t.co\/u81dRo9Wc3 Emails: 240 Keywords: 0.0 #infoleak",
  "id" : 421728719485431808,
  "created_at" : "2014-01-10 19:42:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bJEYcdf0md",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TFEnV5jH",
      "display_url" : "pastebin.com\/raw.php?i=TFEn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421719598379982848",
  "text" : "http:\/\/t.co\/bJEYcdf0md Emails: 34 Keywords: 0.33 #infoleak",
  "id" : 421719598379982848,
  "created_at" : "2014-01-10 19:06:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZQw9mQXmNn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dG7GCncS",
      "display_url" : "pastebin.com\/raw.php?i=dG7G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421716879372062720",
  "text" : "http:\/\/t.co\/ZQw9mQXmNn Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 421716879372062720,
  "created_at" : "2014-01-10 18:55:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vontAXYpgp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KVvgVHpB",
      "display_url" : "pastebin.com\/raw.php?i=KVvg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421713852519051264",
  "text" : "http:\/\/t.co\/vontAXYpgp Emails: 135 Keywords: 0.0 #infoleak",
  "id" : 421713852519051264,
  "created_at" : "2014-01-10 18:43:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WZJUxtn9VO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G6CGS1RM",
      "display_url" : "pastebin.com\/raw.php?i=G6CG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421708262874959872",
  "text" : "http:\/\/t.co\/WZJUxtn9VO Emails: 8012 Keywords: 0.33 #infoleak",
  "id" : 421708262874959872,
  "created_at" : "2014-01-10 18:20:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lEsFdp4N1h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jBuBMkTS",
      "display_url" : "pastebin.com\/raw.php?i=jBuB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421700131805605888",
  "text" : "http:\/\/t.co\/lEsFdp4N1h Keywords: 0.55 #infoleak",
  "id" : 421700131805605888,
  "created_at" : "2014-01-10 17:48:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VQ5wIvt1CV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SzWVPRsk",
      "display_url" : "pastebin.com\/raw.php?i=SzWV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421699968320012288",
  "text" : "http:\/\/t.co\/VQ5wIvt1CV Keywords: 0.55 #infoleak",
  "id" : 421699968320012288,
  "created_at" : "2014-01-10 17:48:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JzIDwQEkQr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vGJgHMfQ",
      "display_url" : "pastebin.com\/raw.php?i=vGJg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421685049952436224",
  "text" : "http:\/\/t.co\/JzIDwQEkQr Found possible Google API key(s) #infoleak",
  "id" : 421685049952436224,
  "created_at" : "2014-01-10 16:48:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y4YDcZwtbF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ns4D8rf2",
      "display_url" : "pastebin.com\/raw.php?i=ns4D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421673030289338368",
  "text" : "http:\/\/t.co\/y4YDcZwtbF Found possible Google API key(s) #infoleak",
  "id" : 421673030289338368,
  "created_at" : "2014-01-10 16:00:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mWmDpoAJRx",
      "expanded_url" : "http:\/\/www.cvedetails.com\/cve\/CVE-2010-1702\/",
      "display_url" : "cvedetails.com\/cve\/CVE-2010-1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "421656602362380288",
  "geo" : { },
  "id_str" : "421670414037688320",
  "in_reply_to_user_id" : 1231625892,
  "text" : "http:\/\/t.co\/mWmDpoAJRx",
  "id" : 421670414037688320,
  "in_reply_to_status_id" : 421656602362380288,
  "created_at" : "2014-01-10 15:50:35 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cj0A8RH5bx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1t5VQUd9",
      "display_url" : "pastebin.com\/raw.php?i=1t5V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421666422968696832",
  "text" : "http:\/\/t.co\/cj0A8RH5bx Found possible Google API key(s) #infoleak",
  "id" : 421666422968696832,
  "created_at" : "2014-01-10 15:34:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JQI9M9Uzo5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AykdRLES",
      "display_url" : "pastebin.com\/raw.php?i=Aykd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421660885262684160",
  "text" : "http:\/\/t.co\/JQI9M9Uzo5 Emails: 396 Keywords: 0.22 #infoleak",
  "id" : 421660885262684160,
  "created_at" : "2014-01-10 15:12:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CcpQWGFCHp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iHBfDBs5",
      "display_url" : "pastebin.com\/raw.php?i=iHBf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421658706544037888",
  "text" : "http:\/\/t.co\/CcpQWGFCHp Emails: 3 Hashes: 34 E\/H: 0.09 Keywords: 0.44 #infoleak",
  "id" : 421658706544037888,
  "created_at" : "2014-01-10 15:04:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CcNvkCQFb4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GNySQ2JB",
      "display_url" : "pastebin.com\/raw.php?i=GNyS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421656602362380288",
  "text" : "http:\/\/t.co\/CcNvkCQFb4 Emails: 928 Hashes: 2069 E\/H: 0.45 Keywords: 0.19 #infoleak",
  "id" : 421656602362380288,
  "created_at" : "2014-01-10 14:55:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bKOJUAkSZA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BPgSASDj",
      "display_url" : "pastebin.com\/raw.php?i=BPgS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421651022314889216",
  "text" : "http:\/\/t.co\/bKOJUAkSZA Emails: 33 Hashes: 33 E\/H: 1.0 Keywords: 0.44 #infoleak",
  "id" : 421651022314889216,
  "created_at" : "2014-01-10 14:33:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F0xooUqqhg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0R7UCa3F",
      "display_url" : "pastebin.com\/raw.php?i=0R7U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421646297481752576",
  "text" : "http:\/\/t.co\/F0xooUqqhg Found possible Google API key(s) #infoleak",
  "id" : 421646297481752576,
  "created_at" : "2014-01-10 14:14:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OHASLY0Ula",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b6TReJeq",
      "display_url" : "pastebin.com\/raw.php?i=b6TR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421645177241870336",
  "text" : "http:\/\/t.co\/OHASLY0Ula Emails: 273 Keywords: 0.3 #infoleak",
  "id" : 421645177241870336,
  "created_at" : "2014-01-10 14:10:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e2DR2Nb6X0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G876upfv",
      "display_url" : "pastebin.com\/raw.php?i=G876\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421644558267449345",
  "text" : "http:\/\/t.co\/e2DR2Nb6X0 Emails: 91 Keywords: 0.11 #infoleak",
  "id" : 421644558267449345,
  "created_at" : "2014-01-10 14:07:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J9z4l5tC5K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RsgvHv7t",
      "display_url" : "pastebin.com\/raw.php?i=Rsgv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421629271203774464",
  "text" : "http:\/\/t.co\/J9z4l5tC5K Emails: 152 Keywords: 0.0 #infoleak",
  "id" : 421629271203774464,
  "created_at" : "2014-01-10 13:07:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iv74uZypX3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kmEnkS89",
      "display_url" : "pastebin.com\/raw.php?i=kmEn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421628630347698176",
  "text" : "http:\/\/t.co\/iv74uZypX3 Emails: 112 Keywords: 0.0 #infoleak",
  "id" : 421628630347698176,
  "created_at" : "2014-01-10 13:04:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bm6U8KIO2L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=APceDeUM",
      "display_url" : "pastebin.com\/raw.php?i=APce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421628567147913216",
  "text" : "http:\/\/t.co\/Bm6U8KIO2L Possible cisco configuration #infoleak",
  "id" : 421628567147913216,
  "created_at" : "2014-01-10 13:04:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NaXJkfB72F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qzu7RxaG",
      "display_url" : "pastebin.com\/raw.php?i=qzu7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421628120358088704",
  "text" : "http:\/\/t.co\/NaXJkfB72F Emails: 92 Keywords: 0.0 #infoleak",
  "id" : 421628120358088704,
  "created_at" : "2014-01-10 13:02:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X02quWgxRE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WFxRFURM",
      "display_url" : "pastebin.com\/raw.php?i=WFxR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421626245978144768",
  "text" : "http:\/\/t.co\/X02quWgxRE Emails: 87 Keywords: 0.0 #infoleak",
  "id" : 421626245978144768,
  "created_at" : "2014-01-10 12:55:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Chq2r0POPo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JKh0D18x",
      "display_url" : "pastebin.com\/raw.php?i=JKh0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421609580963975168",
  "text" : "http:\/\/t.co\/Chq2r0POPo Keywords: 0.55 #infoleak",
  "id" : 421609580963975168,
  "created_at" : "2014-01-10 11:48:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9qTuVGdZkM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J2qpgv12",
      "display_url" : "pastebin.com\/raw.php?i=J2qp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421606260580958208",
  "text" : "http:\/\/t.co\/9qTuVGdZkM Emails: 104 Keywords: -0.03 #infoleak",
  "id" : 421606260580958208,
  "created_at" : "2014-01-10 11:35:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EPsWhYSg2W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QyZsWLRE",
      "display_url" : "pastebin.com\/raw.php?i=QyZs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421576454174830592",
  "text" : "http:\/\/t.co\/EPsWhYSg2W Emails: 11 Hashes: 13 E\/H: 0.85 Keywords: 0.77 #infoleak",
  "id" : 421576454174830592,
  "created_at" : "2014-01-10 09:37:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/77nlligR5W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VS3ULrP0",
      "display_url" : "pastebin.com\/raw.php?i=VS3U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421563186886610944",
  "text" : "http:\/\/t.co\/77nlligR5W Emails: 44 Keywords: 0.0 #infoleak",
  "id" : 421563186886610944,
  "created_at" : "2014-01-10 08:44:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fn3AzFVVcd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RkP1HtDu",
      "display_url" : "pastebin.com\/raw.php?i=RkP1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421562635172057088",
  "text" : "http:\/\/t.co\/Fn3AzFVVcd Emails: 204 Keywords: 0.0 #infoleak",
  "id" : 421562635172057088,
  "created_at" : "2014-01-10 08:42:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qWCovleOyK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BkJjq6uc",
      "display_url" : "pastebin.com\/raw.php?i=BkJj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421562070383865856",
  "text" : "http:\/\/t.co\/qWCovleOyK Emails: 60 Keywords: 0.11 #infoleak",
  "id" : 421562070383865856,
  "created_at" : "2014-01-10 08:40:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PgRiRRsWf2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=822i26V3",
      "display_url" : "pastebin.com\/raw.php?i=822i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421561286514597889",
  "text" : "http:\/\/t.co\/PgRiRRsWf2 Emails: 60 Keywords: 0.11 #infoleak",
  "id" : 421561286514597889,
  "created_at" : "2014-01-10 08:36:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kOTfwrgipf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JggSeTSe",
      "display_url" : "pastebin.com\/raw.php?i=JggS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421548868291940352",
  "text" : "http:\/\/t.co\/kOTfwrgipf Emails: 1015 Keywords: 0.22 #infoleak",
  "id" : 421548868291940352,
  "created_at" : "2014-01-10 07:47:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uyCOyXjv6r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U55nRm2E",
      "display_url" : "pastebin.com\/raw.php?i=U55n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421548197677256704",
  "text" : "http:\/\/t.co\/uyCOyXjv6r Emails: 30 Keywords: 0.22 #infoleak",
  "id" : 421548197677256704,
  "created_at" : "2014-01-10 07:44:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9eTR6Kj5uj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rkvRtxUY",
      "display_url" : "pastebin.com\/raw.php?i=rkvR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421543045272567808",
  "text" : "http:\/\/t.co\/9eTR6Kj5uj Emails: 136 Keywords: -0.03 #infoleak",
  "id" : 421543045272567808,
  "created_at" : "2014-01-10 07:24:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ydK6b6dKbF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ec6wvv5u",
      "display_url" : "pastebin.com\/raw.php?i=Ec6w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421534515618525185",
  "text" : "http:\/\/t.co\/ydK6b6dKbF Emails: 636 Keywords: 0.0 #infoleak",
  "id" : 421534515618525185,
  "created_at" : "2014-01-10 06:50:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ePcWFyIShK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c4dyazbJ",
      "display_url" : "pastebin.com\/raw.php?i=c4dy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421533140872478720",
  "text" : "http:\/\/t.co\/ePcWFyIShK Emails: 730 Keywords: 0.0 #infoleak",
  "id" : 421533140872478720,
  "created_at" : "2014-01-10 06:45:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xdj34877pa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g7aBJyWw",
      "display_url" : "pastebin.com\/raw.php?i=g7aB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421531908313337856",
  "text" : "http:\/\/t.co\/Xdj34877pa Found possible Google API key(s) #infoleak",
  "id" : 421531908313337856,
  "created_at" : "2014-01-10 06:40:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UyGxa32RSx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PsCMk1tV",
      "display_url" : "pastebin.com\/raw.php?i=PsCM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421530607995219968",
  "text" : "http:\/\/t.co\/UyGxa32RSx Emails: 1206 Keywords: 0.11 #infoleak",
  "id" : 421530607995219968,
  "created_at" : "2014-01-10 06:35:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X34e0ZZFKO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dYQNphr6",
      "display_url" : "pastebin.com\/raw.php?i=dYQN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421529553027080192",
  "text" : "http:\/\/t.co\/X34e0ZZFKO Emails: 54 Keywords: 0.22 #infoleak",
  "id" : 421529553027080192,
  "created_at" : "2014-01-10 06:30:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fcrot2kyXy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=idEh4rh0",
      "display_url" : "pastebin.com\/raw.php?i=idEh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421522518491414528",
  "text" : "http:\/\/t.co\/Fcrot2kyXy Possible cisco configuration #infoleak",
  "id" : 421522518491414528,
  "created_at" : "2014-01-10 06:02:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NzLqoI7yuW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ymSXx2fh",
      "display_url" : "pastebin.com\/raw.php?i=ymSX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421512460026146817",
  "text" : "http:\/\/t.co\/NzLqoI7yuW Emails: 37 Keywords: -0.14 #infoleak",
  "id" : 421512460026146817,
  "created_at" : "2014-01-10 05:22:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jHqzmPAmmy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f1eCL9nH",
      "display_url" : "pastebin.com\/raw.php?i=f1eC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421510929054838786",
  "text" : "http:\/\/t.co\/jHqzmPAmmy Emails: 200 Keywords: 0.0 #infoleak",
  "id" : 421510929054838786,
  "created_at" : "2014-01-10 05:16:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EeeTlvP9ft",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=shgv1FCN",
      "display_url" : "pastebin.com\/raw.php?i=shgv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421506751398047746",
  "text" : "http:\/\/t.co\/EeeTlvP9ft Emails: 20 Keywords: 0.08 #infoleak",
  "id" : 421506751398047746,
  "created_at" : "2014-01-10 05:00:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rRtPQsDVuP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9NcdJZDv",
      "display_url" : "pastebin.com\/raw.php?i=9Ncd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421447398699696128",
  "text" : "http:\/\/t.co\/rRtPQsDVuP Hashes: 46 Keywords: 0.0 #infoleak",
  "id" : 421447398699696128,
  "created_at" : "2014-01-10 01:04:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Jg7CdNaPs5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YcF7ktUy",
      "display_url" : "pastebin.com\/raw.php?i=YcF7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421446091716849665",
  "text" : "http:\/\/t.co\/Jg7CdNaPs5 Emails: 163 Keywords: -0.03 #infoleak",
  "id" : 421446091716849665,
  "created_at" : "2014-01-10 00:59:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z6AWKQR0xe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5NfVYXjc",
      "display_url" : "pastebin.com\/raw.php?i=5NfV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421440172157186048",
  "text" : "http:\/\/t.co\/Z6AWKQR0xe Found possible Google API key(s) #infoleak",
  "id" : 421440172157186048,
  "created_at" : "2014-01-10 00:35:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y9q6YioJiA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hMMgYN9a",
      "display_url" : "pastebin.com\/raw.php?i=hMMg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421431060958691328",
  "text" : "http:\/\/t.co\/y9q6YioJiA Emails: 8 Hashes: 78 E\/H: 0.1 Keywords: 0.08 #infoleak",
  "id" : 421431060958691328,
  "created_at" : "2014-01-09 23:59:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aAx6RNUB2k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QnEdjngc",
      "display_url" : "pastebin.com\/raw.php?i=QnEd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421430595223183360",
  "text" : "http:\/\/t.co\/aAx6RNUB2k Emails: 126 Keywords: 0.44 #infoleak",
  "id" : 421430595223183360,
  "created_at" : "2014-01-09 23:57:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NarC64rrDN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2KNrqs2n",
      "display_url" : "pastebin.com\/raw.php?i=2KNr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421414560264749059",
  "text" : "http:\/\/t.co\/NarC64rrDN Possible cisco configuration #infoleak",
  "id" : 421414560264749059,
  "created_at" : "2014-01-09 22:53:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ID8uMz9aNE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dRcW1ER3",
      "display_url" : "pastebin.com\/raw.php?i=dRcW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421400726070247424",
  "text" : "http:\/\/t.co\/ID8uMz9aNE Found possible Google API key(s) #infoleak",
  "id" : 421400726070247424,
  "created_at" : "2014-01-09 21:58:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ua0IHY929m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FEGhyrPa",
      "display_url" : "pastebin.com\/raw.php?i=FEGh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421392305338068992",
  "text" : "http:\/\/t.co\/Ua0IHY929m Emails: 1 Hashes: 204 E\/H: 0.0 Keywords: 0.33 #infoleak",
  "id" : 421392305338068992,
  "created_at" : "2014-01-09 21:25:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8yfATkz4Sc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xwNXQjcC",
      "display_url" : "pastebin.com\/raw.php?i=xwNX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421391989142073344",
  "text" : "http:\/\/t.co\/8yfATkz4Sc Emails: 698 Keywords: 0.11 #infoleak",
  "id" : 421391989142073344,
  "created_at" : "2014-01-09 21:24:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TTpTn1pc0Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s6Qn5UHf",
      "display_url" : "pastebin.com\/raw.php?i=s6Qn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421390329074307072",
  "text" : "http:\/\/t.co\/TTpTn1pc0Y Emails: 698 Keywords: 0.11 #infoleak",
  "id" : 421390329074307072,
  "created_at" : "2014-01-09 21:17:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9Xud2pLVyI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PLgKVL1k",
      "display_url" : "pastebin.com\/raw.php?i=PLgK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421389191520342017",
  "text" : "http:\/\/t.co\/9Xud2pLVyI Emails: 2191 Keywords: -0.03 #infoleak",
  "id" : 421389191520342017,
  "created_at" : "2014-01-09 21:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rGQgev7YIN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MSiHsbuD",
      "display_url" : "pastebin.com\/raw.php?i=MSiH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421382041418993664",
  "text" : "http:\/\/t.co\/rGQgev7YIN Emails: 4349 Hashes: 6 E\/H: 724.83 Keywords: 0.44 #infoleak",
  "id" : 421382041418993664,
  "created_at" : "2014-01-09 20:44:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/me7oWX6mWP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GyQ2knVY",
      "display_url" : "pastebin.com\/raw.php?i=GyQ2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421381861550481408",
  "text" : "http:\/\/t.co\/me7oWX6mWP Hashes: 30 Keywords: 0.08 #infoleak",
  "id" : 421381861550481408,
  "created_at" : "2014-01-09 20:43:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N71BjofQ4b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fYqtV4mU",
      "display_url" : "pastebin.com\/raw.php?i=fYqt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421367550308384768",
  "text" : "http:\/\/t.co\/N71BjofQ4b Emails: 142 Keywords: 0.33 #infoleak",
  "id" : 421367550308384768,
  "created_at" : "2014-01-09 19:47:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6G06nNmt79",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wKQqH7N2",
      "display_url" : "pastebin.com\/raw.php?i=wKQq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421360931776389120",
  "text" : "http:\/\/t.co\/6G06nNmt79 Hashes: 192 Keywords: 0.05 #infoleak",
  "id" : 421360931776389120,
  "created_at" : "2014-01-09 19:20:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OVKlC9SWO8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XCuYyjex",
      "display_url" : "pastebin.com\/raw.php?i=XCuY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421359497563488256",
  "text" : "http:\/\/t.co\/OVKlC9SWO8 Emails: 651 Keywords: 0.0 #infoleak",
  "id" : 421359497563488256,
  "created_at" : "2014-01-09 19:15:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0jlcjasSte",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=atcfPcZW",
      "display_url" : "pastebin.com\/raw.php?i=atcf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421351789246418944",
  "text" : "http:\/\/t.co\/0jlcjasSte Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 421351789246418944,
  "created_at" : "2014-01-09 18:44:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JhngDF59L7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s8WuBRQc",
      "display_url" : "pastebin.com\/raw.php?i=s8Wu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421338934241533952",
  "text" : "http:\/\/t.co\/JhngDF59L7 Emails: 654 Keywords: 0.22 #infoleak",
  "id" : 421338934241533952,
  "created_at" : "2014-01-09 17:53:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3a8URXw695",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9g6qY0vT",
      "display_url" : "pastebin.com\/raw.php?i=9g6q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421325775590014976",
  "text" : "http:\/\/t.co\/3a8URXw695 Emails: 47 Keywords: 0.0 #infoleak",
  "id" : 421325775590014976,
  "created_at" : "2014-01-09 17:01:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EoOpWFZvjc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tzESvUXb",
      "display_url" : "pastebin.com\/raw.php?i=tzES\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421314726266556416",
  "text" : "http:\/\/t.co\/EoOpWFZvjc Emails: 74 Keywords: 0.22 #infoleak",
  "id" : 421314726266556416,
  "created_at" : "2014-01-09 16:17:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/trIDnJYHGT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HM2H5JCP",
      "display_url" : "pastebin.com\/raw.php?i=HM2H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421313523738619904",
  "text" : "http:\/\/t.co\/trIDnJYHGT Keywords: 0.55 #infoleak",
  "id" : 421313523738619904,
  "created_at" : "2014-01-09 16:12:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8PnSRBVefY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p2pMDdbq",
      "display_url" : "pastebin.com\/raw.php?i=p2pM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421313152689520642",
  "text" : "http:\/\/t.co\/8PnSRBVefY Emails: 219 Keywords: 0.19 #infoleak",
  "id" : 421313152689520642,
  "created_at" : "2014-01-09 16:10:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DP1cZGjkA8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q54iy693",
      "display_url" : "pastebin.com\/raw.php?i=q54i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421312703789944832",
  "text" : "http:\/\/t.co\/DP1cZGjkA8 Emails: 31 Hashes: 30 E\/H: 1.03 Keywords: 0.0 #infoleak",
  "id" : 421312703789944832,
  "created_at" : "2014-01-09 16:09:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WKOsPcnp62",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SZa4f4dk",
      "display_url" : "pastebin.com\/raw.php?i=SZa4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421305271915253760",
  "text" : "http:\/\/t.co\/WKOsPcnp62 Emails: 61 Hashes: 76 E\/H: 0.8 Keywords: 0.11 #infoleak",
  "id" : 421305271915253760,
  "created_at" : "2014-01-09 15:39:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VZlGA12gWE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EdfLTxuE",
      "display_url" : "pastebin.com\/raw.php?i=EdfL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421297128627920896",
  "text" : "http:\/\/t.co\/VZlGA12gWE Emails: 1831 Keywords: 0.11 #infoleak",
  "id" : 421297128627920896,
  "created_at" : "2014-01-09 15:07:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d9VJRpaOFf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9aCvgsGx",
      "display_url" : "pastebin.com\/raw.php?i=9aCv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421295603310546944",
  "text" : "http:\/\/t.co\/d9VJRpaOFf Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 421295603310546944,
  "created_at" : "2014-01-09 15:01:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vw0FuNBdTq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VS7U7nFT",
      "display_url" : "pastebin.com\/raw.php?i=VS7U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421294171886862337",
  "text" : "http:\/\/t.co\/vw0FuNBdTq Hashes: 98 Keywords: 0.3 #infoleak",
  "id" : 421294171886862337,
  "created_at" : "2014-01-09 14:55:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v8WLezOkLa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5jmGcU4i",
      "display_url" : "pastebin.com\/raw.php?i=5jmG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421276987232370688",
  "text" : "http:\/\/t.co\/v8WLezOkLa Found possible Google API key(s) #infoleak",
  "id" : 421276987232370688,
  "created_at" : "2014-01-09 13:47:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ipz6GQfJap",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zP6MDnW4",
      "display_url" : "pastebin.com\/raw.php?i=zP6M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421010519957700608",
  "text" : "http:\/\/t.co\/ipz6GQfJap Keywords: 0.55 #infoleak",
  "id" : 421010519957700608,
  "created_at" : "2014-01-08 20:08:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ckj1mRjR98",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=feDUtPpd",
      "display_url" : "pastebin.com\/raw.php?i=feDU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421009121534836736",
  "text" : "http:\/\/t.co\/Ckj1mRjR98 Keywords: 0.55 #infoleak",
  "id" : 421009121534836736,
  "created_at" : "2014-01-08 20:02:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jeKlrIpFzk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5RQuGQ26",
      "display_url" : "pastebin.com\/raw.php?i=5RQu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421003541248245760",
  "text" : "http:\/\/t.co\/jeKlrIpFzk Emails: 90 Keywords: 0.0 #infoleak",
  "id" : 421003541248245760,
  "created_at" : "2014-01-08 19:40:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FM7LIpdZSz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qmg61a3V",
      "display_url" : "pastebin.com\/raw.php?i=Qmg6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420844419298766848",
  "text" : "http:\/\/t.co\/FM7LIpdZSz Emails: 20 Keywords: 0.11 #infoleak",
  "id" : 420844419298766848,
  "created_at" : "2014-01-08 09:08:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Cr0qAgINsh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WvmCEY77",
      "display_url" : "pastebin.com\/raw.php?i=WvmC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420837379528589313",
  "text" : "http:\/\/t.co\/Cr0qAgINsh Hashes: 158 Keywords: 0.11 #infoleak",
  "id" : 420837379528589313,
  "created_at" : "2014-01-08 08:40:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WUyZVBO442",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a0GLB68G",
      "display_url" : "pastebin.com\/raw.php?i=a0GL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420829701544747009",
  "text" : "http:\/\/t.co\/WUyZVBO442 Found possible Google API key(s) #infoleak",
  "id" : 420829701544747009,
  "created_at" : "2014-01-08 08:09:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MzRPIcSxeF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=umNhu3de",
      "display_url" : "pastebin.com\/raw.php?i=umNh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420821880304435200",
  "text" : "http:\/\/t.co\/MzRPIcSxeF Found possible Google API key(s) #infoleak",
  "id" : 420821880304435200,
  "created_at" : "2014-01-08 07:38:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CyOYrB1sRv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bJmE43i5",
      "display_url" : "pastebin.com\/raw.php?i=bJmE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420778440287997952",
  "text" : "http:\/\/t.co\/CyOYrB1sRv Emails: 4407 Hashes: 1 E\/H: 4407.0 Keywords: 0.22 #infoleak",
  "id" : 420778440287997952,
  "created_at" : "2014-01-08 04:46:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D5IHLD2g38",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=geiZTNBe",
      "display_url" : "pastebin.com\/raw.php?i=geiZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420736111145545728",
  "text" : "http:\/\/t.co\/D5IHLD2g38 Emails: 2039 Keywords: -0.03 #infoleak",
  "id" : 420736111145545728,
  "created_at" : "2014-01-08 01:58:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BOCKNhsYaU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y1UqDZPX",
      "display_url" : "pastebin.com\/raw.php?i=y1Uq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420732488390963201",
  "text" : "http:\/\/t.co\/BOCKNhsYaU Emails: 396 Keywords: 0.22 #infoleak",
  "id" : 420732488390963201,
  "created_at" : "2014-01-08 01:43:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a2aStEHS0k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0u4AMgUS",
      "display_url" : "pastebin.com\/raw.php?i=0u4A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420716891175264256",
  "text" : "http:\/\/t.co\/a2aStEHS0k Emails: 126 Keywords: 0.22 #infoleak",
  "id" : 420716891175264256,
  "created_at" : "2014-01-08 00:41:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZQDAPlFHhl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y7yxQsFy",
      "display_url" : "pastebin.com\/raw.php?i=y7yx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420715407134048256",
  "text" : "http:\/\/t.co\/ZQDAPlFHhl Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 420715407134048256,
  "created_at" : "2014-01-08 00:35:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OATIeXfDiw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xgC1Ek8m",
      "display_url" : "pastebin.com\/raw.php?i=xgC1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420710344345260032",
  "text" : "http:\/\/t.co\/OATIeXfDiw Emails: 776 Hashes: 775 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 420710344345260032,
  "created_at" : "2014-01-08 00:15:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/15tFI6tWRB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aUzHsmR0",
      "display_url" : "pastebin.com\/raw.php?i=aUzH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420701047145766912",
  "text" : "http:\/\/t.co\/15tFI6tWRB Hashes: 264 Keywords: 0.11 #infoleak",
  "id" : 420701047145766912,
  "created_at" : "2014-01-07 23:38:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B0D5j9k5Un",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AwuBVUJb",
      "display_url" : "pastebin.com\/raw.php?i=AwuB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420694381767557120",
  "text" : "http:\/\/t.co\/B0D5j9k5Un Found possible Google API key(s) #infoleak",
  "id" : 420694381767557120,
  "created_at" : "2014-01-07 23:12:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GH6d2miAxi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5gDSQXtG",
      "display_url" : "pastebin.com\/raw.php?i=5gDS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420686992238579712",
  "text" : "http:\/\/t.co\/GH6d2miAxi Emails: 91 Keywords: 0.33 #infoleak",
  "id" : 420686992238579712,
  "created_at" : "2014-01-07 22:42:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EJj8NGjfIc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tLZvGna5",
      "display_url" : "pastebin.com\/raw.php?i=tLZv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420684826560057344",
  "text" : "http:\/\/t.co\/EJj8NGjfIc Emails: 173 Keywords: 0.0 #infoleak",
  "id" : 420684826560057344,
  "created_at" : "2014-01-07 22:34:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ofeVazF4Tc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AGnNnuFw",
      "display_url" : "pastebin.com\/raw.php?i=AGnN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420684756095733760",
  "text" : "http:\/\/t.co\/ofeVazF4Tc Emails: 91 Keywords: 0.33 #infoleak",
  "id" : 420684756095733760,
  "created_at" : "2014-01-07 22:33:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oqaQkyN13x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Zn2Nb9a",
      "display_url" : "pastebin.com\/raw.php?i=7Zn2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420679348350242816",
  "text" : "http:\/\/t.co\/oqaQkyN13x Keywords: 0.55 #infoleak",
  "id" : 420679348350242816,
  "created_at" : "2014-01-07 22:12:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WBgQoEAGRq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g9SYmmMm",
      "display_url" : "pastebin.com\/raw.php?i=g9SY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420671565110333440",
  "text" : "http:\/\/t.co\/WBgQoEAGRq Hashes: 157 Keywords: -0.03 #infoleak",
  "id" : 420671565110333440,
  "created_at" : "2014-01-07 21:41:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7qXttObM4q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FDHH9LND",
      "display_url" : "pastebin.com\/raw.php?i=FDHH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420670318609301504",
  "text" : "http:\/\/t.co\/7qXttObM4q Emails: 81 Keywords: 0.08 #infoleak",
  "id" : 420670318609301504,
  "created_at" : "2014-01-07 21:36:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XjEE0ZAh8s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uH33fhM5",
      "display_url" : "pastebin.com\/raw.php?i=uH33\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420663411018440704",
  "text" : "http:\/\/t.co\/XjEE0ZAh8s Hashes: 100 Keywords: 0.11 #infoleak",
  "id" : 420663411018440704,
  "created_at" : "2014-01-07 21:09:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ueeotCbaCC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5068Vzvb",
      "display_url" : "pastebin.com\/raw.php?i=5068\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420658015432228864",
  "text" : "http:\/\/t.co\/ueeotCbaCC Keywords: 0.55 #infoleak",
  "id" : 420658015432228864,
  "created_at" : "2014-01-07 20:47:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aP0REv0Oca",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y61M3NCL",
      "display_url" : "pastebin.com\/raw.php?i=y61M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420654833796775936",
  "text" : "http:\/\/t.co\/aP0REv0Oca Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 420654833796775936,
  "created_at" : "2014-01-07 20:35:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AujNwt02tr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Aw9PuMzt",
      "display_url" : "pastebin.com\/raw.php?i=Aw9P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420654427742035968",
  "text" : "http:\/\/t.co\/AujNwt02tr Emails: 260 Keywords: 0.11 #infoleak",
  "id" : 420654427742035968,
  "created_at" : "2014-01-07 20:33:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ggjy2p1mCe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wVXGZHYd",
      "display_url" : "pastebin.com\/raw.php?i=wVXG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420654300088389634",
  "text" : "http:\/\/t.co\/Ggjy2p1mCe Found possible Google API key(s) #infoleak",
  "id" : 420654300088389634,
  "created_at" : "2014-01-07 20:32:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OjhuJnS8Rl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gLE1pv53",
      "display_url" : "pastebin.com\/raw.php?i=gLE1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420653191353479168",
  "text" : "http:\/\/t.co\/OjhuJnS8Rl Emails: 2625 Keywords: 0.11 #infoleak",
  "id" : 420653191353479168,
  "created_at" : "2014-01-07 20:28:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/79A3OhdSmr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4ypQ0LgM",
      "display_url" : "pastebin.com\/raw.php?i=4ypQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420651463182794752",
  "text" : "http:\/\/t.co\/79A3OhdSmr Hashes: 48 Keywords: -0.17 #infoleak",
  "id" : 420651463182794752,
  "created_at" : "2014-01-07 20:21:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x5HkFOA69o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tqtBBFz0",
      "display_url" : "pastebin.com\/raw.php?i=tqtB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420631457187381249",
  "text" : "http:\/\/t.co\/x5HkFOA69o Emails: 1 Hashes: 165 E\/H: 0.01 Keywords: 0.22 #infoleak",
  "id" : 420631457187381249,
  "created_at" : "2014-01-07 19:02:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jtSjcicLVP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FXZ2n0fq",
      "display_url" : "pastebin.com\/raw.php?i=FXZ2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420630111059058689",
  "text" : "http:\/\/t.co\/jtSjcicLVP Hashes: 543 Keywords: 0.16 #infoleak",
  "id" : 420630111059058689,
  "created_at" : "2014-01-07 18:56:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NHl29qyXff",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yD0NsAiy",
      "display_url" : "pastebin.com\/raw.php?i=yD0N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420620889252560896",
  "text" : "http:\/\/t.co\/NHl29qyXff Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 420620889252560896,
  "created_at" : "2014-01-07 18:20:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iPNXgk37Or",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cLFCSj0J",
      "display_url" : "pastebin.com\/raw.php?i=cLFC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420604673536450560",
  "text" : "http:\/\/t.co\/iPNXgk37Or Emails: 522 Hashes: 1050 E\/H: 0.5 Keywords: 0.22 #infoleak",
  "id" : 420604673536450560,
  "created_at" : "2014-01-07 17:15:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TBrf2VSXk6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2BKLkgYa",
      "display_url" : "pastebin.com\/raw.php?i=2BKL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420602867410423810",
  "text" : "http:\/\/t.co\/TBrf2VSXk6 Hashes: 302 Keywords: 0.33 #infoleak",
  "id" : 420602867410423810,
  "created_at" : "2014-01-07 17:08:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qXVmCOHnKt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tZPK1fRJ",
      "display_url" : "pastebin.com\/raw.php?i=tZPK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420602649138839553",
  "text" : "http:\/\/t.co\/qXVmCOHnKt Emails: 419 Keywords: 0.11 #infoleak",
  "id" : 420602649138839553,
  "created_at" : "2014-01-07 17:07:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iJ3KyJpEpX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YmcbQKgN",
      "display_url" : "pastebin.com\/raw.php?i=Ymcb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420602045284876289",
  "text" : "http:\/\/t.co\/iJ3KyJpEpX Emails: 186 Keywords: 0.22 #infoleak",
  "id" : 420602045284876289,
  "created_at" : "2014-01-07 17:05:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pRDrNjChVG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WeH6dEQD",
      "display_url" : "pastebin.com\/raw.php?i=WeH6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420599159272378368",
  "text" : "http:\/\/t.co\/pRDrNjChVG Emails: 77 Keywords: -0.14 #infoleak",
  "id" : 420599159272378368,
  "created_at" : "2014-01-07 16:53:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rwY9Q9QFzt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8unbZv7v",
      "display_url" : "pastebin.com\/raw.php?i=8unb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420597864142614528",
  "text" : "http:\/\/t.co\/rwY9Q9QFzt Emails: 823 Hashes: 823 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 420597864142614528,
  "created_at" : "2014-01-07 16:48:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N4x2MkRG5u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sbWZjD49",
      "display_url" : "pastebin.com\/raw.php?i=sbWZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420595261849608192",
  "text" : "http:\/\/t.co\/N4x2MkRG5u Emails: 102 Keywords: 0.11 #infoleak",
  "id" : 420595261849608192,
  "created_at" : "2014-01-07 16:38:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/prjrND90at",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cCkSHmfm",
      "display_url" : "pastebin.com\/raw.php?i=cCkS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420594546246832129",
  "text" : "http:\/\/t.co\/prjrND90at Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 420594546246832129,
  "created_at" : "2014-01-07 16:35:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mZuZzB6Tl0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mJakPDhX",
      "display_url" : "pastebin.com\/raw.php?i=mJak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420592518212747265",
  "text" : "http:\/\/t.co\/mZuZzB6Tl0 Emails: 37 Keywords: -0.14 #infoleak",
  "id" : 420592518212747265,
  "created_at" : "2014-01-07 16:27:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4ub42AjSgr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bi0hb6Pz",
      "display_url" : "pastebin.com\/raw.php?i=Bi0h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420574727787122688",
  "text" : "http:\/\/t.co\/4ub42AjSgr Hashes: 52 Keywords: 0.0 #infoleak",
  "id" : 420574727787122688,
  "created_at" : "2014-01-07 15:16:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0ewSNYxxjm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sdpdp5CZ",
      "display_url" : "pastebin.com\/raw.php?i=sdpd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420570248756985856",
  "text" : "http:\/\/t.co\/0ewSNYxxjm Emails: 233 Keywords: 0.22 #infoleak",
  "id" : 420570248756985856,
  "created_at" : "2014-01-07 14:58:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uYB3rVMbhB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NxkSe7Fd",
      "display_url" : "pastebin.com\/raw.php?i=NxkS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420543444281327616",
  "text" : "http:\/\/t.co\/uYB3rVMbhB Found possible Google API key(s) #infoleak",
  "id" : 420543444281327616,
  "created_at" : "2014-01-07 13:12:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yxqfrs4aPm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JqS64kQB",
      "display_url" : "pastebin.com\/raw.php?i=JqS6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420530351019401216",
  "text" : "http:\/\/t.co\/yxqfrs4aPm Emails: 174 Keywords: 0.0 #infoleak",
  "id" : 420530351019401216,
  "created_at" : "2014-01-07 12:20:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/flq2kviA01",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cpRwkGZX",
      "display_url" : "pastebin.com\/raw.php?i=cpRw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420528458360320001",
  "text" : "http:\/\/t.co\/flq2kviA01 Emails: 3 Keywords: 0.66 #infoleak",
  "id" : 420528458360320001,
  "created_at" : "2014-01-07 12:12:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ky1hXTNIvy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w0UHSx1F",
      "display_url" : "pastebin.com\/raw.php?i=w0UH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420517374870044673",
  "text" : "http:\/\/t.co\/ky1hXTNIvy Emails: 350 Keywords: 0.77 #infoleak",
  "id" : 420517374870044673,
  "created_at" : "2014-01-07 11:28:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H1Cxfb98k0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DbVBe2rR",
      "display_url" : "pastebin.com\/raw.php?i=DbVB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420507430259154944",
  "text" : "http:\/\/t.co\/H1Cxfb98k0 Emails: 1015 Keywords: 0.22 #infoleak",
  "id" : 420507430259154944,
  "created_at" : "2014-01-07 10:49:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ip3neF9kBf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=spJ7mZKH",
      "display_url" : "pastebin.com\/raw.php?i=spJ7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420507371589206016",
  "text" : "http:\/\/t.co\/ip3neF9kBf Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 420507371589206016,
  "created_at" : "2014-01-07 10:49:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2BH1EyERze",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZJC442bT",
      "display_url" : "pastebin.com\/raw.php?i=ZJC4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420214863936233473",
  "text" : "http:\/\/t.co\/2BH1EyERze Emails: 59 Keywords: 0.22 #infoleak",
  "id" : 420214863936233473,
  "created_at" : "2014-01-06 15:26:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QdRwqdg2iB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pfm8mCdr",
      "display_url" : "pastebin.com\/raw.php?i=pfm8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420211476628897792",
  "text" : "http:\/\/t.co\/QdRwqdg2iB Keywords: 0.66 #infoleak",
  "id" : 420211476628897792,
  "created_at" : "2014-01-06 15:13:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lQNnqgMKk5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v13KmXbr",
      "display_url" : "pastebin.com\/raw.php?i=v13K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420205651902492673",
  "text" : "http:\/\/t.co\/lQNnqgMKk5 Emails: 31 Keywords: 0.08 #infoleak",
  "id" : 420205651902492673,
  "created_at" : "2014-01-06 14:50:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p0j5I6swt9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Yf7daPe6",
      "display_url" : "pastebin.com\/raw.php?i=Yf7d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420204009832448000",
  "text" : "http:\/\/t.co\/p0j5I6swt9 Emails: 308 Keywords: 0.22 #infoleak",
  "id" : 420204009832448000,
  "created_at" : "2014-01-06 14:43:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1gAhOKcvCi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k8KFeT4L",
      "display_url" : "pastebin.com\/raw.php?i=k8KF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420196094811725824",
  "text" : "http:\/\/t.co\/1gAhOKcvCi Keywords: 0.66 #infoleak",
  "id" : 420196094811725824,
  "created_at" : "2014-01-06 14:12:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MsneOcO6lS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UsHVC0qi",
      "display_url" : "pastebin.com\/raw.php?i=UsHV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420159954608070657",
  "text" : "http:\/\/t.co\/MsneOcO6lS Emails: 94 Keywords: 0.22 #infoleak",
  "id" : 420159954608070657,
  "created_at" : "2014-01-06 11:48:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i2unMeLcPl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ssuMkpVV",
      "display_url" : "pastebin.com\/raw.php?i=ssuM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420159193882972160",
  "text" : "http:\/\/t.co\/i2unMeLcPl Emails: 22 Keywords: -0.03 #infoleak",
  "id" : 420159193882972160,
  "created_at" : "2014-01-06 11:45:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Iz3SONV0Wt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J7MA7yBY",
      "display_url" : "pastebin.com\/raw.php?i=J7MA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420150903719481344",
  "text" : "http:\/\/t.co\/Iz3SONV0Wt Emails: 42 Keywords: 0.0 #infoleak",
  "id" : 420150903719481344,
  "created_at" : "2014-01-06 11:12:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rqzaaR4rLm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WbQsH9AE",
      "display_url" : "pastebin.com\/raw.php?i=WbQs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420113051975548928",
  "text" : "http:\/\/t.co\/rqzaaR4rLm Emails: 27 Keywords: 0.08 #infoleak",
  "id" : 420113051975548928,
  "created_at" : "2014-01-06 08:42:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VvkQNroUaf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qaGX1qUA",
      "display_url" : "pastebin.com\/raw.php?i=qaGX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420112972581588993",
  "text" : "http:\/\/t.co\/VvkQNroUaf Emails: 27 Keywords: 0.08 #infoleak",
  "id" : 420112972581588993,
  "created_at" : "2014-01-06 08:41:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sdMzfIhCdQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4RdWbww7",
      "display_url" : "pastebin.com\/raw.php?i=4RdW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420109563421941760",
  "text" : "http:\/\/t.co\/sdMzfIhCdQ Emails: 334 Keywords: 0.22 #infoleak",
  "id" : 420109563421941760,
  "created_at" : "2014-01-06 08:28:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pPfKvI6UAt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RQKeUeA0",
      "display_url" : "pastebin.com\/raw.php?i=RQKe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420105592108093440",
  "text" : "http:\/\/t.co\/pPfKvI6UAt Emails: 1 Hashes: 75 E\/H: 0.01 Keywords: 0.19 #infoleak",
  "id" : 420105592108093440,
  "created_at" : "2014-01-06 08:12:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BrZC0oD5ZK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nPCCiXas",
      "display_url" : "pastebin.com\/raw.php?i=nPCC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420100417175826432",
  "text" : "http:\/\/t.co\/BrZC0oD5ZK Emails: 91 Keywords: 0.11 #infoleak",
  "id" : 420100417175826432,
  "created_at" : "2014-01-06 07:51:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/imRRxMOr9w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cAdkTK4U",
      "display_url" : "pastebin.com\/raw.php?i=cAdk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420099949326372865",
  "text" : "http:\/\/t.co\/imRRxMOr9w Emails: 2218 Keywords: 0.44 #infoleak",
  "id" : 420099949326372865,
  "created_at" : "2014-01-06 07:50:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HW91RKEgMo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mzux19Zk",
      "display_url" : "pastebin.com\/raw.php?i=Mzux\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420098687608430593",
  "text" : "http:\/\/t.co\/HW91RKEgMo Emails: 392 Hashes: 395 E\/H: 0.99 Keywords: 0.0 #infoleak",
  "id" : 420098687608430593,
  "created_at" : "2014-01-06 07:45:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uzenPJ8k0D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K79zT3Z0",
      "display_url" : "pastebin.com\/raw.php?i=K79z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420090501476270080",
  "text" : "http:\/\/t.co\/uzenPJ8k0D Emails: 361 Keywords: 0.0 #infoleak",
  "id" : 420090501476270080,
  "created_at" : "2014-01-06 07:12:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T2Wr2n78tD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SSrstAWv",
      "display_url" : "pastebin.com\/raw.php?i=SSrs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420087191352516608",
  "text" : "http:\/\/t.co\/T2Wr2n78tD Emails: 82 Hashes: 7 E\/H: 11.71 Keywords: 0.11 #infoleak",
  "id" : 420087191352516608,
  "created_at" : "2014-01-06 06:59:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wNpRRqASjQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sUN0NQmE",
      "display_url" : "pastebin.com\/raw.php?i=sUN0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420087128379252736",
  "text" : "http:\/\/t.co\/wNpRRqASjQ Emails: 10134 Keywords: 0.08 #infoleak",
  "id" : 420087128379252736,
  "created_at" : "2014-01-06 06:59:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LYviMebfh3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W6YpLDwh",
      "display_url" : "pastebin.com\/raw.php?i=W6Yp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420085363894267904",
  "text" : "http:\/\/t.co\/LYviMebfh3 Emails: 82 Keywords: 0.11 #infoleak",
  "id" : 420085363894267904,
  "created_at" : "2014-01-06 06:52:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JIlZeNoLH7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vGbZaSSg",
      "display_url" : "pastebin.com\/raw.php?i=vGbZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420071548175650819",
  "text" : "http:\/\/t.co\/JIlZeNoLH7 Emails: 82 Hashes: 4 E\/H: 20.5 Keywords: 0.22 #infoleak",
  "id" : 420071548175650819,
  "created_at" : "2014-01-06 05:57:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dASYs6OHst",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GHWA4vJN",
      "display_url" : "pastebin.com\/raw.php?i=GHWA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420071275604619264",
  "text" : "http:\/\/t.co\/dASYs6OHst Found possible Google API key(s) #infoleak",
  "id" : 420071275604619264,
  "created_at" : "2014-01-06 05:56:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mukyyAY8d1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8D9JJqM2",
      "display_url" : "pastebin.com\/raw.php?i=8D9J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420051935266217984",
  "text" : "http:\/\/t.co\/mukyyAY8d1 Emails: 642 Keywords: 0.0 #infoleak",
  "id" : 420051935266217984,
  "created_at" : "2014-01-06 04:39:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5bvAfNoENY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H6bgjFFz",
      "display_url" : "pastebin.com\/raw.php?i=H6bg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420025135198785537",
  "text" : "http:\/\/t.co\/5bvAfNoENY Emails: 163 Keywords: 0.11 #infoleak",
  "id" : 420025135198785537,
  "created_at" : "2014-01-06 02:52:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d8qAr2JgGw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eBdE45Hs",
      "display_url" : "pastebin.com\/raw.php?i=eBdE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420016585781178368",
  "text" : "http:\/\/t.co\/d8qAr2JgGw Found possible Google API key(s) #infoleak",
  "id" : 420016585781178368,
  "created_at" : "2014-01-06 02:18:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y5ewvPftEY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v5sqJPQN",
      "display_url" : "pastebin.com\/raw.php?i=v5sq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420008546814554112",
  "text" : "http:\/\/t.co\/Y5ewvPftEY Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 420008546814554112,
  "created_at" : "2014-01-06 01:46:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L1QOr59qc9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Frf1DpgS",
      "display_url" : "pastebin.com\/raw.php?i=Frf1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420003654020517888",
  "text" : "http:\/\/t.co\/L1QOr59qc9 Hashes: 32 Keywords: 0.41 #infoleak",
  "id" : 420003654020517888,
  "created_at" : "2014-01-06 01:27:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tr8cmJAcPw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=29mbU25t",
      "display_url" : "pastebin.com\/raw.php?i=29mb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419990920184856576",
  "text" : "http:\/\/t.co\/tr8cmJAcPw Emails: 1939 Keywords: -0.03 #infoleak",
  "id" : 419990920184856576,
  "created_at" : "2014-01-06 00:36:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oOvinh0N7p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mjRdyYnZ",
      "display_url" : "pastebin.com\/raw.php?i=mjRd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419990416939704320",
  "text" : "http:\/\/t.co\/oOvinh0N7p Found possible Google API key(s) #infoleak",
  "id" : 419990416939704320,
  "created_at" : "2014-01-06 00:34:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Izj3YEOeqR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bGLNhNDs",
      "display_url" : "pastebin.com\/raw.php?i=bGLN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419989997710610432",
  "text" : "http:\/\/t.co\/Izj3YEOeqR Possible cisco configuration #infoleak",
  "id" : 419989997710610432,
  "created_at" : "2014-01-06 00:33:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BgjSJurCYZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JATFiqXF",
      "display_url" : "pastebin.com\/raw.php?i=JATF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419980463516561408",
  "text" : "http:\/\/t.co\/BgjSJurCYZ Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 419980463516561408,
  "created_at" : "2014-01-05 23:55:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IAPlJAky1u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zzqT8rZA",
      "display_url" : "pastebin.com\/raw.php?i=zzqT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419978694740815872",
  "text" : "http:\/\/t.co\/IAPlJAky1u Emails: 623 Keywords: 0.08 #infoleak",
  "id" : 419978694740815872,
  "created_at" : "2014-01-05 23:48:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YhAka7nwLA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nfh0YaAh",
      "display_url" : "pastebin.com\/raw.php?i=nfh0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419977307525087232",
  "text" : "http:\/\/t.co\/YhAka7nwLA Emails: 10028 Keywords: 0.08 #infoleak",
  "id" : 419977307525087232,
  "created_at" : "2014-01-05 23:42:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0m5mDfC038",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HWLjcVjh",
      "display_url" : "pastebin.com\/raw.php?i=HWLj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419974993703759872",
  "text" : "http:\/\/t.co\/0m5mDfC038 Hashes: 32 Keywords: 0.41 #infoleak",
  "id" : 419974993703759872,
  "created_at" : "2014-01-05 23:33:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AYy2A7pO9A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EGzeEy69",
      "display_url" : "pastebin.com\/raw.php?i=EGze\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419962384950644736",
  "text" : "http:\/\/t.co\/AYy2A7pO9A Emails: 33 Keywords: 0.11 #infoleak",
  "id" : 419962384950644736,
  "created_at" : "2014-01-05 22:43:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d8PbuVJeQm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ifbHnuNc",
      "display_url" : "pastebin.com\/raw.php?i=ifbH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419946348977217536",
  "text" : "http:\/\/t.co\/d8PbuVJeQm Hashes: 1739 Keywords: 0.11 #infoleak",
  "id" : 419946348977217536,
  "created_at" : "2014-01-05 21:39:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FmNPiUdDEb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RdFAs2yJ",
      "display_url" : "pastebin.com\/raw.php?i=RdFA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419942667733065728",
  "text" : "http:\/\/t.co\/FmNPiUdDEb Emails: 35 Keywords: 0.22 #infoleak",
  "id" : 419942667733065728,
  "created_at" : "2014-01-05 21:25:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AyaEDmESIf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WnP3S6EU",
      "display_url" : "pastebin.com\/raw.php?i=WnP3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419936724014223360",
  "text" : "http:\/\/t.co\/AyaEDmESIf Emails: 58 Keywords: 0.11 #infoleak",
  "id" : 419936724014223360,
  "created_at" : "2014-01-05 21:01:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EyltnCmqB2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tP5shtb8",
      "display_url" : "pastebin.com\/raw.php?i=tP5s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419935735114776576",
  "text" : "http:\/\/t.co\/EyltnCmqB2 Emails: 246 Keywords: 0.0 #infoleak",
  "id" : 419935735114776576,
  "created_at" : "2014-01-05 20:57:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vPQOEoU28y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TLiupXwV",
      "display_url" : "pastebin.com\/raw.php?i=TLiu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419828237565325312",
  "text" : "http:\/\/t.co\/vPQOEoU28y Found possible Google API key(s) #infoleak",
  "id" : 419828237565325312,
  "created_at" : "2014-01-05 13:50:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2ZygK76Zpk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rhFuZ1HE",
      "display_url" : "pastebin.com\/raw.php?i=rhFu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419811993747341313",
  "text" : "http:\/\/t.co\/2ZygK76Zpk Emails: 644 Keywords: 0.11 #infoleak",
  "id" : 419811993747341313,
  "created_at" : "2014-01-05 12:45:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u6cOMrrVtu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0YRp7WzJ",
      "display_url" : "pastebin.com\/raw.php?i=0YRp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419786454126956545",
  "text" : "http:\/\/t.co\/u6cOMrrVtu Emails: 91 Keywords: 0.11 #infoleak",
  "id" : 419786454126956545,
  "created_at" : "2014-01-05 11:04:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H3jSJvYMpm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e1VAcG51",
      "display_url" : "pastebin.com\/raw.php?i=e1VA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419772226187952128",
  "text" : "http:\/\/t.co\/H3jSJvYMpm Hashes: 1234 Keywords: 0.11 #infoleak",
  "id" : 419772226187952128,
  "created_at" : "2014-01-05 10:07:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oumU90BQhE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8RZQpbfa",
      "display_url" : "pastebin.com\/raw.php?i=8RZQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419769675463933952",
  "text" : "http:\/\/t.co\/oumU90BQhE Found possible Google API key(s) #infoleak",
  "id" : 419769675463933952,
  "created_at" : "2014-01-05 09:57:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OF5gnPnMf1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aF2X9aZ7",
      "display_url" : "pastebin.com\/raw.php?i=aF2X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419758202075348993",
  "text" : "http:\/\/t.co\/OF5gnPnMf1 Emails: 692 Hashes: 3 E\/H: 230.67 Keywords: 0.0 #infoleak",
  "id" : 419758202075348993,
  "created_at" : "2014-01-05 09:12:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dmKBl0T9By",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=asNrC31n",
      "display_url" : "pastebin.com\/raw.php?i=asNr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419756970493497344",
  "text" : "http:\/\/t.co\/dmKBl0T9By Found possible Google API key(s) #infoleak",
  "id" : 419756970493497344,
  "created_at" : "2014-01-05 09:07:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b7BCHN70lW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xjFt84Dr",
      "display_url" : "pastebin.com\/raw.php?i=xjFt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419740368611966976",
  "text" : "http:\/\/t.co\/b7BCHN70lW Hashes: 1369 Keywords: 0.22 #infoleak",
  "id" : 419740368611966976,
  "created_at" : "2014-01-05 08:01:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qdnKmfZyvc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xXX3vzFt",
      "display_url" : "pastebin.com\/raw.php?i=xXX3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419725665030529024",
  "text" : "http:\/\/t.co\/qdnKmfZyvc Hashes: 1921 Keywords: 0.19 #infoleak",
  "id" : 419725665030529024,
  "created_at" : "2014-01-05 07:02:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tD8cZZvNbA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PCCDNS34",
      "display_url" : "pastebin.com\/raw.php?i=PCCD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419723568998408192",
  "text" : "http:\/\/t.co\/tD8cZZvNbA Emails: 1997 Hashes: 1 E\/H: 1997.0 Keywords: 0.52 #infoleak",
  "id" : 419723568998408192,
  "created_at" : "2014-01-05 06:54:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pDyYud02Pd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ew11menh",
      "display_url" : "pastebin.com\/raw.php?i=Ew11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419722084705529857",
  "text" : "http:\/\/t.co\/pDyYud02Pd Found possible Google API key(s) #infoleak",
  "id" : 419722084705529857,
  "created_at" : "2014-01-05 06:48:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GiFqA3szZo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LRUzbUjX",
      "display_url" : "pastebin.com\/raw.php?i=LRUz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419669485067313153",
  "text" : "http:\/\/t.co\/GiFqA3szZo Found possible Google API key(s) #infoleak",
  "id" : 419669485067313153,
  "created_at" : "2014-01-05 03:19:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iu40WBo8vY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CWCsdcwR",
      "display_url" : "pastebin.com\/raw.php?i=CWCs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419666366329671680",
  "text" : "http:\/\/t.co\/iu40WBo8vY Emails: 2 Keywords: 0.66 #infoleak",
  "id" : 419666366329671680,
  "created_at" : "2014-01-05 03:07:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6sPqIeyz2l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eB7hHDjS",
      "display_url" : "pastebin.com\/raw.php?i=eB7h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419663639369379840",
  "text" : "http:\/\/t.co\/6sPqIeyz2l Hashes: 127 Keywords: 0.44 #infoleak",
  "id" : 419663639369379840,
  "created_at" : "2014-01-05 02:56:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JVxMVQkcC1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xP7VndMW",
      "display_url" : "pastebin.com\/raw.php?i=xP7V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419662037887631360",
  "text" : "http:\/\/t.co\/JVxMVQkcC1 Found possible Google API key(s) #infoleak",
  "id" : 419662037887631360,
  "created_at" : "2014-01-05 02:50:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PCqXxgpOvz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q7DrX93j",
      "display_url" : "pastebin.com\/raw.php?i=q7Dr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419655168666263552",
  "text" : "http:\/\/t.co\/PCqXxgpOvz Found possible Google API key(s) #infoleak",
  "id" : 419655168666263552,
  "created_at" : "2014-01-05 02:22:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KBjaU10yCx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1Tq7xWfp",
      "display_url" : "pastebin.com\/raw.php?i=1Tq7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419653413450686464",
  "text" : "http:\/\/t.co\/KBjaU10yCx Emails: 29 Keywords: 0.3 #infoleak",
  "id" : 419653413450686464,
  "created_at" : "2014-01-05 02:15:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hVmAav5z4R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ngd9yx74",
      "display_url" : "pastebin.com\/raw.php?i=ngd9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419643350254247936",
  "text" : "http:\/\/t.co\/hVmAav5z4R Emails: 103 Keywords: 0.0 #infoleak",
  "id" : 419643350254247936,
  "created_at" : "2014-01-05 01:35:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o5TzVYBcnm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nGh5za3Z",
      "display_url" : "pastebin.com\/raw.php?i=nGh5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419625990847868928",
  "text" : "http:\/\/t.co\/o5TzVYBcnm Hashes: 54 Keywords: 0.0 #infoleak",
  "id" : 419625990847868928,
  "created_at" : "2014-01-05 00:26:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WWYOnX06y3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p7PSL06H",
      "display_url" : "pastebin.com\/raw.php?i=p7PS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419602356716576768",
  "text" : "http:\/\/t.co\/WWYOnX06y3 Found possible Google API key(s) #infoleak",
  "id" : 419602356716576768,
  "created_at" : "2014-01-04 22:52:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1j5StYSWKE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7dMzukBu",
      "display_url" : "pastebin.com\/raw.php?i=7dMz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419598343375814656",
  "text" : "http:\/\/t.co\/1j5StYSWKE Keywords: 0.63 #infoleak",
  "id" : 419598343375814656,
  "created_at" : "2014-01-04 22:36:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/geU7qaDrvV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C24mWrZQ",
      "display_url" : "pastebin.com\/raw.php?i=C24m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419587997072252928",
  "text" : "http:\/\/t.co\/geU7qaDrvV Keywords: 0.66 #infoleak",
  "id" : 419587997072252928,
  "created_at" : "2014-01-04 21:55:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Lxc3jLKZdI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wZyZuJat",
      "display_url" : "pastebin.com\/raw.php?i=wZyZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419585490510045184",
  "text" : "http:\/\/t.co\/Lxc3jLKZdI Found possible Google API key(s) #infoleak",
  "id" : 419585490510045184,
  "created_at" : "2014-01-04 21:45:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UY3C48mcAA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sdHVyaMF",
      "display_url" : "pastebin.com\/raw.php?i=sdHV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419576681582432256",
  "text" : "http:\/\/t.co\/UY3C48mcAA Emails: 827 Keywords: 0.33 #infoleak",
  "id" : 419576681582432256,
  "created_at" : "2014-01-04 21:10:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VElUX88jwK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m6q9MC8h",
      "display_url" : "pastebin.com\/raw.php?i=m6q9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419502695901196289",
  "text" : "http:\/\/t.co\/VElUX88jwK Emails: 339 Hashes: 348 E\/H: 0.97 Keywords: 0.19 #infoleak",
  "id" : 419502695901196289,
  "created_at" : "2014-01-04 16:16:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tezlpJHz81",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZdP3zUT4",
      "display_url" : "pastebin.com\/raw.php?i=ZdP3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419497368153649152",
  "text" : "http:\/\/t.co\/tezlpJHz81 Found possible Google API key(s) #infoleak",
  "id" : 419497368153649152,
  "created_at" : "2014-01-04 15:55:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6AGeVnemHl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LQtJYMLW",
      "display_url" : "pastebin.com\/raw.php?i=LQtJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419491553170563074",
  "text" : "http:\/\/t.co\/6AGeVnemHl Emails: 4 Hashes: 42 E\/H: 0.1 Keywords: 0.33 #infoleak",
  "id" : 419491553170563074,
  "created_at" : "2014-01-04 15:32:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f2Xgh08NX0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z00bBBJW",
      "display_url" : "pastebin.com\/raw.php?i=z00b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419478406472818689",
  "text" : "http:\/\/t.co\/f2Xgh08NX0 Emails: 326 Keywords: 0.08 #infoleak",
  "id" : 419478406472818689,
  "created_at" : "2014-01-04 14:40:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZGvGNwRoDt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3Frn7w0a",
      "display_url" : "pastebin.com\/raw.php?i=3Frn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419458029751242752",
  "text" : "http:\/\/t.co\/ZGvGNwRoDt Emails: 5553 Keywords: -0.03 #infoleak",
  "id" : 419458029751242752,
  "created_at" : "2014-01-04 13:19:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uoOL3r4ZWR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gAGebbNE",
      "display_url" : "pastebin.com\/raw.php?i=gAGe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419453776181735424",
  "text" : "http:\/\/t.co\/uoOL3r4ZWR Possible cisco configuration #infoleak",
  "id" : 419453776181735424,
  "created_at" : "2014-01-04 13:02:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1hJzHZ99l3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m0Ks3hhN",
      "display_url" : "pastebin.com\/raw.php?i=m0Ks\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419406422627991552",
  "text" : "http:\/\/t.co\/1hJzHZ99l3 Hashes: 89 Keywords: -0.03 #infoleak",
  "id" : 419406422627991552,
  "created_at" : "2014-01-04 09:54:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n2hXa6ENGq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TLHqY79r",
      "display_url" : "pastebin.com\/raw.php?i=TLHq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419394060156014592",
  "text" : "http:\/\/t.co\/n2hXa6ENGq Possible cisco configuration #infoleak",
  "id" : 419394060156014592,
  "created_at" : "2014-01-04 09:05:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UlfSBzGvzJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pqdz7E0Y",
      "display_url" : "pastebin.com\/raw.php?i=pqdz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419391790358089729",
  "text" : "http:\/\/t.co\/UlfSBzGvzJ Found possible Google API key(s) #infoleak",
  "id" : 419391790358089729,
  "created_at" : "2014-01-04 08:56:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZMpi9DQpop",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rhC9ycU0",
      "display_url" : "pastebin.com\/raw.php?i=rhC9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419379289969012736",
  "text" : "http:\/\/t.co\/ZMpi9DQpop Emails: 51 Keywords: 0.0 #infoleak",
  "id" : 419379289969012736,
  "created_at" : "2014-01-04 08:06:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qViLzEiQVQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kLd69r08",
      "display_url" : "pastebin.com\/raw.php?i=kLd6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419379217168474113",
  "text" : "http:\/\/t.co\/qViLzEiQVQ Emails: 2031 Keywords: 0.44 #infoleak",
  "id" : 419379217168474113,
  "created_at" : "2014-01-04 08:06:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zuOf1yeZiP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RyBCCJpg",
      "display_url" : "pastebin.com\/raw.php?i=RyBC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419370557528756224",
  "text" : "http:\/\/t.co\/zuOf1yeZiP Emails: 89 Keywords: -0.03 #infoleak",
  "id" : 419370557528756224,
  "created_at" : "2014-01-04 07:31:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/epTI0ZA3dj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dfCaPHWb",
      "display_url" : "pastebin.com\/raw.php?i=dfCa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419368953668841472",
  "text" : "http:\/\/t.co\/epTI0ZA3dj Hashes: 35 Keywords: 0.22 #infoleak",
  "id" : 419368953668841472,
  "created_at" : "2014-01-04 07:25:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H4lS3cxIpQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HeR6qrcV",
      "display_url" : "pastebin.com\/raw.php?i=HeR6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419368071979995136",
  "text" : "http:\/\/t.co\/H4lS3cxIpQ Hashes: 94 Keywords: 0.0 #infoleak",
  "id" : 419368071979995136,
  "created_at" : "2014-01-04 07:21:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Np57ma5W5V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TC5SUCLT",
      "display_url" : "pastebin.com\/raw.php?i=TC5S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419367917940006912",
  "text" : "http:\/\/t.co\/Np57ma5W5V Hashes: 196 Keywords: 0.22 #infoleak",
  "id" : 419367917940006912,
  "created_at" : "2014-01-04 07:21:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cm9rEWdrz6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gGctArPQ",
      "display_url" : "pastebin.com\/raw.php?i=gGct\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419365473449295872",
  "text" : "http:\/\/t.co\/cm9rEWdrz6 Emails: 91 Keywords: 0.22 #infoleak",
  "id" : 419365473449295872,
  "created_at" : "2014-01-04 07:11:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ER7EEh2HsL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C4ny5EBY",
      "display_url" : "pastebin.com\/raw.php?i=C4ny\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419352447589437441",
  "text" : "http:\/\/t.co\/ER7EEh2HsL Emails: 2599 Keywords: -0.03 #infoleak",
  "id" : 419352447589437441,
  "created_at" : "2014-01-04 06:19:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tpoa4YKZEm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9SWiqqh3",
      "display_url" : "pastebin.com\/raw.php?i=9SWi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419335874870906881",
  "text" : "http:\/\/t.co\/Tpoa4YKZEm Possible cisco configuration #infoleak",
  "id" : 419335874870906881,
  "created_at" : "2014-01-04 05:13:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QfPTvtSoRo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ByjPZ0i4",
      "display_url" : "pastebin.com\/raw.php?i=ByjP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419329136662827008",
  "text" : "http:\/\/t.co\/QfPTvtSoRo Possible cisco configuration #infoleak",
  "id" : 419329136662827008,
  "created_at" : "2014-01-04 04:47:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6aXwyrGwvm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=de6hgLjZ",
      "display_url" : "pastebin.com\/raw.php?i=de6h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419328836531023872",
  "text" : "http:\/\/t.co\/6aXwyrGwvm Emails: 41 Keywords: 0.11 #infoleak",
  "id" : 419328836531023872,
  "created_at" : "2014-01-04 04:46:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1i9NebTeXQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J0qEMkfe",
      "display_url" : "pastebin.com\/raw.php?i=J0qE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419304878146465792",
  "text" : "http:\/\/t.co\/1i9NebTeXQ Emails: 420 Keywords: -0.03 #infoleak",
  "id" : 419304878146465792,
  "created_at" : "2014-01-04 03:10:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0zlvuAAiIX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mL5ZVFhh",
      "display_url" : "pastebin.com\/raw.php?i=mL5Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419283395022041088",
  "text" : "http:\/\/t.co\/0zlvuAAiIX Emails: 70 Hashes: 70 E\/H: 1.0 Keywords: 0.0 #infoleak",
  "id" : 419283395022041088,
  "created_at" : "2014-01-04 01:45:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XTDC5y0482",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xYVMG13z",
      "display_url" : "pastebin.com\/raw.php?i=xYVM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419282600469856257",
  "text" : "http:\/\/t.co\/XTDC5y0482 Emails: 1684 Keywords: -0.03 #infoleak",
  "id" : 419282600469856257,
  "created_at" : "2014-01-04 01:42:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RZptUfbu3J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cxfxwNHn",
      "display_url" : "pastebin.com\/raw.php?i=cxfx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419273042779332610",
  "text" : "http:\/\/t.co\/RZptUfbu3J Emails: 26 Keywords: 0.11 #infoleak",
  "id" : 419273042779332610,
  "created_at" : "2014-01-04 01:04:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0X4Trf5QwM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u3ZLfQWZ",
      "display_url" : "pastebin.com\/raw.php?i=u3ZL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419272444218601472",
  "text" : "http:\/\/t.co\/0X4Trf5QwM Emails: 299 Hashes: 599 E\/H: 0.5 Keywords: -0.03 #infoleak",
  "id" : 419272444218601472,
  "created_at" : "2014-01-04 01:01:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l88zklA2As",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a64cZEmx",
      "display_url" : "pastebin.com\/raw.php?i=a64c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419246819986534400",
  "text" : "http:\/\/t.co\/l88zklA2As Emails: 294 Keywords: -0.03 #infoleak",
  "id" : 419246819986534400,
  "created_at" : "2014-01-03 23:20:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wc9ExmQPws",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tM8vBypW",
      "display_url" : "pastebin.com\/raw.php?i=tM8v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419238508318834688",
  "text" : "http:\/\/t.co\/wc9ExmQPws Hashes: 717 Keywords: 0.0 #infoleak",
  "id" : 419238508318834688,
  "created_at" : "2014-01-03 22:47:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PtyDdpQ6Jg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XrSCQDNY",
      "display_url" : "pastebin.com\/raw.php?i=XrSC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419234922063097857",
  "text" : "http:\/\/t.co\/PtyDdpQ6Jg Found possible Google API key(s) #infoleak",
  "id" : 419234922063097857,
  "created_at" : "2014-01-03 22:32:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DxPGkqWcrE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HUTD069t",
      "display_url" : "pastebin.com\/raw.php?i=HUTD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419233960581791745",
  "text" : "http:\/\/t.co\/DxPGkqWcrE Emails: 33 Keywords: 0.0 #infoleak",
  "id" : 419233960581791745,
  "created_at" : "2014-01-03 22:28:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B7TCPmKWAF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jkFDcRXF",
      "display_url" : "pastebin.com\/raw.php?i=jkFD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419210414820311040",
  "text" : "http:\/\/t.co\/B7TCPmKWAF Found possible Google API key(s) #infoleak",
  "id" : 419210414820311040,
  "created_at" : "2014-01-03 20:55:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gq7JR0oxyR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n6UYKPQ2",
      "display_url" : "pastebin.com\/raw.php?i=n6UY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419209765072281600",
  "text" : "http:\/\/t.co\/Gq7JR0oxyR Hashes: 115 Keywords: 0.0 #infoleak",
  "id" : 419209765072281600,
  "created_at" : "2014-01-03 20:52:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ck3AnAFz5Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GrdCYjVJ",
      "display_url" : "pastebin.com\/raw.php?i=GrdC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419196512489332736",
  "text" : "http:\/\/t.co\/Ck3AnAFz5Y Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 419196512489332736,
  "created_at" : "2014-01-03 20:00:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rTzuv3F5sP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zyrnmp8d",
      "display_url" : "pastebin.com\/raw.php?i=zyrn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419189069617192960",
  "text" : "http:\/\/t.co\/rTzuv3F5sP Keywords: 0.55 #infoleak",
  "id" : 419189069617192960,
  "created_at" : "2014-01-03 19:30:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8GG8fqOhhY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kQVzMt7g",
      "display_url" : "pastebin.com\/raw.php?i=kQVz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419185853357752320",
  "text" : "http:\/\/t.co\/8GG8fqOhhY Emails: 94 Hashes: 1 E\/H: 94.0 Keywords: 0.08 #infoleak",
  "id" : 419185853357752320,
  "created_at" : "2014-01-03 19:17:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VG8o65lv9Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qZf7izYZ",
      "display_url" : "pastebin.com\/raw.php?i=qZf7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419178139059621889",
  "text" : "http:\/\/t.co\/VG8o65lv9Y Emails: 5407 Keywords: 0.08 #infoleak",
  "id" : 419178139059621889,
  "created_at" : "2014-01-03 18:47:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/czJFsQBxuo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xpEujZRS",
      "display_url" : "pastebin.com\/raw.php?i=xpEu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419173495067525120",
  "text" : "http:\/\/t.co\/czJFsQBxuo Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 419173495067525120,
  "created_at" : "2014-01-03 18:28:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5dS2BoI3EE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V1STJz5q",
      "display_url" : "pastebin.com\/raw.php?i=V1ST\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419160002218049536",
  "text" : "http:\/\/t.co\/5dS2BoI3EE Keywords: 0.55 #infoleak",
  "id" : 419160002218049536,
  "created_at" : "2014-01-03 17:35:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uAp69oEOkM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g4gR8U1V",
      "display_url" : "pastebin.com\/raw.php?i=g4gR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419154920994922496",
  "text" : "http:\/\/t.co\/uAp69oEOkM Hashes: 110 Keywords: 0.11 #infoleak",
  "id" : 419154920994922496,
  "created_at" : "2014-01-03 17:14:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/djO807A8nI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n6GmgtxN",
      "display_url" : "pastebin.com\/raw.php?i=n6Gm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419149582547705856",
  "text" : "http:\/\/t.co\/djO807A8nI Found possible Google API key(s) #infoleak",
  "id" : 419149582547705856,
  "created_at" : "2014-01-03 16:53:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JwikH4yl7z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uCPBLEWW",
      "display_url" : "pastebin.com\/raw.php?i=uCPB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419123843211337728",
  "text" : "http:\/\/t.co\/JwikH4yl7z Emails: 398 Keywords: 0.0 #infoleak",
  "id" : 419123843211337728,
  "created_at" : "2014-01-03 15:11:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oajqQT7Jq1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m3uzK1P6",
      "display_url" : "pastebin.com\/raw.php?i=m3uz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419121618367938560",
  "text" : "http:\/\/t.co\/oajqQT7Jq1 Emails: 21 Hashes: 21 E\/H: 1.0 Keywords: 0.0 #infoleak",
  "id" : 419121618367938560,
  "created_at" : "2014-01-03 15:02:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZLGn8ebxTx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NwWXSeHE",
      "display_url" : "pastebin.com\/raw.php?i=NwWX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419117007301140480",
  "text" : "http:\/\/t.co\/ZLGn8ebxTx Emails: 21 Hashes: 21 E\/H: 1.0 Keywords: 0.0 #infoleak",
  "id" : 419117007301140480,
  "created_at" : "2014-01-03 14:44:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K8iylyM9pE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3Kt6Gs4d",
      "display_url" : "pastebin.com\/raw.php?i=3Kt6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419113353693241344",
  "text" : "http:\/\/t.co\/K8iylyM9pE Hashes: 184 Keywords: 0.44 #infoleak",
  "id" : 419113353693241344,
  "created_at" : "2014-01-03 14:29:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mIQSJpBLza",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gNwmTgam",
      "display_url" : "pastebin.com\/raw.php?i=gNwm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419098893645664256",
  "text" : "http:\/\/t.co\/mIQSJpBLza Emails: 883 Keywords: 0.08 #infoleak",
  "id" : 419098893645664256,
  "created_at" : "2014-01-03 13:32:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IvOEjdrDtr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vGPjNfcb",
      "display_url" : "pastebin.com\/raw.php?i=vGPj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419098544440483840",
  "text" : "http:\/\/t.co\/IvOEjdrDtr Emails: 280 Keywords: 0.0 #infoleak",
  "id" : 419098544440483840,
  "created_at" : "2014-01-03 13:30:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GDDJ5HhUw1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w1ch2j2n",
      "display_url" : "pastebin.com\/raw.php?i=w1ch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419097941668679680",
  "text" : "http:\/\/t.co\/GDDJ5HhUw1 Emails: 363 Keywords: 0.22 #infoleak",
  "id" : 419097941668679680,
  "created_at" : "2014-01-03 13:28:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Uk8Bg84YHo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tPk455ZN",
      "display_url" : "pastebin.com\/raw.php?i=tPk4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419028734956429312",
  "text" : "http:\/\/t.co\/Uk8Bg84YHo Emails: 37 Keywords: 0.0 #infoleak",
  "id" : 419028734956429312,
  "created_at" : "2014-01-03 08:53:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a4nwydaXu1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VY3uU8Pn",
      "display_url" : "pastebin.com\/raw.php?i=VY3u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419008226793750528",
  "text" : "http:\/\/t.co\/a4nwydaXu1 Emails: 95 Keywords: 0.0 #infoleak",
  "id" : 419008226793750528,
  "created_at" : "2014-01-03 07:32:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wtKRXDSscO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hWkt03bg",
      "display_url" : "pastebin.com\/raw.php?i=hWkt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418994140488015872",
  "text" : "http:\/\/t.co\/wtKRXDSscO Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 418994140488015872,
  "created_at" : "2014-01-03 06:36:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3Ub9w5U3Rk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6j8ymZxA",
      "display_url" : "pastebin.com\/raw.php?i=6j8y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418991017610604544",
  "text" : "http:\/\/t.co\/3Ub9w5U3Rk Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 418991017610604544,
  "created_at" : "2014-01-03 06:23:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rUowWstys4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RUJ4Cumh",
      "display_url" : "pastebin.com\/raw.php?i=RUJ4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418985308349140992",
  "text" : "http:\/\/t.co\/rUowWstys4 Emails: 1 Hashes: 64 E\/H: 0.02 Keywords: 0.22 #infoleak",
  "id" : 418985308349140992,
  "created_at" : "2014-01-03 06:00:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dIrLvDooAS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bky5a2da",
      "display_url" : "pastebin.com\/raw.php?i=bky5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418957396237512705",
  "text" : "http:\/\/t.co\/dIrLvDooAS Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 418957396237512705,
  "created_at" : "2014-01-03 04:10:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DB1al7uZct",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pVBrt70x",
      "display_url" : "pastebin.com\/raw.php?i=pVBr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418947270919200768",
  "text" : "http:\/\/t.co\/DB1al7uZct Hashes: 89 Keywords: 0.22 #infoleak",
  "id" : 418947270919200768,
  "created_at" : "2014-01-03 03:29:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z0zXiFOL6v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MGPs8pQ2",
      "display_url" : "pastebin.com\/raw.php?i=MGPs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418946172502294528",
  "text" : "http:\/\/t.co\/Z0zXiFOL6v Emails: 367 Keywords: 0.22 #infoleak",
  "id" : 418946172502294528,
  "created_at" : "2014-01-03 03:25:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/II96hPhp9T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=78SRXtmv",
      "display_url" : "pastebin.com\/raw.php?i=78SR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418944562103455744",
  "text" : "http:\/\/t.co\/II96hPhp9T Emails: 1033 Keywords: 0.22 #infoleak",
  "id" : 418944562103455744,
  "created_at" : "2014-01-03 03:19:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/stUJpZUrsT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vRqcWbDy",
      "display_url" : "pastebin.com\/raw.php?i=vRqc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418785990057013248",
  "text" : "http:\/\/t.co\/stUJpZUrsT Hashes: 6 Keywords: 0.66 #infoleak",
  "id" : 418785990057013248,
  "created_at" : "2014-01-02 16:48:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dZChZzxgoy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g0r463kh",
      "display_url" : "pastebin.com\/raw.php?i=g0r4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418785926970486785",
  "text" : "http:\/\/t.co\/dZChZzxgoy Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 418785926970486785,
  "created_at" : "2014-01-02 16:48:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4BmDZ5VF5M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aE1K6gvr",
      "display_url" : "pastebin.com\/raw.php?i=aE1K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418785558723182592",
  "text" : "http:\/\/t.co\/4BmDZ5VF5M Emails: 21 Hashes: 1 E\/H: 21.0 Keywords: 0.33 #infoleak",
  "id" : 418785558723182592,
  "created_at" : "2014-01-02 16:47:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XEchywvCTL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6GNyzYQN",
      "display_url" : "pastebin.com\/raw.php?i=6GNy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418776889168117760",
  "text" : "http:\/\/t.co\/XEchywvCTL Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 418776889168117760,
  "created_at" : "2014-01-02 16:12:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W27Kgfse0V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qt3jJJkX",
      "display_url" : "pastebin.com\/raw.php?i=Qt3j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418773052973789184",
  "text" : "http:\/\/t.co\/W27Kgfse0V Emails: 164 Keywords: 0.08 #infoleak",
  "id" : 418773052973789184,
  "created_at" : "2014-01-02 15:57:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2TRNd9un2p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nh7ttVAb",
      "display_url" : "pastebin.com\/raw.php?i=nh7t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418771124600573953",
  "text" : "http:\/\/t.co\/2TRNd9un2p Emails: 1941 Hashes: 2312 E\/H: 0.84 Keywords: -0.03 #infoleak",
  "id" : 418771124600573953,
  "created_at" : "2014-01-02 15:49:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m7f1xZQIg4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nR81ewX5",
      "display_url" : "pastebin.com\/raw.php?i=nR81\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418758301178818562",
  "text" : "http:\/\/t.co\/m7f1xZQIg4 Emails: 1018 Keywords: -0.03 #infoleak",
  "id" : 418758301178818562,
  "created_at" : "2014-01-02 14:58:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5wDq1Ga3DN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=07Ug4TC1",
      "display_url" : "pastebin.com\/raw.php?i=07Ug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418757361793130496",
  "text" : "http:\/\/t.co\/5wDq1Ga3DN Emails: 327 Keywords: -0.14 #infoleak",
  "id" : 418757361793130496,
  "created_at" : "2014-01-02 14:55:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mft90stox8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w2TGm2FS",
      "display_url" : "pastebin.com\/raw.php?i=w2TG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418745507586916352",
  "text" : "http:\/\/t.co\/Mft90stox8 Emails: 55 Keywords: 0.0 #infoleak",
  "id" : 418745507586916352,
  "created_at" : "2014-01-02 14:08:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TiWBsTPm1t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KTg0eK5Y",
      "display_url" : "pastebin.com\/raw.php?i=KTg0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418734475908874240",
  "text" : "http:\/\/t.co\/TiWBsTPm1t Emails: 3215 Keywords: 0.11 #infoleak",
  "id" : 418734475908874240,
  "created_at" : "2014-01-02 13:24:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aBt9F32kOL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xJGJPk6P",
      "display_url" : "pastebin.com\/raw.php?i=xJGJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418733035568128002",
  "text" : "http:\/\/t.co\/aBt9F32kOL Hashes: 2636 Keywords: 0.19 #infoleak",
  "id" : 418733035568128002,
  "created_at" : "2014-01-02 13:18:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WlhPGG5rQG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fe2YKqnp",
      "display_url" : "pastebin.com\/raw.php?i=Fe2Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418731637187153920",
  "text" : "http:\/\/t.co\/WlhPGG5rQG Keywords: 0.66 #infoleak",
  "id" : 418731637187153920,
  "created_at" : "2014-01-02 13:12:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EuQcx2OtgN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BBP30yyk",
      "display_url" : "pastebin.com\/raw.php?i=BBP3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418718867532181504",
  "text" : "http:\/\/t.co\/EuQcx2OtgN Emails: 3433 Keywords: 0.19 #infoleak",
  "id" : 418718867532181504,
  "created_at" : "2014-01-02 12:22:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dVKABgyxhn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vkq6e5Qz",
      "display_url" : "pastebin.com\/raw.php?i=vkq6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418717205522444288",
  "text" : "http:\/\/t.co\/dVKABgyxhn Emails: 3273 Keywords: 0.19 #infoleak",
  "id" : 418717205522444288,
  "created_at" : "2014-01-02 12:15:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CQXrzQ9FTL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dCEqTVQC",
      "display_url" : "pastebin.com\/raw.php?i=dCEq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418713466925367296",
  "text" : "http:\/\/t.co\/CQXrzQ9FTL Emails: 3431 Keywords: 0.11 #infoleak",
  "id" : 418713466925367296,
  "created_at" : "2014-01-02 12:00:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X2pBxp1YEp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=61feEQia",
      "display_url" : "pastebin.com\/raw.php?i=61fe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418706238029828096",
  "text" : "http:\/\/t.co\/X2pBxp1YEp Emails: 492 Keywords: 0.0 #infoleak",
  "id" : 418706238029828096,
  "created_at" : "2014-01-02 11:32:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TjKKOHv9Il",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EwaEW0RQ",
      "display_url" : "pastebin.com\/raw.php?i=EwaE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418695931274358784",
  "text" : "http:\/\/t.co\/TjKKOHv9Il Emails: 294 Keywords: -0.03 #infoleak",
  "id" : 418695931274358784,
  "created_at" : "2014-01-02 10:51:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LGALShdHW4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DCEj3DRr",
      "display_url" : "pastebin.com\/raw.php?i=DCEj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418693695030845441",
  "text" : "http:\/\/t.co\/LGALShdHW4 Hashes: 89 Keywords: -0.14 #infoleak",
  "id" : 418693695030845441,
  "created_at" : "2014-01-02 10:42:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qH72uQCPE2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8ytHP1Vb",
      "display_url" : "pastebin.com\/raw.php?i=8ytH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418691151265148928",
  "text" : "http:\/\/t.co\/qH72uQCPE2 Found possible Google API key(s) #infoleak",
  "id" : 418691151265148928,
  "created_at" : "2014-01-02 10:32:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vECfAI4wR5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LiGPSLBy",
      "display_url" : "pastebin.com\/raw.php?i=LiGP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418635490946846720",
  "text" : "http:\/\/t.co\/vECfAI4wR5 Emails: 279 Keywords: 0.22 #infoleak",
  "id" : 418635490946846720,
  "created_at" : "2014-01-02 06:50:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vjfiMB2ot8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FFVtneAk",
      "display_url" : "pastebin.com\/raw.php?i=FFVt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418621787920822274",
  "text" : "http:\/\/t.co\/vjfiMB2ot8 Emails: 45 Keywords: 0.0 #infoleak",
  "id" : 418621787920822274,
  "created_at" : "2014-01-02 05:56:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rXsQIxJecr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vWdgwSNW",
      "display_url" : "pastebin.com\/raw.php?i=vWdg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418621484647452672",
  "text" : "http:\/\/t.co\/rXsQIxJecr Hashes: 49 Keywords: 0.19 #infoleak",
  "id" : 418621484647452672,
  "created_at" : "2014-01-02 05:55:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l1aGU2jTNG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5YVbeqtx",
      "display_url" : "pastebin.com\/raw.php?i=5YVb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418620186220965888",
  "text" : "http:\/\/t.co\/l1aGU2jTNG Emails: 472 Keywords: 0.0 #infoleak",
  "id" : 418620186220965888,
  "created_at" : "2014-01-02 05:50:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X0SoHVyiD9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7E8aR9Xz",
      "display_url" : "pastebin.com\/raw.php?i=7E8a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418620055639707648",
  "text" : "http:\/\/t.co\/X0SoHVyiD9 Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 418620055639707648,
  "created_at" : "2014-01-02 05:49:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GrKm0PeslC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kykcuucW",
      "display_url" : "pastebin.com\/raw.php?i=kykc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418616815573422080",
  "text" : "http:\/\/t.co\/GrKm0PeslC Emails: 137 Keywords: 0.0 #infoleak",
  "id" : 418616815573422080,
  "created_at" : "2014-01-02 05:36:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/um7sta34xm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ndzRLyFv",
      "display_url" : "pastebin.com\/raw.php?i=ndzR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418616250357383168",
  "text" : "http:\/\/t.co\/um7sta34xm Emails: 230 Hashes: 457 E\/H: 0.5 Keywords: 0.41 #infoleak",
  "id" : 418616250357383168,
  "created_at" : "2014-01-02 05:34:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I5H4ffGDBT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DevC04Lc",
      "display_url" : "pastebin.com\/raw.php?i=DevC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418615619022356480",
  "text" : "http:\/\/t.co\/I5H4ffGDBT Emails: 200 Keywords: 0.0 #infoleak",
  "id" : 418615619022356480,
  "created_at" : "2014-01-02 05:31:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FbWKQkaMGG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qJZfSpUr",
      "display_url" : "pastebin.com\/raw.php?i=qJZf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418613999119257600",
  "text" : "http:\/\/t.co\/FbWKQkaMGG Emails: 561 Keywords: 0.0 #infoleak",
  "id" : 418613999119257600,
  "created_at" : "2014-01-02 05:25:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tOrL5DknHu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jgtyPKWf",
      "display_url" : "pastebin.com\/raw.php?i=jgty\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418610172081090561",
  "text" : "http:\/\/t.co\/tOrL5DknHu Emails: 1 Hashes: 200 E\/H: 0.01 Keywords: 0.0 #infoleak",
  "id" : 418610172081090561,
  "created_at" : "2014-01-02 05:10:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3sLYxJZmfL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BuKaSbKi",
      "display_url" : "pastebin.com\/raw.php?i=BuKa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418609172356161536",
  "text" : "http:\/\/t.co\/3sLYxJZmfL Emails: 188 Keywords: 0.08 #infoleak",
  "id" : 418609172356161536,
  "created_at" : "2014-01-02 05:06:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jcCLXCqq3O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qiziwwsq",
      "display_url" : "pastebin.com\/raw.php?i=Qizi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418602363352408064",
  "text" : "http:\/\/t.co\/jcCLXCqq3O Emails: 252 Keywords: 0.11 #infoleak",
  "id" : 418602363352408064,
  "created_at" : "2014-01-02 04:39:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vwSKT2Ins5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j2DXpf5p",
      "display_url" : "pastebin.com\/raw.php?i=j2DX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418595574955249664",
  "text" : "http:\/\/t.co\/vwSKT2Ins5 Emails: 56 Keywords: 0.0 #infoleak",
  "id" : 418595574955249664,
  "created_at" : "2014-01-02 04:12:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/56OAZLlPeb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fFnFJFQJ",
      "display_url" : "pastebin.com\/raw.php?i=fFnF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418563564186509312",
  "text" : "http:\/\/t.co\/56OAZLlPeb Found possible Google API key(s) #infoleak",
  "id" : 418563564186509312,
  "created_at" : "2014-01-02 02:05:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kGynlfRMgz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8f7U9mF9",
      "display_url" : "pastebin.com\/raw.php?i=8f7U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418563215677599746",
  "text" : "http:\/\/t.co\/kGynlfRMgz Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 418563215677599746,
  "created_at" : "2014-01-02 02:03:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jbOyDOHt0G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fk68PXDL",
      "display_url" : "pastebin.com\/raw.php?i=fk68\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418562909480837120",
  "text" : "http:\/\/t.co\/jbOyDOHt0G Emails: 65 Keywords: 0.0 #infoleak",
  "id" : 418562909480837120,
  "created_at" : "2014-01-02 02:02:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XgQnHCw34i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UgBVf7JP",
      "display_url" : "pastebin.com\/raw.php?i=UgBV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418553247918350336",
  "text" : "http:\/\/t.co\/XgQnHCw34i Hashes: 56 Keywords: -0.28 #infoleak",
  "id" : 418553247918350336,
  "created_at" : "2014-01-02 01:24:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HmJyUzu6ce",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uKXJkVCL",
      "display_url" : "pastebin.com\/raw.php?i=uKXJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418551610822778880",
  "text" : "http:\/\/t.co\/HmJyUzu6ce Found possible Google API key(s) #infoleak",
  "id" : 418551610822778880,
  "created_at" : "2014-01-02 01:17:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ocxNqrG2aN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vMEU3en2",
      "display_url" : "pastebin.com\/raw.php?i=vMEU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418541785187483648",
  "text" : "http:\/\/t.co\/ocxNqrG2aN Emails: 4912 Hashes: 4923 E\/H: 1.0 Keywords: 0.08 #infoleak",
  "id" : 418541785187483648,
  "created_at" : "2014-01-02 00:38:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ny7juv2fiE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NGHEZKSw",
      "display_url" : "pastebin.com\/raw.php?i=NGHE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418541100144418817",
  "text" : "http:\/\/t.co\/Ny7juv2fiE Emails: 4981 Hashes: 4990 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 418541100144418817,
  "created_at" : "2014-01-02 00:35:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1JaaCPGAGD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4ZzrSgUD",
      "display_url" : "pastebin.com\/raw.php?i=4Zzr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418540621658193920",
  "text" : "http:\/\/t.co\/1JaaCPGAGD Emails: 1611 Keywords: -0.03 #infoleak",
  "id" : 418540621658193920,
  "created_at" : "2014-01-02 00:33:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YwqyJDmXuC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NkCMfqTd",
      "display_url" : "pastebin.com\/raw.php?i=NkCM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418539934106927105",
  "text" : "http:\/\/t.co\/YwqyJDmXuC Emails: 5236 Hashes: 5252 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 418539934106927105,
  "created_at" : "2014-01-02 00:31:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WBQ9GYeIVs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3xLkcmg7",
      "display_url" : "pastebin.com\/raw.php?i=3xLk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418539327153401856",
  "text" : "http:\/\/t.co\/WBQ9GYeIVs Emails: 4392 Hashes: 4404 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 418539327153401856,
  "created_at" : "2014-01-02 00:28:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SR9Id2aXSm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nH5rA0dS",
      "display_url" : "pastebin.com\/raw.php?i=nH5r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418528633750163456",
  "text" : "http:\/\/t.co\/SR9Id2aXSm Found possible Google API key(s) #infoleak",
  "id" : 418528633750163456,
  "created_at" : "2014-01-01 23:46:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5zt3RHbLkK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uRZ7P2Km",
      "display_url" : "pastebin.com\/raw.php?i=uRZ7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418518867783057408",
  "text" : "http:\/\/t.co\/5zt3RHbLkK Hashes: 63 Keywords: 0.55 #infoleak",
  "id" : 418518867783057408,
  "created_at" : "2014-01-01 23:07:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ojmODPejWn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2fd1fsNA",
      "display_url" : "pastebin.com\/raw.php?i=2fd1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418516015425650688",
  "text" : "http:\/\/t.co\/ojmODPejWn Emails: 69 Keywords: 0.0 #infoleak",
  "id" : 418516015425650688,
  "created_at" : "2014-01-01 22:56:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s0SVFictz9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XNT6CwRw",
      "display_url" : "pastebin.com\/raw.php?i=XNT6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418511690943045632",
  "text" : "http:\/\/t.co\/s0SVFictz9 Emails: 336 Keywords: 0.11 #infoleak",
  "id" : 418511690943045632,
  "created_at" : "2014-01-01 22:38:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/izpwLHoow6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v15NE5cU",
      "display_url" : "pastebin.com\/raw.php?i=v15N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418509972805136384",
  "text" : "http:\/\/t.co\/izpwLHoow6 Hashes: 236 Keywords: 0.44 #infoleak",
  "id" : 418509972805136384,
  "created_at" : "2014-01-01 22:32:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TdLWKEQUmt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x57zfWZb",
      "display_url" : "pastebin.com\/raw.php?i=x57z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418509651223642112",
  "text" : "http:\/\/t.co\/TdLWKEQUmt Emails: 42 Hashes: 41 E\/H: 1.02 Keywords: 0.66 #infoleak",
  "id" : 418509651223642112,
  "created_at" : "2014-01-01 22:30:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8OBKKSYlhl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WtPuE6XV",
      "display_url" : "pastebin.com\/raw.php?i=WtPu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418508180247695360",
  "text" : "http:\/\/t.co\/8OBKKSYlhl Emails: 654 Keywords: 0.11 #infoleak",
  "id" : 418508180247695360,
  "created_at" : "2014-01-01 22:25:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A3sdf7qU7s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CtH6YfGT",
      "display_url" : "pastebin.com\/raw.php?i=CtH6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418506876385378305",
  "text" : "http:\/\/t.co\/A3sdf7qU7s Emails: 1712 Keywords: 0.08 #infoleak",
  "id" : 418506876385378305,
  "created_at" : "2014-01-01 22:19:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KsSx7vTCJ0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rbCW8aHz",
      "display_url" : "pastebin.com\/raw.php?i=rbCW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418506100376215552",
  "text" : "http:\/\/t.co\/KsSx7vTCJ0 Emails: 1 Hashes: 39 E\/H: 0.03 Keywords: 0.08 #infoleak",
  "id" : 418506100376215552,
  "created_at" : "2014-01-01 22:16:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fnxHYlVkyM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nBJ9ufGW",
      "display_url" : "pastebin.com\/raw.php?i=nBJ9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418495476543913985",
  "text" : "http:\/\/t.co\/fnxHYlVkyM Hashes: 50 Keywords: 0.11 #infoleak",
  "id" : 418495476543913985,
  "created_at" : "2014-01-01 21:34:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M9sEeC792d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ESVnrDEP",
      "display_url" : "pastebin.com\/raw.php?i=ESVn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418495065128828928",
  "text" : "http:\/\/t.co\/M9sEeC792d Emails: 1567 Keywords: -0.03 #infoleak",
  "id" : 418495065128828928,
  "created_at" : "2014-01-01 21:32:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0gPfvNUUo9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SQEVeiw8",
      "display_url" : "pastebin.com\/raw.php?i=SQEV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418484650957234176",
  "text" : "http:\/\/t.co\/0gPfvNUUo9 Hashes: 50 Keywords: 0.11 #infoleak",
  "id" : 418484650957234176,
  "created_at" : "2014-01-01 20:51:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/31QZlTcXlp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MksNe1tX",
      "display_url" : "pastebin.com\/raw.php?i=MksN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418483885823909889",
  "text" : "http:\/\/t.co\/31QZlTcXlp Emails: 176 Keywords: 0.11 #infoleak",
  "id" : 418483885823909889,
  "created_at" : "2014-01-01 20:48:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FiCn3n3RTO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kgwdvjzy",
      "display_url" : "pastebin.com\/raw.php?i=kgwd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418480199395598336",
  "text" : "http:\/\/t.co\/FiCn3n3RTO Emails: 82 Keywords: 0.33 #infoleak",
  "id" : 418480199395598336,
  "created_at" : "2014-01-01 20:33:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gIFv9Xkycf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yj1q0RXG",
      "display_url" : "pastebin.com\/raw.php?i=yj1q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418475192965267457",
  "text" : "http:\/\/t.co\/gIFv9Xkycf Hashes: 109 Keywords: -0.06 #infoleak",
  "id" : 418475192965267457,
  "created_at" : "2014-01-01 20:13:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R9aAFQXW2J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q0rM1q52",
      "display_url" : "pastebin.com\/raw.php?i=q0rM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418474103486439424",
  "text" : "http:\/\/t.co\/R9aAFQXW2J Hashes: 168 Keywords: 0.22 #infoleak",
  "id" : 418474103486439424,
  "created_at" : "2014-01-01 20:09:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Oioo0P2FFV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fq66SPmE",
      "display_url" : "pastebin.com\/raw.php?i=Fq66\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418473315166994433",
  "text" : "http:\/\/t.co\/Oioo0P2FFV Found possible Google API key(s) #infoleak",
  "id" : 418473315166994433,
  "created_at" : "2014-01-01 20:06:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KE0omWfAr6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4gNVWNb9",
      "display_url" : "pastebin.com\/raw.php?i=4gNV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418460272349564929",
  "text" : "http:\/\/t.co\/KE0omWfAr6 Emails: 119 Keywords: 0.0 #infoleak",
  "id" : 418460272349564929,
  "created_at" : "2014-01-01 19:14:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vYv4JTAnS2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bEmQeKsi",
      "display_url" : "pastebin.com\/raw.php?i=bEmQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418452730701561856",
  "text" : "http:\/\/t.co\/vYv4JTAnS2 Found possible Google API key(s) #infoleak",
  "id" : 418452730701561856,
  "created_at" : "2014-01-01 18:44:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SCLtGk1U8D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wMuCEtpT",
      "display_url" : "pastebin.com\/raw.php?i=wMuC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418436677959299072",
  "text" : "http:\/\/t.co\/SCLtGk1U8D Emails: 38 Keywords: 0.08 #infoleak",
  "id" : 418436677959299072,
  "created_at" : "2014-01-01 17:40:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cinjvGbkvs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YvJENfUW",
      "display_url" : "pastebin.com\/raw.php?i=YvJE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418436443942309888",
  "text" : "http:\/\/t.co\/cinjvGbkvs Emails: 10002 Keywords: 0.11 #infoleak",
  "id" : 418436443942309888,
  "created_at" : "2014-01-01 17:39:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uZ9hChxCD6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6GR6qWy4",
      "display_url" : "pastebin.com\/raw.php?i=6GR6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418426414220582912",
  "text" : "http:\/\/t.co\/uZ9hChxCD6 Emails: 137 Keywords: 0.11 #infoleak",
  "id" : 418426414220582912,
  "created_at" : "2014-01-01 17:00:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RZ5RDksw7O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KGR1H4yH",
      "display_url" : "pastebin.com\/raw.php?i=KGR1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418400408352985088",
  "text" : "http:\/\/t.co\/RZ5RDksw7O Keywords: 0.66 #infoleak",
  "id" : 418400408352985088,
  "created_at" : "2014-01-01 15:16:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9MU9530EcK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eQ0Au08n",
      "display_url" : "pastebin.com\/raw.php?i=eQ0A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418397609363902464",
  "text" : "http:\/\/t.co\/9MU9530EcK Keywords: 0.66 #infoleak",
  "id" : 418397609363902464,
  "created_at" : "2014-01-01 15:05:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x0G5aR4T2h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tbhKDTnS",
      "display_url" : "pastebin.com\/raw.php?i=tbhK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418395367332270080",
  "text" : "http:\/\/t.co\/x0G5aR4T2h Found possible Google API key(s) #infoleak",
  "id" : 418395367332270080,
  "created_at" : "2014-01-01 14:56:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CutOmNumYp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pm6etrAi",
      "display_url" : "pastebin.com\/raw.php?i=pm6e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418394880772014080",
  "text" : "http:\/\/t.co\/CutOmNumYp Emails: 636 Keywords: 0.0 #infoleak",
  "id" : 418394880772014080,
  "created_at" : "2014-01-01 14:54:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u5g75h5isj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cgqzDpWv",
      "display_url" : "pastebin.com\/raw.php?i=cgqz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418391585080897536",
  "text" : "http:\/\/t.co\/u5g75h5isj Keywords: 0.66 #infoleak",
  "id" : 418391585080897536,
  "created_at" : "2014-01-01 14:41:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1ld9JIwI1u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hpaVEfR9",
      "display_url" : "pastebin.com\/raw.php?i=hpaV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418390128722079746",
  "text" : "http:\/\/t.co\/1ld9JIwI1u Found possible Google API key(s) #infoleak",
  "id" : 418390128722079746,
  "created_at" : "2014-01-01 14:35:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/56zKKQ65Ii",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QBXAEnN6",
      "display_url" : "pastebin.com\/raw.php?i=QBXA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418389524972961792",
  "text" : "http:\/\/t.co\/56zKKQ65Ii Emails: 24 Keywords: -0.14 #infoleak",
  "id" : 418389524972961792,
  "created_at" : "2014-01-01 14:33:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sxXA3AZpiC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mC0E4t0Z",
      "display_url" : "pastebin.com\/raw.php?i=mC0E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418389363496452096",
  "text" : "http:\/\/t.co\/sxXA3AZpiC Keywords: 0.77 #infoleak",
  "id" : 418389363496452096,
  "created_at" : "2014-01-01 14:32:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dPntLErPyd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P81mwmzQ",
      "display_url" : "pastebin.com\/raw.php?i=P81m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418387886879162368",
  "text" : "http:\/\/t.co\/dPntLErPyd Emails: 1 Hashes: 45 E\/H: 0.02 Keywords: 0.33 #infoleak",
  "id" : 418387886879162368,
  "created_at" : "2014-01-01 14:27:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fEOQdyzi89",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HR2FFDgt",
      "display_url" : "pastebin.com\/raw.php?i=HR2F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418385473153667073",
  "text" : "http:\/\/t.co\/fEOQdyzi89 Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 418385473153667073,
  "created_at" : "2014-01-01 14:17:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IYBNtl2Iy1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f7G8KLjm",
      "display_url" : "pastebin.com\/raw.php?i=f7G8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418385082890473472",
  "text" : "http:\/\/t.co\/IYBNtl2Iy1 Found possible Google API key(s) #infoleak",
  "id" : 418385082890473472,
  "created_at" : "2014-01-01 14:15:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8ek2ZcTkFL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2jueG41V",
      "display_url" : "pastebin.com\/raw.php?i=2jue\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418382071472472064",
  "text" : "http:\/\/t.co\/8ek2ZcTkFL Emails: 65 Keywords: 0.11 #infoleak",
  "id" : 418382071472472064,
  "created_at" : "2014-01-01 14:03:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kNdPcfFrPL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qAwWtfjA",
      "display_url" : "pastebin.com\/raw.php?i=qAwW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418332216125431808",
  "text" : "http:\/\/t.co\/kNdPcfFrPL Hashes: 35 Keywords: 0.11 #infoleak",
  "id" : 418332216125431808,
  "created_at" : "2014-01-01 10:45:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3QELdPPXdg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ujyugEpg",
      "display_url" : "pastebin.com\/raw.php?i=ujyu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418330378781216768",
  "text" : "http:\/\/t.co\/3QELdPPXdg Emails: 2 Hashes: 638 E\/H: 0.0 Keywords: 0.19 #infoleak",
  "id" : 418330378781216768,
  "created_at" : "2014-01-01 10:38:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UypM6rayN1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7ui2TM3a",
      "display_url" : "pastebin.com\/raw.php?i=7ui2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418321538887061504",
  "text" : "http:\/\/t.co\/UypM6rayN1 Found possible Google API key(s) #infoleak",
  "id" : 418321538887061504,
  "created_at" : "2014-01-01 10:03:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
} ]
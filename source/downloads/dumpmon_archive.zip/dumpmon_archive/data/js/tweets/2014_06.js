Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W9KV4Rqcch",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YcpuJdEb",
      "display_url" : "pastebin.com\/raw.php?i=Ycpu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483872338815885312",
  "text" : "http:\/\/t.co\/W9KV4Rqcch Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 483872338815885312,
  "created_at" : "2014-07-01 07:18:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZHRvPKQOMf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iKwP2rde",
      "display_url" : "pastebin.com\/raw.php?i=iKwP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483858778559746048",
  "text" : "http:\/\/t.co\/ZHRvPKQOMf Found possible Google API key(s) #infoleak",
  "id" : 483858778559746048,
  "created_at" : "2014-07-01 06:24:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PtqzJhOs12",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r4gd28Ap",
      "display_url" : "pastebin.com\/raw.php?i=r4gd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483856364335157248",
  "text" : "http:\/\/t.co\/PtqzJhOs12 Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 483856364335157248,
  "created_at" : "2014-07-01 06:15:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HKQeQV56g3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3NxDq5kw",
      "display_url" : "pastebin.com\/raw.php?i=3NxD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483854703814393856",
  "text" : "http:\/\/t.co\/HKQeQV56g3 Emails: 50 Keywords: 0.11 #infoleak",
  "id" : 483854703814393856,
  "created_at" : "2014-07-01 06:08:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v9URCRBU3p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g9L4kw8S",
      "display_url" : "pastebin.com\/raw.php?i=g9L4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483848344188358656",
  "text" : "http:\/\/t.co\/v9URCRBU3p Hashes: 49 Keywords: 0.22 #infoleak",
  "id" : 483848344188358656,
  "created_at" : "2014-07-01 05:43:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kZIETgpQl8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aE1LsLVQ",
      "display_url" : "pastebin.com\/raw.php?i=aE1L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483843194862325760",
  "text" : "http:\/\/t.co\/kZIETgpQl8 Hashes: 996 Keywords: 0.11 #infoleak",
  "id" : 483843194862325760,
  "created_at" : "2014-07-01 05:23:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H6b5xBX4bH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i7tmt8qt",
      "display_url" : "pastebin.com\/raw.php?i=i7tm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483831645472968704",
  "text" : "http:\/\/t.co\/H6b5xBX4bH Hashes: 78 Keywords: 0.33 #infoleak",
  "id" : 483831645472968704,
  "created_at" : "2014-07-01 04:37:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DOdcPTnDMw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xEgD8Kj0",
      "display_url" : "pastebin.com\/raw.php?i=xEgD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483816872211521536",
  "text" : "http:\/\/t.co\/DOdcPTnDMw Emails: 49 Keywords: 0.11 #infoleak",
  "id" : 483816872211521536,
  "created_at" : "2014-07-01 03:38:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jdyCv4kiFJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WM718XKr",
      "display_url" : "pastebin.com\/raw.php?i=WM71\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483816023687061505",
  "text" : "http:\/\/t.co\/jdyCv4kiFJ Hashes: 104 Keywords: 0.11 #infoleak",
  "id" : 483816023687061505,
  "created_at" : "2014-07-01 03:35:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FpX7Q2fF8U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LY0DKQuX",
      "display_url" : "pastebin.com\/raw.php?i=LY0D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483811167802908672",
  "text" : "http:\/\/t.co\/FpX7Q2fF8U Emails: 8 Hashes: 39 E\/H: 0.21 Keywords: 0.55 #infoleak",
  "id" : 483811167802908672,
  "created_at" : "2014-07-01 03:15:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HhKU7w5BCD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XNAiKx7J",
      "display_url" : "pastebin.com\/raw.php?i=XNAi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483811103244165120",
  "text" : "http:\/\/t.co\/HhKU7w5BCD Emails: 159 Keywords: 0.0 #infoleak",
  "id" : 483811103244165120,
  "created_at" : "2014-07-01 03:15:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mdMSQF0hxX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LwRBWz5X",
      "display_url" : "pastebin.com\/raw.php?i=LwRB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483810802684547072",
  "text" : "http:\/\/t.co\/mdMSQF0hxX Hashes: 136 Keywords: 0.33 #infoleak",
  "id" : 483810802684547072,
  "created_at" : "2014-07-01 03:14:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DJQTKY6GIh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CUSBcuNG",
      "display_url" : "pastebin.com\/raw.php?i=CUSB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483800584491773952",
  "text" : "http:\/\/t.co\/DJQTKY6GIh Hashes: 35 Keywords: -0.09 #infoleak",
  "id" : 483800584491773952,
  "created_at" : "2014-07-01 02:33:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/idO0dHJN1D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZS7aghBG",
      "display_url" : "pastebin.com\/raw.php?i=ZS7a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483795071607664640",
  "text" : "http:\/\/t.co\/idO0dHJN1D Emails: 97 Hashes: 229 E\/H: 0.42 Keywords: 0.33 #infoleak",
  "id" : 483795071607664640,
  "created_at" : "2014-07-01 02:11:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DxIPnarkL6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1j03Np5K",
      "display_url" : "pastebin.com\/raw.php?i=1j03\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483793998805360640",
  "text" : "http:\/\/t.co\/DxIPnarkL6 Emails: 491 Keywords: 0.0 #infoleak",
  "id" : 483793998805360640,
  "created_at" : "2014-07-01 02:07:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bi9qwM3Dvc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xDsx8PPG",
      "display_url" : "pastebin.com\/raw.php?i=xDsx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483786053233295362",
  "text" : "http:\/\/t.co\/Bi9qwM3Dvc Hashes: 89 Keywords: 0.22 #infoleak",
  "id" : 483786053233295362,
  "created_at" : "2014-07-01 01:35:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NKtZuTzUWb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iKVEngdu",
      "display_url" : "pastebin.com\/raw.php?i=iKVE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483785730448052225",
  "text" : "http:\/\/t.co\/NKtZuTzUWb Emails: 1016 Keywords: 0.0 #infoleak",
  "id" : 483785730448052225,
  "created_at" : "2014-07-01 01:34:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xp7CKKSkz8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2CRn61RG",
      "display_url" : "pastebin.com\/raw.php?i=2CRn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483781797021372416",
  "text" : "http:\/\/t.co\/Xp7CKKSkz8 Hashes: 78 Keywords: 0.33 #infoleak",
  "id" : 483781797021372416,
  "created_at" : "2014-07-01 01:19:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LibEa7Pcw6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h4MffMhK",
      "display_url" : "pastebin.com\/raw.php?i=h4Mf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483773608171286528",
  "text" : "http:\/\/t.co\/LibEa7Pcw6 Emails: 256 Keywords: 0.22 #infoleak",
  "id" : 483773608171286528,
  "created_at" : "2014-07-01 00:46:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZsekVrELQu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3GHsd0ev",
      "display_url" : "pastebin.com\/raw.php?i=3GHs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483770716035088385",
  "text" : "http:\/\/t.co\/ZsekVrELQu Hashes: 72 Keywords: -0.14 #infoleak",
  "id" : 483770716035088385,
  "created_at" : "2014-07-01 00:35:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0n5mgsXygA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xkuBav4A",
      "display_url" : "pastebin.com\/raw.php?i=xkuB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483769477645877248",
  "text" : "http:\/\/t.co\/0n5mgsXygA Emails: 24 Keywords: 0.44 #infoleak",
  "id" : 483769477645877248,
  "created_at" : "2014-07-01 00:30:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ndqmYt35pB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LX4GBAqB",
      "display_url" : "pastebin.com\/raw.php?i=LX4G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483765307668852737",
  "text" : "http:\/\/t.co\/ndqmYt35pB Emails: 87 Keywords: 0.0 #infoleak",
  "id" : 483765307668852737,
  "created_at" : "2014-07-01 00:13:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3j8Gd8hPjh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4Z2jcn9F",
      "display_url" : "pastebin.com\/raw.php?i=4Z2j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483760198457102336",
  "text" : "http:\/\/t.co\/3j8Gd8hPjh Emails: 31 Keywords: 0.22 #infoleak",
  "id" : 483760198457102336,
  "created_at" : "2014-06-30 23:53:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eCk1LgKsZI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JCczBbgm",
      "display_url" : "pastebin.com\/raw.php?i=JCcz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483758085819727872",
  "text" : "http:\/\/t.co\/eCk1LgKsZI Emails: 33 Keywords: 0.0 #infoleak",
  "id" : 483758085819727872,
  "created_at" : "2014-06-30 23:44:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xTwcBqvERF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tNfULq7K",
      "display_url" : "pastebin.com\/raw.php?i=tNfU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483750635242672128",
  "text" : "http:\/\/t.co\/xTwcBqvERF Hashes: 82 Keywords: 0.22 #infoleak",
  "id" : 483750635242672128,
  "created_at" : "2014-06-30 23:15:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JEuSfrp0xi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RTWuhz7x",
      "display_url" : "pastebin.com\/raw.php?i=RTWu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483749128397000704",
  "text" : "http:\/\/t.co\/JEuSfrp0xi Emails: 85 Keywords: 0.0 #infoleak",
  "id" : 483749128397000704,
  "created_at" : "2014-06-30 23:09:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QTlVJ1dDDJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rnMiWmsE",
      "display_url" : "pastebin.com\/raw.php?i=rnMi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483745868370022401",
  "text" : "http:\/\/t.co\/QTlVJ1dDDJ Possible cisco configuration #infoleak",
  "id" : 483745868370022401,
  "created_at" : "2014-06-30 22:56:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DtaAOW0WJo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=21ym4cLu",
      "display_url" : "pastebin.com\/raw.php?i=21ym\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483739751946539009",
  "text" : "http:\/\/t.co\/DtaAOW0WJo Possible cisco configuration #infoleak",
  "id" : 483739751946539009,
  "created_at" : "2014-06-30 22:31:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TFEiX1EPXH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D9TMQsFp",
      "display_url" : "pastebin.com\/raw.php?i=D9TM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483735620750024704",
  "text" : "http:\/\/t.co\/TFEiX1EPXH Hashes: 100 Keywords: 0.0 #infoleak",
  "id" : 483735620750024704,
  "created_at" : "2014-06-30 22:15:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AE9OOn9Ce1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jVfnYKnu",
      "display_url" : "pastebin.com\/raw.php?i=jVfn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483726975807127552",
  "text" : "http:\/\/t.co\/AE9OOn9Ce1 Hashes: 86 Keywords: -0.06 #infoleak",
  "id" : 483726975807127552,
  "created_at" : "2014-06-30 21:41:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Av0lbHWr2k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xp6d6uwU",
      "display_url" : "pastebin.com\/raw.php?i=Xp6d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483720035676856320",
  "text" : "http:\/\/t.co\/Av0lbHWr2k Emails: 187 Keywords: 0.0 #infoleak",
  "id" : 483720035676856320,
  "created_at" : "2014-06-30 21:13:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3qkNYDQ29O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e49bWJcs",
      "display_url" : "pastebin.com\/raw.php?i=e49b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483718770968367104",
  "text" : "http:\/\/t.co\/3qkNYDQ29O Emails: 39 Keywords: 0.19 #infoleak",
  "id" : 483718770968367104,
  "created_at" : "2014-06-30 21:08:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ya79pyVhY9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZZnJvDJL",
      "display_url" : "pastebin.com\/raw.php?i=ZZnJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483718160281899008",
  "text" : "http:\/\/t.co\/Ya79pyVhY9 Emails: 60 Keywords: 0.0 #infoleak",
  "id" : 483718160281899008,
  "created_at" : "2014-06-30 21:06:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KQjrkb26xG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tYQrgw6A",
      "display_url" : "pastebin.com\/raw.php?i=tYQr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483713046691315712",
  "text" : "http:\/\/t.co\/KQjrkb26xG Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 483713046691315712,
  "created_at" : "2014-06-30 20:45:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4d2DQgEUaD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p872h7m7",
      "display_url" : "pastebin.com\/raw.php?i=p872\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483709819908395009",
  "text" : "http:\/\/t.co\/4d2DQgEUaD Emails: 24 Keywords: 0.19 #infoleak",
  "id" : 483709819908395009,
  "created_at" : "2014-06-30 20:33:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0b0w40soRP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SmkGSxts",
      "display_url" : "pastebin.com\/raw.php?i=SmkG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483707649192513536",
  "text" : "http:\/\/t.co\/0b0w40soRP Hashes: 57 Keywords: 0.08 #infoleak",
  "id" : 483707649192513536,
  "created_at" : "2014-06-30 20:24:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f5x8aXakps",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5ikkiVzh",
      "display_url" : "pastebin.com\/raw.php?i=5ikk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483706731948568577",
  "text" : "http:\/\/t.co\/f5x8aXakps Emails: 99 Keywords: 0.22 #infoleak",
  "id" : 483706731948568577,
  "created_at" : "2014-06-30 20:20:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QRBriny4Cw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vuttAKaj",
      "display_url" : "pastebin.com\/raw.php?i=vutt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483704695588790272",
  "text" : "http:\/\/t.co\/QRBriny4Cw Keywords: 0.55 #infoleak",
  "id" : 483704695588790272,
  "created_at" : "2014-06-30 20:12:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VVIc0Z1rK3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xTzZm4sK",
      "display_url" : "pastebin.com\/raw.php?i=xTzZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483704020649779200",
  "text" : "http:\/\/t.co\/VVIc0Z1rK3 Keywords: 0.55 #infoleak",
  "id" : 483704020649779200,
  "created_at" : "2014-06-30 20:09:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xa1nvGIBTu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1jXcYnSD",
      "display_url" : "pastebin.com\/raw.php?i=1jXc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483702806663004161",
  "text" : "http:\/\/t.co\/xa1nvGIBTu Emails: 141 Keywords: 0.0 #infoleak",
  "id" : 483702806663004161,
  "created_at" : "2014-06-30 20:05:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/anMK4KWBda",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eg2HAir6",
      "display_url" : "pastebin.com\/raw.php?i=eg2H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483702119363395584",
  "text" : "http:\/\/t.co\/anMK4KWBda Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 483702119363395584,
  "created_at" : "2014-06-30 20:02:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SDxHeNqpsM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K8zqUYiV",
      "display_url" : "pastebin.com\/raw.php?i=K8zq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483701197333733376",
  "text" : "http:\/\/t.co\/SDxHeNqpsM Emails: 626 Keywords: 0.11 #infoleak",
  "id" : 483701197333733376,
  "created_at" : "2014-06-30 19:58:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x9FwgoyTDz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M191UDrS",
      "display_url" : "pastebin.com\/raw.php?i=M191\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483701148725948416",
  "text" : "http:\/\/t.co\/x9FwgoyTDz Possible cisco configuration #infoleak",
  "id" : 483701148725948416,
  "created_at" : "2014-06-30 19:58:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cOTP6OBlka",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VKPZYbsY",
      "display_url" : "pastebin.com\/raw.php?i=VKPZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483690095375949824",
  "text" : "http:\/\/t.co\/cOTP6OBlka Emails: 220 Keywords: 0.33 #infoleak",
  "id" : 483690095375949824,
  "created_at" : "2014-06-30 19:14:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iOs1B6TFvc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XUSvwr5E",
      "display_url" : "pastebin.com\/raw.php?i=XUSv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483688645023387648",
  "text" : "http:\/\/t.co\/iOs1B6TFvc Emails: 199 Keywords: 0.0 #infoleak",
  "id" : 483688645023387648,
  "created_at" : "2014-06-30 19:08:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tVGudQIM1I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Fky8fMc",
      "display_url" : "pastebin.com\/raw.php?i=7Fky\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483682230972055552",
  "text" : "http:\/\/t.co\/tVGudQIM1I Emails: 2039 Keywords: 0.22 #infoleak",
  "id" : 483682230972055552,
  "created_at" : "2014-06-30 18:43:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VhBc0LM2ef",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zznGA0Sa",
      "display_url" : "pastebin.com\/raw.php?i=zznG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483679103422185472",
  "text" : "http:\/\/t.co\/VhBc0LM2ef Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 483679103422185472,
  "created_at" : "2014-06-30 18:30:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cSw5eP8xcm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M971bDvS",
      "display_url" : "pastebin.com\/raw.php?i=M971\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483678292243787776",
  "text" : "http:\/\/t.co\/cSw5eP8xcm Emails: 76 Keywords: 0.0 #infoleak",
  "id" : 483678292243787776,
  "created_at" : "2014-06-30 18:27:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s21DJPlXG1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6Prz3QgG",
      "display_url" : "pastebin.com\/raw.php?i=6Prz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483676822085718016",
  "text" : "http:\/\/t.co\/s21DJPlXG1 Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 483676822085718016,
  "created_at" : "2014-06-30 18:21:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NrwBof3GLI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y28468Ri",
      "display_url" : "pastebin.com\/raw.php?i=y284\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483675831454023680",
  "text" : "http:\/\/t.co\/NrwBof3GLI Emails: 676 Keywords: 0.11 #infoleak",
  "id" : 483675831454023680,
  "created_at" : "2014-06-30 18:17:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/79dhL68rtv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tmR1dYBb",
      "display_url" : "pastebin.com\/raw.php?i=tmR1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483675678005424129",
  "text" : "http:\/\/t.co\/79dhL68rtv Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 483675678005424129,
  "created_at" : "2014-06-30 18:17:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Sa4NZ5fv2X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=162ZQdUy",
      "display_url" : "pastebin.com\/raw.php?i=162Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483675173669711872",
  "text" : "http:\/\/t.co\/Sa4NZ5fv2X Keywords: 0.55 #infoleak",
  "id" : 483675173669711872,
  "created_at" : "2014-06-30 18:15:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/76HwoaWEq4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QiMxVfUz",
      "display_url" : "pastebin.com\/raw.php?i=QiMx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483674893414711297",
  "text" : "http:\/\/t.co\/76HwoaWEq4 Emails: 269 Keywords: 0.11 #infoleak",
  "id" : 483674893414711297,
  "created_at" : "2014-06-30 18:14:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MejtM8i1wi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T91mW0y6",
      "display_url" : "pastebin.com\/raw.php?i=T91m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483671623958941696",
  "text" : "http:\/\/t.co\/MejtM8i1wi Keywords: 0.55 #infoleak",
  "id" : 483671623958941696,
  "created_at" : "2014-06-30 18:01:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WRhxFDn4xA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5Cgjm84M",
      "display_url" : "pastebin.com\/raw.php?i=5Cgj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483670900315656192",
  "text" : "http:\/\/t.co\/WRhxFDn4xA Emails: 750 Keywords: 0.11 #infoleak",
  "id" : 483670900315656192,
  "created_at" : "2014-06-30 17:58:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9US4ODtELz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LCx9h3H4",
      "display_url" : "pastebin.com\/raw.php?i=LCx9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483650165123735552",
  "text" : "http:\/\/t.co\/9US4ODtELz Hashes: 2345 Keywords: 0.11 #infoleak",
  "id" : 483650165123735552,
  "created_at" : "2014-06-30 16:35:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sGLsaCxvUm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cgVq34eY",
      "display_url" : "pastebin.com\/raw.php?i=cgVq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483649789360230401",
  "text" : "http:\/\/t.co\/sGLsaCxvUm Emails: 48 Keywords: 0.0 #infoleak",
  "id" : 483649789360230401,
  "created_at" : "2014-06-30 16:34:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u2CtN6xTuY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=etG1Pq4q",
      "display_url" : "pastebin.com\/raw.php?i=etG1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483643554984517632",
  "text" : "http:\/\/t.co\/u2CtN6xTuY Emails: 158 Keywords: 0.0 #infoleak",
  "id" : 483643554984517632,
  "created_at" : "2014-06-30 16:09:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ynwMVmIfIt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f0TZ4k29",
      "display_url" : "pastebin.com\/raw.php?i=f0TZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483640671413088256",
  "text" : "http:\/\/t.co\/ynwMVmIfIt Emails: 20 Hashes: 3 E\/H: 6.67 Keywords: 0.3 #infoleak",
  "id" : 483640671413088256,
  "created_at" : "2014-06-30 15:58:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1YjYE8nxjY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UHjWyZ5n",
      "display_url" : "pastebin.com\/raw.php?i=UHjW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483638255942778880",
  "text" : "http:\/\/t.co\/1YjYE8nxjY Hashes: 393 Keywords: 0.0 #infoleak",
  "id" : 483638255942778880,
  "created_at" : "2014-06-30 15:48:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ait0Ikneml",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xymPcrKy",
      "display_url" : "pastebin.com\/raw.php?i=xymP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483636827224412161",
  "text" : "http:\/\/t.co\/Ait0Ikneml Emails: 76 Keywords: 0.0 #infoleak",
  "id" : 483636827224412161,
  "created_at" : "2014-06-30 15:42:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y1TnMpo7xl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uDvL5c4z",
      "display_url" : "pastebin.com\/raw.php?i=uDvL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483634614053793792",
  "text" : "http:\/\/t.co\/y1TnMpo7xl Found possible Google API key(s) #infoleak",
  "id" : 483634614053793792,
  "created_at" : "2014-06-30 15:34:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QU1vBQ4TKF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0kw248A0",
      "display_url" : "pastebin.com\/raw.php?i=0kw2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483632834599329792",
  "text" : "http:\/\/t.co\/QU1vBQ4TKF Emails: 13322 Hashes: 1 E\/H: 13322.0 Keywords: 0.22 #infoleak",
  "id" : 483632834599329792,
  "created_at" : "2014-06-30 15:27:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rSPiFYlEsx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C8huarAZ",
      "display_url" : "pastebin.com\/raw.php?i=C8hu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483629728029368321",
  "text" : "http:\/\/t.co\/rSPiFYlEsx Emails: 73 Keywords: 0.0 #infoleak",
  "id" : 483629728029368321,
  "created_at" : "2014-06-30 15:14:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8wHGyBHzb7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=86dpFa2W",
      "display_url" : "pastebin.com\/raw.php?i=86dp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483627774666477568",
  "text" : "http:\/\/t.co\/8wHGyBHzb7 Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 483627774666477568,
  "created_at" : "2014-06-30 15:07:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gfHhkj24fv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Uu52ePTb",
      "display_url" : "pastebin.com\/raw.php?i=Uu52\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483625655599255553",
  "text" : "http:\/\/t.co\/gfHhkj24fv Emails: 23 Keywords: 0.22 #infoleak",
  "id" : 483625655599255553,
  "created_at" : "2014-06-30 14:58:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O88ExRZnwd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ARXwvU1D",
      "display_url" : "pastebin.com\/raw.php?i=ARXw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483624797524328448",
  "text" : "http:\/\/t.co\/O88ExRZnwd Emails: 52 Keywords: 0.0 #infoleak",
  "id" : 483624797524328448,
  "created_at" : "2014-06-30 14:55:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HgrhCz11H7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4CtZEkkw",
      "display_url" : "pastebin.com\/raw.php?i=4CtZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483622308947296256",
  "text" : "http:\/\/t.co\/HgrhCz11H7 Emails: 77 Keywords: 0.33 #infoleak",
  "id" : 483622308947296256,
  "created_at" : "2014-06-30 14:45:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7cSoUgZqez",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UKntJYFy",
      "display_url" : "pastebin.com\/raw.php?i=UKnt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483621672340033537",
  "text" : "http:\/\/t.co\/7cSoUgZqez Emails: 625 Keywords: 0.22 #infoleak",
  "id" : 483621672340033537,
  "created_at" : "2014-06-30 14:42:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y0hzsLv3cM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vM73vgjx",
      "display_url" : "pastebin.com\/raw.php?i=vM73\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483619469483180032",
  "text" : "http:\/\/t.co\/Y0hzsLv3cM Emails: 23 Keywords: 0.22 #infoleak",
  "id" : 483619469483180032,
  "created_at" : "2014-06-30 14:34:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jRRdSe7SBs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zgbN75dG",
      "display_url" : "pastebin.com\/raw.php?i=zgbN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483614658331283456",
  "text" : "http:\/\/t.co\/jRRdSe7SBs Emails: 77 Keywords: 0.33 #infoleak",
  "id" : 483614658331283456,
  "created_at" : "2014-06-30 14:14:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ecfifvs4sH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9iS3WCai",
      "display_url" : "pastebin.com\/raw.php?i=9iS3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483609313793953792",
  "text" : "http:\/\/t.co\/Ecfifvs4sH Found possible Google API key(s) #infoleak",
  "id" : 483609313793953792,
  "created_at" : "2014-06-30 13:53:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I0tmZZnvSm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7ri0wT9K",
      "display_url" : "pastebin.com\/raw.php?i=7ri0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483606498497409026",
  "text" : "http:\/\/t.co\/I0tmZZnvSm Hashes: 47 Keywords: 0.11 #infoleak",
  "id" : 483606498497409026,
  "created_at" : "2014-06-30 13:42:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k5SR7BcyN1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2UitE5iK",
      "display_url" : "pastebin.com\/raw.php?i=2Uit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483603539462082561",
  "text" : "http:\/\/t.co\/k5SR7BcyN1 Hashes: 74 Keywords: 0.0 #infoleak",
  "id" : 483603539462082561,
  "created_at" : "2014-06-30 13:30:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lAyRMe0VIf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vgzGSLAd",
      "display_url" : "pastebin.com\/raw.php?i=vgzG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483597830360018944",
  "text" : "http:\/\/t.co\/lAyRMe0VIf Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 483597830360018944,
  "created_at" : "2014-06-30 13:08:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H4vTPiZEHh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=giBnBGE7",
      "display_url" : "pastebin.com\/raw.php?i=giBn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483593718566359040",
  "text" : "http:\/\/t.co\/H4vTPiZEHh Emails: 236 Keywords: 0.0 #infoleak",
  "id" : 483593718566359040,
  "created_at" : "2014-06-30 12:51:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R4aEZS7G5c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S0kLNN2G",
      "display_url" : "pastebin.com\/raw.php?i=S0kL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483584620139528192",
  "text" : "http:\/\/t.co\/R4aEZS7G5c Emails: 205 Keywords: 0.0 #infoleak",
  "id" : 483584620139528192,
  "created_at" : "2014-06-30 12:15:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vXgmduusWB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gmUhVwVX",
      "display_url" : "pastebin.com\/raw.php?i=gmUh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483583221393682433",
  "text" : "http:\/\/t.co\/vXgmduusWB Emails: 65 Keywords: 0.22 #infoleak",
  "id" : 483583221393682433,
  "created_at" : "2014-06-30 12:09:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vnvMcrXBKz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UfRGSd8m",
      "display_url" : "pastebin.com\/raw.php?i=UfRG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483581999186071552",
  "text" : "http:\/\/t.co\/vnvMcrXBKz Hashes: 118 Keywords: 0.33 #infoleak",
  "id" : 483581999186071552,
  "created_at" : "2014-06-30 12:05:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9ueecORQYH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kYvEUgqD",
      "display_url" : "pastebin.com\/raw.php?i=kYvE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483571001637076992",
  "text" : "http:\/\/t.co\/9ueecORQYH Emails: 119 Keywords: 0.11 #infoleak",
  "id" : 483571001637076992,
  "created_at" : "2014-06-30 11:21:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R3pd2fZOWr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t8fRNc4m",
      "display_url" : "pastebin.com\/raw.php?i=t8fR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483565602926104578",
  "text" : "http:\/\/t.co\/R3pd2fZOWr Emails: 1006 Hashes: 812 E\/H: 1.24 Keywords: 0.3 #infoleak",
  "id" : 483565602926104578,
  "created_at" : "2014-06-30 10:59:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/48By7goYlb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iN4EHHyt",
      "display_url" : "pastebin.com\/raw.php?i=iN4E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483548008240250880",
  "text" : "http:\/\/t.co\/48By7goYlb Keywords: 0.55 #infoleak",
  "id" : 483548008240250880,
  "created_at" : "2014-06-30 09:50:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GruMhoGQDl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C72zWSdE",
      "display_url" : "pastebin.com\/raw.php?i=C72z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483543953036173312",
  "text" : "http:\/\/t.co\/GruMhoGQDl Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 483543953036173312,
  "created_at" : "2014-06-30 09:33:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OCeYJ9SsWs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fvmDDsZ5",
      "display_url" : "pastebin.com\/raw.php?i=fvmD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483539309631242240",
  "text" : "http:\/\/t.co\/OCeYJ9SsWs Emails: 134 Keywords: 0.0 #infoleak",
  "id" : 483539309631242240,
  "created_at" : "2014-06-30 09:15:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0qgl5rW5Ys",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1k7Nf2RF",
      "display_url" : "pastebin.com\/raw.php?i=1k7N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483538489040834560",
  "text" : "http:\/\/t.co\/0qgl5rW5Ys Emails: 533 Keywords: 0.0 #infoleak",
  "id" : 483538489040834560,
  "created_at" : "2014-06-30 09:12:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hw5a99CKDm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nwkgyBCt",
      "display_url" : "pastebin.com\/raw.php?i=nwkg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483525737895321600",
  "text" : "http:\/\/t.co\/Hw5a99CKDm Found possible Google API key(s) #infoleak",
  "id" : 483525737895321600,
  "created_at" : "2014-06-30 08:21:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ygZFQkDJEq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ViJt5NDe",
      "display_url" : "pastebin.com\/raw.php?i=ViJt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483516495222161409",
  "text" : "http:\/\/t.co\/ygZFQkDJEq Hashes: 57 Keywords: 0.11 #infoleak",
  "id" : 483516495222161409,
  "created_at" : "2014-06-30 07:44:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HQYTgdEWwr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tumKYCXT",
      "display_url" : "pastebin.com\/raw.php?i=tumK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483516018824720385",
  "text" : "http:\/\/t.co\/HQYTgdEWwr Hashes: 49 Keywords: 0.0 #infoleak",
  "id" : 483516018824720385,
  "created_at" : "2014-06-30 07:42:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ujxbGk3nOo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5BLSQMGY",
      "display_url" : "pastebin.com\/raw.php?i=5BLS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483503204072574977",
  "text" : "http:\/\/t.co\/ujxbGk3nOo Hashes: 511 Keywords: -0.03 #infoleak",
  "id" : 483503204072574977,
  "created_at" : "2014-06-30 06:52:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ghy7Z9ZChq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=my48NTcw",
      "display_url" : "pastebin.com\/raw.php?i=my48\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483493865844785153",
  "text" : "http:\/\/t.co\/ghy7Z9ZChq Emails: 243 Keywords: 0.0 #infoleak",
  "id" : 483493865844785153,
  "created_at" : "2014-06-30 06:14:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9LgMuNp2ab",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MQbzvpsr",
      "display_url" : "pastebin.com\/raw.php?i=MQbz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483479472335642624",
  "text" : "http:\/\/t.co\/9LgMuNp2ab Emails: 889 Keywords: 0.0 #infoleak",
  "id" : 483479472335642624,
  "created_at" : "2014-06-30 05:17:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sfT2nPOTe4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=phqHvMHq",
      "display_url" : "pastebin.com\/raw.php?i=phqH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483468444424077313",
  "text" : "http:\/\/t.co\/sfT2nPOTe4 Emails: 231 Keywords: 0.11 #infoleak",
  "id" : 483468444424077313,
  "created_at" : "2014-06-30 04:33:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cq4OlgwHr2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4Smq6FqG",
      "display_url" : "pastebin.com\/raw.php?i=4Smq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483464762764705792",
  "text" : "http:\/\/t.co\/cq4OlgwHr2 Emails: 21518 Keywords: 0.08 #infoleak",
  "id" : 483464762764705792,
  "created_at" : "2014-06-30 04:19:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fZjCUg4sD5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2JHQWu6G",
      "display_url" : "pastebin.com\/raw.php?i=2JHQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483463193516191745",
  "text" : "http:\/\/t.co\/fZjCUg4sD5 Emails: 98 Hashes: 97 E\/H: 1.01 Keywords: -0.03 #infoleak",
  "id" : 483463193516191745,
  "created_at" : "2014-06-30 04:13:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KwLrzGZvZp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8tfEss83",
      "display_url" : "pastebin.com\/raw.php?i=8tfE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483452887981256704",
  "text" : "http:\/\/t.co\/KwLrzGZvZp Emails: 51 Keywords: 0.0 #infoleak",
  "id" : 483452887981256704,
  "created_at" : "2014-06-30 03:32:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nr8FMbISwc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E9BZzkbc",
      "display_url" : "pastebin.com\/raw.php?i=E9BZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483448558872309760",
  "text" : "http:\/\/t.co\/nr8FMbISwc Emails: 242 Keywords: 0.0 #infoleak",
  "id" : 483448558872309760,
  "created_at" : "2014-06-30 03:14:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GskwhpXobP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hhSbeHXY",
      "display_url" : "pastebin.com\/raw.php?i=hhSb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483440923448057857",
  "text" : "http:\/\/t.co\/GskwhpXobP Hashes: 109 Keywords: 0.11 #infoleak",
  "id" : 483440923448057857,
  "created_at" : "2014-06-30 02:44:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bpve7SXEDc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kcA80AHL",
      "display_url" : "pastebin.com\/raw.php?i=kcA8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483439599113355264",
  "text" : "http:\/\/t.co\/Bpve7SXEDc Emails: 498 Keywords: 0.0 #infoleak",
  "id" : 483439599113355264,
  "created_at" : "2014-06-30 02:39:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2rLPBZRLgS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PR8P7Vc3",
      "display_url" : "pastebin.com\/raw.php?i=PR8P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483438198375202819",
  "text" : "http:\/\/t.co\/2rLPBZRLgS Emails: 26 Keywords: 0.08 #infoleak",
  "id" : 483438198375202819,
  "created_at" : "2014-06-30 02:33:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3ZhroJ5fnL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kWWJvDs6",
      "display_url" : "pastebin.com\/raw.php?i=kWWJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483430809202733056",
  "text" : "http:\/\/t.co\/3ZhroJ5fnL Emails: 204 Keywords: 0.0 #infoleak",
  "id" : 483430809202733056,
  "created_at" : "2014-06-30 02:04:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PFDSWBxhaA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mPq4ExTA",
      "display_url" : "pastebin.com\/raw.php?i=mPq4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483418065950867456",
  "text" : "http:\/\/t.co\/PFDSWBxhaA Emails: 64 Keywords: 0.11 #infoleak",
  "id" : 483418065950867456,
  "created_at" : "2014-06-30 01:13:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QWNVLza0ki",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3k2uaUgj",
      "display_url" : "pastebin.com\/raw.php?i=3k2u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483403048903921664",
  "text" : "http:\/\/t.co\/QWNVLza0ki Emails: 124 Keywords: 0.11 #infoleak",
  "id" : 483403048903921664,
  "created_at" : "2014-06-30 00:14:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sUvv6iqueL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S6SUbza0",
      "display_url" : "pastebin.com\/raw.php?i=S6SU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483385159891161088",
  "text" : "http:\/\/t.co\/sUvv6iqueL Emails: 68 Keywords: 0.11 #infoleak",
  "id" : 483385159891161088,
  "created_at" : "2014-06-29 23:02:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NgUEhqTmX2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Vefga4FY",
      "display_url" : "pastebin.com\/raw.php?i=Vefg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483382833742761985",
  "text" : "http:\/\/t.co\/NgUEhqTmX2 Emails: 548 Keywords: 0.11 #infoleak",
  "id" : 483382833742761985,
  "created_at" : "2014-06-29 22:53:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O7lsLyT9yy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qdqYSNvN",
      "display_url" : "pastebin.com\/raw.php?i=qdqY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483381988267552768",
  "text" : "http:\/\/t.co\/O7lsLyT9yy Emails: 68 Keywords: 0.0 #infoleak",
  "id" : 483381988267552768,
  "created_at" : "2014-06-29 22:50:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w1C9GuBsMY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PEdDJWs7",
      "display_url" : "pastebin.com\/raw.php?i=PEdD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483381512373432320",
  "text" : "http:\/\/t.co\/w1C9GuBsMY Emails: 527 Keywords: 0.0 #infoleak",
  "id" : 483381512373432320,
  "created_at" : "2014-06-29 22:48:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wCb0Ian4sa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i0S2tmvP",
      "display_url" : "pastebin.com\/raw.php?i=i0S2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483337833302618113",
  "text" : "http:\/\/t.co\/wCb0Ian4sa Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 483337833302618113,
  "created_at" : "2014-06-29 19:54:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ChPWaDSHB5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eYkx0jzc",
      "display_url" : "pastebin.com\/raw.php?i=eYkx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483334003798188033",
  "text" : "http:\/\/t.co\/ChPWaDSHB5 Hashes: 78 Keywords: 0.33 #infoleak",
  "id" : 483334003798188033,
  "created_at" : "2014-06-29 19:39:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6i2jaO7QqS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3HPRkmwm",
      "display_url" : "pastebin.com\/raw.php?i=3HPR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483329735368265728",
  "text" : "http:\/\/t.co\/6i2jaO7QqS Possible cisco configuration #infoleak",
  "id" : 483329735368265728,
  "created_at" : "2014-06-29 19:22:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/05uPVcUvds",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rcuBbE9U",
      "display_url" : "pastebin.com\/raw.php?i=rcuB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483328701006745600",
  "text" : "http:\/\/t.co\/05uPVcUvds Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 483328701006745600,
  "created_at" : "2014-06-29 19:18:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BDUGHCCwhV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=41brMH7u",
      "display_url" : "pastebin.com\/raw.php?i=41br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483326953181556736",
  "text" : "http:\/\/t.co\/BDUGHCCwhV Possible cisco configuration #infoleak",
  "id" : 483326953181556736,
  "created_at" : "2014-06-29 19:11:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rqIldShbbb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w1sPsjEX",
      "display_url" : "pastebin.com\/raw.php?i=w1sP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483323734392967168",
  "text" : "http:\/\/t.co\/rqIldShbbb Emails: 144 Keywords: -0.03 #infoleak",
  "id" : 483323734392967168,
  "created_at" : "2014-06-29 18:58:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AnkvSFtbZc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WL7Xysif",
      "display_url" : "pastebin.com\/raw.php?i=WL7X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483316818665144321",
  "text" : "http:\/\/t.co\/AnkvSFtbZc Emails: 32 Keywords: 0.22 #infoleak",
  "id" : 483316818665144321,
  "created_at" : "2014-06-29 18:31:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IYOVoywpN3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ytYubyQf",
      "display_url" : "pastebin.com\/raw.php?i=ytYu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483312730489630720",
  "text" : "http:\/\/t.co\/IYOVoywpN3 Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 483312730489630720,
  "created_at" : "2014-06-29 18:15:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A5tFUCcnax",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yzpPm4Jh",
      "display_url" : "pastebin.com\/raw.php?i=yzpP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483312351093862401",
  "text" : "http:\/\/t.co\/A5tFUCcnax Emails: 112 Keywords: 0.11 #infoleak",
  "id" : 483312351093862401,
  "created_at" : "2014-06-29 18:13:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JyptPUP1BV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=183BLqA4",
      "display_url" : "pastebin.com\/raw.php?i=183B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483310220337111040",
  "text" : "http:\/\/t.co\/JyptPUP1BV Keywords: 0.55 #infoleak",
  "id" : 483310220337111040,
  "created_at" : "2014-06-29 18:05:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B25ehxxdC1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v0URzsnK",
      "display_url" : "pastebin.com\/raw.php?i=v0UR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483278818241544192",
  "text" : "http:\/\/t.co\/B25ehxxdC1 Hashes: 62 Keywords: 0.0 #infoleak",
  "id" : 483278818241544192,
  "created_at" : "2014-06-29 16:00:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/90GtKyVVpE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZfYCzNsZ",
      "display_url" : "pastebin.com\/raw.php?i=ZfYC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483274463467675648",
  "text" : "http:\/\/t.co\/90GtKyVVpE Emails: 1000 Keywords: 0.11 #infoleak",
  "id" : 483274463467675648,
  "created_at" : "2014-06-29 15:43:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AACzdw3bqN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MRDkGpKp",
      "display_url" : "pastebin.com\/raw.php?i=MRDk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483274008012390400",
  "text" : "http:\/\/t.co\/AACzdw3bqN Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 483274008012390400,
  "created_at" : "2014-06-29 15:41:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q7fOE3uSvb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Br7YgRJ3",
      "display_url" : "pastebin.com\/raw.php?i=Br7Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483270475007537152",
  "text" : "http:\/\/t.co\/Q7fOE3uSvb Emails: 1342 Keywords: 0.22 #infoleak",
  "id" : 483270475007537152,
  "created_at" : "2014-06-29 15:27:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E1vRwgga9D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cKcQhD1T",
      "display_url" : "pastebin.com\/raw.php?i=cKcQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483267320391794688",
  "text" : "http:\/\/t.co\/E1vRwgga9D Emails: 171 Keywords: 0.11 #infoleak",
  "id" : 483267320391794688,
  "created_at" : "2014-06-29 15:14:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LnJP8ao3yi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=152Dh55x",
      "display_url" : "pastebin.com\/raw.php?i=152D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483260047011483649",
  "text" : "http:\/\/t.co\/LnJP8ao3yi Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 483260047011483649,
  "created_at" : "2014-06-29 14:45:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IsnyzGLUMG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zt7515eP",
      "display_url" : "pastebin.com\/raw.php?i=Zt75\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483253196710625281",
  "text" : "http:\/\/t.co\/IsnyzGLUMG Hashes: 45 Keywords: 0.3 #infoleak",
  "id" : 483253196710625281,
  "created_at" : "2014-06-29 14:18:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4Clu9A9EtV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jWSYH1na",
      "display_url" : "pastebin.com\/raw.php?i=jWSY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483237478296346624",
  "text" : "http:\/\/t.co\/4Clu9A9EtV Emails: 6143 Keywords: 0.11 #infoleak",
  "id" : 483237478296346624,
  "created_at" : "2014-06-29 13:16:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zOeXPD0YII",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P3Cp4D7L",
      "display_url" : "pastebin.com\/raw.php?i=P3Cp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483236990351978496",
  "text" : "http:\/\/t.co\/zOeXPD0YII Emails: 935 Keywords: 0.22 #infoleak",
  "id" : 483236990351978496,
  "created_at" : "2014-06-29 13:14:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C77Pdg3hMY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ebEAdcNA",
      "display_url" : "pastebin.com\/raw.php?i=ebEA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483235014742519810",
  "text" : "http:\/\/t.co\/C77Pdg3hMY Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 483235014742519810,
  "created_at" : "2014-06-29 13:06:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yQx64XD3sy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0MkqcFjT",
      "display_url" : "pastebin.com\/raw.php?i=0Mkq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483231218012393472",
  "text" : "http:\/\/t.co\/yQx64XD3sy Emails: 4623 Keywords: -0.03 #infoleak",
  "id" : 483231218012393472,
  "created_at" : "2014-06-29 12:51:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tkgerF7EmL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JxSYP3S7",
      "display_url" : "pastebin.com\/raw.php?i=JxSY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483226340988944384",
  "text" : "http:\/\/t.co\/tkgerF7EmL Emails: 1905 Keywords: 0.22 #infoleak",
  "id" : 483226340988944384,
  "created_at" : "2014-06-29 12:31:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0GQTEXu6eO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yPT0GvE4",
      "display_url" : "pastebin.com\/raw.php?i=yPT0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483221645469810689",
  "text" : "http:\/\/t.co\/0GQTEXu6eO Emails: 63 Keywords: 0.11 #infoleak",
  "id" : 483221645469810689,
  "created_at" : "2014-06-29 12:13:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MyvukBAqAH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fXRhKEX4",
      "display_url" : "pastebin.com\/raw.php?i=fXRh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483211458373627904",
  "text" : "http:\/\/t.co\/MyvukBAqAH Emails: 60 Keywords: 0.11 #infoleak",
  "id" : 483211458373627904,
  "created_at" : "2014-06-29 11:32:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7sf3ro9MZB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=csNP6Y7m",
      "display_url" : "pastebin.com\/raw.php?i=csNP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483210910584954880",
  "text" : "http:\/\/t.co\/7sf3ro9MZB Emails: 75 Keywords: 0.11 #infoleak",
  "id" : 483210910584954880,
  "created_at" : "2014-06-29 11:30:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JT2VlVIN8T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vmGjc3AD",
      "display_url" : "pastebin.com\/raw.php?i=vmGj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483192747528953857",
  "text" : "http:\/\/t.co\/JT2VlVIN8T Found possible Google API key(s) #infoleak",
  "id" : 483192747528953857,
  "created_at" : "2014-06-29 10:18:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CHLc760vOd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9ZbZ8qzw",
      "display_url" : "pastebin.com\/raw.php?i=9ZbZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483185577244635137",
  "text" : "http:\/\/t.co\/CHLc760vOd Found possible Google API key(s) #infoleak",
  "id" : 483185577244635137,
  "created_at" : "2014-06-29 09:49:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C4LkttdVNK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XAQ14vwt",
      "display_url" : "pastebin.com\/raw.php?i=XAQ1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483185300764512256",
  "text" : "http:\/\/t.co\/C4LkttdVNK Found possible Google API key(s) #infoleak",
  "id" : 483185300764512256,
  "created_at" : "2014-06-29 09:48:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/seDpWxAAAq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=swP6m61m",
      "display_url" : "pastebin.com\/raw.php?i=swP6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483184428714172418",
  "text" : "http:\/\/t.co\/seDpWxAAAq Found possible Google API key(s) #infoleak",
  "id" : 483184428714172418,
  "created_at" : "2014-06-29 09:45:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yh5VPuJ1Cc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tvLgiURX",
      "display_url" : "pastebin.com\/raw.php?i=tvLg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483176431757697024",
  "text" : "http:\/\/t.co\/Yh5VPuJ1Cc Emails: 156 Keywords: 0.11 #infoleak",
  "id" : 483176431757697024,
  "created_at" : "2014-06-29 09:13:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zL7MAeKZy3",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2XKW2aKct",
      "display_url" : "slexy.org\/raw\/s2XKW2aKct"
    } ]
  },
  "geo" : { },
  "id_str" : "483171143457587201",
  "text" : "http:\/\/t.co\/zL7MAeKZy3 Emails: 1483 Keywords: 0.11 #infoleak",
  "id" : 483171143457587201,
  "created_at" : "2014-06-29 08:52:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NGP8Ic31qM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PQJJ8mEn",
      "display_url" : "pastebin.com\/raw.php?i=PQJJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483166648371658752",
  "text" : "http:\/\/t.co\/NGP8Ic31qM Emails: 127 Keywords: 0.0 #infoleak",
  "id" : 483166648371658752,
  "created_at" : "2014-06-29 08:34:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6HVHFxZVzQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fBN0tXzZ",
      "display_url" : "pastebin.com\/raw.php?i=fBN0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483165834471174144",
  "text" : "http:\/\/t.co\/6HVHFxZVzQ Emails: 131 Keywords: 0.0 #infoleak",
  "id" : 483165834471174144,
  "created_at" : "2014-06-29 08:31:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZsDzvvNob2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tekvuBbp",
      "display_url" : "pastebin.com\/raw.php?i=tekv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483155787037310976",
  "text" : "http:\/\/t.co\/ZsDzvvNob2 Emails: 26 Keywords: 0.11 #infoleak",
  "id" : 483155787037310976,
  "created_at" : "2014-06-29 07:51:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jCtMl8sxAA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8QHJAsyJ",
      "display_url" : "pastebin.com\/raw.php?i=8QHJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483138879512264704",
  "text" : "http:\/\/t.co\/jCtMl8sxAA Hashes: 86 Keywords: 0.08 #infoleak",
  "id" : 483138879512264704,
  "created_at" : "2014-06-29 06:44:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qBmK4vPRnU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=112fEQjz",
      "display_url" : "pastebin.com\/raw.php?i=112f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483132815802777600",
  "text" : "http:\/\/t.co\/qBmK4vPRnU Possible cisco configuration #infoleak",
  "id" : 483132815802777600,
  "created_at" : "2014-06-29 06:20:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fxCH7TASht",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wZG64URK",
      "display_url" : "pastebin.com\/raw.php?i=wZG6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483131124302872578",
  "text" : "http:\/\/t.co\/fxCH7TASht Emails: 257 Keywords: 0.11 #infoleak",
  "id" : 483131124302872578,
  "created_at" : "2014-06-29 06:13:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ExKCz1gVvJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Lx0jwEb9",
      "display_url" : "pastebin.com\/raw.php?i=Lx0j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483116542461108226",
  "text" : "http:\/\/t.co\/ExKCz1gVvJ Emails: 44 Keywords: 0.0 #infoleak",
  "id" : 483116542461108226,
  "created_at" : "2014-06-29 05:15:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Orkn4eYeLn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=302a4wG2",
      "display_url" : "pastebin.com\/raw.php?i=302a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483112686209613825",
  "text" : "http:\/\/t.co\/Orkn4eYeLn Keywords: 0.55 #infoleak",
  "id" : 483112686209613825,
  "created_at" : "2014-06-29 05:00:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ii8ANSDq4s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ph2UrDwS",
      "display_url" : "pastebin.com\/raw.php?i=ph2U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483096399735578624",
  "text" : "http:\/\/t.co\/Ii8ANSDq4s Hashes: 41 Keywords: 0.11 #infoleak",
  "id" : 483096399735578624,
  "created_at" : "2014-06-29 03:55:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DbgB673RzY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fCURrZ45",
      "display_url" : "pastebin.com\/raw.php?i=fCUR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483085732634824705",
  "text" : "http:\/\/t.co\/DbgB673RzY Emails: 270 Keywords: 0.11 #infoleak",
  "id" : 483085732634824705,
  "created_at" : "2014-06-29 03:13:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2i1iXhyj1c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6z9H9AwR",
      "display_url" : "pastebin.com\/raw.php?i=6z9H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483079619495481345",
  "text" : "http:\/\/t.co\/2i1iXhyj1c Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 483079619495481345,
  "created_at" : "2014-06-29 02:48:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B9JQGKn3uP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=05M7LQ4s",
      "display_url" : "pastebin.com\/raw.php?i=05M7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483070730930622465",
  "text" : "http:\/\/t.co\/B9JQGKn3uP Possible cisco configuration #infoleak",
  "id" : 483070730930622465,
  "created_at" : "2014-06-29 02:13:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dOGfXxdgnX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2eMNuZGJ",
      "display_url" : "pastebin.com\/raw.php?i=2eMN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483056653927845888",
  "text" : "http:\/\/t.co\/dOGfXxdgnX Keywords: 0.55 #infoleak",
  "id" : 483056653927845888,
  "created_at" : "2014-06-29 01:17:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G0I78t57HM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C0NMJUE2",
      "display_url" : "pastebin.com\/raw.php?i=C0NM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483052637223264258",
  "text" : "http:\/\/t.co\/G0I78t57HM Hashes: 43 Keywords: 0.08 #infoleak",
  "id" : 483052637223264258,
  "created_at" : "2014-06-29 01:01:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gAuq0Hnulk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EeBY4Djk",
      "display_url" : "pastebin.com\/raw.php?i=EeBY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483049630146363393",
  "text" : "http:\/\/t.co\/gAuq0Hnulk Hashes: 76 Keywords: 0.22 #infoleak",
  "id" : 483049630146363393,
  "created_at" : "2014-06-29 00:49:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qyOtEbe0E8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Le5F5dBE",
      "display_url" : "pastebin.com\/raw.php?i=Le5F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483040405273837569",
  "text" : "http:\/\/t.co\/qyOtEbe0E8 Emails: 246 Keywords: 0.11 #infoleak",
  "id" : 483040405273837569,
  "created_at" : "2014-06-29 00:13:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0hfNVgcC3v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bJxip9UN",
      "display_url" : "pastebin.com\/raw.php?i=bJxi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483030013055229952",
  "text" : "http:\/\/t.co\/0hfNVgcC3v Hashes: 69 Keywords: 0.0 #infoleak",
  "id" : 483030013055229952,
  "created_at" : "2014-06-28 23:31:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GoIAcvtX2f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xXejG9r9",
      "display_url" : "pastebin.com\/raw.php?i=xXej\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483029137112588288",
  "text" : "http:\/\/t.co\/GoIAcvtX2f Hashes: 326 Keywords: 0.11 #infoleak",
  "id" : 483029137112588288,
  "created_at" : "2014-06-28 23:28:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tJ5EYd5XJy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PR3806JG",
      "display_url" : "pastebin.com\/raw.php?i=PR38\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483010666379235328",
  "text" : "http:\/\/t.co\/tJ5EYd5XJy Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 483010666379235328,
  "created_at" : "2014-06-28 22:14:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FmKT2TcQkb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JSWCMEh1",
      "display_url" : "pastebin.com\/raw.php?i=JSWC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483007426929512448",
  "text" : "http:\/\/t.co\/FmKT2TcQkb Hashes: 78 Keywords: 0.44 #infoleak",
  "id" : 483007426929512448,
  "created_at" : "2014-06-28 22:01:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ygjx7OwvSi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RccxGepR",
      "display_url" : "pastebin.com\/raw.php?i=Rccx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483006580372148224",
  "text" : "http:\/\/t.co\/Ygjx7OwvSi Emails: 500 Keywords: 0.0 #infoleak",
  "id" : 483006580372148224,
  "created_at" : "2014-06-28 21:58:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/koH5pToswB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y1JVMj9z",
      "display_url" : "pastebin.com\/raw.php?i=y1JV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483002208137396224",
  "text" : "http:\/\/t.co\/koH5pToswB Emails: 97 Keywords: 0.55 #infoleak",
  "id" : 483002208137396224,
  "created_at" : "2014-06-28 21:41:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/szO1CVi4vW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v14AH7rk",
      "display_url" : "pastebin.com\/raw.php?i=v14A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482995140827430912",
  "text" : "http:\/\/t.co\/szO1CVi4vW Emails: 131 Keywords: 0.0 #infoleak",
  "id" : 482995140827430912,
  "created_at" : "2014-06-28 21:13:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pQbPHSfqmY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=prYYDetT",
      "display_url" : "pastebin.com\/raw.php?i=prYY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482989762362351616",
  "text" : "http:\/\/t.co\/pQbPHSfqmY Emails: 28 Keywords: 0.11 #infoleak",
  "id" : 482989762362351616,
  "created_at" : "2014-06-28 20:51:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BNcfOs4OvO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3ZPj8aXt",
      "display_url" : "pastebin.com\/raw.php?i=3ZPj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482986790207238144",
  "text" : "http:\/\/t.co\/BNcfOs4OvO Keywords: 0.66 #infoleak",
  "id" : 482986790207238144,
  "created_at" : "2014-06-28 20:39:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZVGZrS9qhZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YL5xSHft",
      "display_url" : "pastebin.com\/raw.php?i=YL5x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482982325274157056",
  "text" : "http:\/\/t.co\/ZVGZrS9qhZ Emails: 625 Keywords: 0.22 #infoleak",
  "id" : 482982325274157056,
  "created_at" : "2014-06-28 20:22:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jmDwNfb48N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DQWNaq9G",
      "display_url" : "pastebin.com\/raw.php?i=DQWN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482976625999372288",
  "text" : "http:\/\/t.co\/jmDwNfb48N Emails: 243 Hashes: 241 E\/H: 1.01 Keywords: 0.19 #infoleak",
  "id" : 482976625999372288,
  "created_at" : "2014-06-28 19:59:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ctuf2wGlLH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y9xFKG2f",
      "display_url" : "pastebin.com\/raw.php?i=y9xF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482976196288724993",
  "text" : "http:\/\/t.co\/Ctuf2wGlLH Emails: 1499 Hashes: 1580 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 482976196288724993,
  "created_at" : "2014-06-28 19:57:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mjzepKL1MT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5642r9Ad",
      "display_url" : "pastebin.com\/raw.php?i=5642\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482974208981352448",
  "text" : "http:\/\/t.co\/mjzepKL1MT Emails: 1 Hashes: 365 E\/H: 0.0 Keywords: 0.08 #infoleak",
  "id" : 482974208981352448,
  "created_at" : "2014-06-28 19:49:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d68P1v7xKS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uXtE9hfA",
      "display_url" : "pastebin.com\/raw.php?i=uXtE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482962602029367296",
  "text" : "http:\/\/t.co\/d68P1v7xKS Emails: 6649 Keywords: 0.08 #infoleak",
  "id" : 482962602029367296,
  "created_at" : "2014-06-28 19:03:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o0NTfUbsHn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U1kpgN4b",
      "display_url" : "pastebin.com\/raw.php?i=U1kp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482962502506905600",
  "text" : "http:\/\/t.co\/o0NTfUbsHn Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 482962502506905600,
  "created_at" : "2014-06-28 19:03:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RP8iFLk0Sm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XhAPVQ5y",
      "display_url" : "pastebin.com\/raw.php?i=XhAP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482957998285791234",
  "text" : "http:\/\/t.co\/RP8iFLk0Sm Emails: 56 Keywords: 0.0 #infoleak",
  "id" : 482957998285791234,
  "created_at" : "2014-06-28 18:45:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M6djMJgZCm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kgLb3Kj3",
      "display_url" : "pastebin.com\/raw.php?i=kgLb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482952801635799041",
  "text" : "http:\/\/t.co\/M6djMJgZCm Emails: 55 Keywords: 0.0 #infoleak",
  "id" : 482952801635799041,
  "created_at" : "2014-06-28 18:24:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tGwLAubFAZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=puBzBB3s",
      "display_url" : "pastebin.com\/raw.php?i=puBz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482951751914369024",
  "text" : "http:\/\/t.co\/tGwLAubFAZ Emails: 61 Keywords: 0.0 #infoleak",
  "id" : 482951751914369024,
  "created_at" : "2014-06-28 18:20:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uPNxj6B8h3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UAbyD9zM",
      "display_url" : "pastebin.com\/raw.php?i=UAby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482949900229812225",
  "text" : "http:\/\/t.co\/uPNxj6B8h3 Emails: 250 Keywords: 0.11 #infoleak",
  "id" : 482949900229812225,
  "created_at" : "2014-06-28 18:13:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QKM7G17NQb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pMcb2uFx",
      "display_url" : "pastebin.com\/raw.php?i=pMcb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482949413501804544",
  "text" : "http:\/\/t.co\/QKM7G17NQb Emails: 40 Keywords: 0.0 #infoleak",
  "id" : 482949413501804544,
  "created_at" : "2014-06-28 18:11:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O9UXbPESOm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YTNQqXYY",
      "display_url" : "pastebin.com\/raw.php?i=YTNQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482948798470057985",
  "text" : "http:\/\/t.co\/O9UXbPESOm Found possible Google API key(s) #infoleak",
  "id" : 482948798470057985,
  "created_at" : "2014-06-28 18:09:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qnskV4GdQK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EPEwz6aK",
      "display_url" : "pastebin.com\/raw.php?i=EPEw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482932129752289280",
  "text" : "http:\/\/t.co\/qnskV4GdQK Hashes: 71 Keywords: 0.0 #infoleak",
  "id" : 482932129752289280,
  "created_at" : "2014-06-28 17:02:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jXMrW0qcSf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8w2eME7M",
      "display_url" : "pastebin.com\/raw.php?i=8w2e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482931621360701440",
  "text" : "http:\/\/t.co\/jXMrW0qcSf Keywords: 0.55 #infoleak",
  "id" : 482931621360701440,
  "created_at" : "2014-06-28 17:00:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p0oSXp9lwl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QJ9f4sXp",
      "display_url" : "pastebin.com\/raw.php?i=QJ9f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482927894658699264",
  "text" : "http:\/\/t.co\/p0oSXp9lwl Emails: 89 Keywords: -0.14 #infoleak",
  "id" : 482927894658699264,
  "created_at" : "2014-06-28 16:45:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bE54whULqp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bSW9mGKT",
      "display_url" : "pastebin.com\/raw.php?i=bSW9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482917739338559488",
  "text" : "http:\/\/t.co\/bE54whULqp Emails: 1612 Keywords: 0.11 #infoleak",
  "id" : 482917739338559488,
  "created_at" : "2014-06-28 16:05:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OCj7h78Djg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CbeFwVdQ",
      "display_url" : "pastebin.com\/raw.php?i=CbeF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482908873469087744",
  "text" : "http:\/\/t.co\/OCj7h78Djg Emails: 1 Hashes: 2 E\/H: 0.5 Keywords: 0.66 #infoleak",
  "id" : 482908873469087744,
  "created_at" : "2014-06-28 15:30:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aMsduiQM5L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wtGv6py3",
      "display_url" : "pastebin.com\/raw.php?i=wtGv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482908502558375936",
  "text" : "http:\/\/t.co\/aMsduiQM5L Emails: 2 Hashes: 134 E\/H: 0.01 Keywords: 0.3 #infoleak",
  "id" : 482908502558375936,
  "created_at" : "2014-06-28 15:28:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WGq89595u8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wdXM9DUP",
      "display_url" : "pastebin.com\/raw.php?i=wdXM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482904559715487744",
  "text" : "http:\/\/t.co\/WGq89595u8 Emails: 226 Keywords: 0.11 #infoleak",
  "id" : 482904559715487744,
  "created_at" : "2014-06-28 15:13:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7YeEDc9tMS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MY3EtQAe",
      "display_url" : "pastebin.com\/raw.php?i=MY3E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482888730424782849",
  "text" : "http:\/\/t.co\/7YeEDc9tMS Emails: 1499 Hashes: 1580 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 482888730424782849,
  "created_at" : "2014-06-28 14:10:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nt3BVB1Sww",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V7YHKpGk",
      "display_url" : "pastebin.com\/raw.php?i=V7YH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482882078745190400",
  "text" : "http:\/\/t.co\/nt3BVB1Sww Emails: 1499 Hashes: 1580 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 482882078745190400,
  "created_at" : "2014-06-28 13:43:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2Fv35pO9go",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K2pg0T31",
      "display_url" : "pastebin.com\/raw.php?i=K2pg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482881637554716672",
  "text" : "http:\/\/t.co\/2Fv35pO9go Emails: 32 Keywords: 0.11 #infoleak",
  "id" : 482881637554716672,
  "created_at" : "2014-06-28 13:42:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kAf4ABtWaU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KcdpfFmy",
      "display_url" : "pastebin.com\/raw.php?i=Kcdp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482879749597822976",
  "text" : "http:\/\/t.co\/kAf4ABtWaU Emails: 901 Keywords: 0.0 #infoleak",
  "id" : 482879749597822976,
  "created_at" : "2014-06-28 13:34:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/93CXqPbXYT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SWVJF7dD",
      "display_url" : "pastebin.com\/raw.php?i=SWVJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482859365519470595",
  "text" : "http:\/\/t.co\/93CXqPbXYT Emails: 120 Keywords: 0.11 #infoleak",
  "id" : 482859365519470595,
  "created_at" : "2014-06-28 12:13:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fzV4EDNHRl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tw75vJsX",
      "display_url" : "pastebin.com\/raw.php?i=Tw75\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482835503352266753",
  "text" : "http:\/\/t.co\/fzV4EDNHRl Found possible Google API key(s) #infoleak",
  "id" : 482835503352266753,
  "created_at" : "2014-06-28 10:38:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XFZ6YjeCXF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xi8Y2S05",
      "display_url" : "pastebin.com\/raw.php?i=Xi8Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482813968063279105",
  "text" : "http:\/\/t.co\/XFZ6YjeCXF Emails: 242 Keywords: 0.11 #infoleak",
  "id" : 482813968063279105,
  "created_at" : "2014-06-28 09:13:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Jtsq6jPh0a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TafRNFdC",
      "display_url" : "pastebin.com\/raw.php?i=TafR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482798018928734208",
  "text" : "http:\/\/t.co\/Jtsq6jPh0a Hashes: 110 Keywords: 0.11 #infoleak",
  "id" : 482798018928734208,
  "created_at" : "2014-06-28 08:09:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ESmgxM9KK6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=riAtHptd",
      "display_url" : "pastebin.com\/raw.php?i=riAt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482796816363036672",
  "text" : "http:\/\/t.co\/ESmgxM9KK6 Hashes: 106 Keywords: 0.11 #infoleak",
  "id" : 482796816363036672,
  "created_at" : "2014-06-28 08:05:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d1NJ1J24xd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NVEASCp0",
      "display_url" : "pastebin.com\/raw.php?i=NVEA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482795752679153664",
  "text" : "http:\/\/t.co\/d1NJ1J24xd Hashes: 110 Keywords: 0.11 #infoleak",
  "id" : 482795752679153664,
  "created_at" : "2014-06-28 08:00:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GAKPYlkfsZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zhWUs0gG",
      "display_url" : "pastebin.com\/raw.php?i=zhWU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482793798859112448",
  "text" : "http:\/\/t.co\/GAKPYlkfsZ Hashes: 108 Keywords: 0.11 #infoleak",
  "id" : 482793798859112448,
  "created_at" : "2014-06-28 07:53:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JQyNbEPNGC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z3yXp46j",
      "display_url" : "pastebin.com\/raw.php?i=Z3yX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482792727700967424",
  "text" : "http:\/\/t.co\/JQyNbEPNGC Hashes: 102 Keywords: 0.11 #infoleak",
  "id" : 482792727700967424,
  "created_at" : "2014-06-28 07:48:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zclEP7cfGa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EFmnQxbV",
      "display_url" : "pastebin.com\/raw.php?i=EFmn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482792506698903552",
  "text" : "http:\/\/t.co\/zclEP7cfGa Hashes: 97 Keywords: 0.11 #infoleak",
  "id" : 482792506698903552,
  "created_at" : "2014-06-28 07:47:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MpBEoBQWEw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sd45Gg7Z",
      "display_url" : "pastebin.com\/raw.php?i=sd45\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482789393090887684",
  "text" : "http:\/\/t.co\/MpBEoBQWEw Emails: 263 Hashes: 529 E\/H: 0.5 Keywords: 0.11 #infoleak",
  "id" : 482789393090887684,
  "created_at" : "2014-06-28 07:35:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GjgoKbHQqC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yp91hnYP",
      "display_url" : "pastebin.com\/raw.php?i=yp91\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482788533636038658",
  "text" : "http:\/\/t.co\/GjgoKbHQqC Emails: 86 Keywords: 0.0 #infoleak",
  "id" : 482788533636038658,
  "created_at" : "2014-06-28 07:32:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SXiQDoTMLl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D18G7Bn7",
      "display_url" : "pastebin.com\/raw.php?i=D18G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482785655047479296",
  "text" : "http:\/\/t.co\/SXiQDoTMLl Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 482785655047479296,
  "created_at" : "2014-06-28 07:20:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EhYJM9c1th",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NeZAz5Tu",
      "display_url" : "pastebin.com\/raw.php?i=NeZA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482777903533289473",
  "text" : "http:\/\/t.co\/EhYJM9c1th Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 482777903533289473,
  "created_at" : "2014-06-28 06:49:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1nXPxcxd69",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2PFYRe07",
      "display_url" : "pastebin.com\/raw.php?i=2PFY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482760257202974720",
  "text" : "http:\/\/t.co\/1nXPxcxd69 Hashes: 3 Keywords: 0.66 #infoleak",
  "id" : 482760257202974720,
  "created_at" : "2014-06-28 05:39:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dfnUUJ9Zzz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S9ghm82e",
      "display_url" : "pastebin.com\/raw.php?i=S9gh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482759518174994432",
  "text" : "http:\/\/t.co\/dfnUUJ9Zzz Emails: 534 Keywords: 0.11 #infoleak",
  "id" : 482759518174994432,
  "created_at" : "2014-06-28 05:36:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482741238492168194",
  "geo" : { },
  "id_str" : "482747114531725312",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon Ouch.",
  "id" : 482747114531725312,
  "in_reply_to_status_id" : 482741238492168194,
  "created_at" : "2014-06-28 04:47:35 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LUZw9KYhyn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a2AYFhZs",
      "display_url" : "pastebin.com\/raw.php?i=a2AY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482741238492168194",
  "text" : "http:\/\/t.co\/LUZw9KYhyn Emails: 4545 Hashes: 4545 E\/H: 1.0 Keywords: 0.52 #infoleak",
  "id" : 482741238492168194,
  "created_at" : "2014-06-28 04:24:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LpFlWFXtCh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MfimS5iR",
      "display_url" : "pastebin.com\/raw.php?i=Mfim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482736618579587072",
  "text" : "http:\/\/t.co\/LpFlWFXtCh Emails: 499 Keywords: 0.33 #infoleak",
  "id" : 482736618579587072,
  "created_at" : "2014-06-28 04:05:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/28jAdkt0n8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vQzETpUV",
      "display_url" : "pastebin.com\/raw.php?i=vQzE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482734772683169792",
  "text" : "http:\/\/t.co\/28jAdkt0n8 Emails: 564 Hashes: 210 E\/H: 2.69 Keywords: 0.11 #infoleak",
  "id" : 482734772683169792,
  "created_at" : "2014-06-28 03:58:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2Xki44gexF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3zW9uTWn",
      "display_url" : "pastebin.com\/raw.php?i=3zW9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482724725882232832",
  "text" : "http:\/\/t.co\/2Xki44gexF Hashes: 112 Keywords: 0.33 #infoleak",
  "id" : 482724725882232832,
  "created_at" : "2014-06-28 03:18:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GwncXDXmsQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FavymYBr",
      "display_url" : "pastebin.com\/raw.php?i=Favy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482723399915945984",
  "text" : "http:\/\/t.co\/GwncXDXmsQ Emails: 119 Keywords: 0.11 #infoleak",
  "id" : 482723399915945984,
  "created_at" : "2014-06-28 03:13:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U4R9Ed5wNb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8aRaNPyY",
      "display_url" : "pastebin.com\/raw.php?i=8aRa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482723048626204672",
  "text" : "http:\/\/t.co\/U4R9Ed5wNb Emails: 20 Keywords: 0.33 #infoleak",
  "id" : 482723048626204672,
  "created_at" : "2014-06-28 03:11:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/73YC17GPJ3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n85EWvzS",
      "display_url" : "pastebin.com\/raw.php?i=n85E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482713462754144257",
  "text" : "http:\/\/t.co\/73YC17GPJ3 Emails: 502 Keywords: 0.0 #infoleak",
  "id" : 482713462754144257,
  "created_at" : "2014-06-28 02:33:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eKaxO2usYm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jhUgPhSp",
      "display_url" : "pastebin.com\/raw.php?i=jhUg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482704737117024256",
  "text" : "http:\/\/t.co\/eKaxO2usYm Emails: 130 Hashes: 130 E\/H: 1.0 Keywords: 0.44 #infoleak",
  "id" : 482704737117024256,
  "created_at" : "2014-06-28 01:59:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YZgKNENbhf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EzZ17eRG",
      "display_url" : "pastebin.com\/raw.php?i=EzZ1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482699447910952960",
  "text" : "http:\/\/t.co\/YZgKNENbhf Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 482699447910952960,
  "created_at" : "2014-06-28 01:38:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5U8AOd3xoc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uuZAMmbX",
      "display_url" : "pastebin.com\/raw.php?i=uuZA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482696599936593921",
  "text" : "http:\/\/t.co\/5U8AOd3xoc Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 482696599936593921,
  "created_at" : "2014-06-28 01:26:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AEtwdSBP3y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=18Yr4Un4",
      "display_url" : "pastebin.com\/raw.php?i=18Yr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482680312221016064",
  "text" : "http:\/\/t.co\/AEtwdSBP3y Hashes: 255 Keywords: -0.14 #infoleak",
  "id" : 482680312221016064,
  "created_at" : "2014-06-28 00:22:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ve3yFxmXzK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J2PuXrBv",
      "display_url" : "pastebin.com\/raw.php?i=J2Pu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482679233215336448",
  "text" : "http:\/\/t.co\/Ve3yFxmXzK Emails: 52 Hashes: 2 E\/H: 26.0 Keywords: 0.0 #infoleak",
  "id" : 482679233215336448,
  "created_at" : "2014-06-28 00:17:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UsTgral11I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FfDvyNtH",
      "display_url" : "pastebin.com\/raw.php?i=FfDv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482678242046795777",
  "text" : "http:\/\/t.co\/UsTgral11I Emails: 246 Keywords: 0.0 #infoleak",
  "id" : 482678242046795777,
  "created_at" : "2014-06-28 00:13:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nkvWTU3B5A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FpaM9RRn",
      "display_url" : "pastebin.com\/raw.php?i=FpaM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482675995585966080",
  "text" : "http:\/\/t.co\/nkvWTU3B5A Emails: 3480 Hashes: 3480 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 482675995585966080,
  "created_at" : "2014-06-28 00:04:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yyhvPLXVZc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tAR8Jyi5",
      "display_url" : "pastebin.com\/raw.php?i=tAR8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482672796422533120",
  "text" : "http:\/\/t.co\/yyhvPLXVZc Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 482672796422533120,
  "created_at" : "2014-06-27 23:52:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IjCfBXisGs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BNCbu60v",
      "display_url" : "pastebin.com\/raw.php?i=BNCb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482672502766723073",
  "text" : "http:\/\/t.co\/IjCfBXisGs Emails: 70 Keywords: 0.0 #infoleak",
  "id" : 482672502766723073,
  "created_at" : "2014-06-27 23:51:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yF8PfcMrsq",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9316046\/text",
      "display_url" : "pastie.org\/pastes\/9316046\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481030521967759360",
  "text" : "http:\/\/t.co\/yF8PfcMrsq Found possible Google API key(s) #infoleak",
  "id" : 481030521967759360,
  "created_at" : "2014-06-23 11:06:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p7Vy9tLmsb",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9316039\/text",
      "display_url" : "pastie.org\/pastes\/9316039\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481029290578821120",
  "text" : "http:\/\/t.co\/p7Vy9tLmsb Found possible Google API key(s) #infoleak",
  "id" : 481029290578821120,
  "created_at" : "2014-06-23 11:01:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3VM3xQgT95",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9316013\/text",
      "display_url" : "pastie.org\/pastes\/9316013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481025437670203392",
  "text" : "http:\/\/t.co\/3VM3xQgT95 Found possible Google API key(s) #infoleak",
  "id" : 481025437670203392,
  "created_at" : "2014-06-23 10:46:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fse5ImOiu1",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9315452\/text",
      "display_url" : "pastie.org\/pastes\/9315452\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480930162008010753",
  "text" : "http:\/\/t.co\/Fse5ImOiu1 Found possible Google API key(s) #infoleak",
  "id" : 480930162008010753,
  "created_at" : "2014-06-23 04:27:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v5EkaX5g6V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jurrbHMm",
      "display_url" : "pastebin.com\/raw.php?i=jurr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480556522951278592",
  "text" : "http:\/\/t.co\/v5EkaX5g6V Hashes: 43 Keywords: 0.44 #infoleak",
  "id" : 480556522951278592,
  "created_at" : "2014-06-22 03:42:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KWVy1qpLyk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1rD5FxrV",
      "display_url" : "pastebin.com\/raw.php?i=1rD5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480553618798440450",
  "text" : "http:\/\/t.co\/KWVy1qpLyk Emails: 1 Hashes: 2442 E\/H: 0.0 Keywords: 0.11 #infoleak",
  "id" : 480553618798440450,
  "created_at" : "2014-06-22 03:31:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zds1EHRPE8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aBhYGu2m",
      "display_url" : "pastebin.com\/raw.php?i=aBhY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480552012983967745",
  "text" : "http:\/\/t.co\/zds1EHRPE8 Possible cisco configuration #infoleak",
  "id" : 480552012983967745,
  "created_at" : "2014-06-22 03:25:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BX765L7AQ4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=47pK89Rk",
      "display_url" : "pastebin.com\/raw.php?i=47pK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480548949200084992",
  "text" : "http:\/\/t.co\/BX765L7AQ4 Emails: 280 Keywords: 0.0 #infoleak",
  "id" : 480548949200084992,
  "created_at" : "2014-06-22 03:12:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T5rwp9JzU3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gmw04T1F",
      "display_url" : "pastebin.com\/raw.php?i=gmw0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480527264933621760",
  "text" : "http:\/\/t.co\/T5rwp9JzU3 Hashes: 3 Keywords: 0.55 #infoleak",
  "id" : 480527264933621760,
  "created_at" : "2014-06-22 01:46:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/siXanqIk8l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JAL9bM9s",
      "display_url" : "pastebin.com\/raw.php?i=JAL9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480525919358971905",
  "text" : "http:\/\/t.co\/siXanqIk8l Emails: 61 Keywords: 0.3 #infoleak",
  "id" : 480525919358971905,
  "created_at" : "2014-06-22 01:41:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u9gW0HgeN0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7JcjL8Dh",
      "display_url" : "pastebin.com\/raw.php?i=7Jcj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480508813083017216",
  "text" : "http:\/\/t.co\/u9gW0HgeN0 Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 480508813083017216,
  "created_at" : "2014-06-22 00:33:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uwtSb3t8tZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GUV70Jqa",
      "display_url" : "pastebin.com\/raw.php?i=GUV7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480505014511624192",
  "text" : "http:\/\/t.co\/uwtSb3t8tZ Emails: 4210 Keywords: 0.08 #infoleak",
  "id" : 480505014511624192,
  "created_at" : "2014-06-22 00:18:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8stLs9XVTZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vxEZzEgg",
      "display_url" : "pastebin.com\/raw.php?i=vxEZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480503650683334656",
  "text" : "http:\/\/t.co\/8stLs9XVTZ Emails: 157 Keywords: 0.0 #infoleak",
  "id" : 480503650683334656,
  "created_at" : "2014-06-22 00:12:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wq0NgI3DCd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dMbdXv7K",
      "display_url" : "pastebin.com\/raw.php?i=dMbd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480501837724790784",
  "text" : "http:\/\/t.co\/wq0NgI3DCd Hashes: 34 Keywords: -0.03 #infoleak",
  "id" : 480501837724790784,
  "created_at" : "2014-06-22 00:05:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TdrwsPgn6R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FE1Q1vz8",
      "display_url" : "pastebin.com\/raw.php?i=FE1Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480494293388234752",
  "text" : "http:\/\/t.co\/TdrwsPgn6R Emails: 285 Keywords: 0.0 #infoleak",
  "id" : 480494293388234752,
  "created_at" : "2014-06-21 23:35:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/awu3QnCLuP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aVsikaKH",
      "display_url" : "pastebin.com\/raw.php?i=aVsi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480413113158623233",
  "text" : "http:\/\/t.co\/awu3QnCLuP Emails: 112 Keywords: 0.0 #infoleak",
  "id" : 480413113158623233,
  "created_at" : "2014-06-21 18:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MKsQFLdZD5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tMnGAcB0",
      "display_url" : "pastebin.com\/raw.php?i=tMnG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480412983999209472",
  "text" : "http:\/\/t.co\/MKsQFLdZD5 Hashes: 73 Keywords: 0.0 #infoleak",
  "id" : 480412983999209472,
  "created_at" : "2014-06-21 18:12:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EYDKdn43Db",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PfmH98Pr",
      "display_url" : "pastebin.com\/raw.php?i=PfmH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480408741376835585",
  "text" : "http:\/\/t.co\/EYDKdn43Db Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 480408741376835585,
  "created_at" : "2014-06-21 17:55:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1QuqAbdX3L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jNFKKdpt",
      "display_url" : "pastebin.com\/raw.php?i=jNFK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480405990462861312",
  "text" : "http:\/\/t.co\/1QuqAbdX3L Hashes: 123 Keywords: 0.55 #infoleak",
  "id" : 480405990462861312,
  "created_at" : "2014-06-21 17:44:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hpd7Ph5VtT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4HTaqSL1",
      "display_url" : "pastebin.com\/raw.php?i=4HTa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480402918357483523",
  "text" : "http:\/\/t.co\/Hpd7Ph5VtT Emails: 5757 Hashes: 5776 E\/H: 1.0 Keywords: 0.19 #infoleak",
  "id" : 480402918357483523,
  "created_at" : "2014-06-21 17:32:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ukQyCow9Hl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W3e1ZsCA",
      "display_url" : "pastebin.com\/raw.php?i=W3e1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480402064120373249",
  "text" : "http:\/\/t.co\/ukQyCow9Hl Emails: 23 Keywords: -0.03 #infoleak",
  "id" : 480402064120373249,
  "created_at" : "2014-06-21 17:29:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A01ZrW9JEP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=10e7ef0t",
      "display_url" : "pastebin.com\/raw.php?i=10e7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480398632772849664",
  "text" : "http:\/\/t.co\/A01ZrW9JEP Emails: 537 Keywords: 0.0 #infoleak",
  "id" : 480398632772849664,
  "created_at" : "2014-06-21 17:15:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LeMiTuTD7N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nSdkxpqi",
      "display_url" : "pastebin.com\/raw.php?i=nSdk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480386704721719296",
  "text" : "http:\/\/t.co\/LeMiTuTD7N Emails: 60 Keywords: 0.11 #infoleak",
  "id" : 480386704721719296,
  "created_at" : "2014-06-21 16:28:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UyyXLQ3w1D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3wfVu6W5",
      "display_url" : "pastebin.com\/raw.php?i=3wfV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480381161496014852",
  "text" : "http:\/\/t.co\/UyyXLQ3w1D Emails: 13 Hashes: 13 E\/H: 1.0 Keywords: 0.55 #infoleak",
  "id" : 480381161496014852,
  "created_at" : "2014-06-21 16:06:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1BA6lOeStF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BZvkNHQe",
      "display_url" : "pastebin.com\/raw.php?i=BZvk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480381154298589184",
  "text" : "http:\/\/t.co\/1BA6lOeStF Possible cisco configuration #infoleak",
  "id" : 480381154298589184,
  "created_at" : "2014-06-21 16:06:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BWs4Aj0L5n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7zeAj3bG",
      "display_url" : "pastebin.com\/raw.php?i=7zeA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480380399181246465",
  "text" : "http:\/\/t.co\/BWs4Aj0L5n Emails: 392 Hashes: 6 E\/H: 65.33 Keywords: 0.0 #infoleak",
  "id" : 480380399181246465,
  "created_at" : "2014-06-21 16:03:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "briankrebs",
      "screen_name" : "briankrebs",
      "indices" : [ 0, 11 ],
      "id_str" : "22790881",
      "id" : 22790881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480350515294117889",
  "geo" : { },
  "id_str" : "480380203584090113",
  "in_reply_to_user_id" : 22790881,
  "text" : "@briankrebs Roger that. Always like to keep you in the loop, just in case.",
  "id" : 480380203584090113,
  "in_reply_to_status_id" : 480350515294117889,
  "created_at" : "2014-06-21 16:02:20 +0000",
  "in_reply_to_screen_name" : "briankrebs",
  "in_reply_to_user_id_str" : "22790881",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kq81vswza5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uHf7VWPh",
      "display_url" : "pastebin.com\/raw.php?i=uHf7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480379658421035009",
  "text" : "http:\/\/t.co\/Kq81vswza5 Hashes: 56 Keywords: 0.19 #infoleak",
  "id" : 480379658421035009,
  "created_at" : "2014-06-21 16:00:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lvzYT6QgCG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qR6E75fW",
      "display_url" : "pastebin.com\/raw.php?i=qR6E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480379140017623040",
  "text" : "http:\/\/t.co\/lvzYT6QgCG Emails: 147 Keywords: 0.0 #infoleak",
  "id" : 480379140017623040,
  "created_at" : "2014-06-21 15:58:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yFhF72RnGc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WEw7QAxn",
      "display_url" : "pastebin.com\/raw.php?i=WEw7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480368346760613889",
  "text" : "http:\/\/t.co\/yFhF72RnGc Emails: 2730 Keywords: 0.22 #infoleak",
  "id" : 480368346760613889,
  "created_at" : "2014-06-21 15:15:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ENBHT1CoO5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0w4zN4jY",
      "display_url" : "pastebin.com\/raw.php?i=0w4z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480367767044907009",
  "text" : "http:\/\/t.co\/ENBHT1CoO5 Emails: 66 Keywords: 0.0 #infoleak",
  "id" : 480367767044907009,
  "created_at" : "2014-06-21 15:12:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CE3vqV6eOs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q1DrSeBw",
      "display_url" : "pastebin.com\/raw.php?i=Q1Dr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480367137454686208",
  "text" : "http:\/\/t.co\/CE3vqV6eOs Emails: 497 Keywords: 0.0 #infoleak",
  "id" : 480367137454686208,
  "created_at" : "2014-06-21 15:10:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tdHSc1rbQ7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7tBQgvtw",
      "display_url" : "pastebin.com\/raw.php?i=7tBQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480349291416797184",
  "text" : "http:\/\/t.co\/tdHSc1rbQ7 Emails: 499 Keywords: 0.0 #infoleak",
  "id" : 480349291416797184,
  "created_at" : "2014-06-21 13:59:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C8gjqwboHP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QDqcdm42",
      "display_url" : "pastebin.com\/raw.php?i=QDqc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480328529079308290",
  "text" : "http:\/\/t.co\/C8gjqwboHP Emails: 39 Hashes: 1 E\/H: 39.0 Keywords: 0.3 #infoleak",
  "id" : 480328529079308290,
  "created_at" : "2014-06-21 12:37:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6EN1Jtwh5S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1vg6yJcu",
      "display_url" : "pastebin.com\/raw.php?i=1vg6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480322547582394368",
  "text" : "http:\/\/t.co\/6EN1Jtwh5S Emails: 271 Keywords: 0.0 #infoleak",
  "id" : 480322547582394368,
  "created_at" : "2014-06-21 12:13:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WYfyUiHh5J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kGLnHw6B",
      "display_url" : "pastebin.com\/raw.php?i=kGLn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480315381005819904",
  "text" : "http:\/\/t.co\/WYfyUiHh5J Emails: 1241 Hashes: 1241 E\/H: 1.0 Keywords: 0.55 #infoleak",
  "id" : 480315381005819904,
  "created_at" : "2014-06-21 11:44:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6fs1eH7p20",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PM18uXVd",
      "display_url" : "pastebin.com\/raw.php?i=PM18\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480294230988845056",
  "text" : "http:\/\/t.co\/6fs1eH7p20 Emails: 2 Hashes: 166 E\/H: 0.01 Keywords: 0.3 #infoleak",
  "id" : 480294230988845056,
  "created_at" : "2014-06-21 10:20:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BR596W6hP9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CTF12KND",
      "display_url" : "pastebin.com\/raw.php?i=CTF1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480277971798736896",
  "text" : "http:\/\/t.co\/BR596W6hP9 Hashes: 255 Keywords: -0.14 #infoleak",
  "id" : 480277971798736896,
  "created_at" : "2014-06-21 09:16:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8uAJ8LEjoU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KJs0X3Nn",
      "display_url" : "pastebin.com\/raw.php?i=KJs0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480277195571482624",
  "text" : "http:\/\/t.co\/8uAJ8LEjoU Emails: 220 Keywords: 0.0 #infoleak",
  "id" : 480277195571482624,
  "created_at" : "2014-06-21 09:13:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FbLfWHjv2t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y8NT3hiG",
      "display_url" : "pastebin.com\/raw.php?i=Y8NT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480268606853226496",
  "text" : "http:\/\/t.co\/FbLfWHjv2t Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 480268606853226496,
  "created_at" : "2014-06-21 08:38:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vdbOateECj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C8L5kDcm",
      "display_url" : "pastebin.com\/raw.php?i=C8L5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480246721927061504",
  "text" : "http:\/\/t.co\/vdbOateECj Emails: 200 Keywords: 0.0 #infoleak",
  "id" : 480246721927061504,
  "created_at" : "2014-06-21 07:11:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fIalcE1uVm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EYdTntQj",
      "display_url" : "pastebin.com\/raw.php?i=EYdT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480244685353394176",
  "text" : "http:\/\/t.co\/fIalcE1uVm Hashes: 31 Keywords: 0.19 #infoleak",
  "id" : 480244685353394176,
  "created_at" : "2014-06-21 07:03:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/utts0c5HeU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BtZp73J8",
      "display_url" : "pastebin.com\/raw.php?i=BtZp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480243597678084097",
  "text" : "http:\/\/t.co\/utts0c5HeU Found possible Google API key(s) #infoleak",
  "id" : 480243597678084097,
  "created_at" : "2014-06-21 06:59:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BpTtnU7MlI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1GwtrwEE",
      "display_url" : "pastebin.com\/raw.php?i=1Gwt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480239445061287936",
  "text" : "http:\/\/t.co\/BpTtnU7MlI Emails: 167 Keywords: 0.11 #infoleak",
  "id" : 480239445061287936,
  "created_at" : "2014-06-21 06:43:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MJULFiO4Ti",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xb9uJNLd",
      "display_url" : "pastebin.com\/raw.php?i=Xb9u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480231884459225090",
  "text" : "http:\/\/t.co\/MJULFiO4Ti Emails: 226 Keywords: 0.0 #infoleak",
  "id" : 480231884459225090,
  "created_at" : "2014-06-21 06:12:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EanZqy5KhZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7fZj9V4e",
      "display_url" : "pastebin.com\/raw.php?i=7fZj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480228340704370688",
  "text" : "http:\/\/t.co\/EanZqy5KhZ Emails: 60 Keywords: 0.0 #infoleak",
  "id" : 480228340704370688,
  "created_at" : "2014-06-21 05:58:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/prFAl9Ek3P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fJG47HUM",
      "display_url" : "pastebin.com\/raw.php?i=fJG4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480211750076166145",
  "text" : "http:\/\/t.co\/prFAl9Ek3P Hashes: 137 Keywords: 0.0 #infoleak",
  "id" : 480211750076166145,
  "created_at" : "2014-06-21 04:52:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xOPPhDyr68",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8aQaBVQa",
      "display_url" : "pastebin.com\/raw.php?i=8aQa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480209642547470337",
  "text" : "http:\/\/t.co\/xOPPhDyr68 Emails: 1 Hashes: 2438 E\/H: 0.0 Keywords: 0.11 #infoleak",
  "id" : 480209642547470337,
  "created_at" : "2014-06-21 04:44:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yeZkYOAymz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1FnNM6G7",
      "display_url" : "pastebin.com\/raw.php?i=1FnN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480208533938393088",
  "text" : "http:\/\/t.co\/yeZkYOAymz Emails: 1783 Keywords: 0.33 #infoleak",
  "id" : 480208533938393088,
  "created_at" : "2014-06-21 04:40:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tbvkqjewPD",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9310297\/text",
      "display_url" : "pastie.org\/pastes\/9310297\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480205452530032642",
  "text" : "http:\/\/t.co\/tbvkqjewPD Keywords: 0.55 #infoleak",
  "id" : 480205452530032642,
  "created_at" : "2014-06-21 04:27:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JZNEJhwBN7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WuDvPPmt",
      "display_url" : "pastebin.com\/raw.php?i=WuDv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480192967513092100",
  "text" : "http:\/\/t.co\/JZNEJhwBN7 Hashes: 310 Keywords: 0.33 #infoleak",
  "id" : 480192967513092100,
  "created_at" : "2014-06-21 03:38:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tk2rCl2kRw",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2icteUuCI",
      "display_url" : "slexy.org\/raw\/s2icteUuCI"
    } ]
  },
  "geo" : { },
  "id_str" : "480191249698144257",
  "text" : "http:\/\/t.co\/tk2rCl2kRw Emails: 30 Keywords: 0.33 #infoleak",
  "id" : 480191249698144257,
  "created_at" : "2014-06-21 03:31:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bib8j69NWp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bUq60ZKA",
      "display_url" : "pastebin.com\/raw.php?i=bUq6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480186893846319104",
  "text" : "http:\/\/t.co\/bib8j69NWp Emails: 134 Keywords: 0.11 #infoleak",
  "id" : 480186893846319104,
  "created_at" : "2014-06-21 03:14:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tbuf3ESHhW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yL2BQgDH",
      "display_url" : "pastebin.com\/raw.php?i=yL2B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480186788590264321",
  "text" : "http:\/\/t.co\/Tbuf3ESHhW Emails: 170 Keywords: 0.0 #infoleak",
  "id" : 480186788590264321,
  "created_at" : "2014-06-21 03:13:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dxFLdVX0wh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TKvvach0",
      "display_url" : "pastebin.com\/raw.php?i=TKvv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480186047284781057",
  "text" : "http:\/\/t.co\/dxFLdVX0wh Emails: 126 Keywords: 0.0 #infoleak",
  "id" : 480186047284781057,
  "created_at" : "2014-06-21 03:10:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yYiDxxHCTR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PU3ZPrpZ",
      "display_url" : "pastebin.com\/raw.php?i=PU3Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480183903353716736",
  "text" : "http:\/\/t.co\/yYiDxxHCTR Emails: 447 Keywords: 0.0 #infoleak",
  "id" : 480183903353716736,
  "created_at" : "2014-06-21 03:02:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YWWOsHs7TF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HewKK2AD",
      "display_url" : "pastebin.com\/raw.php?i=HewK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480182756131893248",
  "text" : "http:\/\/t.co\/YWWOsHs7TF Hashes: 30 Keywords: 0.33 #infoleak",
  "id" : 480182756131893248,
  "created_at" : "2014-06-21 02:57:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UgWyOYO8XA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VVWxbXAF",
      "display_url" : "pastebin.com\/raw.php?i=VVWx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480182409724305408",
  "text" : "http:\/\/t.co\/UgWyOYO8XA Hashes: 4528 Keywords: -0.03 #infoleak",
  "id" : 480182409724305408,
  "created_at" : "2014-06-21 02:56:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bbZIDfkryj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yHftUe5i",
      "display_url" : "pastebin.com\/raw.php?i=yHft\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480182067607527424",
  "text" : "http:\/\/t.co\/bbZIDfkryj Hashes: 42 Keywords: 0.22 #infoleak",
  "id" : 480182067607527424,
  "created_at" : "2014-06-21 02:55:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zr3TW9lifg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EzwSB5hB",
      "display_url" : "pastebin.com\/raw.php?i=EzwS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480170464140992512",
  "text" : "http:\/\/t.co\/zr3TW9lifg Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 480170464140992512,
  "created_at" : "2014-06-21 02:08:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uZK1n5DiPW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xprWws1i",
      "display_url" : "pastebin.com\/raw.php?i=xprW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480170419626852352",
  "text" : "http:\/\/t.co\/uZK1n5DiPW Hashes: 48 Keywords: 0.05 #infoleak",
  "id" : 480170419626852352,
  "created_at" : "2014-06-21 02:08:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/greERVzk21",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sEKja1Uy",
      "display_url" : "pastebin.com\/raw.php?i=sEKj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480164160697692161",
  "text" : "http:\/\/t.co\/greERVzk21 Found possible Google API key(s) #infoleak",
  "id" : 480164160697692161,
  "created_at" : "2014-06-21 01:43:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e9F8FnfTGI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8X4dJE67",
      "display_url" : "pastebin.com\/raw.php?i=8X4d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480155844453998593",
  "text" : "http:\/\/t.co\/e9F8FnfTGI Hashes: 42 Keywords: 0.16 #infoleak",
  "id" : 480155844453998593,
  "created_at" : "2014-06-21 01:10:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iQIwLS4GjU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2gRZL8BL",
      "display_url" : "pastebin.com\/raw.php?i=2gRZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480155105769959426",
  "text" : "http:\/\/t.co\/iQIwLS4GjU Emails: 303 Keywords: 0.0 #infoleak",
  "id" : 480155105769959426,
  "created_at" : "2014-06-21 01:07:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/foLKj0Zi0B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SN9jQLfg",
      "display_url" : "pastebin.com\/raw.php?i=SN9j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480148040662011904",
  "text" : "http:\/\/t.co\/foLKj0Zi0B Emails: 32 Hashes: 32 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 480148040662011904,
  "created_at" : "2014-06-21 00:39:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AGwHtMpBQD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CRE38teP",
      "display_url" : "pastebin.com\/raw.php?i=CRE3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480141275765559296",
  "text" : "http:\/\/t.co\/AGwHtMpBQD Emails: 84 Keywords: 0.0 #infoleak",
  "id" : 480141275765559296,
  "created_at" : "2014-06-21 00:12:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M9ZImafL6S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SaJ0vCmd",
      "display_url" : "pastebin.com\/raw.php?i=SaJ0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480139643380187136",
  "text" : "http:\/\/t.co\/M9ZImafL6S Emails: 20 Hashes: 46 E\/H: 0.43 Keywords: 0.22 #infoleak",
  "id" : 480139643380187136,
  "created_at" : "2014-06-21 00:06:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VIpUonWm75",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dbvuhETA",
      "display_url" : "pastebin.com\/raw.php?i=dbvu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480111464447885312",
  "text" : "http:\/\/t.co\/VIpUonWm75 Found possible Google API key(s) #infoleak",
  "id" : 480111464447885312,
  "created_at" : "2014-06-20 22:14:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gabWtdaBm0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S5dBAs0M",
      "display_url" : "pastebin.com\/raw.php?i=S5dB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480096005367410688",
  "text" : "http:\/\/t.co\/gabWtdaBm0 Emails: 147 Keywords: 0.0 #infoleak",
  "id" : 480096005367410688,
  "created_at" : "2014-06-20 21:13:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4QoFRmGZ6G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dScKyhq5",
      "display_url" : "pastebin.com\/raw.php?i=dScK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480086451766296577",
  "text" : "http:\/\/t.co\/4QoFRmGZ6G Hashes: 255 Keywords: -0.03 #infoleak",
  "id" : 480086451766296577,
  "created_at" : "2014-06-20 20:35:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jie5ApIuce",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=swTbt70C",
      "display_url" : "pastebin.com\/raw.php?i=swTb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480083926686265344",
  "text" : "http:\/\/t.co\/jie5ApIuce Emails: 160 Keywords: 0.33 #infoleak",
  "id" : 480083926686265344,
  "created_at" : "2014-06-20 20:25:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tUfuGAP7rg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8mrc71iw",
      "display_url" : "pastebin.com\/raw.php?i=8mrc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480082558126796800",
  "text" : "http:\/\/t.co\/tUfuGAP7rg Emails: 1 Hashes: 44 E\/H: 0.02 Keywords: 0.08 #infoleak",
  "id" : 480082558126796800,
  "created_at" : "2014-06-20 20:19:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gHGOOR42BV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t40aCEU4",
      "display_url" : "pastebin.com\/raw.php?i=t40a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480081706901192704",
  "text" : "http:\/\/t.co\/gHGOOR42BV Emails: 2 Keywords: 0.66 #infoleak",
  "id" : 480081706901192704,
  "created_at" : "2014-06-20 20:16:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qv6zltLqya",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TJYx7Qsv",
      "display_url" : "pastebin.com\/raw.php?i=TJYx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480077648576532480",
  "text" : "http:\/\/t.co\/Qv6zltLqya Hashes: 72 Keywords: 0.33 #infoleak",
  "id" : 480077648576532480,
  "created_at" : "2014-06-20 20:00:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zNBuSMqMxN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fqu1j7wa",
      "display_url" : "pastebin.com\/raw.php?i=Fqu1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480060004376928257",
  "text" : "http:\/\/t.co\/zNBuSMqMxN Emails: 53 Keywords: 0.0 #infoleak",
  "id" : 480060004376928257,
  "created_at" : "2014-06-20 18:49:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    }, {
      "name" : "briankrebs",
      "screen_name" : "briankrebs",
      "indices" : [ 9, 20 ],
      "id_str" : "22790881",
      "id" : 22790881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480053122216124417",
  "geo" : { },
  "id_str" : "480059403081502720",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon @briankrebs Just thought you should know about this.",
  "id" : 480059403081502720,
  "in_reply_to_status_id" : 480053122216124417,
  "created_at" : "2014-06-20 18:47:35 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vhMmG2EnZS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n0pvzy3Q",
      "display_url" : "pastebin.com\/raw.php?i=n0pv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480058073449365504",
  "text" : "http:\/\/t.co\/vhMmG2EnZS Hashes: 43 Keywords: 0.05 #infoleak",
  "id" : 480058073449365504,
  "created_at" : "2014-06-20 18:42:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cNGSn6atuY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VXXaDec8",
      "display_url" : "pastebin.com\/raw.php?i=VXXa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480056925522907136",
  "text" : "http:\/\/t.co\/cNGSn6atuY Hashes: 2364 Keywords: 0.11 #infoleak",
  "id" : 480056925522907136,
  "created_at" : "2014-06-20 18:37:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h165ZsVdO1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BRNWMHj7",
      "display_url" : "pastebin.com\/raw.php?i=BRNW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480055901882028032",
  "text" : "http:\/\/t.co\/h165ZsVdO1 Emails: 467 Keywords: 0.0 #infoleak",
  "id" : 480055901882028032,
  "created_at" : "2014-06-20 18:33:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HwMHCjHE5X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9TkckFj0",
      "display_url" : "pastebin.com\/raw.php?i=9Tkc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480054293341298688",
  "text" : "http:\/\/t.co\/HwMHCjHE5X Emails: 338 Keywords: 0.11 #infoleak",
  "id" : 480054293341298688,
  "created_at" : "2014-06-20 18:27:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f6pOYHBIjq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GzhEiemv",
      "display_url" : "pastebin.com\/raw.php?i=GzhE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480054074063060992",
  "text" : "http:\/\/t.co\/f6pOYHBIjq Emails: 25 Hashes: 11 E\/H: 2.27 Keywords: 0.0 #infoleak",
  "id" : 480054074063060992,
  "created_at" : "2014-06-20 18:26:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zEQAoLgL3Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b3nwaC9d",
      "display_url" : "pastebin.com\/raw.php?i=b3nw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480053122216124417",
  "text" : "http:\/\/t.co\/zEQAoLgL3Z Emails: 1074 Keywords: 0.22 #infoleak",
  "id" : 480053122216124417,
  "created_at" : "2014-06-20 18:22:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t5gFvYEQn7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FSFV0hQF",
      "display_url" : "pastebin.com\/raw.php?i=FSFV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480050693596647424",
  "text" : "http:\/\/t.co\/t5gFvYEQn7 Emails: 148 Keywords: 0.0 #infoleak",
  "id" : 480050693596647424,
  "created_at" : "2014-06-20 18:12:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t2TGsbzz1z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=akZxWYcY",
      "display_url" : "pastebin.com\/raw.php?i=akZx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480048863298875392",
  "text" : "http:\/\/t.co\/t2TGsbzz1z Emails: 2472 Hashes: 2469 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 480048863298875392,
  "created_at" : "2014-06-20 18:05:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LZnwOOKsoL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RBJ60sck",
      "display_url" : "pastebin.com\/raw.php?i=RBJ6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480047723794530304",
  "text" : "http:\/\/t.co\/LZnwOOKsoL Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 480047723794530304,
  "created_at" : "2014-06-20 18:01:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8ehNYwfoE7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5ydFt9Rz",
      "display_url" : "pastebin.com\/raw.php?i=5ydF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480045092149800960",
  "text" : "http:\/\/t.co\/8ehNYwfoE7 Found possible Google API key(s) #infoleak",
  "id" : 480045092149800960,
  "created_at" : "2014-06-20 17:50:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xXkGn9k0mp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=egPRvXDA",
      "display_url" : "pastebin.com\/raw.php?i=egPR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480037344372731904",
  "text" : "http:\/\/t.co\/xXkGn9k0mp Hashes: 126 Keywords: 0.22 #infoleak",
  "id" : 480037344372731904,
  "created_at" : "2014-06-20 17:19:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eyqeeNGO4u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MRwyXMfV",
      "display_url" : "pastebin.com\/raw.php?i=MRwy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480024193501655041",
  "text" : "http:\/\/t.co\/eyqeeNGO4u Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 480024193501655041,
  "created_at" : "2014-06-20 16:27:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E8CPZBmJXe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z2WKhgg1",
      "display_url" : "pastebin.com\/raw.php?i=Z2WK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480015128377556992",
  "text" : "http:\/\/t.co\/E8CPZBmJXe Emails: 26 Keywords: 0.33 #infoleak",
  "id" : 480015128377556992,
  "created_at" : "2014-06-20 15:51:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TQe85FtlKA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TpSbY4DD",
      "display_url" : "pastebin.com\/raw.php?i=TpSb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480013515797716992",
  "text" : "http:\/\/t.co\/TQe85FtlKA Hashes: 49 Keywords: 0.0 #infoleak",
  "id" : 480013515797716992,
  "created_at" : "2014-06-20 15:45:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bpPY5f2hE6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WGs1w4w2",
      "display_url" : "pastebin.com\/raw.php?i=WGs1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480009184360935424",
  "text" : "http:\/\/t.co\/bpPY5f2hE6 Keywords: 0.55 #infoleak",
  "id" : 480009184360935424,
  "created_at" : "2014-06-20 15:28:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hhXdTzYt6X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EP8RmFzA",
      "display_url" : "pastebin.com\/raw.php?i=EP8R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480008514077601793",
  "text" : "http:\/\/t.co\/hhXdTzYt6X Hashes: 87 Keywords: 0.33 #infoleak",
  "id" : 480008514077601793,
  "created_at" : "2014-06-20 15:25:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hVVAHZbNmm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7L1nU42s",
      "display_url" : "pastebin.com\/raw.php?i=7L1n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480006883856490497",
  "text" : "http:\/\/t.co\/hVVAHZbNmm Emails: 158 Keywords: 0.08 #infoleak",
  "id" : 480006883856490497,
  "created_at" : "2014-06-20 15:18:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y9LVz0JgFU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=byjuvqYJ",
      "display_url" : "pastebin.com\/raw.php?i=byju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480006523247013889",
  "text" : "http:\/\/t.co\/y9LVz0JgFU Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 480006523247013889,
  "created_at" : "2014-06-20 15:17:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4X0eAtPr9I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z4axDbyE",
      "display_url" : "pastebin.com\/raw.php?i=Z4ax\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480005495902593025",
  "text" : "http:\/\/t.co\/4X0eAtPr9I Emails: 75 Keywords: 0.0 #infoleak",
  "id" : 480005495902593025,
  "created_at" : "2014-06-20 15:13:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SDZ7nRrdNB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dUrHX7zu",
      "display_url" : "pastebin.com\/raw.php?i=dUrH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479994175400583170",
  "text" : "http:\/\/t.co\/SDZ7nRrdNB Hashes: 126 Keywords: 0.11 #infoleak",
  "id" : 479994175400583170,
  "created_at" : "2014-06-20 14:28:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wspa18TOK2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aMMj2vhT",
      "display_url" : "pastebin.com\/raw.php?i=aMMj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479988715842859011",
  "text" : "http:\/\/t.co\/wspa18TOK2 Emails: 57 Keywords: 0.0 #infoleak",
  "id" : 479988715842859011,
  "created_at" : "2014-06-20 14:06:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EHEN0rBxCY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7P4Yi6M9",
      "display_url" : "pastebin.com\/raw.php?i=7P4Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479978553245577216",
  "text" : "http:\/\/t.co\/EHEN0rBxCY Emails: 1000 Hashes: 5 E\/H: 200.0 Keywords: 0.33 #infoleak",
  "id" : 479978553245577216,
  "created_at" : "2014-06-20 13:26:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FHU1Pasd3z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9gacD2b0",
      "display_url" : "pastebin.com\/raw.php?i=9gac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479960101306892288",
  "text" : "http:\/\/t.co\/FHU1Pasd3z Emails: 128 Keywords: 0.0 #infoleak",
  "id" : 479960101306892288,
  "created_at" : "2014-06-20 12:13:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cXhL5DH28J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DJ5snd9z",
      "display_url" : "pastebin.com\/raw.php?i=DJ5s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479954855054684160",
  "text" : "http:\/\/t.co\/cXhL5DH28J Emails: 128 Keywords: -0.03 #infoleak",
  "id" : 479954855054684160,
  "created_at" : "2014-06-20 11:52:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SHc9LmUpGr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KS9LgVS0",
      "display_url" : "pastebin.com\/raw.php?i=KS9L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479949194082258945",
  "text" : "http:\/\/t.co\/SHc9LmUpGr Emails: 34 Keywords: 0.11 #infoleak",
  "id" : 479949194082258945,
  "created_at" : "2014-06-20 11:29:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fUY4UBLuhV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BeN6ua3g",
      "display_url" : "pastebin.com\/raw.php?i=BeN6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479945139113050113",
  "text" : "http:\/\/t.co\/fUY4UBLuhV Emails: 25 Keywords: -0.14 #infoleak",
  "id" : 479945139113050113,
  "created_at" : "2014-06-20 11:13:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LQP4gvbK5G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bz46Jyvw",
      "display_url" : "pastebin.com\/raw.php?i=Bz46\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479942578507239424",
  "text" : "http:\/\/t.co\/LQP4gvbK5G Hashes: 69 Keywords: -0.06 #infoleak",
  "id" : 479942578507239424,
  "created_at" : "2014-06-20 11:03:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CzBfDPXF7O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JQSvChBJ",
      "display_url" : "pastebin.com\/raw.php?i=JQSv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479937891452198912",
  "text" : "http:\/\/t.co\/CzBfDPXF7O Hashes: 126 Keywords: 0.22 #infoleak",
  "id" : 479937891452198912,
  "created_at" : "2014-06-20 10:44:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mj3wieNAQc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f0U8c50s",
      "display_url" : "pastebin.com\/raw.php?i=f0U8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479914803964563456",
  "text" : "http:\/\/t.co\/Mj3wieNAQc Emails: 265 Keywords: 0.0 #infoleak",
  "id" : 479914803964563456,
  "created_at" : "2014-06-20 09:13:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eIDf8vruvm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=utS49W5B",
      "display_url" : "pastebin.com\/raw.php?i=utS4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479910917635719168",
  "text" : "http:\/\/t.co\/eIDf8vruvm Emails: 106 Keywords: 0.33 #infoleak",
  "id" : 479910917635719168,
  "created_at" : "2014-06-20 08:57:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fr4J93OVzu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n6czfD3c",
      "display_url" : "pastebin.com\/raw.php?i=n6cz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479903883167154178",
  "text" : "http:\/\/t.co\/Fr4J93OVzu Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 479903883167154178,
  "created_at" : "2014-06-20 08:29:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wsphySE4T3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=atzBfhXH",
      "display_url" : "pastebin.com\/raw.php?i=atzB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479901005539065856",
  "text" : "http:\/\/t.co\/wsphySE4T3 Emails: 55 Hashes: 58 E\/H: 0.95 Keywords: 0.22 #infoleak",
  "id" : 479901005539065856,
  "created_at" : "2014-06-20 08:18:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YMQfz3L0n8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9k9fk8M3",
      "display_url" : "pastebin.com\/raw.php?i=9k9f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479887069037072384",
  "text" : "http:\/\/t.co\/YMQfz3L0n8 Emails: 136 Keywords: 0.0 #infoleak",
  "id" : 479887069037072384,
  "created_at" : "2014-06-20 07:22:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TZK6mK4sxz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nrXzzBFr",
      "display_url" : "pastebin.com\/raw.php?i=nrXz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479869616450056192",
  "text" : "http:\/\/t.co\/TZK6mK4sxz Emails: 146 Keywords: 0.0 #infoleak",
  "id" : 479869616450056192,
  "created_at" : "2014-06-20 06:13:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gS44BNHf7X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nUPwR0Bt",
      "display_url" : "pastebin.com\/raw.php?i=nUPw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479869202300276737",
  "text" : "http:\/\/t.co\/gS44BNHf7X Emails: 125 Keywords: 0.0 #infoleak",
  "id" : 479869202300276737,
  "created_at" : "2014-06-20 06:11:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vR7CJaI9Sd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NqCspCgw",
      "display_url" : "pastebin.com\/raw.php?i=NqCs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479849173399769088",
  "text" : "http:\/\/t.co\/vR7CJaI9Sd Keywords: 0.55 #infoleak",
  "id" : 479849173399769088,
  "created_at" : "2014-06-20 04:52:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FSUqWusAEi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xrg9pJ6S",
      "display_url" : "pastebin.com\/raw.php?i=xrg9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479848923142438912",
  "text" : "http:\/\/t.co\/FSUqWusAEi Emails: 305 Keywords: 0.11 #infoleak",
  "id" : 479848923142438912,
  "created_at" : "2014-06-20 04:51:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kmd84gJ0s7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BPerQmXB",
      "display_url" : "pastebin.com\/raw.php?i=BPer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479846221909999616",
  "text" : "http:\/\/t.co\/Kmd84gJ0s7 Emails: 1086 Keywords: 0.22 #infoleak",
  "id" : 479846221909999616,
  "created_at" : "2014-06-20 04:40:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/awgJwMrS9b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Nhi7XYmV",
      "display_url" : "pastebin.com\/raw.php?i=Nhi7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479846015223091202",
  "text" : "http:\/\/t.co\/awgJwMrS9b Emails: 239 Keywords: 0.22 #infoleak",
  "id" : 479846015223091202,
  "created_at" : "2014-06-20 04:39:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h8NOMdQ7Lg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nKg4kEwC",
      "display_url" : "pastebin.com\/raw.php?i=nKg4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479842603437813761",
  "text" : "http:\/\/t.co\/h8NOMdQ7Lg Hashes: 88 Keywords: 0.33 #infoleak",
  "id" : 479842603437813761,
  "created_at" : "2014-06-20 04:26:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U0uUV86jvo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dqrFJqE3",
      "display_url" : "pastebin.com\/raw.php?i=dqrF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479840260197597184",
  "text" : "http:\/\/t.co\/U0uUV86jvo Hashes: 73 Keywords: 0.33 #infoleak",
  "id" : 479840260197597184,
  "created_at" : "2014-06-20 04:16:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CP2MHWkrU9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=edHtwd65",
      "display_url" : "pastebin.com\/raw.php?i=edHt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479837256614563840",
  "text" : "http:\/\/t.co\/CP2MHWkrU9 Hashes: 1023 Keywords: 0.11 #infoleak",
  "id" : 479837256614563840,
  "created_at" : "2014-06-20 04:04:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xfwc7lmp9y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8JYwkrhs",
      "display_url" : "pastebin.com\/raw.php?i=8JYw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479828236008845312",
  "text" : "http:\/\/t.co\/Xfwc7lmp9y Hashes: 157 Keywords: 0.11 #infoleak",
  "id" : 479828236008845312,
  "created_at" : "2014-06-20 03:29:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BQOgiraes9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pxQPZ40N",
      "display_url" : "pastebin.com\/raw.php?i=pxQP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479824734750646273",
  "text" : "http:\/\/t.co\/BQOgiraes9 Emails: 352 Keywords: 0.22 #infoleak",
  "id" : 479824734750646273,
  "created_at" : "2014-06-20 03:15:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FMLC3BQ1hb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pUQ8hRCj",
      "display_url" : "pastebin.com\/raw.php?i=pUQ8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479824276678127616",
  "text" : "http:\/\/t.co\/FMLC3BQ1hb Emails: 151 Keywords: 0.0 #infoleak",
  "id" : 479824276678127616,
  "created_at" : "2014-06-20 03:13:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3vKIEF4kA0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LqfUZc5D",
      "display_url" : "pastebin.com\/raw.php?i=LqfU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479818579689209856",
  "text" : "http:\/\/t.co\/3vKIEF4kA0 Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 479818579689209856,
  "created_at" : "2014-06-20 02:50:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/whi1kYEyOC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wpX5pFv3",
      "display_url" : "pastebin.com\/raw.php?i=wpX5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479818255284989952",
  "text" : "http:\/\/t.co\/whi1kYEyOC Hashes: 40 Keywords: 0.22 #infoleak",
  "id" : 479818255284989952,
  "created_at" : "2014-06-20 02:49:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kI0yDzjjsg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WQKaBnqa",
      "display_url" : "pastebin.com\/raw.php?i=WQKa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479815772424773632",
  "text" : "http:\/\/t.co\/kI0yDzjjsg Possible cisco configuration #infoleak",
  "id" : 479815772424773632,
  "created_at" : "2014-06-20 02:39:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bM6x0MsqwZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6rLQyjfe",
      "display_url" : "pastebin.com\/raw.php?i=6rLQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479804454045089792",
  "text" : "http:\/\/t.co\/bM6x0MsqwZ Emails: 116 Keywords: -0.14 #infoleak",
  "id" : 479804454045089792,
  "created_at" : "2014-06-20 01:54:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uZWkr1F6QX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HPacpDNC",
      "display_url" : "pastebin.com\/raw.php?i=HPac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479803885431705600",
  "text" : "http:\/\/t.co\/uZWkr1F6QX Keywords: 0.55 #infoleak",
  "id" : 479803885431705600,
  "created_at" : "2014-06-20 01:52:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u4ydRJ7oIu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GDUMtHSq",
      "display_url" : "pastebin.com\/raw.php?i=GDUM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479803043022532608",
  "text" : "http:\/\/t.co\/u4ydRJ7oIu Keywords: 0.55 #infoleak",
  "id" : 479803043022532608,
  "created_at" : "2014-06-20 01:48:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A5rWoDp1kk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VzYM5DB3",
      "display_url" : "pastebin.com\/raw.php?i=VzYM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479799707586138112",
  "text" : "http:\/\/t.co\/A5rWoDp1kk Emails: 1340 Keywords: 0.33 #infoleak",
  "id" : 479799707586138112,
  "created_at" : "2014-06-20 01:35:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UHJdomsnBi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NfUGdE2E",
      "display_url" : "pastebin.com\/raw.php?i=NfUG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479795532831809536",
  "text" : "http:\/\/t.co\/UHJdomsnBi Emails: 72 Keywords: 0.0 #infoleak",
  "id" : 479795532831809536,
  "created_at" : "2014-06-20 01:19:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2RTjXk0e0l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xzVNN5CB",
      "display_url" : "pastebin.com\/raw.php?i=xzVN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479792758106771456",
  "text" : "http:\/\/t.co\/2RTjXk0e0l Emails: 2075 Keywords: 0.22 #infoleak",
  "id" : 479792758106771456,
  "created_at" : "2014-06-20 01:08:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/djS0LIwR7G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QvkmBJue",
      "display_url" : "pastebin.com\/raw.php?i=Qvkm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479784688190373888",
  "text" : "http:\/\/t.co\/djS0LIwR7G Possible cisco configuration #infoleak",
  "id" : 479784688190373888,
  "created_at" : "2014-06-20 00:35:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iblUhMypuu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZEprsVYn",
      "display_url" : "pastebin.com\/raw.php?i=ZEpr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479780384175968256",
  "text" : "http:\/\/t.co\/iblUhMypuu Emails: 38 Keywords: -0.03 #infoleak",
  "id" : 479780384175968256,
  "created_at" : "2014-06-20 00:18:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/viSQ8YNE1t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CtvfEaFx",
      "display_url" : "pastebin.com\/raw.php?i=Ctvf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479778932846108672",
  "text" : "http:\/\/t.co\/viSQ8YNE1t Emails: 199 Keywords: 0.0 #infoleak",
  "id" : 479778932846108672,
  "created_at" : "2014-06-20 00:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TaBlh8NkPO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kMmx3MU7",
      "display_url" : "pastebin.com\/raw.php?i=kMmx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479776758242099204",
  "text" : "http:\/\/t.co\/TaBlh8NkPO Emails: 261 Keywords: -0.03 #infoleak",
  "id" : 479776758242099204,
  "created_at" : "2014-06-20 00:04:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FVCEtSHo5N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cq3Ds0gi",
      "display_url" : "pastebin.com\/raw.php?i=cq3D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479770320945938432",
  "text" : "http:\/\/t.co\/FVCEtSHo5N Emails: 23 Keywords: -0.03 #infoleak",
  "id" : 479770320945938432,
  "created_at" : "2014-06-19 23:38:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dTq4bzQKtC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tnu7vi0W",
      "display_url" : "pastebin.com\/raw.php?i=tnu7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479757496349765632",
  "text" : "http:\/\/t.co\/dTq4bzQKtC Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 479757496349765632,
  "created_at" : "2014-06-19 22:47:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SPti9YhhTm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6Mj0d5XZ",
      "display_url" : "pastebin.com\/raw.php?i=6Mj0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479751780444553216",
  "text" : "http:\/\/t.co\/SPti9YhhTm Emails: 460 Keywords: 0.11 #infoleak",
  "id" : 479751780444553216,
  "created_at" : "2014-06-19 22:25:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bh2q0iJGke",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mZ3D0paa",
      "display_url" : "pastebin.com\/raw.php?i=mZ3D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479741339580379137",
  "text" : "http:\/\/t.co\/bh2q0iJGke Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 479741339580379137,
  "created_at" : "2014-06-19 21:43:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kIdbziI3L4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dCALV6Qp",
      "display_url" : "pastebin.com\/raw.php?i=dCAL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479737358510997505",
  "text" : "http:\/\/t.co\/kIdbziI3L4 Emails: 289 Keywords: 0.0 #infoleak",
  "id" : 479737358510997505,
  "created_at" : "2014-06-19 21:27:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uZnHWmjOAa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wJgcGM65",
      "display_url" : "pastebin.com\/raw.php?i=wJgc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479734105727197184",
  "text" : "http:\/\/t.co\/uZnHWmjOAa Keywords: 0.55 #infoleak",
  "id" : 479734105727197184,
  "created_at" : "2014-06-19 21:14:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9kW3evgBBE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kSJFe0SQ",
      "display_url" : "pastebin.com\/raw.php?i=kSJF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479733607976546304",
  "text" : "http:\/\/t.co\/9kW3evgBBE Emails: 196 Keywords: 0.0 #infoleak",
  "id" : 479733607976546304,
  "created_at" : "2014-06-19 21:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/azCIDPNvXx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R8GsUdEC",
      "display_url" : "pastebin.com\/raw.php?i=R8Gs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479719072225972224",
  "text" : "http:\/\/t.co\/azCIDPNvXx Emails: 46 Keywords: 0.02 #infoleak",
  "id" : 479719072225972224,
  "created_at" : "2014-06-19 20:15:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2x6MvRuKRu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UsknnzcR",
      "display_url" : "pastebin.com\/raw.php?i=Uskn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479716896439140352",
  "text" : "http:\/\/t.co\/2x6MvRuKRu Emails: 294 Keywords: 0.11 #infoleak",
  "id" : 479716896439140352,
  "created_at" : "2014-06-19 20:06:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8OJvA1Wx4Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fsu5heKp",
      "display_url" : "pastebin.com\/raw.php?i=Fsu5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479709110309380096",
  "text" : "http:\/\/t.co\/8OJvA1Wx4Z Hashes: 102 Keywords: 0.33 #infoleak",
  "id" : 479709110309380096,
  "created_at" : "2014-06-19 19:35:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1BEBgw8Fds",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gVRgj3tn",
      "display_url" : "pastebin.com\/raw.php?i=gVRg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479708221167243264",
  "text" : "http:\/\/t.co\/1BEBgw8Fds Hashes: 73 Keywords: 0.33 #infoleak",
  "id" : 479708221167243264,
  "created_at" : "2014-06-19 19:32:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iivGx8HacU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ADyfCWBZ",
      "display_url" : "pastebin.com\/raw.php?i=ADyf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479695219344932864",
  "text" : "http:\/\/t.co\/iivGx8HacU Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 479695219344932864,
  "created_at" : "2014-06-19 18:40:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9iF7cAnUwz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4b8CjUvA",
      "display_url" : "pastebin.com\/raw.php?i=4b8C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479688961275600897",
  "text" : "http:\/\/t.co\/9iF7cAnUwz Emails: 103 Keywords: 0.0 #infoleak",
  "id" : 479688961275600897,
  "created_at" : "2014-06-19 18:15:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v6FavfxkqX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Df7EnfTf",
      "display_url" : "pastebin.com\/raw.php?i=Df7E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479688911057207296",
  "text" : "http:\/\/t.co\/v6FavfxkqX Emails: 73 Keywords: 0.22 #infoleak",
  "id" : 479688911057207296,
  "created_at" : "2014-06-19 18:15:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e7ueXUgXp1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CrBQBqPZ",
      "display_url" : "pastebin.com\/raw.php?i=CrBQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479688250907316224",
  "text" : "http:\/\/t.co\/e7ueXUgXp1 Emails: 120 Keywords: 0.0 #infoleak",
  "id" : 479688250907316224,
  "created_at" : "2014-06-19 18:12:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JSx9binB7l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=35Aug7uU",
      "display_url" : "pastebin.com\/raw.php?i=35Au\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479686890463825921",
  "text" : "http:\/\/t.co\/JSx9binB7l Emails: 73 Keywords: 0.22 #infoleak",
  "id" : 479686890463825921,
  "created_at" : "2014-06-19 18:07:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tRPzYEAsrz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jGiPmB9r",
      "display_url" : "pastebin.com\/raw.php?i=jGiP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479680637159223297",
  "text" : "http:\/\/t.co\/tRPzYEAsrz Hashes: 2 Keywords: 0.66 #infoleak",
  "id" : 479680637159223297,
  "created_at" : "2014-06-19 17:42:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qLSXFRIlOS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GntHaXHw",
      "display_url" : "pastebin.com\/raw.php?i=GntH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479680148103364608",
  "text" : "http:\/\/t.co\/qLSXFRIlOS Hashes: 76 Keywords: 0.0 #infoleak",
  "id" : 479680148103364608,
  "created_at" : "2014-06-19 17:40:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yvFcNGixhL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G99wgXUF",
      "display_url" : "pastebin.com\/raw.php?i=G99w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479679389282488320",
  "text" : "http:\/\/t.co\/yvFcNGixhL Emails: 538 Keywords: 0.0 #infoleak",
  "id" : 479679389282488320,
  "created_at" : "2014-06-19 17:37:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ijbOIUCr0g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TnHZMEda",
      "display_url" : "pastebin.com\/raw.php?i=TnHZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479679108163461120",
  "text" : "http:\/\/t.co\/ijbOIUCr0g Keywords: 0.55 #infoleak",
  "id" : 479679108163461120,
  "created_at" : "2014-06-19 17:36:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9ptX4BhA9e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KgNn0emj",
      "display_url" : "pastebin.com\/raw.php?i=KgNn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479677075184308224",
  "text" : "http:\/\/t.co\/9ptX4BhA9e Hashes: 114 Keywords: 0.11 #infoleak",
  "id" : 479677075184308224,
  "created_at" : "2014-06-19 17:28:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zVolkdumSV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RteCCLGH",
      "display_url" : "pastebin.com\/raw.php?i=RteC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479676985728172032",
  "text" : "http:\/\/t.co\/zVolkdumSV Emails: 50 Keywords: 0.11 #infoleak",
  "id" : 479676985728172032,
  "created_at" : "2014-06-19 17:28:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Njc3K8k4oj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vENChPCV",
      "display_url" : "pastebin.com\/raw.php?i=vENC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479676914504699904",
  "text" : "http:\/\/t.co\/Njc3K8k4oj Hashes: 189 Keywords: 0.33 #infoleak",
  "id" : 479676914504699904,
  "created_at" : "2014-06-19 17:27:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J96uuIkAxr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gEeAa0Dc",
      "display_url" : "pastebin.com\/raw.php?i=gEeA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479676874956615681",
  "text" : "http:\/\/t.co\/J96uuIkAxr Emails: 499 Keywords: 0.0 #infoleak",
  "id" : 479676874956615681,
  "created_at" : "2014-06-19 17:27:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CgtVFYpf2a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=czNbbC6V",
      "display_url" : "pastebin.com\/raw.php?i=czNb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479675148971147266",
  "text" : "http:\/\/t.co\/CgtVFYpf2a Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 479675148971147266,
  "created_at" : "2014-06-19 17:20:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cVEKRUfs69",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iRMWherS",
      "display_url" : "pastebin.com\/raw.php?i=iRMW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479670814271234049",
  "text" : "http:\/\/t.co\/cVEKRUfs69 Emails: 75 Keywords: 0.11 #infoleak",
  "id" : 479670814271234049,
  "created_at" : "2014-06-19 17:03:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gjl8qhvXNj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=34NtPa6w",
      "display_url" : "pastebin.com\/raw.php?i=34Nt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479668082105798656",
  "text" : "http:\/\/t.co\/Gjl8qhvXNj Found possible Google API key(s) #infoleak",
  "id" : 479668082105798656,
  "created_at" : "2014-06-19 16:52:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/haZ3DpCyAf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N7EHrUVd",
      "display_url" : "pastebin.com\/raw.php?i=N7EH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479662351877042176",
  "text" : "http:\/\/t.co\/haZ3DpCyAf Emails: 422 Hashes: 458 E\/H: 0.92 Keywords: 0.11 #infoleak",
  "id" : 479662351877042176,
  "created_at" : "2014-06-19 16:29:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0wapIZmHgd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4geU9V0Z",
      "display_url" : "pastebin.com\/raw.php?i=4geU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479657085647323138",
  "text" : "http:\/\/t.co\/0wapIZmHgd Emails: 89 Keywords: 0.11 #infoleak",
  "id" : 479657085647323138,
  "created_at" : "2014-06-19 16:08:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KmJHuDdmlt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bRLVGtfx",
      "display_url" : "pastebin.com\/raw.php?i=bRLV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479648176257769472",
  "text" : "http:\/\/t.co\/KmJHuDdmlt Emails: 19 Hashes: 382 E\/H: 0.05 Keywords: 0.55 #infoleak",
  "id" : 479648176257769472,
  "created_at" : "2014-06-19 15:33:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gqow1bLwjj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D8FC41e4",
      "display_url" : "pastebin.com\/raw.php?i=D8FC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479646461265584128",
  "text" : "http:\/\/t.co\/gqow1bLwjj Hashes: 1363 Keywords: 0.19 #infoleak",
  "id" : 479646461265584128,
  "created_at" : "2014-06-19 15:26:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c5IDnGNgn4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ew3Y35tY",
      "display_url" : "pastebin.com\/raw.php?i=ew3Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479644319855288320",
  "text" : "http:\/\/t.co\/c5IDnGNgn4 Possible cisco configuration #infoleak",
  "id" : 479644319855288320,
  "created_at" : "2014-06-19 15:18:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VrE4nfzey4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1FB1aWfd",
      "display_url" : "pastebin.com\/raw.php?i=1FB1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479644263555162113",
  "text" : "http:\/\/t.co\/VrE4nfzey4 Hashes: 72 Keywords: 0.33 #infoleak",
  "id" : 479644263555162113,
  "created_at" : "2014-06-19 15:17:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LdbCYVWow7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rXLx4BFM",
      "display_url" : "pastebin.com\/raw.php?i=rXLx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479643016827637761",
  "text" : "http:\/\/t.co\/LdbCYVWow7 Emails: 202 Keywords: 0.0 #infoleak",
  "id" : 479643016827637761,
  "created_at" : "2014-06-19 15:13:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9InLMRI5oI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7R3QX8Eh",
      "display_url" : "pastebin.com\/raw.php?i=7R3Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479632390013214724",
  "text" : "http:\/\/t.co\/9InLMRI5oI Emails: 292 Keywords: 0.0 #infoleak",
  "id" : 479632390013214724,
  "created_at" : "2014-06-19 14:30:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HiCylXBBIF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2EVfAsjH",
      "display_url" : "pastebin.com\/raw.php?i=2EVf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479630257587122177",
  "text" : "http:\/\/t.co\/HiCylXBBIF Emails: 294 Keywords: 0.0 #infoleak",
  "id" : 479630257587122177,
  "created_at" : "2014-06-19 14:22:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SKhO8AkKji",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wc2Zi9UF",
      "display_url" : "pastebin.com\/raw.php?i=wc2Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479629417652572162",
  "text" : "http:\/\/t.co\/SKhO8AkKji Possible cisco configuration #infoleak",
  "id" : 479629417652572162,
  "created_at" : "2014-06-19 14:18:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mqX31S7SaW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AkCwedtk",
      "display_url" : "pastebin.com\/raw.php?i=AkCw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479624677921288192",
  "text" : "http:\/\/t.co\/mqX31S7SaW Hashes: 61 Keywords: 0.11 #infoleak",
  "id" : 479624677921288192,
  "created_at" : "2014-06-19 14:00:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kL02SPGknl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ww55PNZY",
      "display_url" : "pastebin.com\/raw.php?i=ww55\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479623143862960129",
  "text" : "http:\/\/t.co\/kL02SPGknl Emails: 28 Keywords: -0.03 #infoleak",
  "id" : 479623143862960129,
  "created_at" : "2014-06-19 13:54:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ef8vJN3WWE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FuTu2MDq",
      "display_url" : "pastebin.com\/raw.php?i=FuTu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479617252119945217",
  "text" : "http:\/\/t.co\/Ef8vJN3WWE Hashes: 54 Keywords: 0.11 #infoleak",
  "id" : 479617252119945217,
  "created_at" : "2014-06-19 13:30:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RrNKRO810D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0E750QSb",
      "display_url" : "pastebin.com\/raw.php?i=0E75\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479617215499468800",
  "text" : "http:\/\/t.co\/RrNKRO810D Hashes: 238 Keywords: 0.33 #infoleak",
  "id" : 479617215499468800,
  "created_at" : "2014-06-19 13:30:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k1K1SbbuPU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xLV4PCDm",
      "display_url" : "pastebin.com\/raw.php?i=xLV4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479616982770147329",
  "text" : "http:\/\/t.co\/k1K1SbbuPU Hashes: 43 Keywords: 0.22 #infoleak",
  "id" : 479616982770147329,
  "created_at" : "2014-06-19 13:29:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bAA3uEILNs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aFeeJTTC",
      "display_url" : "pastebin.com\/raw.php?i=aFee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479613108156002305",
  "text" : "http:\/\/t.co\/bAA3uEILNs Emails: 69 Hashes: 1363 E\/H: 0.05 Keywords: 0.55 #infoleak",
  "id" : 479613108156002305,
  "created_at" : "2014-06-19 13:14:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JwFLyRSCJR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kPyJQTJF",
      "display_url" : "pastebin.com\/raw.php?i=kPyJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479605241319391233",
  "text" : "http:\/\/t.co\/JwFLyRSCJR Hashes: 162 Keywords: 0.33 #infoleak",
  "id" : 479605241319391233,
  "created_at" : "2014-06-19 12:42:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g9xHljwmN2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ityFx3V9",
      "display_url" : "pastebin.com\/raw.php?i=ityF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479602427633487872",
  "text" : "http:\/\/t.co\/g9xHljwmN2 Hashes: 74 Keywords: 0.22 #infoleak",
  "id" : 479602427633487872,
  "created_at" : "2014-06-19 12:31:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3pupPEdEFq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=85q16xMC",
      "display_url" : "pastebin.com\/raw.php?i=85q1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479601729042800640",
  "text" : "http:\/\/t.co\/3pupPEdEFq Hashes: 48 Keywords: 0.0 #infoleak",
  "id" : 479601729042800640,
  "created_at" : "2014-06-19 12:28:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WKgOlgWZ7I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZcjCBWYf",
      "display_url" : "pastebin.com\/raw.php?i=ZcjC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479598576306110464",
  "text" : "http:\/\/t.co\/WKgOlgWZ7I Emails: 420 Keywords: 0.0 #infoleak",
  "id" : 479598576306110464,
  "created_at" : "2014-06-19 12:16:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5hiuGaLb3j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rY4RnAxB",
      "display_url" : "pastebin.com\/raw.php?i=rY4R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479598501848829952",
  "text" : "http:\/\/t.co\/5hiuGaLb3j Hashes: 117 Keywords: 0.22 #infoleak",
  "id" : 479598501848829952,
  "created_at" : "2014-06-19 12:16:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pqrbFpgLP4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rcqGSUbB",
      "display_url" : "pastebin.com\/raw.php?i=rcqG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479597756370018304",
  "text" : "http:\/\/t.co\/pqrbFpgLP4 Emails: 213 Keywords: 0.0 #infoleak",
  "id" : 479597756370018304,
  "created_at" : "2014-06-19 12:13:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BpvfBLjFRc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mecLp3En",
      "display_url" : "pastebin.com\/raw.php?i=mecL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479586772741914626",
  "text" : "http:\/\/t.co\/BpvfBLjFRc Emails: 69 Hashes: 1366 E\/H: 0.05 Keywords: 0.55 #infoleak",
  "id" : 479586772741914626,
  "created_at" : "2014-06-19 11:29:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KkHqLUhhBL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=77khxQKE",
      "display_url" : "pastebin.com\/raw.php?i=77kh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479585595489263617",
  "text" : "http:\/\/t.co\/KkHqLUhhBL Emails: 94 Keywords: 0.11 #infoleak",
  "id" : 479585595489263617,
  "created_at" : "2014-06-19 11:24:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mRzwjaXT03",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cmbDL9XK",
      "display_url" : "pastebin.com\/raw.php?i=cmbD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479582759652843520",
  "text" : "http:\/\/t.co\/mRzwjaXT03 Emails: 263 Keywords: 0.11 #infoleak",
  "id" : 479582759652843520,
  "created_at" : "2014-06-19 11:13:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lr13F4e180",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ePzhY7Aj",
      "display_url" : "pastebin.com\/raw.php?i=ePzh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479581844409548800",
  "text" : "http:\/\/t.co\/lr13F4e180 Emails: 38 Keywords: 0.11 #infoleak",
  "id" : 479581844409548800,
  "created_at" : "2014-06-19 11:09:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2x8IPWWGay",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U0zAHiDS",
      "display_url" : "pastebin.com\/raw.php?i=U0zA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479581169063718912",
  "text" : "http:\/\/t.co\/2x8IPWWGay Emails: 26 Keywords: 0.11 #infoleak",
  "id" : 479581169063718912,
  "created_at" : "2014-06-19 11:07:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tGPUNzXh43",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8aiyUjyA",
      "display_url" : "pastebin.com\/raw.php?i=8aiy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479570096071782400",
  "text" : "http:\/\/t.co\/tGPUNzXh43 Emails: 33 Keywords: 0.0 #infoleak",
  "id" : 479570096071782400,
  "created_at" : "2014-06-19 10:23:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/io693eiRBB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6VE8yQ4r",
      "display_url" : "pastebin.com\/raw.php?i=6VE8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479561750082101248",
  "text" : "http:\/\/t.co\/io693eiRBB Possible cisco configuration #infoleak",
  "id" : 479561750082101248,
  "created_at" : "2014-06-19 09:50:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2aiWtqAQn1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iun8WKne",
      "display_url" : "pastebin.com\/raw.php?i=iun8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479561402852458496",
  "text" : "http:\/\/t.co\/2aiWtqAQn1 Possible cisco configuration #infoleak",
  "id" : 479561402852458496,
  "created_at" : "2014-06-19 09:48:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3T2cxNIAkU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SG0F79hV",
      "display_url" : "pastebin.com\/raw.php?i=SG0F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479558976330166272",
  "text" : "http:\/\/t.co\/3T2cxNIAkU Emails: 169 Keywords: 0.22 #infoleak",
  "id" : 479558976330166272,
  "created_at" : "2014-06-19 09:39:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lLuDMK7PcL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XugGVzFc",
      "display_url" : "pastebin.com\/raw.php?i=XugG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479558905744203776",
  "text" : "http:\/\/t.co\/lLuDMK7PcL Hashes: 105 Keywords: -0.14 #infoleak",
  "id" : 479558905744203776,
  "created_at" : "2014-06-19 09:38:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XYORR3wS54",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N9MPs2Ct",
      "display_url" : "pastebin.com\/raw.php?i=N9MP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479558194218295296",
  "text" : "http:\/\/t.co\/XYORR3wS54 Hashes: 72 Keywords: 0.33 #infoleak",
  "id" : 479558194218295296,
  "created_at" : "2014-06-19 09:35:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H1PvWaRpie",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZpaBSnEw",
      "display_url" : "pastebin.com\/raw.php?i=ZpaB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479552445576523776",
  "text" : "http:\/\/t.co\/H1PvWaRpie Emails: 244 Keywords: 0.0 #infoleak",
  "id" : 479552445576523776,
  "created_at" : "2014-06-19 09:13:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GnDd0EEVZC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YXUPPHDV",
      "display_url" : "pastebin.com\/raw.php?i=YXUP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479549300473479168",
  "text" : "http:\/\/t.co\/GnDd0EEVZC Emails: 50 Keywords: 0.11 #infoleak",
  "id" : 479549300473479168,
  "created_at" : "2014-06-19 09:00:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vHm22y5CiQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c7S0kEJt",
      "display_url" : "pastebin.com\/raw.php?i=c7S0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479545923328958465",
  "text" : "http:\/\/t.co\/vHm22y5CiQ Emails: 152 Keywords: 0.22 #infoleak",
  "id" : 479545923328958465,
  "created_at" : "2014-06-19 08:47:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7KqkesMu9A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MgXLCita",
      "display_url" : "pastebin.com\/raw.php?i=MgXL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479544235260002304",
  "text" : "http:\/\/t.co\/7KqkesMu9A Emails: 341 Hashes: 341 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 479544235260002304,
  "created_at" : "2014-06-19 08:40:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q9HRz0grG6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nWzNkfJ9",
      "display_url" : "pastebin.com\/raw.php?i=nWzN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479540669627658240",
  "text" : "http:\/\/t.co\/q9HRz0grG6 Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 479540669627658240,
  "created_at" : "2014-06-19 08:26:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CcK9kvVuig",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ajVe6Yec",
      "display_url" : "pastebin.com\/raw.php?i=ajVe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479537095271145472",
  "text" : "http:\/\/t.co\/CcK9kvVuig Found possible Google API key(s) #infoleak",
  "id" : 479537095271145472,
  "created_at" : "2014-06-19 08:12:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dDvoHmJn2c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2NbPaBiZ",
      "display_url" : "pastebin.com\/raw.php?i=2NbP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479529212622016512",
  "text" : "http:\/\/t.co\/dDvoHmJn2c Emails: 72 Keywords: 0.22 #infoleak",
  "id" : 479529212622016512,
  "created_at" : "2014-06-19 07:40:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J8kiuRrzhC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dfEauzji",
      "display_url" : "pastebin.com\/raw.php?i=dfEa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479527733219696640",
  "text" : "http:\/\/t.co\/J8kiuRrzhC Emails: 133 Keywords: 0.0 #infoleak",
  "id" : 479527733219696640,
  "created_at" : "2014-06-19 07:34:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CKdmnoHKmo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cKq88Phn",
      "display_url" : "pastebin.com\/raw.php?i=cKq8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479518706863583232",
  "text" : "http:\/\/t.co\/CKdmnoHKmo Emails: 212 Keywords: 0.0 #infoleak",
  "id" : 479518706863583232,
  "created_at" : "2014-06-19 06:59:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kOX8fr7t24",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UeP19tNU",
      "display_url" : "pastebin.com\/raw.php?i=UeP1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479507119780020226",
  "text" : "http:\/\/t.co\/kOX8fr7t24 Emails: 255 Keywords: 0.0 #infoleak",
  "id" : 479507119780020226,
  "created_at" : "2014-06-19 06:13:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wImEOswc4j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RSKAxKhK",
      "display_url" : "pastebin.com\/raw.php?i=RSKA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479500830618308608",
  "text" : "http:\/\/t.co\/wImEOswc4j Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 479500830618308608,
  "created_at" : "2014-06-19 05:48:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nz9mz2kF7j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dkcZZiXr",
      "display_url" : "pastebin.com\/raw.php?i=dkcZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479499528270131200",
  "text" : "http:\/\/t.co\/nz9mz2kF7j Hashes: 93 Keywords: -0.14 #infoleak",
  "id" : 479499528270131200,
  "created_at" : "2014-06-19 05:42:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E6prHnn8nS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yfw88Cza",
      "display_url" : "pastebin.com\/raw.php?i=yfw8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479496816505810944",
  "text" : "http:\/\/t.co\/E6prHnn8nS Emails: 701 Keywords: 0.11 #infoleak",
  "id" : 479496816505810944,
  "created_at" : "2014-06-19 05:32:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lrULbGtb7d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q3usCrCK",
      "display_url" : "pastebin.com\/raw.php?i=q3us\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479487951655546881",
  "text" : "http:\/\/t.co\/lrULbGtb7d Emails: 23 Hashes: 23 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 479487951655546881,
  "created_at" : "2014-06-19 04:56:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1l6bt6JtsI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k08rUCPb",
      "display_url" : "pastebin.com\/raw.php?i=k08r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479486709252358144",
  "text" : "http:\/\/t.co\/1l6bt6JtsI Found possible Google API key(s) #infoleak",
  "id" : 479486709252358144,
  "created_at" : "2014-06-19 04:51:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/slQxjvESHA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pXtCPNFA",
      "display_url" : "pastebin.com\/raw.php?i=pXtC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479464455441371137",
  "text" : "http:\/\/t.co\/slQxjvESHA Emails: 49 Keywords: -0.14 #infoleak",
  "id" : 479464455441371137,
  "created_at" : "2014-06-19 03:23:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hJwoVoVpHL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p1zK5CPL",
      "display_url" : "pastebin.com\/raw.php?i=p1zK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479461851084767233",
  "text" : "http:\/\/t.co\/hJwoVoVpHL Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 479461851084767233,
  "created_at" : "2014-06-19 03:13:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gTN4z5Bfgh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hQhU5N5p",
      "display_url" : "pastebin.com\/raw.php?i=hQhU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479453447532466177",
  "text" : "http:\/\/t.co\/gTN4z5Bfgh Emails: 9 Hashes: 13 E\/H: 0.69 Keywords: 0.55 #infoleak",
  "id" : 479453447532466177,
  "created_at" : "2014-06-19 02:39:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8Q9q75etkn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XJ8ab2rB",
      "display_url" : "pastebin.com\/raw.php?i=XJ8a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479436064583471105",
  "text" : "http:\/\/t.co\/8Q9q75etkn Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 479436064583471105,
  "created_at" : "2014-06-19 01:30:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dBx2w6R37W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yYEwWMSt",
      "display_url" : "pastebin.com\/raw.php?i=yYEw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479425884663734272",
  "text" : "http:\/\/t.co\/dBx2w6R37W Emails: 63 Keywords: 0.08 #infoleak",
  "id" : 479425884663734272,
  "created_at" : "2014-06-19 00:50:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JIlY2odiVZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bnWPYxxz",
      "display_url" : "pastebin.com\/raw.php?i=bnWP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479423297252106240",
  "text" : "http:\/\/t.co\/JIlY2odiVZ Emails: 44 Keywords: 0.0 #infoleak",
  "id" : 479423297252106240,
  "created_at" : "2014-06-19 00:39:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YtHRepdYKt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m0zVLHns",
      "display_url" : "pastebin.com\/raw.php?i=m0zV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479420071610023936",
  "text" : "http:\/\/t.co\/YtHRepdYKt Emails: 117 Keywords: 0.22 #infoleak",
  "id" : 479420071610023936,
  "created_at" : "2014-06-19 00:27:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EFMfHLcpG0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZFYhvd4J",
      "display_url" : "pastebin.com\/raw.php?i=ZFYh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479416494413971456",
  "text" : "http:\/\/t.co\/EFMfHLcpG0 Emails: 233 Keywords: 0.0 #infoleak",
  "id" : 479416494413971456,
  "created_at" : "2014-06-19 00:12:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5VoHl3GTph",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AvLY8aL7",
      "display_url" : "pastebin.com\/raw.php?i=AvLY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479415751766319105",
  "text" : "http:\/\/t.co\/5VoHl3GTph Emails: 7102 Keywords: 0.11 #infoleak",
  "id" : 479415751766319105,
  "created_at" : "2014-06-19 00:09:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1YrfUwSdgQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F14s7Lhr",
      "display_url" : "pastebin.com\/raw.php?i=F14s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479410155394572288",
  "text" : "http:\/\/t.co\/1YrfUwSdgQ Hashes: 202 Keywords: 0.11 #infoleak",
  "id" : 479410155394572288,
  "created_at" : "2014-06-18 23:47:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Udb3z8Zt9g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6zrHuGwf",
      "display_url" : "pastebin.com\/raw.php?i=6zrH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479409462235525120",
  "text" : "http:\/\/t.co\/Udb3z8Zt9g Emails: 289 Keywords: 0.11 #infoleak",
  "id" : 479409462235525120,
  "created_at" : "2014-06-18 23:44:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1iTJ8BCf08",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sV0ksbba",
      "display_url" : "pastebin.com\/raw.php?i=sV0k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479408539148906496",
  "text" : "http:\/\/t.co\/1iTJ8BCf08 Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 479408539148906496,
  "created_at" : "2014-06-18 23:41:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YMyJieg0Hb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZbEy7yGP",
      "display_url" : "pastebin.com\/raw.php?i=ZbEy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479401659341086720",
  "text" : "http:\/\/t.co\/YMyJieg0Hb Emails: 442 Keywords: 0.19 #infoleak",
  "id" : 479401659341086720,
  "created_at" : "2014-06-18 23:13:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aImlqVA4zR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rybGDY89",
      "display_url" : "pastebin.com\/raw.php?i=rybG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479401307241857024",
  "text" : "http:\/\/t.co\/aImlqVA4zR Emails: 40 Keywords: 0.33 #infoleak",
  "id" : 479401307241857024,
  "created_at" : "2014-06-18 23:12:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XG8p0E3bfi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uhxiWWv1",
      "display_url" : "pastebin.com\/raw.php?i=uhxi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479395651357143040",
  "text" : "http:\/\/t.co\/XG8p0E3bfi Emails: 953 Keywords: 0.19 #infoleak",
  "id" : 479395651357143040,
  "created_at" : "2014-06-18 22:50:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/woKlURfOSp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ev76q261",
      "display_url" : "pastebin.com\/raw.php?i=ev76\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479390586529525760",
  "text" : "http:\/\/t.co\/woKlURfOSp Hashes: 62 Keywords: 0.0 #infoleak",
  "id" : 479390586529525760,
  "created_at" : "2014-06-18 22:29:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cF5yLXtVdA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9CbxgCie",
      "display_url" : "pastebin.com\/raw.php?i=9Cbx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479223184126791681",
  "text" : "http:\/\/t.co\/cF5yLXtVdA Keywords: 0.66 #infoleak",
  "id" : 479223184126791681,
  "created_at" : "2014-06-18 11:24:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tN8ptIyPKw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s0f5tQUY",
      "display_url" : "pastebin.com\/raw.php?i=s0f5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479176551129313280",
  "text" : "http:\/\/t.co\/tN8ptIyPKw Emails: 193 Keywords: 0.11 #infoleak",
  "id" : 479176551129313280,
  "created_at" : "2014-06-18 08:19:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hcJ2p3QB03",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QJ8c7zzc",
      "display_url" : "pastebin.com\/raw.php?i=QJ8c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479174769804201985",
  "text" : "http:\/\/t.co\/hcJ2p3QB03 Emails: 83 Hashes: 81 E\/H: 1.02 Keywords: 0.22 #infoleak",
  "id" : 479174769804201985,
  "created_at" : "2014-06-18 08:12:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6z8LVGjENz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i51kV0ay",
      "display_url" : "pastebin.com\/raw.php?i=i51k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479166803076063232",
  "text" : "http:\/\/t.co\/6z8LVGjENz Hashes: 68 Keywords: 0.0 #infoleak",
  "id" : 479166803076063232,
  "created_at" : "2014-06-18 07:40:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/10x0sUEuLv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H0c26XeH",
      "display_url" : "pastebin.com\/raw.php?i=H0c2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479166081383157760",
  "text" : "http:\/\/t.co\/10x0sUEuLv Emails: 2 Hashes: 42 E\/H: 0.05 Keywords: 0.16 #infoleak",
  "id" : 479166081383157760,
  "created_at" : "2014-06-18 07:37:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IglsK8NzNa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5wGuibTH",
      "display_url" : "pastebin.com\/raw.php?i=5wGu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479155845037436928",
  "text" : "http:\/\/t.co\/IglsK8NzNa Emails: 22 Keywords: -0.06 #infoleak",
  "id" : 479155845037436928,
  "created_at" : "2014-06-18 06:57:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WVypzvUYLZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mx4rjec9",
      "display_url" : "pastebin.com\/raw.php?i=Mx4r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479149705348128769",
  "text" : "http:\/\/t.co\/WVypzvUYLZ Emails: 4656 Keywords: 0.22 #infoleak",
  "id" : 479149705348128769,
  "created_at" : "2014-06-18 06:32:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RPMfYzz3YB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DP2xyGp8",
      "display_url" : "pastebin.com\/raw.php?i=DP2x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479146141125058560",
  "text" : "http:\/\/t.co\/RPMfYzz3YB Hashes: 272 Keywords: 0.22 #infoleak",
  "id" : 479146141125058560,
  "created_at" : "2014-06-18 06:18:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R2LTMq2WRU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HE0n3FTn",
      "display_url" : "pastebin.com\/raw.php?i=HE0n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479145904138498049",
  "text" : "http:\/\/t.co\/R2LTMq2WRU Emails: 20 Keywords: 0.22 #infoleak",
  "id" : 479145904138498049,
  "created_at" : "2014-06-18 06:17:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CCvGzCRonj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bTD6J7sQ",
      "display_url" : "pastebin.com\/raw.php?i=bTD6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479144857055662080",
  "text" : "http:\/\/t.co\/CCvGzCRonj Emails: 134 Keywords: 0.0 #infoleak",
  "id" : 479144857055662080,
  "created_at" : "2014-06-18 06:13:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LrJTDe8r8n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w4fBh4Hi",
      "display_url" : "pastebin.com\/raw.php?i=w4fB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479139776126124033",
  "text" : "http:\/\/t.co\/LrJTDe8r8n Found possible Google API key(s) #infoleak",
  "id" : 479139776126124033,
  "created_at" : "2014-06-18 05:53:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RaSZ11Syjv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vkGLRbxP",
      "display_url" : "pastebin.com\/raw.php?i=vkGL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479135166602829825",
  "text" : "http:\/\/t.co\/RaSZ11Syjv Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 479135166602829825,
  "created_at" : "2014-06-18 05:35:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k7n3x5TUJD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CwYCUZUL",
      "display_url" : "pastebin.com\/raw.php?i=CwYC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479133147368390656",
  "text" : "http:\/\/t.co\/k7n3x5TUJD Emails: 74 Keywords: 0.0 #infoleak",
  "id" : 479133147368390656,
  "created_at" : "2014-06-18 05:26:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2uufq8IdxZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=323MbQTt",
      "display_url" : "pastebin.com\/raw.php?i=323M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479124587884466176",
  "text" : "http:\/\/t.co\/2uufq8IdxZ Emails: 588 Keywords: 0.22 #infoleak",
  "id" : 479124587884466176,
  "created_at" : "2014-06-18 04:52:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Craxv4E4W5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q1JvaG4m",
      "display_url" : "pastebin.com\/raw.php?i=q1Jv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479122347983523840",
  "text" : "http:\/\/t.co\/Craxv4E4W5 Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 479122347983523840,
  "created_at" : "2014-06-18 04:44:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nWusSCg6Cm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MtdZKf2a",
      "display_url" : "pastebin.com\/raw.php?i=MtdZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479117793351057408",
  "text" : "http:\/\/t.co\/nWusSCg6Cm Emails: 149 Keywords: 0.08 #infoleak",
  "id" : 479117793351057408,
  "created_at" : "2014-06-18 04:25:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YrzN8eIHoG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p7GdJd6S",
      "display_url" : "pastebin.com\/raw.php?i=p7Gd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479117303561220096",
  "text" : "http:\/\/t.co\/YrzN8eIHoG Hashes: 32 Keywords: 0.11 #infoleak",
  "id" : 479117303561220096,
  "created_at" : "2014-06-18 04:24:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qDonk0eRLD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4Qs2viR5",
      "display_url" : "pastebin.com\/raw.php?i=4Qs2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479116055994855424",
  "text" : "http:\/\/t.co\/qDonk0eRLD Hashes: 5 Keywords: 0.55 #infoleak",
  "id" : 479116055994855424,
  "created_at" : "2014-06-18 04:19:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YBTsiSHcnd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5WctTXfS",
      "display_url" : "pastebin.com\/raw.php?i=5Wct\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479114712076922881",
  "text" : "http:\/\/t.co\/YBTsiSHcnd Hashes: 5 Keywords: 0.55 #infoleak",
  "id" : 479114712076922881,
  "created_at" : "2014-06-18 04:13:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UNX2DkiuUV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HpwkQ6FM",
      "display_url" : "pastebin.com\/raw.php?i=Hpwk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479110054558179328",
  "text" : "http:\/\/t.co\/UNX2DkiuUV Emails: 48 Keywords: 0.0 #infoleak",
  "id" : 479110054558179328,
  "created_at" : "2014-06-18 03:55:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VdBFNlohc0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=igcMa3Au",
      "display_url" : "pastebin.com\/raw.php?i=igcM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479099569666420737",
  "text" : "http:\/\/t.co\/VdBFNlohc0 Emails: 157 Keywords: 0.0 #infoleak",
  "id" : 479099569666420737,
  "created_at" : "2014-06-18 03:13:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hVtq80ZRMF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Rfs34CX",
      "display_url" : "pastebin.com\/raw.php?i=7Rfs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479096390560137216",
  "text" : "http:\/\/t.co\/hVtq80ZRMF Emails: 74 Keywords: 0.11 #infoleak",
  "id" : 479096390560137216,
  "created_at" : "2014-06-18 03:00:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SCQLNQZV1b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cy8zRsjZ",
      "display_url" : "pastebin.com\/raw.php?i=Cy8z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479092235695161344",
  "text" : "http:\/\/t.co\/SCQLNQZV1b Emails: 551 Keywords: 0.0 #infoleak",
  "id" : 479092235695161344,
  "created_at" : "2014-06-18 02:44:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7UhONjD06o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kz1bVUbu",
      "display_url" : "pastebin.com\/raw.php?i=kz1b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479092186055589888",
  "text" : "http:\/\/t.co\/7UhONjD06o Emails: 27 Keywords: 0.08 #infoleak",
  "id" : 479092186055589888,
  "created_at" : "2014-06-18 02:44:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sSmB5o7WWY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0zVhDEj0",
      "display_url" : "pastebin.com\/raw.php?i=0zVh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479088212829143041",
  "text" : "http:\/\/t.co\/sSmB5o7WWY Hashes: 10663 Keywords: 0.19 #infoleak",
  "id" : 479088212829143041,
  "created_at" : "2014-06-18 02:28:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H8M51n9mV1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pf8UN7gJ",
      "display_url" : "pastebin.com\/raw.php?i=pf8U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479087101728665600",
  "text" : "http:\/\/t.co\/H8M51n9mV1 Hashes: 8134 Keywords: 0.22 #infoleak",
  "id" : 479087101728665600,
  "created_at" : "2014-06-18 02:24:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dWvevQXCBn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cNRKUQBM",
      "display_url" : "pastebin.com\/raw.php?i=cNRK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479083712391286784",
  "text" : "http:\/\/t.co\/dWvevQXCBn Emails: 89 Keywords: 0.0 #infoleak",
  "id" : 479083712391286784,
  "created_at" : "2014-06-18 02:10:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k0IQPouUfv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b03TxBmM",
      "display_url" : "pastebin.com\/raw.php?i=b03T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479078329899679744",
  "text" : "http:\/\/t.co\/k0IQPouUfv Emails: 7118 Keywords: 0.08 #infoleak",
  "id" : 479078329899679744,
  "created_at" : "2014-06-18 01:49:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ukWcFufQKk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZPt6jd8r",
      "display_url" : "pastebin.com\/raw.php?i=ZPt6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479077232757854208",
  "text" : "http:\/\/t.co\/ukWcFufQKk Hashes: 2365 Keywords: 0.11 #infoleak",
  "id" : 479077232757854208,
  "created_at" : "2014-06-18 01:44:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DjEtJUxDRH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XUYR8ijQ",
      "display_url" : "pastebin.com\/raw.php?i=XUYR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479059175301844992",
  "text" : "http:\/\/t.co\/DjEtJUxDRH Hashes: 108 Keywords: 0.0 #infoleak",
  "id" : 479059175301844992,
  "created_at" : "2014-06-18 00:33:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PoHiTq5Tcn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PQx4y7HH",
      "display_url" : "pastebin.com\/raw.php?i=PQx4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479058369055952896",
  "text" : "http:\/\/t.co\/PoHiTq5Tcn Emails: 20 Keywords: 0.55 #infoleak",
  "id" : 479058369055952896,
  "created_at" : "2014-06-18 00:29:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4QJ2fPtRSB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RsvvnXdi",
      "display_url" : "pastebin.com\/raw.php?i=Rsvv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478792313116700672",
  "text" : "http:\/\/t.co\/4QJ2fPtRSB Hashes: 30 Keywords: 0.33 #infoleak",
  "id" : 478792313116700672,
  "created_at" : "2014-06-17 06:52:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WrlDtXKYGY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e5wpvVB4",
      "display_url" : "pastebin.com\/raw.php?i=e5wp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478783839678898176",
  "text" : "http:\/\/t.co\/WrlDtXKYGY Emails: 21 Keywords: 0.11 #infoleak",
  "id" : 478783839678898176,
  "created_at" : "2014-06-17 06:18:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eY9Vyanx61",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nz7MZESL",
      "display_url" : "pastebin.com\/raw.php?i=nz7M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478782321986772992",
  "text" : "http:\/\/t.co\/eY9Vyanx61 Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 478782321986772992,
  "created_at" : "2014-06-17 06:12:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LWuHdsgpAG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CgUxEnhV",
      "display_url" : "pastebin.com\/raw.php?i=CgUx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478774760982069248",
  "text" : "http:\/\/t.co\/LWuHdsgpAG Emails: 149 Keywords: 0.08 #infoleak",
  "id" : 478774760982069248,
  "created_at" : "2014-06-17 05:42:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PqQ0lS5k6U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d0pJFSSc",
      "display_url" : "pastebin.com\/raw.php?i=d0pJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478768003161399296",
  "text" : "http:\/\/t.co\/PqQ0lS5k6U Hashes: 526 Keywords: 0.08 #infoleak",
  "id" : 478768003161399296,
  "created_at" : "2014-06-17 05:16:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KHo66uBvpc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HkRGpQ9w",
      "display_url" : "pastebin.com\/raw.php?i=HkRG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478760368446005248",
  "text" : "http:\/\/t.co\/KHo66uBvpc Hashes: 184 Keywords: 0.22 #infoleak",
  "id" : 478760368446005248,
  "created_at" : "2014-06-17 04:45:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yFJlCRFNr6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=95FzNdYD",
      "display_url" : "pastebin.com\/raw.php?i=95Fz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478745090056155136",
  "text" : "http:\/\/t.co\/yFJlCRFNr6 Emails: 801 Keywords: 0.22 #infoleak",
  "id" : 478745090056155136,
  "created_at" : "2014-06-17 03:44:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LmEWUIJvpw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hypc1bFw",
      "display_url" : "pastebin.com\/raw.php?i=hypc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478738709873827840",
  "text" : "http:\/\/t.co\/LmEWUIJvpw Emails: 397 Keywords: 0.22 #infoleak",
  "id" : 478738709873827840,
  "created_at" : "2014-06-17 03:19:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8baK0hYH4r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SqCZsNDx",
      "display_url" : "pastebin.com\/raw.php?i=SqCZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478737044730949632",
  "text" : "http:\/\/t.co\/8baK0hYH4r Emails: 295 Keywords: 0.0 #infoleak",
  "id" : 478737044730949632,
  "created_at" : "2014-06-17 03:13:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wki0p4fTlo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GJm8xa87",
      "display_url" : "pastebin.com\/raw.php?i=GJm8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478730234544402432",
  "text" : "http:\/\/t.co\/Wki0p4fTlo Keywords: 0.55 #infoleak",
  "id" : 478730234544402432,
  "created_at" : "2014-06-17 02:45:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yiiIRzkjdt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eAjuY52m",
      "display_url" : "pastebin.com\/raw.php?i=eAju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478712365219721216",
  "text" : "http:\/\/t.co\/yiiIRzkjdt Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 478712365219721216,
  "created_at" : "2014-06-17 01:34:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3iAN6qCnBH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aPS08wVH",
      "display_url" : "pastebin.com\/raw.php?i=aPS0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478711972192481280",
  "text" : "http:\/\/t.co\/3iAN6qCnBH Emails: 137 Keywords: 0.11 #infoleak",
  "id" : 478711972192481280,
  "created_at" : "2014-06-17 01:33:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IWpWCqvubV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8UUxMKs4",
      "display_url" : "pastebin.com\/raw.php?i=8UUx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478711834191462400",
  "text" : "http:\/\/t.co\/IWpWCqvubV Hashes: 52 Keywords: 0.0 #infoleak",
  "id" : 478711834191462400,
  "created_at" : "2014-06-17 01:32:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bAbEKuGYf3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uY2rFxJx",
      "display_url" : "pastebin.com\/raw.php?i=uY2r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478511141669203968",
  "text" : "http:\/\/t.co\/bAbEKuGYf3 Emails: 135 Keywords: 0.22 #infoleak",
  "id" : 478511141669203968,
  "created_at" : "2014-06-16 12:15:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/smIJPFdTZZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fxdV1HHu",
      "display_url" : "pastebin.com\/raw.php?i=fxdV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478510752748158976",
  "text" : "http:\/\/t.co\/smIJPFdTZZ Emails: 94 Keywords: 0.0 #infoleak",
  "id" : 478510752748158976,
  "created_at" : "2014-06-16 12:13:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478277184046391297",
  "geo" : { },
  "id_str" : "478506933922443264",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon \"123\" isn't a good password, Tomas.",
  "id" : 478506933922443264,
  "in_reply_to_status_id" : 478277184046391297,
  "created_at" : "2014-06-16 11:58:37 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TY7rfXpJs8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0UP7SPYE",
      "display_url" : "pastebin.com\/raw.php?i=0UP7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478505558090063872",
  "text" : "http:\/\/t.co\/TY7rfXpJs8 Emails: 80 Keywords: 0.19 #infoleak",
  "id" : 478505558090063872,
  "created_at" : "2014-06-16 11:53:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iyMT2iOAmV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TiVpp0HL",
      "display_url" : "pastebin.com\/raw.php?i=TiVp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478498900219662336",
  "text" : "http:\/\/t.co\/iyMT2iOAmV Possible cisco configuration #infoleak",
  "id" : 478498900219662336,
  "created_at" : "2014-06-16 11:26:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cjxyE1VOUW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YwV9RhAj",
      "display_url" : "pastebin.com\/raw.php?i=YwV9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478494117312204800",
  "text" : "http:\/\/t.co\/cjxyE1VOUW Possible cisco configuration #infoleak",
  "id" : 478494117312204800,
  "created_at" : "2014-06-16 11:07:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iDf3QTfaWS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BF4QrYHt",
      "display_url" : "pastebin.com\/raw.php?i=BF4Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478484183883341824",
  "text" : "http:\/\/t.co\/iDf3QTfaWS Emails: 57 Keywords: 0.11 #infoleak",
  "id" : 478484183883341824,
  "created_at" : "2014-06-16 10:28:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ebVpZxFYoy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dVQCsfEg",
      "display_url" : "pastebin.com\/raw.php?i=dVQC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478473788791607296",
  "text" : "http:\/\/t.co\/ebVpZxFYoy Hashes: 66 Keywords: 0.11 #infoleak",
  "id" : 478473788791607296,
  "created_at" : "2014-06-16 09:46:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XabcRWhxqh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YVw4haUT",
      "display_url" : "pastebin.com\/raw.php?i=YVw4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478465271716270080",
  "text" : "http:\/\/t.co\/XabcRWhxqh Emails: 66 Keywords: 0.0 #infoleak",
  "id" : 478465271716270080,
  "created_at" : "2014-06-16 09:13:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uY2uu4mRIA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Rsa9H0UN",
      "display_url" : "pastebin.com\/raw.php?i=Rsa9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478460738567012352",
  "text" : "http:\/\/t.co\/uY2uu4mRIA Hashes: 99 Keywords: -0.06 #infoleak",
  "id" : 478460738567012352,
  "created_at" : "2014-06-16 08:55:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fw7JgXnm6F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8W5TUcns",
      "display_url" : "pastebin.com\/raw.php?i=8W5T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478460124931952640",
  "text" : "http:\/\/t.co\/fw7JgXnm6F Emails: 1159 Keywords: 0.22 #infoleak",
  "id" : 478460124931952640,
  "created_at" : "2014-06-16 08:52:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IXcj1bTiFS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VC2bEbZY",
      "display_url" : "pastebin.com\/raw.php?i=VC2b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478456224740954112",
  "text" : "http:\/\/t.co\/IXcj1bTiFS Hashes: 31 Keywords: 0.11 #infoleak",
  "id" : 478456224740954112,
  "created_at" : "2014-06-16 08:37:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8qBHrChIUn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p5Ft8Kew",
      "display_url" : "pastebin.com\/raw.php?i=p5Ft\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478446272643219456",
  "text" : "http:\/\/t.co\/8qBHrChIUn Emails: 23 Keywords: 0.33 #infoleak",
  "id" : 478446272643219456,
  "created_at" : "2014-06-16 07:57:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oqoYPIMPz5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ENxtznnt",
      "display_url" : "pastebin.com\/raw.php?i=ENxt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478441937637089282",
  "text" : "http:\/\/t.co\/oqoYPIMPz5 Keywords: 0.55 #infoleak",
  "id" : 478441937637089282,
  "created_at" : "2014-06-16 07:40:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TyHL84Z1mR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YxTGaVHx",
      "display_url" : "pastebin.com\/raw.php?i=YxTG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478419784820740096",
  "text" : "http:\/\/t.co\/TyHL84Z1mR Found possible Google API key(s) #infoleak",
  "id" : 478419784820740096,
  "created_at" : "2014-06-16 06:12:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sTeNeyQ8QY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8zkuEhvt",
      "display_url" : "pastebin.com\/raw.php?i=8zku\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478409055094833152",
  "text" : "http:\/\/t.co\/sTeNeyQ8QY Emails: 73 Keywords: 0.11 #infoleak",
  "id" : 478409055094833152,
  "created_at" : "2014-06-16 05:29:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hTOTMmRCXG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XpGFkZ9a",
      "display_url" : "pastebin.com\/raw.php?i=XpGF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478388268744982528",
  "text" : "http:\/\/t.co\/hTOTMmRCXG Emails: 1301 Hashes: 1301 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 478388268744982528,
  "created_at" : "2014-06-16 04:07:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qM5A91lopM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZG1uvpgG",
      "display_url" : "pastebin.com\/raw.php?i=ZG1u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478388236650151937",
  "text" : "http:\/\/t.co\/qM5A91lopM Emails: 155 Keywords: 0.0 #infoleak",
  "id" : 478388236650151937,
  "created_at" : "2014-06-16 04:06:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c5LoXSpK89",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9PG4AEbf",
      "display_url" : "pastebin.com\/raw.php?i=9PG4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478374634086088704",
  "text" : "http:\/\/t.co\/c5LoXSpK89 Emails: 216 Keywords: 0.0 #infoleak",
  "id" : 478374634086088704,
  "created_at" : "2014-06-16 03:12:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3KYIsTiOD6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9Yex2yA5",
      "display_url" : "pastebin.com\/raw.php?i=9Yex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478374087442456577",
  "text" : "http:\/\/t.co\/3KYIsTiOD6 Emails: 103 Keywords: 0.0 #infoleak",
  "id" : 478374087442456577,
  "created_at" : "2014-06-16 03:10:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/erC8HnWuu1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bLuMmAbE",
      "display_url" : "pastebin.com\/raw.php?i=bLuM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478374040944390145",
  "text" : "http:\/\/t.co\/erC8HnWuu1 Hashes: 93 Keywords: -0.14 #infoleak",
  "id" : 478374040944390145,
  "created_at" : "2014-06-16 03:10:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eQ8YGqEyZS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8NchLy0f",
      "display_url" : "pastebin.com\/raw.php?i=8Nch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478372760528248832",
  "text" : "http:\/\/t.co\/eQ8YGqEyZS Emails: 2181 Keywords: 0.11 #infoleak",
  "id" : 478372760528248832,
  "created_at" : "2014-06-16 03:05:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DO4aZsSvsc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NurEy2YF",
      "display_url" : "pastebin.com\/raw.php?i=NurE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478371152058802177",
  "text" : "http:\/\/t.co\/DO4aZsSvsc Emails: 23 Hashes: 62 E\/H: 0.37 Keywords: 0.0 #infoleak",
  "id" : 478371152058802177,
  "created_at" : "2014-06-16 02:59:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z9fT2t52wX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Yy4qBuvG",
      "display_url" : "pastebin.com\/raw.php?i=Yy4q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478368975999344641",
  "text" : "http:\/\/t.co\/Z9fT2t52wX Emails: 500 Keywords: 0.0 #infoleak",
  "id" : 478368975999344641,
  "created_at" : "2014-06-16 02:50:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/byYKgKttBW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=edKLNQCv",
      "display_url" : "pastebin.com\/raw.php?i=edKL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478365205253357569",
  "text" : "http:\/\/t.co\/byYKgKttBW Emails: 502 Keywords: 0.0 #infoleak",
  "id" : 478365205253357569,
  "created_at" : "2014-06-16 02:35:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Lt1DbRf17m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=umvKpksT",
      "display_url" : "pastebin.com\/raw.php?i=umvK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478346152178225152",
  "text" : "http:\/\/t.co\/Lt1DbRf17m Emails: 1756 Hashes: 2 E\/H: 878.0 Keywords: 0.77 #infoleak",
  "id" : 478346152178225152,
  "created_at" : "2014-06-16 01:19:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vqu6e92r99",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rrejt44C",
      "display_url" : "pastebin.com\/raw.php?i=rrej\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478346061711282176",
  "text" : "http:\/\/t.co\/vqu6e92r99 Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 478346061711282176,
  "created_at" : "2014-06-16 01:19:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vJUFriclRM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V77h83cy",
      "display_url" : "pastebin.com\/raw.php?i=V77h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478341364791246848",
  "text" : "http:\/\/t.co\/vJUFriclRM Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 478341364791246848,
  "created_at" : "2014-06-16 01:00:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ikpb2liYD5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9YHehkr9",
      "display_url" : "pastebin.com\/raw.php?i=9YHe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478334663232995328",
  "text" : "http:\/\/t.co\/ikpb2liYD5 Emails: 1750 Keywords: 0.11 #infoleak",
  "id" : 478334663232995328,
  "created_at" : "2014-06-16 00:34:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uxZ6pGlV3J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Srnik30R",
      "display_url" : "pastebin.com\/raw.php?i=Srni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478334406529003520",
  "text" : "http:\/\/t.co\/uxZ6pGlV3J Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 478334406529003520,
  "created_at" : "2014-06-16 00:33:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Auk4FMCfEH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XUchCJB5",
      "display_url" : "pastebin.com\/raw.php?i=XUch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478329338215931905",
  "text" : "http:\/\/t.co\/Auk4FMCfEH Emails: 168 Keywords: 0.0 #infoleak",
  "id" : 478329338215931905,
  "created_at" : "2014-06-16 00:12:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tSnRkbn733",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VVgL8Fzp",
      "display_url" : "pastebin.com\/raw.php?i=VVgL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478325929878376449",
  "text" : "http:\/\/t.co\/tSnRkbn733 Emails: 4151 Keywords: 0.08 #infoleak",
  "id" : 478325929878376449,
  "created_at" : "2014-06-15 23:59:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RAGU5klOre",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BLvp8KdN",
      "display_url" : "pastebin.com\/raw.php?i=BLvp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478321605072789505",
  "text" : "http:\/\/t.co\/RAGU5klOre Emails: 141 Hashes: 1 E\/H: 141.0 Keywords: 0.11 #infoleak",
  "id" : 478321605072789505,
  "created_at" : "2014-06-15 23:42:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B4X6aC6ApD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TDJHhf3g",
      "display_url" : "pastebin.com\/raw.php?i=TDJH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478317389960855553",
  "text" : "http:\/\/t.co\/B4X6aC6ApD Emails: 27 Keywords: 0.11 #infoleak",
  "id" : 478317389960855553,
  "created_at" : "2014-06-15 23:25:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9pojNtGmPU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b1c4iv9P",
      "display_url" : "pastebin.com\/raw.php?i=b1c4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478312548064698368",
  "text" : "http:\/\/t.co\/9pojNtGmPU Emails: 1 Hashes: 42 E\/H: 0.02 Keywords: 0.11 #infoleak",
  "id" : 478312548064698368,
  "created_at" : "2014-06-15 23:06:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bumzk9VSvM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jJfpPJMC",
      "display_url" : "pastebin.com\/raw.php?i=jJfp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478301778417430530",
  "text" : "http:\/\/t.co\/Bumzk9VSvM Emails: 185 Keywords: 0.11 #infoleak",
  "id" : 478301778417430530,
  "created_at" : "2014-06-15 22:23:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/NicmAPkcVs",
      "expanded_url" : "http:\/\/pastebin.com\/nrTB21uA",
      "display_url" : "pastebin.com\/nrTB21uA"
    }, {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/qo4mdu1cyB",
      "expanded_url" : "http:\/\/pastebin.com\/7pbmALJa",
      "display_url" : "pastebin.com\/7pbmALJa"
    } ]
  },
  "in_reply_to_status_id_str" : "478289790786215936",
  "geo" : { },
  "id_str" : "478290956781748224",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon Here's some others from the same site: http:\/\/t.co\/NicmAPkcVs http:\/\/t.co\/qo4mdu1cyB",
  "id" : 478290956781748224,
  "in_reply_to_status_id" : 478289790786215936,
  "created_at" : "2014-06-15 21:40:24 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zOVcclRheC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2ZJGDJDk",
      "display_url" : "pastebin.com\/raw.php?i=2ZJG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478289790786215936",
  "text" : "http:\/\/t.co\/zOVcclRheC Emails: 1064 Keywords: 0.44 #infoleak",
  "id" : 478289790786215936,
  "created_at" : "2014-06-15 21:35:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tYjM3AjdOs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eHSVJWui",
      "display_url" : "pastebin.com\/raw.php?i=eHSV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478286019783966720",
  "text" : "http:\/\/t.co\/tYjM3AjdOs Keywords: 0.55 #infoleak",
  "id" : 478286019783966720,
  "created_at" : "2014-06-15 21:20:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mRmSTXiYf5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aT2nZQCz",
      "display_url" : "pastebin.com\/raw.php?i=aT2n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478284057998946304",
  "text" : "http:\/\/t.co\/mRmSTXiYf5 Emails: 150 Keywords: 0.0 #infoleak",
  "id" : 478284057998946304,
  "created_at" : "2014-06-15 21:13:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qBWydaJBGJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9rxanRaG",
      "display_url" : "pastebin.com\/raw.php?i=9rxa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478280959163248640",
  "text" : "http:\/\/t.co\/qBWydaJBGJ Emails: 68 Keywords: 0.11 #infoleak",
  "id" : 478280959163248640,
  "created_at" : "2014-06-15 21:00:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vLmdsN5fBH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t4xehmTv",
      "display_url" : "pastebin.com\/raw.php?i=t4xe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478279734199975937",
  "text" : "http:\/\/t.co\/vLmdsN5fBH Keywords: 0.55 #infoleak",
  "id" : 478279734199975937,
  "created_at" : "2014-06-15 20:55:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eGBSSvQC7Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HVVKpkVY",
      "display_url" : "pastebin.com\/raw.php?i=HVVK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478277184046391297",
  "text" : "http:\/\/t.co\/eGBSSvQC7Y Keywords: 0.55 #infoleak",
  "id" : 478277184046391297,
  "created_at" : "2014-06-15 20:45:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478257118638665730",
  "geo" : { },
  "id_str" : "478275030782971905",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon This is an HTML dump of Protonmail.ch - wonder why they put the recipients email addresses hardcoded into JS?",
  "id" : 478275030782971905,
  "in_reply_to_status_id" : 478257118638665730,
  "created_at" : "2014-06-15 20:37:07 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tEsQFQ1dQv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WGUhH8c3",
      "display_url" : "pastebin.com\/raw.php?i=WGUh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478264053664477184",
  "text" : "http:\/\/t.co\/tEsQFQ1dQv Keywords: 0.55 #infoleak",
  "id" : 478264053664477184,
  "created_at" : "2014-06-15 19:53:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DaBDqvL7jm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9wQyt6ic",
      "display_url" : "pastebin.com\/raw.php?i=9wQy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478260757012819969",
  "text" : "http:\/\/t.co\/DaBDqvL7jm Emails: 995 Keywords: 0.0 #infoleak",
  "id" : 478260757012819969,
  "created_at" : "2014-06-15 19:40:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AetjXR9PVw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FGdEptqw",
      "display_url" : "pastebin.com\/raw.php?i=FGdE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478257118638665730",
  "text" : "http:\/\/t.co\/AetjXR9PVw Emails: 670 Keywords: 0.02 #infoleak",
  "id" : 478257118638665730,
  "created_at" : "2014-06-15 19:25:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HowDoIDevOps",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477861206464528384",
  "text" : "Hold tight - looks like a crash happened overnight. Restoring the db now. #HowDoIDevOps",
  "id" : 477861206464528384,
  "created_at" : "2014-06-14 17:12:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2wxJBUaByp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2uQ6aRTq",
      "display_url" : "pastebin.com\/raw.php?i=2uQ6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477590746086645760",
  "text" : "http:\/\/t.co\/2wxJBUaByp Emails: 137 Keywords: 0.11 #infoleak",
  "id" : 477590746086645760,
  "created_at" : "2014-06-13 23:18:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SGmGooujxa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Rqg4F6jr",
      "display_url" : "pastebin.com\/raw.php?i=Rqg4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477574558552051712",
  "text" : "http:\/\/t.co\/SGmGooujxa Hashes: 68 Keywords: -0.06 #infoleak",
  "id" : 477574558552051712,
  "created_at" : "2014-06-13 22:13:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bcYQs88Aft",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9287510\/text",
      "display_url" : "pastie.org\/pastes\/9287510\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477540913107832832",
  "text" : "http:\/\/t.co\/bcYQs88Aft Possible cisco configuration #infoleak",
  "id" : 477540913107832832,
  "created_at" : "2014-06-13 20:00:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SPjYjFbBXk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VmgpwpXb",
      "display_url" : "pastebin.com\/raw.php?i=Vmgp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477538814382968832",
  "text" : "http:\/\/t.co\/SPjYjFbBXk Emails: 39 Hashes: 46 E\/H: 0.85 Keywords: 0.11 #infoleak",
  "id" : 477538814382968832,
  "created_at" : "2014-06-13 19:51:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ECnYc7Sv78",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yLvCujdg",
      "display_url" : "pastebin.com\/raw.php?i=yLvC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477538260596453376",
  "text" : "http:\/\/t.co\/ECnYc7Sv78 Emails: 428 Keywords: 0.22 #infoleak",
  "id" : 477538260596453376,
  "created_at" : "2014-06-13 19:49:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y4J9WKmR8t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mfmxg287",
      "display_url" : "pastebin.com\/raw.php?i=mfmx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477536430432862208",
  "text" : "http:\/\/t.co\/Y4J9WKmR8t Emails: 1050 Keywords: 0.33 #infoleak",
  "id" : 477536430432862208,
  "created_at" : "2014-06-13 19:42:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JGZ75zCHMv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XL8n1aaG",
      "display_url" : "pastebin.com\/raw.php?i=XL8n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477527664001953792",
  "text" : "http:\/\/t.co\/JGZ75zCHMv Emails: 877 Keywords: 0.08 #infoleak",
  "id" : 477527664001953792,
  "created_at" : "2014-06-13 19:07:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f80qrr5Jq2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AnTUDMtj",
      "display_url" : "pastebin.com\/raw.php?i=AnTU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477526878786318336",
  "text" : "http:\/\/t.co\/f80qrr5Jq2 Emails: 240 Keywords: 0.11 #infoleak",
  "id" : 477526878786318336,
  "created_at" : "2014-06-13 19:04:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4LF8wkD7gN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n6g8c9gW",
      "display_url" : "pastebin.com\/raw.php?i=n6g8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477521660380069888",
  "text" : "http:\/\/t.co\/4LF8wkD7gN Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 477521660380069888,
  "created_at" : "2014-06-13 18:43:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DumpAllTheThings",
      "indices" : [ 51, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477518963815886849",
  "text" : "New HDD setup - should be back up and running now! #DumpAllTheThings",
  "id" : 477518963815886849,
  "created_at" : "2014-06-13 18:32:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474303834144002048",
  "text" : "Sorry for the extended delay - working on setting up an external HD to handle the database. Stay tuned!",
  "id" : 474303834144002048,
  "created_at" : "2014-06-04 21:37:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
} ]
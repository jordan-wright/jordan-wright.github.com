Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a9FgkATYpv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xUJAZ5YF",
      "display_url" : "pastebin.com\/raw.php?i=xUJA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384931221030965248",
  "text" : "http:\/\/t.co\/a9FgkATYpv Emails: 151 Keywords: 0.0 #infoleak",
  "id" : 384931221030965248,
  "created_at" : "2013-10-01 06:42:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CF7INMoKhq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cuY6EDKN",
      "display_url" : "pastebin.com\/raw.php?i=cuY6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384905214911737856",
  "text" : "http:\/\/t.co\/CF7INMoKhq Emails: 6 Hashes: 104 E\/H: 0.06 Keywords: 0.22 #infoleak",
  "id" : 384905214911737856,
  "created_at" : "2013-10-01 04:58:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V0z2I9pF3T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1nMQvzTb",
      "display_url" : "pastebin.com\/raw.php?i=1nMQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384857733851148288",
  "text" : "http:\/\/t.co\/V0z2I9pF3T Emails: 3 Hashes: 41 E\/H: 0.07 Keywords: 0.11 #infoleak",
  "id" : 384857733851148288,
  "created_at" : "2013-10-01 01:50:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4lERvbjhft",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E2hQYz9D",
      "display_url" : "pastebin.com\/raw.php?i=E2hQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384845355734401024",
  "text" : "http:\/\/t.co\/4lERvbjhft Emails: 23 Keywords: 0.22 #infoleak",
  "id" : 384845355734401024,
  "created_at" : "2013-10-01 01:00:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gWdX3NEwe0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vFqb5TXp",
      "display_url" : "pastebin.com\/raw.php?i=vFqb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384788512119078913",
  "text" : "http:\/\/t.co\/gWdX3NEwe0 Emails: 62 Keywords: 0.22 #infoleak",
  "id" : 384788512119078913,
  "created_at" : "2013-09-30 21:15:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OD1NoKhYQf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=krH8Wc2V",
      "display_url" : "pastebin.com\/raw.php?i=krH8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384567020554948609",
  "text" : "http:\/\/t.co\/OD1NoKhYQf Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 384567020554948609,
  "created_at" : "2013-09-30 06:34:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fICxrKq5jS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4a129PQ6",
      "display_url" : "pastebin.com\/raw.php?i=4a12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384562496524132353",
  "text" : "http:\/\/t.co\/fICxrKq5jS Emails: 45 Hashes: 1 E\/H: 45.0 Keywords: -0.14 #infoleak",
  "id" : 384562496524132353,
  "created_at" : "2013-09-30 06:16:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jN5nDLv5e1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DU8cAaLh",
      "display_url" : "pastebin.com\/raw.php?i=DU8c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384556017679220738",
  "text" : "http:\/\/t.co\/jN5nDLv5e1 Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 384556017679220738,
  "created_at" : "2013-09-30 05:51:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/keIIq1gLFc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZKUrywuN",
      "display_url" : "pastebin.com\/raw.php?i=ZKUr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384549209963102208",
  "text" : "http:\/\/t.co\/keIIq1gLFc Hashes: 91 Keywords: 0.0 #infoleak",
  "id" : 384549209963102208,
  "created_at" : "2013-09-30 05:24:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GPH1fCFGic",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vvVpGfN9",
      "display_url" : "pastebin.com\/raw.php?i=vvVp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384547895807987712",
  "text" : "http:\/\/t.co\/GPH1fCFGic Emails: 99 Keywords: -0.03 #infoleak",
  "id" : 384547895807987712,
  "created_at" : "2013-09-30 05:18:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DehqFitH7J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KGiPWvXQ",
      "display_url" : "pastebin.com\/raw.php?i=KGiP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384522393726615552",
  "text" : "http:\/\/t.co\/DehqFitH7J Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 384522393726615552,
  "created_at" : "2013-09-30 03:37:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AQHqMCvnf3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DZ67jiAy",
      "display_url" : "pastebin.com\/raw.php?i=DZ67\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384518685752180736",
  "text" : "http:\/\/t.co\/AQHqMCvnf3 Emails: 395 Hashes: 842 E\/H: 0.47 Keywords: -0.06 #infoleak",
  "id" : 384518685752180736,
  "created_at" : "2013-09-30 03:22:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XPctnYUsV4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D4yBsw7Y",
      "display_url" : "pastebin.com\/raw.php?i=D4yB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384518016152522753",
  "text" : "http:\/\/t.co\/XPctnYUsV4 Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 384518016152522753,
  "created_at" : "2013-09-30 03:20:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gEMxPKUNfd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z6sBMGnc",
      "display_url" : "pastebin.com\/raw.php?i=Z6sB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384501812893478913",
  "text" : "http:\/\/t.co\/gEMxPKUNfd Emails: 101 Keywords: -0.03 #infoleak",
  "id" : 384501812893478913,
  "created_at" : "2013-09-30 02:15:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Td5w9YLhkK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xXymcnkR",
      "display_url" : "pastebin.com\/raw.php?i=xXym\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384496180391972864",
  "text" : "http:\/\/t.co\/Td5w9YLhkK Emails: 2967 Keywords: 0.22 #infoleak",
  "id" : 384496180391972864,
  "created_at" : "2013-09-30 01:53:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eHhirAiBNi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LMCV1TNM",
      "display_url" : "pastebin.com\/raw.php?i=LMCV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384495303354634240",
  "text" : "http:\/\/t.co\/eHhirAiBNi Emails: 101 Keywords: 0.0 #infoleak",
  "id" : 384495303354634240,
  "created_at" : "2013-09-30 01:49:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0tRuGqn7xF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0z6NWG3e",
      "display_url" : "pastebin.com\/raw.php?i=0z6N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384493171683508226",
  "text" : "http:\/\/t.co\/0tRuGqn7xF Emails: 187 Keywords: 0.22 #infoleak",
  "id" : 384493171683508226,
  "created_at" : "2013-09-30 01:41:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/faywQPCJoc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6gQSk8W0",
      "display_url" : "pastebin.com\/raw.php?i=6gQS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384487158368571392",
  "text" : "http:\/\/t.co\/faywQPCJoc Emails: 99 Keywords: 0.11 #infoleak",
  "id" : 384487158368571392,
  "created_at" : "2013-09-30 01:17:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AuBa8Qkkgn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XRJch1y9",
      "display_url" : "pastebin.com\/raw.php?i=XRJc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384481270614351872",
  "text" : "http:\/\/t.co\/AuBa8Qkkgn Emails: 99 Keywords: -0.03 #infoleak",
  "id" : 384481270614351872,
  "created_at" : "2013-09-30 00:54:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CoKnAA53qu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M9ByDPdc",
      "display_url" : "pastebin.com\/raw.php?i=M9By\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384459940288401408",
  "text" : "http:\/\/t.co\/CoKnAA53qu Emails: 50 Keywords: 0.22 #infoleak",
  "id" : 384459940288401408,
  "created_at" : "2013-09-29 23:29:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FwLVFkwufn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qZsQqE9R",
      "display_url" : "pastebin.com\/raw.php?i=qZsQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384459611161382912",
  "text" : "http:\/\/t.co\/FwLVFkwufn Emails: 82 Keywords: 0.22 #infoleak",
  "id" : 384459611161382912,
  "created_at" : "2013-09-29 23:28:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xEmux0jnWb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RtQQ15gL",
      "display_url" : "pastebin.com\/raw.php?i=RtQQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384449074297974784",
  "text" : "http:\/\/t.co\/xEmux0jnWb Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 384449074297974784,
  "created_at" : "2013-09-29 22:46:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2AqN66fkea",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BcpA6NYM",
      "display_url" : "pastebin.com\/raw.php?i=BcpA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384445584280543232",
  "text" : "http:\/\/t.co\/2AqN66fkea Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 384445584280543232,
  "created_at" : "2013-09-29 22:32:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6wyvAY2IYP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KajNuNKj",
      "display_url" : "pastebin.com\/raw.php?i=KajN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384445340947988481",
  "text" : "http:\/\/t.co\/6wyvAY2IYP Emails: 47 Keywords: 0.0 #infoleak",
  "id" : 384445340947988481,
  "created_at" : "2013-09-29 22:31:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IFt3AFNIK7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rjhUQm2G",
      "display_url" : "pastebin.com\/raw.php?i=rjhU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384429993477951488",
  "text" : "http:\/\/t.co\/IFt3AFNIK7 Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 384429993477951488,
  "created_at" : "2013-09-29 21:30:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zPdCGO1YTy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mmpgfGQE",
      "display_url" : "pastebin.com\/raw.php?i=mmpg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384415704365006848",
  "text" : "http:\/\/t.co\/zPdCGO1YTy Emails: 22 Hashes: 22 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 384415704365006848,
  "created_at" : "2013-09-29 20:33:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/15yXoutOrk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zjejbKsp",
      "display_url" : "pastebin.com\/raw.php?i=zjej\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384415348809674752",
  "text" : "http:\/\/t.co\/15yXoutOrk Emails: 22 Hashes: 22 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 384415348809674752,
  "created_at" : "2013-09-29 20:32:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ezpHW1VHZb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GpDQgvzg",
      "display_url" : "pastebin.com\/raw.php?i=GpDQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384376647404625921",
  "text" : "http:\/\/t.co\/ezpHW1VHZb Hashes: 7574 Keywords: 0.11 #infoleak",
  "id" : 384376647404625921,
  "created_at" : "2013-09-29 17:58:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pYRVbvkGvc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rKfqDGd1",
      "display_url" : "pastebin.com\/raw.php?i=rKfq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384374416852799488",
  "text" : "http:\/\/t.co\/pYRVbvkGvc Possible cisco configuration #infoleak",
  "id" : 384374416852799488,
  "created_at" : "2013-09-29 17:49:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LOVDqLK5sS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gtQuGUK7",
      "display_url" : "pastebin.com\/raw.php?i=gtQu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384374132319608832",
  "text" : "http:\/\/t.co\/LOVDqLK5sS Hashes: 7574 Keywords: 0.11 #infoleak",
  "id" : 384374132319608832,
  "created_at" : "2013-09-29 17:48:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0oOHNJ3Add",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DQuH1ueg",
      "display_url" : "pastebin.com\/raw.php?i=DQuH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384365600396427264",
  "text" : "http:\/\/t.co\/0oOHNJ3Add Hashes: 81 Keywords: 0.33 #infoleak",
  "id" : 384365600396427264,
  "created_at" : "2013-09-29 17:14:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/42b18kqQKW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BTZ5ZKpZ",
      "display_url" : "pastebin.com\/raw.php?i=BTZ5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384363726310080513",
  "text" : "http:\/\/t.co\/42b18kqQKW Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 384363726310080513,
  "created_at" : "2013-09-29 17:07:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gyUIjTPnRP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3Pk60RRN",
      "display_url" : "pastebin.com\/raw.php?i=3Pk6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384363648044380160",
  "text" : "http:\/\/t.co\/gyUIjTPnRP Hashes: 266 Keywords: 0.11 #infoleak",
  "id" : 384363648044380160,
  "created_at" : "2013-09-29 17:06:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CUyxqES13X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x4zdM5Nz",
      "display_url" : "pastebin.com\/raw.php?i=x4zd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384348393645940738",
  "text" : "http:\/\/t.co\/CUyxqES13X Emails: 24 Keywords: -0.03 #infoleak",
  "id" : 384348393645940738,
  "created_at" : "2013-09-29 16:06:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jEBNUZaY0C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bYgTmHrj",
      "display_url" : "pastebin.com\/raw.php?i=bYgT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384347560850104320",
  "text" : "http:\/\/t.co\/jEBNUZaY0C Emails: 2124 Hashes: 2234 E\/H: 0.95 Keywords: 0.74 #infoleak",
  "id" : 384347560850104320,
  "created_at" : "2013-09-29 16:02:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k51TU8lW8B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NJ8C155s",
      "display_url" : "pastebin.com\/raw.php?i=NJ8C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384326895543676928",
  "text" : "http:\/\/t.co\/k51TU8lW8B Emails: 55 Keywords: 0.44 #infoleak",
  "id" : 384326895543676928,
  "created_at" : "2013-09-29 14:40:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bq6hvjzCVR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HHhjgK1J",
      "display_url" : "pastebin.com\/raw.php?i=HHhj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384312131811700737",
  "text" : "http:\/\/t.co\/Bq6hvjzCVR Hashes: 4 Keywords: 0.55 #infoleak",
  "id" : 384312131811700737,
  "created_at" : "2013-09-29 13:42:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jKTigAZTcu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r5zufkxu",
      "display_url" : "pastebin.com\/raw.php?i=r5zu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384310324528037888",
  "text" : "http:\/\/t.co\/jKTigAZTcu Emails: 660 Keywords: 0.0 #infoleak",
  "id" : 384310324528037888,
  "created_at" : "2013-09-29 13:34:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7NFvvOE5t3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nrA0sagE",
      "display_url" : "pastebin.com\/raw.php?i=nrA0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384296248016007168",
  "text" : "http:\/\/t.co\/7NFvvOE5t3 Emails: 24 Keywords: -0.03 #infoleak",
  "id" : 384296248016007168,
  "created_at" : "2013-09-29 12:39:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QaLL9oLfiV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4b5rENLg",
      "display_url" : "pastebin.com\/raw.php?i=4b5r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384293545588174848",
  "text" : "http:\/\/t.co\/QaLL9oLfiV Emails: 32 Hashes: 3150 E\/H: 0.01 Keywords: 0.44 #infoleak",
  "id" : 384293545588174848,
  "created_at" : "2013-09-29 12:28:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NFpK0CBJBw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eR8vkyRL",
      "display_url" : "pastebin.com\/raw.php?i=eR8v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384292565635186688",
  "text" : "http:\/\/t.co\/NFpK0CBJBw Emails: 247 Hashes: 247 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 384292565635186688,
  "created_at" : "2013-09-29 12:24:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jUeLtdOiwn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X7GjPUXj",
      "display_url" : "pastebin.com\/raw.php?i=X7Gj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384240222575140864",
  "text" : "http:\/\/t.co\/jUeLtdOiwn Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 384240222575140864,
  "created_at" : "2013-09-29 08:56:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W6La5tqhhY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yFVyhNwj",
      "display_url" : "pastebin.com\/raw.php?i=yFVy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384126026093035520",
  "text" : "http:\/\/t.co\/W6La5tqhhY Emails: 29 Keywords: -0.03 #infoleak",
  "id" : 384126026093035520,
  "created_at" : "2013-09-29 01:22:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E6zBNTU8Q4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=22bivhxi",
      "display_url" : "pastebin.com\/raw.php?i=22bi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384115482422304768",
  "text" : "http:\/\/t.co\/E6zBNTU8Q4 Emails: 1000 Keywords: 0.3 #infoleak",
  "id" : 384115482422304768,
  "created_at" : "2013-09-29 00:40:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YAaCxjS6rS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R3aT61tg",
      "display_url" : "pastebin.com\/raw.php?i=R3aT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384103339098513409",
  "text" : "http:\/\/t.co\/YAaCxjS6rS Emails: 109 Keywords: 0.11 #infoleak",
  "id" : 384103339098513409,
  "created_at" : "2013-09-28 23:52:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UJ4d6Q2Ugo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vXGpEa2q",
      "display_url" : "pastebin.com\/raw.php?i=vXGp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384084458573291520",
  "text" : "http:\/\/t.co\/UJ4d6Q2Ugo Keywords: 0.55 #infoleak",
  "id" : 384084458573291520,
  "created_at" : "2013-09-28 22:37:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DzoM9qhHDH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nA1Y6B1j",
      "display_url" : "pastebin.com\/raw.php?i=nA1Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384082810555756545",
  "text" : "http:\/\/t.co\/DzoM9qhHDH Emails: 42 Keywords: 0.19 #infoleak",
  "id" : 384082810555756545,
  "created_at" : "2013-09-28 22:30:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bpPbWsGlOE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2D2MkP0P",
      "display_url" : "pastebin.com\/raw.php?i=2D2M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384073086602993665",
  "text" : "http:\/\/t.co\/bpPbWsGlOE Emails: 228 Keywords: 0.19 #infoleak",
  "id" : 384073086602993665,
  "created_at" : "2013-09-28 21:52:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DrBIZ7GVMa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ePPEr0m7",
      "display_url" : "pastebin.com\/raw.php?i=ePPE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384069527228518400",
  "text" : "http:\/\/t.co\/DrBIZ7GVMa Emails: 133 Keywords: -0.03 #infoleak",
  "id" : 384069527228518400,
  "created_at" : "2013-09-28 21:38:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OAFBgmSBf1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WpbfWUPn",
      "display_url" : "pastebin.com\/raw.php?i=Wpbf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384061092420268032",
  "text" : "http:\/\/t.co\/OAFBgmSBf1 Emails: 436 Keywords: 0.19 #infoleak",
  "id" : 384061092420268032,
  "created_at" : "2013-09-28 21:04:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BksD4rL7tq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AaLuDPxT",
      "display_url" : "pastebin.com\/raw.php?i=AaLu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384059034539552768",
  "text" : "http:\/\/t.co\/BksD4rL7tq Hashes: 376 Keywords: 0.11 #infoleak",
  "id" : 384059034539552768,
  "created_at" : "2013-09-28 20:56:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XhwSferyAr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GMhSUMe5",
      "display_url" : "pastebin.com\/raw.php?i=GMhS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384057420395196416",
  "text" : "http:\/\/t.co\/XhwSferyAr Hashes: 43 Keywords: 0.0 #infoleak",
  "id" : 384057420395196416,
  "created_at" : "2013-09-28 20:49:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wIynIgt9ab",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JUQCHhk7",
      "display_url" : "pastebin.com\/raw.php?i=JUQC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384047099160977409",
  "text" : "http:\/\/t.co\/wIynIgt9ab Hashes: 36 Keywords: -0.03 #infoleak",
  "id" : 384047099160977409,
  "created_at" : "2013-09-28 20:08:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qXXFMG6KWU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zRPCxeHW",
      "display_url" : "pastebin.com\/raw.php?i=zRPC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384043324560007168",
  "text" : "http:\/\/t.co\/qXXFMG6KWU Emails: 63 Hashes: 63 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 384043324560007168,
  "created_at" : "2013-09-28 19:53:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NGTl4FlCoq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YXqZFphx",
      "display_url" : "pastebin.com\/raw.php?i=YXqZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384041203823431680",
  "text" : "http:\/\/t.co\/NGTl4FlCoq Emails: 4639 Keywords: 0.19 #infoleak",
  "id" : 384041203823431680,
  "created_at" : "2013-09-28 19:45:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d38EUzSxyq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ayPcLNKX",
      "display_url" : "pastebin.com\/raw.php?i=ayPc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384033010024079360",
  "text" : "http:\/\/t.co\/d38EUzSxyq Hashes: 596 Keywords: 0.11 #infoleak",
  "id" : 384033010024079360,
  "created_at" : "2013-09-28 19:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/84QGysryG6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PMG5C01G",
      "display_url" : "pastebin.com\/raw.php?i=PMG5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384026712448565248",
  "text" : "http:\/\/t.co\/84QGysryG6 Hashes: 7573 Keywords: 0.11 #infoleak",
  "id" : 384026712448565248,
  "created_at" : "2013-09-28 18:47:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r65brd7KGa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1g6UL37a",
      "display_url" : "pastebin.com\/raw.php?i=1g6U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384008127646924800",
  "text" : "http:\/\/t.co\/r65brd7KGa Found possible Google API key(s) #infoleak",
  "id" : 384008127646924800,
  "created_at" : "2013-09-28 17:34:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w2MGn0lfr2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CHSxdazY",
      "display_url" : "pastebin.com\/raw.php?i=CHSx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384007402313367552",
  "text" : "http:\/\/t.co\/w2MGn0lfr2 Emails: 2051 Keywords: 0.08 #infoleak",
  "id" : 384007402313367552,
  "created_at" : "2013-09-28 17:31:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P2QpivGpZ1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UR5up0T2",
      "display_url" : "pastebin.com\/raw.php?i=UR5u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384006699427721216",
  "text" : "http:\/\/t.co\/P2QpivGpZ1 Emails: 9 Hashes: 5 E\/H: 1.8 Keywords: 0.77 #infoleak",
  "id" : 384006699427721216,
  "created_at" : "2013-09-28 17:28:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Jev1eH6Xqm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LshwhJvK",
      "display_url" : "pastebin.com\/raw.php?i=Lshw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384005864153038849",
  "text" : "http:\/\/t.co\/Jev1eH6Xqm Emails: 9 Hashes: 5 E\/H: 1.8 Keywords: 0.77 #infoleak",
  "id" : 384005864153038849,
  "created_at" : "2013-09-28 17:25:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bJVNiNexaX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fThFDTPg",
      "display_url" : "pastebin.com\/raw.php?i=fThF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384005580760702976",
  "text" : "http:\/\/t.co\/bJVNiNexaX Emails: 200 Keywords: 0.11 #infoleak",
  "id" : 384005580760702976,
  "created_at" : "2013-09-28 17:23:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5SMZzmoVYI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=suGUtcYb",
      "display_url" : "pastebin.com\/raw.php?i=suGU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383999250897436672",
  "text" : "http:\/\/t.co\/5SMZzmoVYI Found possible Google API key(s) #infoleak",
  "id" : 383999250897436672,
  "created_at" : "2013-09-28 16:58:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eOkozLnxe8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=isgwQE4f",
      "display_url" : "pastebin.com\/raw.php?i=isgw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383994328491634689",
  "text" : "http:\/\/t.co\/eOkozLnxe8 Emails: 28 Keywords: 0.11 #infoleak",
  "id" : 383994328491634689,
  "created_at" : "2013-09-28 16:39:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tEs69bxLG1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=L3UnBd4R",
      "display_url" : "pastebin.com\/raw.php?i=L3Un\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383983593967480832",
  "text" : "http:\/\/t.co\/tEs69bxLG1 Emails: 743 Keywords: 0.22 #infoleak",
  "id" : 383983593967480832,
  "created_at" : "2013-09-28 15:56:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/54dwO05ZGn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RGKevvgh",
      "display_url" : "pastebin.com\/raw.php?i=RGKe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383968309403611137",
  "text" : "http:\/\/t.co\/54dwO05ZGn Found possible Google API key(s) #infoleak",
  "id" : 383968309403611137,
  "created_at" : "2013-09-28 14:55:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HQbdeMkIoJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=72nvHPZb",
      "display_url" : "pastebin.com\/raw.php?i=72nv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383952773085024256",
  "text" : "http:\/\/t.co\/HQbdeMkIoJ Emails: 194 Keywords: 0.11 #infoleak",
  "id" : 383952773085024256,
  "created_at" : "2013-09-28 13:54:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dF8uyEBIsx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m5L97EkJ",
      "display_url" : "pastebin.com\/raw.php?i=m5L9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383952075446419456",
  "text" : "http:\/\/t.co\/dF8uyEBIsx Emails: 136 Hashes: 2 E\/H: 68.0 Keywords: 0.19 #infoleak",
  "id" : 383952075446419456,
  "created_at" : "2013-09-28 13:51:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c6TXeZGv8I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vpGNtrQM",
      "display_url" : "pastebin.com\/raw.php?i=vpGN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383951310610915328",
  "text" : "http:\/\/t.co\/c6TXeZGv8I Keywords: 0.55 #infoleak",
  "id" : 383951310610915328,
  "created_at" : "2013-09-28 13:48:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hsSBaD9wtW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CdMp8BUX",
      "display_url" : "pastebin.com\/raw.php?i=CdMp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383946356491956224",
  "text" : "http:\/\/t.co\/hsSBaD9wtW Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 383946356491956224,
  "created_at" : "2013-09-28 13:28:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YfukVqi6tb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yk2zymrN",
      "display_url" : "pastebin.com\/raw.php?i=yk2z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383927121820672001",
  "text" : "http:\/\/t.co\/YfukVqi6tb Emails: 99 Keywords: -0.03 #infoleak",
  "id" : 383927121820672001,
  "created_at" : "2013-09-28 12:12:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zCoYyEmkeY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VrUYWj3B",
      "display_url" : "pastebin.com\/raw.php?i=VrUY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383904680297775104",
  "text" : "http:\/\/t.co\/zCoYyEmkeY Emails: 69 Hashes: 139 E\/H: 0.5 Keywords: 0.55 #infoleak",
  "id" : 383904680297775104,
  "created_at" : "2013-09-28 10:43:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I3snUulYDc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bV9jzmkh",
      "display_url" : "pastebin.com\/raw.php?i=bV9j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383904488555175936",
  "text" : "http:\/\/t.co\/I3snUulYDc Emails: 24 Keywords: 0.08 #infoleak",
  "id" : 383904488555175936,
  "created_at" : "2013-09-28 10:42:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BFIj4DH3WL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0Vm9QCaX",
      "display_url" : "pastebin.com\/raw.php?i=0Vm9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383869680206635008",
  "text" : "http:\/\/t.co\/BFIj4DH3WL Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 383869680206635008,
  "created_at" : "2013-09-28 08:23:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/08Goo8dz3X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JqF5LNih",
      "display_url" : "pastebin.com\/raw.php?i=JqF5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383856472712441856",
  "text" : "http:\/\/t.co\/08Goo8dz3X Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 383856472712441856,
  "created_at" : "2013-09-28 07:31:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YTWNT6lZR8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=47aBzZgz",
      "display_url" : "pastebin.com\/raw.php?i=47aB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383820958198296576",
  "text" : "http:\/\/t.co\/YTWNT6lZR8 Keywords: 0.55 #infoleak",
  "id" : 383820958198296576,
  "created_at" : "2013-09-28 05:10:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YC0H2RRGfI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JiRx6DcR",
      "display_url" : "pastebin.com\/raw.php?i=JiRx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383812372550275072",
  "text" : "http:\/\/t.co\/YC0H2RRGfI Emails: 261 Keywords: 0.0 #infoleak",
  "id" : 383812372550275072,
  "created_at" : "2013-09-28 04:36:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FVxK2mKvWS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UkwHan4z",
      "display_url" : "pastebin.com\/raw.php?i=UkwH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383806090762149888",
  "text" : "http:\/\/t.co\/FVxK2mKvWS Hashes: 64 Keywords: 0.33 #infoleak",
  "id" : 383806090762149888,
  "created_at" : "2013-09-28 04:11:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CX3NkwDLfX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TNkLp4gY",
      "display_url" : "pastebin.com\/raw.php?i=TNkL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383801901382242305",
  "text" : "http:\/\/t.co\/CX3NkwDLfX Emails: 164 Hashes: 6 E\/H: 27.33 Keywords: 0.22 #infoleak",
  "id" : 383801901382242305,
  "created_at" : "2013-09-28 03:54:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aVMPFwXEC6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rTeXMCbT",
      "display_url" : "pastebin.com\/raw.php?i=rTeX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383798790764781568",
  "text" : "http:\/\/t.co\/aVMPFwXEC6 Emails: 51 Keywords: 0.0 #infoleak",
  "id" : 383798790764781568,
  "created_at" : "2013-09-28 03:42:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/163YUaLvaS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DarwFeEp",
      "display_url" : "pastebin.com\/raw.php?i=Darw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383798657469796352",
  "text" : "http:\/\/t.co\/163YUaLvaS Keywords: 0.55 #infoleak",
  "id" : 383798657469796352,
  "created_at" : "2013-09-28 03:41:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/APFdbJHvEs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gXKiMqDf",
      "display_url" : "pastebin.com\/raw.php?i=gXKi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383773182789824513",
  "text" : "http:\/\/t.co\/APFdbJHvEs Hashes: 225 Keywords: 0.0 #infoleak",
  "id" : 383773182789824513,
  "created_at" : "2013-09-28 02:00:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lwDrsBtc2x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nFKdzde1",
      "display_url" : "pastebin.com\/raw.php?i=nFKd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383763712437256194",
  "text" : "http:\/\/t.co\/lwDrsBtc2x Emails: 25 Keywords: 0.3 #infoleak",
  "id" : 383763712437256194,
  "created_at" : "2013-09-28 01:22:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NO8gRn6sXE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RKn2H1HX",
      "display_url" : "pastebin.com\/raw.php?i=RKn2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383763064396345344",
  "text" : "http:\/\/t.co\/NO8gRn6sXE Emails: 32 Keywords: 0.08 #infoleak",
  "id" : 383763064396345344,
  "created_at" : "2013-09-28 01:20:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F4Dhf4eTEi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mk3TvYWN",
      "display_url" : "pastebin.com\/raw.php?i=mk3T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383762177288437760",
  "text" : "http:\/\/t.co\/F4Dhf4eTEi Emails: 7460 Hashes: 7805 E\/H: 0.96 Keywords: 0.3 #infoleak",
  "id" : 383762177288437760,
  "created_at" : "2013-09-28 01:16:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EcgOJUWXuY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UrdBKgHD",
      "display_url" : "pastebin.com\/raw.php?i=UrdB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383754168155926528",
  "text" : "http:\/\/t.co\/EcgOJUWXuY Emails: 7876 Keywords: 0.22 #infoleak",
  "id" : 383754168155926528,
  "created_at" : "2013-09-28 00:44:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E2eull33un",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fSSPHARd",
      "display_url" : "pastebin.com\/raw.php?i=fSSP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383707349673713665",
  "text" : "http:\/\/t.co\/E2eull33un Emails: 63 Keywords: 0.22 #infoleak",
  "id" : 383707349673713665,
  "created_at" : "2013-09-27 21:38:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XRK3zXmB7M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nt4CkVcP",
      "display_url" : "pastebin.com\/raw.php?i=nt4C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383701506064539649",
  "text" : "http:\/\/t.co\/XRK3zXmB7M Emails: 125 Keywords: 0.22 #infoleak",
  "id" : 383701506064539649,
  "created_at" : "2013-09-27 21:15:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VGwt21CpPo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MhWcEqtT",
      "display_url" : "pastebin.com\/raw.php?i=MhWc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383666347319623680",
  "text" : "http:\/\/t.co\/VGwt21CpPo Emails: 228 Keywords: 0.3 #infoleak",
  "id" : 383666347319623680,
  "created_at" : "2013-09-27 18:56:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XeiRorNvPn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ie4D9YAC",
      "display_url" : "pastebin.com\/raw.php?i=ie4D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383651024549838849",
  "text" : "http:\/\/t.co\/XeiRorNvPn Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.55 #infoleak",
  "id" : 383651024549838849,
  "created_at" : "2013-09-27 17:55:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kRusL9aL2B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mHqB0zsJ",
      "display_url" : "pastebin.com\/raw.php?i=mHqB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383644671185940480",
  "text" : "http:\/\/t.co\/kRusL9aL2B Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.55 #infoleak",
  "id" : 383644671185940480,
  "created_at" : "2013-09-27 17:29:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zJs5ekolY4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P7wYeTUf",
      "display_url" : "pastebin.com\/raw.php?i=P7wY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383632262060728320",
  "text" : "http:\/\/t.co\/zJs5ekolY4 Emails: 7999 Keywords: -0.03 #infoleak",
  "id" : 383632262060728320,
  "created_at" : "2013-09-27 16:40:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4U9eX0omnK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WKQYyQYQ",
      "display_url" : "pastebin.com\/raw.php?i=WKQY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383627989172248576",
  "text" : "http:\/\/t.co\/4U9eX0omnK Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.55 #infoleak",
  "id" : 383627989172248576,
  "created_at" : "2013-09-27 16:23:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cMcTBNFJL3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EthFnGka",
      "display_url" : "pastebin.com\/raw.php?i=EthF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383622101585760257",
  "text" : "http:\/\/t.co\/cMcTBNFJL3 Emails: 1 Hashes: 30 E\/H: 0.03 Keywords: 0.11 #infoleak",
  "id" : 383622101585760257,
  "created_at" : "2013-09-27 16:00:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h4MSj5uPc9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Lv6V63pi",
      "display_url" : "pastebin.com\/raw.php?i=Lv6V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383592566685327360",
  "text" : "http:\/\/t.co\/h4MSj5uPc9 Emails: 439 Keywords: 0.0 #infoleak",
  "id" : 383592566685327360,
  "created_at" : "2013-09-27 14:02:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ICcq9JiHcK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sCrjzpvN",
      "display_url" : "pastebin.com\/raw.php?i=sCrj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383586424642998272",
  "text" : "http:\/\/t.co\/ICcq9JiHcK Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.55 #infoleak",
  "id" : 383586424642998272,
  "created_at" : "2013-09-27 13:38:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d3FTgCC3HD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gMt30QH5",
      "display_url" : "pastebin.com\/raw.php?i=gMt3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383582957849423872",
  "text" : "http:\/\/t.co\/d3FTgCC3HD Hashes: 73 Keywords: 0.11 #infoleak",
  "id" : 383582957849423872,
  "created_at" : "2013-09-27 13:24:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qh52r9TEWu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nYhhVqjr",
      "display_url" : "pastebin.com\/raw.php?i=nYhh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383581200100491264",
  "text" : "http:\/\/t.co\/Qh52r9TEWu Hashes: 37 Keywords: 0.11 #infoleak",
  "id" : 383581200100491264,
  "created_at" : "2013-09-27 13:17:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ykvAXYFaEd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Asuh0b8d",
      "display_url" : "pastebin.com\/raw.php?i=Asuh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383570921392312320",
  "text" : "http:\/\/t.co\/ykvAXYFaEd Hashes: 943 Keywords: 0.33 #infoleak",
  "id" : 383570921392312320,
  "created_at" : "2013-09-27 12:36:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lyZw4RaAOl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4vJ2q1A6",
      "display_url" : "pastebin.com\/raw.php?i=4vJ2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383539401705287680",
  "text" : "http:\/\/t.co\/lyZw4RaAOl Emails: 161 Hashes: 158 E\/H: 1.02 Keywords: 0.0 #infoleak",
  "id" : 383539401705287680,
  "created_at" : "2013-09-27 10:31:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9iqIF9Ov0K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K0HwaDyH",
      "display_url" : "pastebin.com\/raw.php?i=K0Hw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383477547293347840",
  "text" : "http:\/\/t.co\/9iqIF9Ov0K Hashes: 4 Keywords: 0.77 #infoleak",
  "id" : 383477547293347840,
  "created_at" : "2013-09-27 06:25:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HGfGoKQ7DN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EnWGRUDF",
      "display_url" : "pastebin.com\/raw.php?i=EnWG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383468649899495424",
  "text" : "http:\/\/t.co\/HGfGoKQ7DN Keywords: 0.55 #infoleak",
  "id" : 383468649899495424,
  "created_at" : "2013-09-27 05:50:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mTme1ftIvX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JX0yLX6k",
      "display_url" : "pastebin.com\/raw.php?i=JX0y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383422908413931521",
  "text" : "http:\/\/t.co\/mTme1ftIvX Emails: 1880 Keywords: 0.08 #infoleak",
  "id" : 383422908413931521,
  "created_at" : "2013-09-27 02:48:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lGvm54DEVh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=assrsD5D",
      "display_url" : "pastebin.com\/raw.php?i=assr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383420196871876609",
  "text" : "http:\/\/t.co\/lGvm54DEVh Found possible Google API key(s) #infoleak",
  "id" : 383420196871876609,
  "created_at" : "2013-09-27 02:37:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g2w6IYT21T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WQ4CTUU0",
      "display_url" : "pastebin.com\/raw.php?i=WQ4C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383419836631486464",
  "text" : "http:\/\/t.co\/g2w6IYT21T Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 383419836631486464,
  "created_at" : "2013-09-27 02:36:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Nse22n4aR5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PcmKbyZE",
      "display_url" : "pastebin.com\/raw.php?i=PcmK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383411251860107264",
  "text" : "http:\/\/t.co\/Nse22n4aR5 Emails: 60 Keywords: 0.11 #infoleak",
  "id" : 383411251860107264,
  "created_at" : "2013-09-27 02:02:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CNIrp84ujX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HKABBzzk",
      "display_url" : "pastebin.com\/raw.php?i=HKAB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383400003609178112",
  "text" : "http:\/\/t.co\/CNIrp84ujX Emails: 5654 Keywords: -0.03 #infoleak",
  "id" : 383400003609178112,
  "created_at" : "2013-09-27 01:17:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c9SwL0ZDxZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bcFz1h77",
      "display_url" : "pastebin.com\/raw.php?i=bcFz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383394889892757504",
  "text" : "http:\/\/t.co\/c9SwL0ZDxZ Found possible Google API key(s) #infoleak",
  "id" : 383394889892757504,
  "created_at" : "2013-09-27 00:57:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EeV6QOo6BX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vDXKtXJB",
      "display_url" : "pastebin.com\/raw.php?i=vDXK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383392164375306240",
  "text" : "http:\/\/t.co\/EeV6QOo6BX Emails: 23 Keywords: -0.14 #infoleak",
  "id" : 383392164375306240,
  "created_at" : "2013-09-27 00:46:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T0lMJ2qL8I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t4uGaWKx",
      "display_url" : "pastebin.com\/raw.php?i=t4uG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383390033379475456",
  "text" : "http:\/\/t.co\/T0lMJ2qL8I Possible cisco configuration #infoleak",
  "id" : 383390033379475456,
  "created_at" : "2013-09-27 00:38:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/InsfKFCBR7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p7XHfsEc",
      "display_url" : "pastebin.com\/raw.php?i=p7XH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383373781105786882",
  "text" : "http:\/\/t.co\/InsfKFCBR7 Hashes: 64 Keywords: 0.0 #infoleak",
  "id" : 383373781105786882,
  "created_at" : "2013-09-26 23:33:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TvMZjZTRmO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WQ32Yqet",
      "display_url" : "pastebin.com\/raw.php?i=WQ32\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383356162789220352",
  "text" : "http:\/\/t.co\/TvMZjZTRmO Emails: 387 Keywords: 0.55 #infoleak",
  "id" : 383356162789220352,
  "created_at" : "2013-09-26 22:23:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zs1iEhmI8u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8R4MS5zg",
      "display_url" : "pastebin.com\/raw.php?i=8R4M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383346525041991680",
  "text" : "http:\/\/t.co\/Zs1iEhmI8u Emails: 297 Keywords: 0.22 #infoleak",
  "id" : 383346525041991680,
  "created_at" : "2013-09-26 21:45:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/roaD0wlAwl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UtRzAkCw",
      "display_url" : "pastebin.com\/raw.php?i=UtRz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383344479404445697",
  "text" : "http:\/\/t.co\/roaD0wlAwl Emails: 69 Hashes: 69 E\/H: 1.0 Keywords: 0.0 #infoleak",
  "id" : 383344479404445697,
  "created_at" : "2013-09-26 21:37:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Iqw7dXqjqF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3Ek5kTn9",
      "display_url" : "pastebin.com\/raw.php?i=3Ek5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383340221271535616",
  "text" : "http:\/\/t.co\/Iqw7dXqjqF Hashes: 221 Keywords: -0.06 #infoleak",
  "id" : 383340221271535616,
  "created_at" : "2013-09-26 21:20:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WDCtGRrsCC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8tz3cf7k",
      "display_url" : "pastebin.com\/raw.php?i=8tz3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383340110172807168",
  "text" : "http:\/\/t.co\/WDCtGRrsCC Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 383340110172807168,
  "created_at" : "2013-09-26 21:19:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DxYvioRpCF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bXepz50Y",
      "display_url" : "pastebin.com\/raw.php?i=bXep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383339813996199936",
  "text" : "http:\/\/t.co\/DxYvioRpCF Hashes: 119 Keywords: 0.08 #infoleak",
  "id" : 383339813996199936,
  "created_at" : "2013-09-26 21:18:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UcG4wm1OQU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iWLJdDuS",
      "display_url" : "pastebin.com\/raw.php?i=iWLJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383339517807038464",
  "text" : "http:\/\/t.co\/UcG4wm1OQU Emails: 74 Keywords: -0.03 #infoleak",
  "id" : 383339517807038464,
  "created_at" : "2013-09-26 21:17:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gCuztTpCd0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cawegrku",
      "display_url" : "pastebin.com\/raw.php?i=Cawe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383338576613605376",
  "text" : "http:\/\/t.co\/gCuztTpCd0 Emails: 21 Keywords: 0.11 #infoleak",
  "id" : 383338576613605376,
  "created_at" : "2013-09-26 21:13:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JPcNd2c8RD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eQ1RpGh6",
      "display_url" : "pastebin.com\/raw.php?i=eQ1R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383337226592985089",
  "text" : "http:\/\/t.co\/JPcNd2c8RD Emails: 94 Keywords: 0.0 #infoleak",
  "id" : 383337226592985089,
  "created_at" : "2013-09-26 21:08:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rOaaS8lRR6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qJx9AbKm",
      "display_url" : "pastebin.com\/raw.php?i=qJx9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383331568669847552",
  "text" : "http:\/\/t.co\/rOaaS8lRR6 Hashes: 1922 Keywords: 0.11 #infoleak",
  "id" : 383331568669847552,
  "created_at" : "2013-09-26 20:45:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Sg5ehMk0ps",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZphQQKHC",
      "display_url" : "pastebin.com\/raw.php?i=ZphQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383330286575955968",
  "text" : "http:\/\/t.co\/Sg5ehMk0ps Hashes: 1920 Keywords: 0.11 #infoleak",
  "id" : 383330286575955968,
  "created_at" : "2013-09-26 20:40:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uQvtbjwpDA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1K566ZFD",
      "display_url" : "pastebin.com\/raw.php?i=1K56\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383329793397104640",
  "text" : "http:\/\/t.co\/uQvtbjwpDA Hashes: 1919 Keywords: 0.11 #infoleak",
  "id" : 383329793397104640,
  "created_at" : "2013-09-26 20:38:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iSpFg2UyBX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bPS2Mh32",
      "display_url" : "pastebin.com\/raw.php?i=bPS2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383328144779776002",
  "text" : "http:\/\/t.co\/iSpFg2UyBX Emails: 89 Keywords: 0.0 #infoleak",
  "id" : 383328144779776002,
  "created_at" : "2013-09-26 20:32:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PWMthYhVtC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zv7zjX0T",
      "display_url" : "pastebin.com\/raw.php?i=zv7z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383327356430979072",
  "text" : "http:\/\/t.co\/PWMthYhVtC Emails: 99 Keywords: 0.0 #infoleak",
  "id" : 383327356430979072,
  "created_at" : "2013-09-26 20:28:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZEWzMjBvnN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6Qg4ttdc",
      "display_url" : "pastebin.com\/raw.php?i=6Qg4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383325092014342144",
  "text" : "http:\/\/t.co\/ZEWzMjBvnN Emails: 117 Hashes: 118 E\/H: 0.99 Keywords: 0.11 #infoleak",
  "id" : 383325092014342144,
  "created_at" : "2013-09-26 20:19:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eaFkRmNjr9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mvpk66cK",
      "display_url" : "pastebin.com\/raw.php?i=mvpk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383320522903146497",
  "text" : "http:\/\/t.co\/eaFkRmNjr9 Hashes: 56 Keywords: 0.44 #infoleak",
  "id" : 383320522903146497,
  "created_at" : "2013-09-26 20:01:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uLrLBLtyFO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ctAWQRHR",
      "display_url" : "pastebin.com\/raw.php?i=ctAW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383317841455247361",
  "text" : "http:\/\/t.co\/uLrLBLtyFO Emails: 1 Hashes: 59 E\/H: 0.02 Keywords: -0.03 #infoleak",
  "id" : 383317841455247361,
  "created_at" : "2013-09-26 19:51:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5IC55KkPKD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1jKzwfPD",
      "display_url" : "pastebin.com\/raw.php?i=1jKz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383306356234539008",
  "text" : "http:\/\/t.co\/5IC55KkPKD Emails: 1 Hashes: 701 E\/H: 0.0 Keywords: -0.03 #infoleak",
  "id" : 383306356234539008,
  "created_at" : "2013-09-26 19:05:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nTCvUqzzSO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S9AePvSh",
      "display_url" : "pastebin.com\/raw.php?i=S9Ae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383305562844168193",
  "text" : "http:\/\/t.co\/nTCvUqzzSO Emails: 1 Hashes: 457 E\/H: 0.0 Keywords: 0.11 #infoleak",
  "id" : 383305562844168193,
  "created_at" : "2013-09-26 19:02:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/osSxYHPmmZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZUgL1QWf",
      "display_url" : "pastebin.com\/raw.php?i=ZUgL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383296373929414656",
  "text" : "http:\/\/t.co\/osSxYHPmmZ Keywords: 0.55 #infoleak",
  "id" : 383296373929414656,
  "created_at" : "2013-09-26 18:25:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c4HIdyg7LZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ynsefe45",
      "display_url" : "pastebin.com\/raw.php?i=Ynse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383282027258068992",
  "text" : "http:\/\/t.co\/c4HIdyg7LZ Emails: 66 Hashes: 67 E\/H: 0.99 Keywords: 0.22 #infoleak",
  "id" : 383282027258068992,
  "created_at" : "2013-09-26 17:28:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FRnwbpduon",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PKAYc72d",
      "display_url" : "pastebin.com\/raw.php?i=PKAY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383281907263225856",
  "text" : "http:\/\/t.co\/FRnwbpduon Hashes: 97 Keywords: -0.03 #infoleak",
  "id" : 383281907263225856,
  "created_at" : "2013-09-26 17:28:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sJaYgVZA4h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NSeCktgZ",
      "display_url" : "pastebin.com\/raw.php?i=NSeC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383278359972569088",
  "text" : "http:\/\/t.co\/sJaYgVZA4h Emails: 155 Hashes: 159 E\/H: 0.97 Keywords: 0.22 #infoleak",
  "id" : 383278359972569088,
  "created_at" : "2013-09-26 17:14:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MFuP0xKlTi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gXByM0py",
      "display_url" : "pastebin.com\/raw.php?i=gXBy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383277219423870976",
  "text" : "http:\/\/t.co\/MFuP0xKlTi Emails: 155 Hashes: 159 E\/H: 0.97 Keywords: 0.33 #infoleak",
  "id" : 383277219423870976,
  "created_at" : "2013-09-26 17:09:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j20F6WS09W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Sb2fLRh",
      "display_url" : "pastebin.com\/raw.php?i=7Sb2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383269897456738304",
  "text" : "http:\/\/t.co\/j20F6WS09W Hashes: 3078 Keywords: 0.22 #infoleak",
  "id" : 383269897456738304,
  "created_at" : "2013-09-26 16:40:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YBvYmRqGIg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hvwNZ7F2",
      "display_url" : "pastebin.com\/raw.php?i=hvwN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383247757407842304",
  "text" : "http:\/\/t.co\/YBvYmRqGIg Hashes: 1947 Keywords: 0.41 #infoleak",
  "id" : 383247757407842304,
  "created_at" : "2013-09-26 15:12:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ubqnxgXf8C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dBfTZcU6",
      "display_url" : "pastebin.com\/raw.php?i=dBfT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383240882079531009",
  "text" : "http:\/\/t.co\/ubqnxgXf8C Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 383240882079531009,
  "created_at" : "2013-09-26 14:45:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t5dobdhzhE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XQ8LDJ8P",
      "display_url" : "pastebin.com\/raw.php?i=XQ8L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383237790772649985",
  "text" : "http:\/\/t.co\/t5dobdhzhE Emails: 654 Hashes: 657 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 383237790772649985,
  "created_at" : "2013-09-26 14:33:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BluWkJKZKT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2S3tDRak",
      "display_url" : "pastebin.com\/raw.php?i=2S3t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383237016877428737",
  "text" : "http:\/\/t.co\/BluWkJKZKT Emails: 55 Keywords: 0.0 #infoleak",
  "id" : 383237016877428737,
  "created_at" : "2013-09-26 14:29:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NbZrI9RXbj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rcgEAwwL",
      "display_url" : "pastebin.com\/raw.php?i=rcgE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383235980976594944",
  "text" : "http:\/\/t.co\/NbZrI9RXbj Hashes: 640 Keywords: 0.41 #infoleak",
  "id" : 383235980976594944,
  "created_at" : "2013-09-26 14:25:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yK4BqPyxPm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tENRXzT3",
      "display_url" : "pastebin.com\/raw.php?i=tENR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383210935839490048",
  "text" : "http:\/\/t.co\/yK4BqPyxPm Emails: 296 Keywords: 0.11 #infoleak",
  "id" : 383210935839490048,
  "created_at" : "2013-09-26 12:46:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DzJy1rWoHa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tja8bKAG",
      "display_url" : "pastebin.com\/raw.php?i=Tja8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383209444055601152",
  "text" : "http:\/\/t.co\/DzJy1rWoHa Hashes: 2341 Keywords: 0.11 #infoleak",
  "id" : 383209444055601152,
  "created_at" : "2013-09-26 12:40:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rGfEVf8HGf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Afuum4ex",
      "display_url" : "pastebin.com\/raw.php?i=Afuu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383191042096263169",
  "text" : "http:\/\/t.co\/rGfEVf8HGf Keywords: 0.55 #infoleak",
  "id" : 383191042096263169,
  "created_at" : "2013-09-26 11:27:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/huJ7rOharP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5eiXe3Y5",
      "display_url" : "pastebin.com\/raw.php?i=5eiX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383188717675876352",
  "text" : "http:\/\/t.co\/huJ7rOharP Emails: 1485 Keywords: 0.19 #infoleak",
  "id" : 383188717675876352,
  "created_at" : "2013-09-26 11:18:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mdMpx3dZDJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m5A5g1xt",
      "display_url" : "pastebin.com\/raw.php?i=m5A5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383164331212296193",
  "text" : "http:\/\/t.co\/mdMpx3dZDJ Emails: 38 Hashes: 1048 E\/H: 0.04 Keywords: 0.66 #infoleak",
  "id" : 383164331212296193,
  "created_at" : "2013-09-26 09:41:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TrxOj15fyI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jXQHq0Kx",
      "display_url" : "pastebin.com\/raw.php?i=jXQH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383160840934797312",
  "text" : "http:\/\/t.co\/TrxOj15fyI Emails: 137 Keywords: 0.22 #infoleak",
  "id" : 383160840934797312,
  "created_at" : "2013-09-26 09:27:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x339XhcHJS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kAp5S0JF",
      "display_url" : "pastebin.com\/raw.php?i=kAp5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383106704230973440",
  "text" : "http:\/\/t.co\/x339XhcHJS Emails: 40 Hashes: 77 E\/H: 0.52 Keywords: 0.11 #infoleak",
  "id" : 383106704230973440,
  "created_at" : "2013-09-26 05:52:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CcEJdEWjmh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=71g94XW1",
      "display_url" : "pastebin.com\/raw.php?i=71g9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382999855133515776",
  "text" : "http:\/\/t.co\/CcEJdEWjmh Possible cisco configuration #infoleak",
  "id" : 382999855133515776,
  "created_at" : "2013-09-25 22:47:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mcyT8nKXrO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KvuBAD0N",
      "display_url" : "pastebin.com\/raw.php?i=KvuB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382999246128947200",
  "text" : "http:\/\/t.co\/mcyT8nKXrO Hashes: 1 Keywords: 0.66 #infoleak",
  "id" : 382999246128947200,
  "created_at" : "2013-09-25 22:45:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yxn8F9ptqb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=euMkwd3p",
      "display_url" : "pastebin.com\/raw.php?i=euMk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382985418343337986",
  "text" : "http:\/\/t.co\/Yxn8F9ptqb Emails: 1635 Keywords: 0.0 #infoleak",
  "id" : 382985418343337986,
  "created_at" : "2013-09-25 21:50:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HaIlvsSPsW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NAfEdJ6q",
      "display_url" : "pastebin.com\/raw.php?i=NAfE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382980524601384960",
  "text" : "http:\/\/t.co\/HaIlvsSPsW Emails: 142 Hashes: 13 E\/H: 10.92 Keywords: 0.22 #infoleak",
  "id" : 382980524601384960,
  "created_at" : "2013-09-25 21:30:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R4tvnN9cma",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fGBf9ybg",
      "display_url" : "pastebin.com\/raw.php?i=fGBf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382979322593546240",
  "text" : "http:\/\/t.co\/R4tvnN9cma Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 382979322593546240,
  "created_at" : "2013-09-25 21:26:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lFEPc1RIew",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kJaX0rFv",
      "display_url" : "pastebin.com\/raw.php?i=kJaX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382976934692417536",
  "text" : "http:\/\/t.co\/lFEPc1RIew Emails: 27 Hashes: 1 E\/H: 27.0 Keywords: 0.11 #infoleak",
  "id" : 382976934692417536,
  "created_at" : "2013-09-25 21:16:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/22dsIshlKd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2MqrZuWa",
      "display_url" : "pastebin.com\/raw.php?i=2Mqr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382968260880130048",
  "text" : "http:\/\/t.co\/22dsIshlKd Found possible Google API key(s) #infoleak",
  "id" : 382968260880130048,
  "created_at" : "2013-09-25 20:42:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tX3Pq6Pmt2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JR82M8Hv",
      "display_url" : "pastebin.com\/raw.php?i=JR82\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382935395756830720",
  "text" : "http:\/\/t.co\/tX3Pq6Pmt2 Emails: 800 Keywords: 0.22 #infoleak",
  "id" : 382935395756830720,
  "created_at" : "2013-09-25 18:31:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6SM9oDkCCT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZSdwg5n0",
      "display_url" : "pastebin.com\/raw.php?i=ZSdw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382921619691147264",
  "text" : "http:\/\/t.co\/6SM9oDkCCT Emails: 44 Hashes: 75 E\/H: 0.59 Keywords: 0.44 #infoleak",
  "id" : 382921619691147264,
  "created_at" : "2013-09-25 17:36:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JX4oBfP38j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JGGsmZ4a",
      "display_url" : "pastebin.com\/raw.php?i=JGGs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382918128830656513",
  "text" : "http:\/\/t.co\/JX4oBfP38j Emails: 212 Keywords: 0.44 #infoleak",
  "id" : 382918128830656513,
  "created_at" : "2013-09-25 17:22:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/skBdIPx5MZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VjqX8xd1",
      "display_url" : "pastebin.com\/raw.php?i=VjqX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382902758866563072",
  "text" : "http:\/\/t.co\/skBdIPx5MZ Emails: 12 Hashes: 130 E\/H: 0.09 Keywords: 0.33 #infoleak",
  "id" : 382902758866563072,
  "created_at" : "2013-09-25 16:21:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5L4voonHtO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mer2Kydb",
      "display_url" : "pastebin.com\/raw.php?i=Mer2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382889430307991552",
  "text" : "http:\/\/t.co\/5L4voonHtO Keywords: 0.55 #infoleak",
  "id" : 382889430307991552,
  "created_at" : "2013-09-25 15:28:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tos7mIVwOQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R57J584E",
      "display_url" : "pastebin.com\/raw.php?i=R57J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382887184258195456",
  "text" : "http:\/\/t.co\/Tos7mIVwOQ Emails: 463 Keywords: 0.11 #infoleak",
  "id" : 382887184258195456,
  "created_at" : "2013-09-25 15:19:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l7eBr8e0yt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5tsHAezP",
      "display_url" : "pastebin.com\/raw.php?i=5tsH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382886663233359872",
  "text" : "http:\/\/t.co\/l7eBr8e0yt Hashes: 51 Keywords: 0.11 #infoleak",
  "id" : 382886663233359872,
  "created_at" : "2013-09-25 15:17:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fdnb9RSVpN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TUdPkUhf",
      "display_url" : "pastebin.com\/raw.php?i=TUdP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382801353153605632",
  "text" : "http:\/\/t.co\/fdnb9RSVpN Keywords: 0.55 #infoleak",
  "id" : 382801353153605632,
  "created_at" : "2013-09-25 09:38:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9U8T4rcCNY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F23QV2qM",
      "display_url" : "pastebin.com\/raw.php?i=F23Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382797953091383296",
  "text" : "http:\/\/t.co\/9U8T4rcCNY Keywords: 0.55 #infoleak",
  "id" : 382797953091383296,
  "created_at" : "2013-09-25 09:25:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VzoMsSuPMC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UMFKmBYN",
      "display_url" : "pastebin.com\/raw.php?i=UMFK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382793944624402432",
  "text" : "http:\/\/t.co\/VzoMsSuPMC Emails: 51 Hashes: 51 E\/H: 1.0 Keywords: 0.44 #infoleak",
  "id" : 382793944624402432,
  "created_at" : "2013-09-25 09:09:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NYeHllEyOV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NVD98ywJ",
      "display_url" : "pastebin.com\/raw.php?i=NVD9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382792908400631808",
  "text" : "http:\/\/t.co\/NYeHllEyOV Hashes: 268 Keywords: 0.16 #infoleak",
  "id" : 382792908400631808,
  "created_at" : "2013-09-25 09:05:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/csF0oyYXhf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7pz3heNC",
      "display_url" : "pastebin.com\/raw.php?i=7pz3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382781301838729216",
  "text" : "http:\/\/t.co\/csF0oyYXhf Emails: 3 Hashes: 6 E\/H: 0.5 Keywords: 0.55 #infoleak",
  "id" : 382781301838729216,
  "created_at" : "2013-09-25 08:19:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/015PywFjM4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6S83ABvg",
      "display_url" : "pastebin.com\/raw.php?i=6S83\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382772777750515713",
  "text" : "http:\/\/t.co\/015PywFjM4 Hashes: 89 Keywords: -0.14 #infoleak",
  "id" : 382772777750515713,
  "created_at" : "2013-09-25 07:45:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/icuqjxirjF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4EUSSGmU",
      "display_url" : "pastebin.com\/raw.php?i=4EUS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382771668285784064",
  "text" : "http:\/\/t.co\/icuqjxirjF Emails: 73 Keywords: 0.0 #infoleak",
  "id" : 382771668285784064,
  "created_at" : "2013-09-25 07:40:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kMJHXe1Otc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z9diiD6V",
      "display_url" : "pastebin.com\/raw.php?i=Z9di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382766940193689600",
  "text" : "http:\/\/t.co\/kMJHXe1Otc Emails: 87 Keywords: 0.22 #infoleak",
  "id" : 382766940193689600,
  "created_at" : "2013-09-25 07:22:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MfEFBfivqY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=whL2SjSG",
      "display_url" : "pastebin.com\/raw.php?i=whL2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382757122728927232",
  "text" : "http:\/\/t.co\/MfEFBfivqY Emails: 38 Keywords: 0.08 #infoleak",
  "id" : 382757122728927232,
  "created_at" : "2013-09-25 06:43:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/66kTrNAUlD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mKkUvUkU",
      "display_url" : "pastebin.com\/raw.php?i=mKkU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382726730965741568",
  "text" : "http:\/\/t.co\/66kTrNAUlD Emails: 133 Keywords: 0.33 #infoleak",
  "id" : 382726730965741568,
  "created_at" : "2013-09-25 04:42:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4xPkE8WA7E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iY32p6FM",
      "display_url" : "pastebin.com\/raw.php?i=iY32\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382707429177163777",
  "text" : "http:\/\/t.co\/4xPkE8WA7E Emails: 5995 Keywords: 0.19 #infoleak",
  "id" : 382707429177163777,
  "created_at" : "2013-09-25 03:25:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HWEc85Yb5N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8Xd9G6F7",
      "display_url" : "pastebin.com\/raw.php?i=8Xd9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382680024018456576",
  "text" : "http:\/\/t.co\/HWEc85Yb5N Emails: 47 Keywords: 0.44 #infoleak",
  "id" : 382680024018456576,
  "created_at" : "2013-09-25 01:36:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PUnYxs1IdH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2wunKm94",
      "display_url" : "pastebin.com\/raw.php?i=2wun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382667039128559616",
  "text" : "http:\/\/t.co\/PUnYxs1IdH Hashes: 162 Keywords: 0.11 #infoleak",
  "id" : 382667039128559616,
  "created_at" : "2013-09-25 00:45:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rIGRewoIBO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HQdBQSpa",
      "display_url" : "pastebin.com\/raw.php?i=HQdB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382644012428976128",
  "text" : "http:\/\/t.co\/rIGRewoIBO Emails: 20 Keywords: 0.11 #infoleak",
  "id" : 382644012428976128,
  "created_at" : "2013-09-24 23:13:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3GsUG1vAg6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gkrcwibN",
      "display_url" : "pastebin.com\/raw.php?i=gkrc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382635626060738560",
  "text" : "http:\/\/t.co\/3GsUG1vAg6 Emails: 157 Keywords: 0.0 #infoleak",
  "id" : 382635626060738560,
  "created_at" : "2013-09-24 22:40:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I4Ke1zd5Jj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CcxFk7R8",
      "display_url" : "pastebin.com\/raw.php?i=CcxF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382635506279776256",
  "text" : "http:\/\/t.co\/I4Ke1zd5Jj Emails: 142 Hashes: 298 E\/H: 0.48 Keywords: 0.08 #infoleak",
  "id" : 382635506279776256,
  "created_at" : "2013-09-24 22:39:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TAsV6gdXwg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8WCFzEQg",
      "display_url" : "pastebin.com\/raw.php?i=8WCF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382624182359433216",
  "text" : "http:\/\/t.co\/TAsV6gdXwg Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 382624182359433216,
  "created_at" : "2013-09-24 21:54:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ukvyC8RdXZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xM4qr4Tx",
      "display_url" : "pastebin.com\/raw.php?i=xM4q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382622687962492928",
  "text" : "http:\/\/t.co\/ukvyC8RdXZ Keywords: 0.55 #infoleak",
  "id" : 382622687962492928,
  "created_at" : "2013-09-24 21:48:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eX01sUiWvN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bceHTcEh",
      "display_url" : "pastebin.com\/raw.php?i=bceH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382605925426536448",
  "text" : "http:\/\/t.co\/eX01sUiWvN Hashes: 2 Keywords: 0.55 #infoleak",
  "id" : 382605925426536448,
  "created_at" : "2013-09-24 20:42:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ycG5yaelRG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZgZY5qmb",
      "display_url" : "pastebin.com\/raw.php?i=ZgZY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382601284869566464",
  "text" : "http:\/\/t.co\/ycG5yaelRG Emails: 33 Keywords: 0.11 #infoleak",
  "id" : 382601284869566464,
  "created_at" : "2013-09-24 20:23:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3fPdWgP27c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dDTgfDJK",
      "display_url" : "pastebin.com\/raw.php?i=dDTg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382591520718594048",
  "text" : "http:\/\/t.co\/3fPdWgP27c Hashes: 30 Keywords: -0.17 #infoleak",
  "id" : 382591520718594048,
  "created_at" : "2013-09-24 19:45:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qMqB21jAqw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZJLExrmv",
      "display_url" : "pastebin.com\/raw.php?i=ZJLE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382580700362199041",
  "text" : "http:\/\/t.co\/qMqB21jAqw Hashes: 41 Keywords: 0.22 #infoleak",
  "id" : 382580700362199041,
  "created_at" : "2013-09-24 19:02:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4Scjp1RSVO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R4erCbW2",
      "display_url" : "pastebin.com\/raw.php?i=R4er\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382559188192198657",
  "text" : "http:\/\/t.co\/4Scjp1RSVO Possible cisco configuration #infoleak",
  "id" : 382559188192198657,
  "created_at" : "2013-09-24 17:36:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/awAncrv7S3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0dq7UkMX",
      "display_url" : "pastebin.com\/raw.php?i=0dq7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382541930141204482",
  "text" : "http:\/\/t.co\/awAncrv7S3 Keywords: 0.55 #infoleak",
  "id" : 382541930141204482,
  "created_at" : "2013-09-24 16:27:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FmcPMlB5NO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S2jE4ZAx",
      "display_url" : "pastebin.com\/raw.php?i=S2jE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382536658962227200",
  "text" : "http:\/\/t.co\/FmcPMlB5NO Hashes: 35 Keywords: 0.0 #infoleak",
  "id" : 382536658962227200,
  "created_at" : "2013-09-24 16:07:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UuMtPXzPqC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=npKT8AX9",
      "display_url" : "pastebin.com\/raw.php?i=npKT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382439898206072832",
  "text" : "http:\/\/t.co\/UuMtPXzPqC Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 382439898206072832,
  "created_at" : "2013-09-24 09:42:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I6K12MIc6u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xEmLajSs",
      "display_url" : "pastebin.com\/raw.php?i=xEmL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382384620622213120",
  "text" : "http:\/\/t.co\/I6K12MIc6u Emails: 210 Keywords: 0.0 #infoleak",
  "id" : 382384620622213120,
  "created_at" : "2013-09-24 06:02:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cERsVnQMPp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eeujTxiG",
      "display_url" : "pastebin.com\/raw.php?i=eeuj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382305064330604544",
  "text" : "http:\/\/t.co\/cERsVnQMPp Emails: 39 Keywords: 0.0 #infoleak",
  "id" : 382305064330604544,
  "created_at" : "2013-09-24 00:46:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p2lvew4RrV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZCqnEbrv",
      "display_url" : "pastebin.com\/raw.php?i=ZCqn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382272405197946881",
  "text" : "http:\/\/t.co\/p2lvew4RrV Possible cisco configuration #infoleak",
  "id" : 382272405197946881,
  "created_at" : "2013-09-23 22:36:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r0rEr6zFQ3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6GKuvYrs",
      "display_url" : "pastebin.com\/raw.php?i=6GKu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382269351065178112",
  "text" : "http:\/\/t.co\/r0rEr6zFQ3 Emails: 3101 Keywords: 0.11 #infoleak",
  "id" : 382269351065178112,
  "created_at" : "2013-09-23 22:24:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PBSJhUvtor",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zGt7HPKz",
      "display_url" : "pastebin.com\/raw.php?i=zGt7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382268492713426944",
  "text" : "http:\/\/t.co\/PBSJhUvtor Emails: 20 Keywords: 0.11 #infoleak",
  "id" : 382268492713426944,
  "created_at" : "2013-09-23 22:21:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lvKQU88a4j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VHy5azU8",
      "display_url" : "pastebin.com\/raw.php?i=VHy5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382268379714699264",
  "text" : "http:\/\/t.co\/lvKQU88a4j Hashes: 135 Keywords: 0.0 #infoleak",
  "id" : 382268379714699264,
  "created_at" : "2013-09-23 22:20:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nSGzdkNAjq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i9ye3wZX",
      "display_url" : "pastebin.com\/raw.php?i=i9ye\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382222458675159040",
  "text" : "http:\/\/t.co\/nSGzdkNAjq Emails: 10 Hashes: 126 E\/H: 0.08 Keywords: 0.52 #infoleak",
  "id" : 382222458675159040,
  "created_at" : "2013-09-23 19:18:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QdKrhzrPgV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=51T5n7bj",
      "display_url" : "pastebin.com\/raw.php?i=51T5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382070984825516032",
  "text" : "http:\/\/t.co\/QdKrhzrPgV Hashes: 192 Keywords: -0.03 #infoleak",
  "id" : 382070984825516032,
  "created_at" : "2013-09-23 09:16:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gYUx83uagX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XRFXvz6h",
      "display_url" : "pastebin.com\/raw.php?i=XRFX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382062685459714049",
  "text" : "http:\/\/t.co\/gYUx83uagX Emails: 74 Keywords: 0.33 #infoleak",
  "id" : 382062685459714049,
  "created_at" : "2013-09-23 08:43:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BkhcWyZ5NT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sNPqCuEF",
      "display_url" : "pastebin.com\/raw.php?i=sNPq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381986493155143680",
  "text" : "http:\/\/t.co\/BkhcWyZ5NT Emails: 25 Hashes: 21 E\/H: 1.19 Keywords: 0.11 #infoleak",
  "id" : 381986493155143680,
  "created_at" : "2013-09-23 03:40:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IJ2aifc2Kp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zbw4BXQn",
      "display_url" : "pastebin.com\/raw.php?i=Zbw4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381882748572426240",
  "text" : "http:\/\/t.co\/IJ2aifc2Kp Emails: 994 Keywords: 0.22 #infoleak",
  "id" : 381882748572426240,
  "created_at" : "2013-09-22 20:48:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/npRiJ8y19g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P3bV2ZFJ",
      "display_url" : "pastebin.com\/raw.php?i=P3bV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381869221585506304",
  "text" : "http:\/\/t.co\/npRiJ8y19g Possible cisco configuration #infoleak",
  "id" : 381869221585506304,
  "created_at" : "2013-09-22 19:54:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IpAdUigrEp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vcxuvy1x",
      "display_url" : "pastebin.com\/raw.php?i=vcxu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381853817383317504",
  "text" : "http:\/\/t.co\/IpAdUigrEp Emails: 72 Keywords: 0.44 #infoleak",
  "id" : 381853817383317504,
  "created_at" : "2013-09-22 18:53:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gNGEEGNYxR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7NJhRuCZ",
      "display_url" : "pastebin.com\/raw.php?i=7NJh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381813976239058946",
  "text" : "http:\/\/t.co\/gNGEEGNYxR Emails: 876 Keywords: 0.22 #infoleak",
  "id" : 381813976239058946,
  "created_at" : "2013-09-22 16:15:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5IWJsWtb0l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mr3NemKM",
      "display_url" : "pastebin.com\/raw.php?i=Mr3N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381808012991553536",
  "text" : "http:\/\/t.co\/5IWJsWtb0l Emails: 877 Keywords: 0.22 #infoleak",
  "id" : 381808012991553536,
  "created_at" : "2013-09-22 15:51:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rF0IC5Tj7E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yDN9U1Z3",
      "display_url" : "pastebin.com\/raw.php?i=yDN9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381804194966933505",
  "text" : "http:\/\/t.co\/rF0IC5Tj7E Emails: 293 Keywords: 0.3 #infoleak",
  "id" : 381804194966933505,
  "created_at" : "2013-09-22 15:36:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AebtNj5bvK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r76BtJxY",
      "display_url" : "pastebin.com\/raw.php?i=r76B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381803938556551168",
  "text" : "http:\/\/t.co\/AebtNj5bvK Possible cisco configuration #infoleak",
  "id" : 381803938556551168,
  "created_at" : "2013-09-22 15:35:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PTmNXu3dpv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ru4rGbLa",
      "display_url" : "pastebin.com\/raw.php?i=Ru4r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381800822360662016",
  "text" : "http:\/\/t.co\/PTmNXu3dpv Emails: 58 Keywords: 0.22 #infoleak",
  "id" : 381800822360662016,
  "created_at" : "2013-09-22 15:23:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eZ4GRYSKTB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PXUxuAhL",
      "display_url" : "pastebin.com\/raw.php?i=PXUx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381796889554731008",
  "text" : "http:\/\/t.co\/eZ4GRYSKTB Emails: 115 Keywords: 0.08 #infoleak",
  "id" : 381796889554731008,
  "created_at" : "2013-09-22 15:07:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8M3PeRUWxl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P3TuPDr4",
      "display_url" : "pastebin.com\/raw.php?i=P3Tu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381791885909442560",
  "text" : "http:\/\/t.co\/8M3PeRUWxl Emails: 813 Keywords: 0.44 #infoleak",
  "id" : 381791885909442560,
  "created_at" : "2013-09-22 14:47:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t0lJCpiN5f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XVbBxcqD",
      "display_url" : "pastebin.com\/raw.php?i=XVbB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381779090404945920",
  "text" : "http:\/\/t.co\/t0lJCpiN5f Emails: 63 Keywords: 0.11 #infoleak",
  "id" : 381779090404945920,
  "created_at" : "2013-09-22 13:56:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d1FkJA8Vg9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RWM70rDx",
      "display_url" : "pastebin.com\/raw.php?i=RWM7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381778562442743808",
  "text" : "http:\/\/t.co\/d1FkJA8Vg9 Emails: 123 Keywords: 0.11 #infoleak",
  "id" : 381778562442743808,
  "created_at" : "2013-09-22 13:54:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FNcF1TYQ91",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DkA6UG2G",
      "display_url" : "pastebin.com\/raw.php?i=DkA6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381778441017647104",
  "text" : "http:\/\/t.co\/FNcF1TYQ91 Emails: 877 Keywords: 0.22 #infoleak",
  "id" : 381778441017647104,
  "created_at" : "2013-09-22 13:54:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LHX5DdQ6Z6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VYV8E7hM",
      "display_url" : "pastebin.com\/raw.php?i=VYV8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381774468709752833",
  "text" : "http:\/\/t.co\/LHX5DdQ6Z6 Found possible Google API key(s) #infoleak",
  "id" : 381774468709752833,
  "created_at" : "2013-09-22 13:38:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Byk98azKzN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nVM8AUed",
      "display_url" : "pastebin.com\/raw.php?i=nVM8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381760902929715200",
  "text" : "http:\/\/t.co\/Byk98azKzN Emails: 42 Keywords: 0.0 #infoleak",
  "id" : 381760902929715200,
  "created_at" : "2013-09-22 12:44:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WnwVXGI168",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=na6ZLQTq",
      "display_url" : "pastebin.com\/raw.php?i=na6Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381759969609003008",
  "text" : "http:\/\/t.co\/WnwVXGI168 Emails: 14220 Keywords: -0.03 #infoleak",
  "id" : 381759969609003008,
  "created_at" : "2013-09-22 12:40:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fNJcU6Bis2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uxhdmNs7",
      "display_url" : "pastebin.com\/raw.php?i=uxhd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381756432023961600",
  "text" : "http:\/\/t.co\/fNJcU6Bis2 Hashes: 45 Keywords: 0.0 #infoleak",
  "id" : 381756432023961600,
  "created_at" : "2013-09-22 12:26:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tda6YsWMLJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=L6DJ9Rh6",
      "display_url" : "pastebin.com\/raw.php?i=L6DJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381753326439641088",
  "text" : "http:\/\/t.co\/tda6YsWMLJ Emails: 322 Keywords: 0.0 #infoleak",
  "id" : 381753326439641088,
  "created_at" : "2013-09-22 12:14:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gApO7Nkfj0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1y7HGpcU",
      "display_url" : "pastebin.com\/raw.php?i=1y7H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381749912611741696",
  "text" : "http:\/\/t.co\/gApO7Nkfj0 Emails: 119 Keywords: -0.03 #infoleak",
  "id" : 381749912611741696,
  "created_at" : "2013-09-22 12:00:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j9kQJLonMY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gpd9tbx4",
      "display_url" : "pastebin.com\/raw.php?i=gpd9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381713575166763009",
  "text" : "http:\/\/t.co\/j9kQJLonMY Keywords: 0.55 #infoleak",
  "id" : 381713575166763009,
  "created_at" : "2013-09-22 09:36:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g0dGPTF1ja",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WWEwEK6G",
      "display_url" : "pastebin.com\/raw.php?i=WWEw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381710848198053888",
  "text" : "http:\/\/t.co\/g0dGPTF1ja Emails: 21 Hashes: 73 E\/H: 0.29 Keywords: 0.08 #infoleak",
  "id" : 381710848198053888,
  "created_at" : "2013-09-22 09:25:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GUdRPCjYGh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZbkgFLBb",
      "display_url" : "pastebin.com\/raw.php?i=Zbkg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381623971700932609",
  "text" : "http:\/\/t.co\/GUdRPCjYGh Keywords: 0.55 #infoleak",
  "id" : 381623971700932609,
  "created_at" : "2013-09-22 03:40:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/agKEkNLlNT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gvYT1ftK",
      "display_url" : "pastebin.com\/raw.php?i=gvYT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381578560726515712",
  "text" : "http:\/\/t.co\/agKEkNLlNT Emails: 38 Hashes: 12 E\/H: 3.17 Keywords: 0.19 #infoleak",
  "id" : 381578560726515712,
  "created_at" : "2013-09-22 00:39:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XC78V8hm6r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9KRdT8Rz",
      "display_url" : "pastebin.com\/raw.php?i=9KRd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381578406074146817",
  "text" : "http:\/\/t.co\/XC78V8hm6r Emails: 206 Hashes: 13 E\/H: 15.85 Keywords: 0.19 #infoleak",
  "id" : 381578406074146817,
  "created_at" : "2013-09-22 00:39:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YObrOvzwis",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=95MMqNAD",
      "display_url" : "pastebin.com\/raw.php?i=95MM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381577842078662656",
  "text" : "http:\/\/t.co\/YObrOvzwis Emails: 38 Hashes: 12 E\/H: 3.17 Keywords: 0.19 #infoleak",
  "id" : 381577842078662656,
  "created_at" : "2013-09-22 00:37:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dLKMWSNT7i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=szkeAZEL",
      "display_url" : "pastebin.com\/raw.php?i=szke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381571628393451520",
  "text" : "http:\/\/t.co\/dLKMWSNT7i Emails: 812 Keywords: 0.44 #infoleak",
  "id" : 381571628393451520,
  "created_at" : "2013-09-22 00:12:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GNNzEDcm7x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RUiBK4Se",
      "display_url" : "pastebin.com\/raw.php?i=RUiB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381567748603514881",
  "text" : "http:\/\/t.co\/GNNzEDcm7x Hashes: 1 Keywords: 0.55 #infoleak",
  "id" : 381567748603514881,
  "created_at" : "2013-09-21 23:56:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P5MYSFFuPw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RWAV0ZTr",
      "display_url" : "pastebin.com\/raw.php?i=RWAV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381376762094952448",
  "text" : "http:\/\/t.co\/P5MYSFFuPw Emails: 49 Keywords: 0.22 #infoleak",
  "id" : 381376762094952448,
  "created_at" : "2013-09-21 11:18:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QatOGdjmj5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c37eYHmj",
      "display_url" : "pastebin.com\/raw.php?i=c37e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381348267646136321",
  "text" : "http:\/\/t.co\/QatOGdjmj5 Emails: 40 Keywords: -0.03 #infoleak",
  "id" : 381348267646136321,
  "created_at" : "2013-09-21 09:24:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/66BFnyGvA6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zz5KNQVN",
      "display_url" : "pastebin.com\/raw.php?i=zz5K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381340227727400960",
  "text" : "http:\/\/t.co\/66BFnyGvA6 Emails: 263 Keywords: 0.19 #infoleak",
  "id" : 381340227727400960,
  "created_at" : "2013-09-21 08:52:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4AaU33xW58",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aSQM0q4K",
      "display_url" : "pastebin.com\/raw.php?i=aSQM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381328585593610240",
  "text" : "http:\/\/t.co\/4AaU33xW58 Emails: 545 Keywords: 0.55 #infoleak",
  "id" : 381328585593610240,
  "created_at" : "2013-09-21 08:06:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gTfHIVKVEI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F2fk27dF",
      "display_url" : "pastebin.com\/raw.php?i=F2fk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381325369980121088",
  "text" : "http:\/\/t.co\/gTfHIVKVEI Emails: 446 Keywords: 0.22 #infoleak",
  "id" : 381325369980121088,
  "created_at" : "2013-09-21 07:53:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U9BuqljtG6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K8T8d6F1",
      "display_url" : "pastebin.com\/raw.php?i=K8T8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381323439069343744",
  "text" : "http:\/\/t.co\/U9BuqljtG6 Emails: 26 Keywords: 0.22 #infoleak",
  "id" : 381323439069343744,
  "created_at" : "2013-09-21 07:46:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zn8hm9VYAl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hg1hzCbn",
      "display_url" : "pastebin.com\/raw.php?i=Hg1h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381292466395033600",
  "text" : "http:\/\/t.co\/Zn8hm9VYAl Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 381292466395033600,
  "created_at" : "2013-09-21 05:43:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nGdWPhKMtY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hYayRaT1",
      "display_url" : "pastebin.com\/raw.php?i=hYay\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381285628723228672",
  "text" : "http:\/\/t.co\/nGdWPhKMtY Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 381285628723228672,
  "created_at" : "2013-09-21 05:15:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dKZgCtDz94",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1yKyJ6Y7",
      "display_url" : "pastebin.com\/raw.php?i=1yKy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381275893508759552",
  "text" : "http:\/\/t.co\/dKZgCtDz94 Emails: 163 Keywords: 0.19 #infoleak",
  "id" : 381275893508759552,
  "created_at" : "2013-09-21 04:37:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TfIt4Dkoc1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9qdjiFtB",
      "display_url" : "pastebin.com\/raw.php?i=9qdj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381275235724435456",
  "text" : "http:\/\/t.co\/TfIt4Dkoc1 Hashes: 56 Keywords: 0.3 #infoleak",
  "id" : 381275235724435456,
  "created_at" : "2013-09-21 04:34:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7F0UZY9TpE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MTS9nyi1",
      "display_url" : "pastebin.com\/raw.php?i=MTS9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381273333922164736",
  "text" : "http:\/\/t.co\/7F0UZY9TpE Hashes: 1 Keywords: 0.66 #infoleak",
  "id" : 381273333922164736,
  "created_at" : "2013-09-21 04:27:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tLz2kVidTl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gP58s7nA",
      "display_url" : "pastebin.com\/raw.php?i=gP58\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381250977895956481",
  "text" : "http:\/\/t.co\/tLz2kVidTl Hashes: 132 Keywords: 0.44 #infoleak",
  "id" : 381250977895956481,
  "created_at" : "2013-09-21 02:58:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZppbfZUihq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TQMJC40K",
      "display_url" : "pastebin.com\/raw.php?i=TQMJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381246419144683520",
  "text" : "http:\/\/t.co\/ZppbfZUihq Emails: 42 Keywords: 0.0 #infoleak",
  "id" : 381246419144683520,
  "created_at" : "2013-09-21 02:40:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pnhi7MVYV9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a9X4HG1Z",
      "display_url" : "pastebin.com\/raw.php?i=a9X4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381242954586664960",
  "text" : "http:\/\/t.co\/pnhi7MVYV9 Found possible Google API key(s) #infoleak",
  "id" : 381242954586664960,
  "created_at" : "2013-09-21 02:26:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BqtHxETPHZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F45kz6nw",
      "display_url" : "pastebin.com\/raw.php?i=F45k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381242824101867520",
  "text" : "http:\/\/t.co\/BqtHxETPHZ Hashes: 166 Keywords: 0.08 #infoleak",
  "id" : 381242824101867520,
  "created_at" : "2013-09-21 02:25:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VJBkBpXwPt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DiKNngjb",
      "display_url" : "pastebin.com\/raw.php?i=DiKN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381220776235376640",
  "text" : "http:\/\/t.co\/VJBkBpXwPt Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 381220776235376640,
  "created_at" : "2013-09-21 00:58:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gWdL5Iimqp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6A6gH1c1",
      "display_url" : "pastebin.com\/raw.php?i=6A6g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381195869724221441",
  "text" : "http:\/\/t.co\/gWdL5Iimqp Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 381195869724221441,
  "created_at" : "2013-09-20 23:19:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uoEpcIMm9q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1t3Dp4Tj",
      "display_url" : "pastebin.com\/raw.php?i=1t3D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381186878151475200",
  "text" : "http:\/\/t.co\/uoEpcIMm9q Emails: 45 Hashes: 48 E\/H: 0.94 Keywords: 0.77 #infoleak",
  "id" : 381186878151475200,
  "created_at" : "2013-09-20 22:43:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tgYlLnZxa3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JWC69Z8x",
      "display_url" : "pastebin.com\/raw.php?i=JWC6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381182085991378944",
  "text" : "http:\/\/t.co\/tgYlLnZxa3 Keywords: 0.55 #infoleak",
  "id" : 381182085991378944,
  "created_at" : "2013-09-20 22:24:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YFZ0KTqlJW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9vHprAZr",
      "display_url" : "pastebin.com\/raw.php?i=9vHp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381181898195619841",
  "text" : "http:\/\/t.co\/YFZ0KTqlJW Emails: 55 Keywords: 0.0 #infoleak",
  "id" : 381181898195619841,
  "created_at" : "2013-09-20 22:23:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nwlPzvWtRb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VNHJW7ks",
      "display_url" : "pastebin.com\/raw.php?i=VNHJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381180939390316544",
  "text" : "http:\/\/t.co\/nwlPzvWtRb Keywords: 0.55 #infoleak",
  "id" : 381180939390316544,
  "created_at" : "2013-09-20 22:19:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4nLKJYy9EG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6VCSz7s0",
      "display_url" : "pastebin.com\/raw.php?i=6VCS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381179411795431424",
  "text" : "http:\/\/t.co\/4nLKJYy9EG Emails: 24 Keywords: 0.11 #infoleak",
  "id" : 381179411795431424,
  "created_at" : "2013-09-20 22:13:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uUxs7W0Qlh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tKR6Hj0S",
      "display_url" : "pastebin.com\/raw.php?i=tKR6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381173807278342144",
  "text" : "http:\/\/t.co\/uUxs7W0Qlh Hashes: 549 Keywords: 0.22 #infoleak",
  "id" : 381173807278342144,
  "created_at" : "2013-09-20 21:51:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BdsMHS0Zki",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=275hDgh5",
      "display_url" : "pastebin.com\/raw.php?i=275h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381163020052729856",
  "text" : "http:\/\/t.co\/BdsMHS0Zki Emails: 1085 Keywords: 0.33 #infoleak",
  "id" : 381163020052729856,
  "created_at" : "2013-09-20 21:08:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fDdiQQlLZW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6Xv69cf7",
      "display_url" : "pastebin.com\/raw.php?i=6Xv6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381162056134569984",
  "text" : "http:\/\/t.co\/fDdiQQlLZW Emails: 1085 Keywords: 0.33 #infoleak",
  "id" : 381162056134569984,
  "created_at" : "2013-09-20 21:04:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0kSPfpkuO9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FG7D5LQR",
      "display_url" : "pastebin.com\/raw.php?i=FG7D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381158063186518016",
  "text" : "http:\/\/t.co\/0kSPfpkuO9 Hashes: 155 Keywords: 0.08 #infoleak",
  "id" : 381158063186518016,
  "created_at" : "2013-09-20 20:48:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rk3hS0Fr9f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AWfhaEcQ",
      "display_url" : "pastebin.com\/raw.php?i=AWfh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381156674272100352",
  "text" : "http:\/\/t.co\/rk3hS0Fr9f Hashes: 150 Keywords: 0.08 #infoleak",
  "id" : 381156674272100352,
  "created_at" : "2013-09-20 20:43:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wA8oVCwzzY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2jSrEPQA",
      "display_url" : "pastebin.com\/raw.php?i=2jSr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381151099979173888",
  "text" : "http:\/\/t.co\/wA8oVCwzzY Keywords: 0.55 #infoleak",
  "id" : 381151099979173888,
  "created_at" : "2013-09-20 20:21:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e5GhsK0J0M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LwXkZ1WZ",
      "display_url" : "pastebin.com\/raw.php?i=LwXk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381148057556897792",
  "text" : "http:\/\/t.co\/e5GhsK0J0M Hashes: 125 Keywords: 0.08 #infoleak",
  "id" : 381148057556897792,
  "created_at" : "2013-09-20 20:09:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OWHsJ6toVu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C1R2NE16",
      "display_url" : "pastebin.com\/raw.php?i=C1R2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381147525895315456",
  "text" : "http:\/\/t.co\/OWHsJ6toVu Emails: 2191 Keywords: 0.11 #infoleak",
  "id" : 381147525895315456,
  "created_at" : "2013-09-20 20:07:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WXfFFGXIKP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k9yYy0Xj",
      "display_url" : "pastebin.com\/raw.php?i=k9yY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381147127990079489",
  "text" : "http:\/\/t.co\/WXfFFGXIKP Emails: 2191 Keywords: 0.11 #infoleak",
  "id" : 381147127990079489,
  "created_at" : "2013-09-20 20:05:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6VWDyYSVzF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f6DGvXsr",
      "display_url" : "pastebin.com\/raw.php?i=f6DG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381146839828815872",
  "text" : "http:\/\/t.co\/6VWDyYSVzF Hashes: 105 Keywords: 0.08 #infoleak",
  "id" : 381146839828815872,
  "created_at" : "2013-09-20 20:04:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R3sQG9y5sN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z5puAq4T",
      "display_url" : "pastebin.com\/raw.php?i=z5pu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381145385235791872",
  "text" : "http:\/\/t.co\/R3sQG9y5sN Hashes: 75 Keywords: 0.08 #infoleak",
  "id" : 381145385235791872,
  "created_at" : "2013-09-20 19:58:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/47QemX2MKt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gqHm609p",
      "display_url" : "pastebin.com\/raw.php?i=gqHm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381136220262117376",
  "text" : "http:\/\/t.co\/47QemX2MKt Hashes: 35 Keywords: -0.03 #infoleak",
  "id" : 381136220262117376,
  "created_at" : "2013-09-20 19:22:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qhLASlcFWe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e0tH80Qc",
      "display_url" : "pastebin.com\/raw.php?i=e0tH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381130479409197056",
  "text" : "http:\/\/t.co\/qhLASlcFWe Emails: 260 Keywords: 0.22 #infoleak",
  "id" : 381130479409197056,
  "created_at" : "2013-09-20 18:59:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PwJrFH1Yum",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=czA4BjNp",
      "display_url" : "pastebin.com\/raw.php?i=czA4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381044784095186944",
  "text" : "http:\/\/t.co\/PwJrFH1Yum Emails: 2236 Keywords: 0.33 #infoleak",
  "id" : 381044784095186944,
  "created_at" : "2013-09-20 13:18:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5utnmxzdlR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VdZUfKjM",
      "display_url" : "pastebin.com\/raw.php?i=VdZU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381044433950498816",
  "text" : "http:\/\/t.co\/5utnmxzdlR Hashes: 94 Keywords: 0.0 #infoleak",
  "id" : 381044433950498816,
  "created_at" : "2013-09-20 13:17:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1MLhSFJmm3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tn0UpzjH",
      "display_url" : "pastebin.com\/raw.php?i=Tn0U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381041562534154240",
  "text" : "http:\/\/t.co\/1MLhSFJmm3 Hashes: 81 Keywords: 0.11 #infoleak",
  "id" : 381041562534154240,
  "created_at" : "2013-09-20 13:06:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vtJXmRM44f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9uAij4Ld",
      "display_url" : "pastebin.com\/raw.php?i=9uAi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381034556972756992",
  "text" : "http:\/\/t.co\/vtJXmRM44f Hashes: 70 Keywords: 0.19 #infoleak",
  "id" : 381034556972756992,
  "created_at" : "2013-09-20 12:38:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zXXEJ51Vzg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rBP6uV0S",
      "display_url" : "pastebin.com\/raw.php?i=rBP6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381030728533688320",
  "text" : "http:\/\/t.co\/zXXEJ51Vzg Hashes: 287 Keywords: 0.11 #infoleak",
  "id" : 381030728533688320,
  "created_at" : "2013-09-20 12:22:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D9AOKAimEM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N3ASQN09",
      "display_url" : "pastebin.com\/raw.php?i=N3AS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381025904501080065",
  "text" : "http:\/\/t.co\/D9AOKAimEM Emails: 340 Hashes: 359 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 381025904501080065,
  "created_at" : "2013-09-20 12:03:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ykxnW4C1jk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MnMFQb37",
      "display_url" : "pastebin.com\/raw.php?i=MnMF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381025286281625601",
  "text" : "http:\/\/t.co\/ykxnW4C1jk Hashes: 154 Keywords: 0.33 #infoleak",
  "id" : 381025286281625601,
  "created_at" : "2013-09-20 12:01:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AE4Z5R4Fez",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZfSFe358",
      "display_url" : "pastebin.com\/raw.php?i=ZfSF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381021216611381248",
  "text" : "http:\/\/t.co\/AE4Z5R4Fez Emails: 340 Hashes: 359 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 381021216611381248,
  "created_at" : "2013-09-20 11:45:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YcGGQHPfmB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yxN1Ybmp",
      "display_url" : "pastebin.com\/raw.php?i=yxN1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381019576902774786",
  "text" : "http:\/\/t.co\/YcGGQHPfmB Hashes: 192 Keywords: 0.22 #infoleak",
  "id" : 381019576902774786,
  "created_at" : "2013-09-20 11:38:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yfa7MdbFNq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TZaS3X5K",
      "display_url" : "pastebin.com\/raw.php?i=TZaS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381016825443528705",
  "text" : "http:\/\/t.co\/Yfa7MdbFNq Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 381016825443528705,
  "created_at" : "2013-09-20 11:27:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S9Wbx3KPEt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yUPe0a0X",
      "display_url" : "pastebin.com\/raw.php?i=yUPe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381007817458450432",
  "text" : "http:\/\/t.co\/S9Wbx3KPEt Emails: 120 Keywords: 0.11 #infoleak",
  "id" : 381007817458450432,
  "created_at" : "2013-09-20 10:51:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TUSWS8EKHm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X8WCs9hD",
      "display_url" : "pastebin.com\/raw.php?i=X8WC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380962887792996353",
  "text" : "http:\/\/t.co\/TUSWS8EKHm Hashes: 1629 Keywords: 0.11 #infoleak",
  "id" : 380962887792996353,
  "created_at" : "2013-09-20 07:53:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z6BwkN5qdb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tGZn7rtr",
      "display_url" : "pastebin.com\/raw.php?i=tGZn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380953905472864256",
  "text" : "http:\/\/t.co\/Z6BwkN5qdb Emails: 22 Hashes: 58 E\/H: 0.38 Keywords: 0.11 #infoleak",
  "id" : 380953905472864256,
  "created_at" : "2013-09-20 07:17:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zHl7qVoP6p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5Yw1i4hm",
      "display_url" : "pastebin.com\/raw.php?i=5Yw1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380867127801958400",
  "text" : "http:\/\/t.co\/zHl7qVoP6p Emails: 8797 Keywords: 0.33 #infoleak",
  "id" : 380867127801958400,
  "created_at" : "2013-09-20 01:32:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J8rXmNEC8U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZK03gmHs",
      "display_url" : "pastebin.com\/raw.php?i=ZK03\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380850263520583681",
  "text" : "http:\/\/t.co\/J8rXmNEC8U Keywords: 0.66 #infoleak",
  "id" : 380850263520583681,
  "created_at" : "2013-09-20 00:25:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9rK02nbSff",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2qgbYryZ",
      "display_url" : "pastebin.com\/raw.php?i=2qgb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380786742703316993",
  "text" : "http:\/\/t.co\/9rK02nbSff Hashes: 83 Keywords: -0.03 #infoleak",
  "id" : 380786742703316993,
  "created_at" : "2013-09-19 20:13:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wRq6HZB6v0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ky4eB0bt",
      "display_url" : "pastebin.com\/raw.php?i=ky4e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380776515438272512",
  "text" : "http:\/\/t.co\/wRq6HZB6v0 Keywords: 0.55 #infoleak",
  "id" : 380776515438272512,
  "created_at" : "2013-09-19 19:32:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S4wrLE2Nrl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A0h8Amgs",
      "display_url" : "pastebin.com\/raw.php?i=A0h8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380754140151816192",
  "text" : "http:\/\/t.co\/S4wrLE2Nrl Emails: 35 Keywords: 0.11 #infoleak",
  "id" : 380754140151816192,
  "created_at" : "2013-09-19 18:03:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BqjTMebEJM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4Z8EtB1u",
      "display_url" : "pastebin.com\/raw.php?i=4Z8E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380753857711579136",
  "text" : "http:\/\/t.co\/BqjTMebEJM Emails: 35 Keywords: 0.11 #infoleak",
  "id" : 380753857711579136,
  "created_at" : "2013-09-19 18:02:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G3zpfAjvCI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NN2xzv8x",
      "display_url" : "pastebin.com\/raw.php?i=NN2x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380732608000188416",
  "text" : "http:\/\/t.co\/G3zpfAjvCI Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 380732608000188416,
  "created_at" : "2013-09-19 16:38:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wx7yyCkiyn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3KAmCHES",
      "display_url" : "pastebin.com\/raw.php?i=3KAm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380716875631448064",
  "text" : "http:\/\/t.co\/Wx7yyCkiyn Emails: 451 Keywords: 0.3 #infoleak",
  "id" : 380716875631448064,
  "created_at" : "2013-09-19 15:35:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ApwZPImllg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A6EGjsSV",
      "display_url" : "pastebin.com\/raw.php?i=A6EG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380703450985549824",
  "text" : "http:\/\/t.co\/ApwZPImllg Emails: 254 Keywords: 0.0 #infoleak",
  "id" : 380703450985549824,
  "created_at" : "2013-09-19 14:42:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OWPZyocMSz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=txahz4xt",
      "display_url" : "pastebin.com\/raw.php?i=txah\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380695566629343232",
  "text" : "http:\/\/t.co\/OWPZyocMSz Emails: 79 Keywords: 0.19 #infoleak",
  "id" : 380695566629343232,
  "created_at" : "2013-09-19 14:11:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BYuv6HZvyW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k2fUAhMq",
      "display_url" : "pastebin.com\/raw.php?i=k2fU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380689854931021824",
  "text" : "http:\/\/t.co\/BYuv6HZvyW Hashes: 272 Keywords: -0.14 #infoleak",
  "id" : 380689854931021824,
  "created_at" : "2013-09-19 13:48:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/22AzxH6reY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DTSFSPBC",
      "display_url" : "pastebin.com\/raw.php?i=DTSF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380675374683680769",
  "text" : "http:\/\/t.co\/22AzxH6reY Hashes: 229 Keywords: 0.11 #infoleak",
  "id" : 380675374683680769,
  "created_at" : "2013-09-19 12:50:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qUsaD59jK6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PmRees11",
      "display_url" : "pastebin.com\/raw.php?i=PmRe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380667698792787969",
  "text" : "http:\/\/t.co\/qUsaD59jK6 Emails: 5 Hashes: 99 E\/H: 0.05 Keywords: 0.33 #infoleak",
  "id" : 380667698792787969,
  "created_at" : "2013-09-19 12:20:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IBuMLo3WBZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JTeR5J5U",
      "display_url" : "pastebin.com\/raw.php?i=JTeR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380665392118517760",
  "text" : "http:\/\/t.co\/IBuMLo3WBZ Emails: 28 Hashes: 701 E\/H: 0.04 Keywords: 0.02 #infoleak",
  "id" : 380665392118517760,
  "created_at" : "2013-09-19 12:11:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/biICkpCVhD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GjApw0iq",
      "display_url" : "pastebin.com\/raw.php?i=GjAp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380657527324561408",
  "text" : "http:\/\/t.co\/biICkpCVhD Hashes: 119 Keywords: 0.11 #infoleak",
  "id" : 380657527324561408,
  "created_at" : "2013-09-19 11:40:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OFWP9SMHfA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q3kXMguv",
      "display_url" : "pastebin.com\/raw.php?i=Q3kX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380653186022797313",
  "text" : "http:\/\/t.co\/OFWP9SMHfA Possible cisco configuration #infoleak",
  "id" : 380653186022797313,
  "created_at" : "2013-09-19 11:22:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1rAbB5MEdW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z7LZewkB",
      "display_url" : "pastebin.com\/raw.php?i=z7LZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380640102973583360",
  "text" : "http:\/\/t.co\/1rAbB5MEdW Emails: 52 Keywords: 0.41 #infoleak",
  "id" : 380640102973583360,
  "created_at" : "2013-09-19 10:30:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F9cv9qlIfg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hmVbBmU5",
      "display_url" : "pastebin.com\/raw.php?i=hmVb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380627744335224832",
  "text" : "http:\/\/t.co\/F9cv9qlIfg Emails: 304 Hashes: 306 E\/H: 0.99 Keywords: 0.11 #infoleak",
  "id" : 380627744335224832,
  "created_at" : "2013-09-19 09:41:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X4n0qE1wTo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7czBKwNp",
      "display_url" : "pastebin.com\/raw.php?i=7czB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380552939682549760",
  "text" : "http:\/\/t.co\/X4n0qE1wTo Emails: 107 Keywords: 0.66 #infoleak",
  "id" : 380552939682549760,
  "created_at" : "2013-09-19 04:44:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G7Uw3zJIMb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i5r1JYKj",
      "display_url" : "pastebin.com\/raw.php?i=i5r1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380546570241835008",
  "text" : "http:\/\/t.co\/G7Uw3zJIMb Emails: 131 Keywords: 0.11 #infoleak",
  "id" : 380546570241835008,
  "created_at" : "2013-09-19 04:19:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qx6GSihV4y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zngMWuu6",
      "display_url" : "pastebin.com\/raw.php?i=zngM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380545382725320704",
  "text" : "http:\/\/t.co\/qx6GSihV4y Emails: 70 Keywords: 0.19 #infoleak",
  "id" : 380545382725320704,
  "created_at" : "2013-09-19 04:14:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fUAQwiiCzG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8bNDJan7",
      "display_url" : "pastebin.com\/raw.php?i=8bND\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380541580584562689",
  "text" : "http:\/\/t.co\/fUAQwiiCzG Emails: 104 Hashes: 1 E\/H: 104.0 Keywords: 0.33 #infoleak",
  "id" : 380541580584562689,
  "created_at" : "2013-09-19 03:59:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IJsH07vyZb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k4jdi1m1",
      "display_url" : "pastebin.com\/raw.php?i=k4jd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380540304710852608",
  "text" : "http:\/\/t.co\/IJsH07vyZb Emails: 290 Keywords: 0.11 #infoleak",
  "id" : 380540304710852608,
  "created_at" : "2013-09-19 03:54:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ip2WXachCi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sSTst3A7",
      "display_url" : "pastebin.com\/raw.php?i=sSTs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380537539959848960",
  "text" : "http:\/\/t.co\/ip2WXachCi Emails: 37 Keywords: 0.0 #infoleak",
  "id" : 380537539959848960,
  "created_at" : "2013-09-19 03:43:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0eok02clO8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hpMNCBu0",
      "display_url" : "pastebin.com\/raw.php?i=hpMN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380517002235756545",
  "text" : "http:\/\/t.co\/0eok02clO8 Emails: 3525 Keywords: 0.33 #infoleak",
  "id" : 380517002235756545,
  "created_at" : "2013-09-19 02:21:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/orllrRdPlq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QaB9hJ9y",
      "display_url" : "pastebin.com\/raw.php?i=QaB9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380406261130330112",
  "text" : "http:\/\/t.co\/orllrRdPlq Hashes: 32 Keywords: 0.08 #infoleak",
  "id" : 380406261130330112,
  "created_at" : "2013-09-18 19:01:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lVvZycuTS0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FP5dF0EF",
      "display_url" : "pastebin.com\/raw.php?i=FP5d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380404914792304640",
  "text" : "http:\/\/t.co\/lVvZycuTS0 Possible cisco configuration #infoleak",
  "id" : 380404914792304640,
  "created_at" : "2013-09-18 18:56:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0h5nkskhlv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vEEzNKDu",
      "display_url" : "pastebin.com\/raw.php?i=vEEz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380398658094514176",
  "text" : "http:\/\/t.co\/0h5nkskhlv Emails: 5 Hashes: 153 E\/H: 0.03 Keywords: 0.22 #infoleak",
  "id" : 380398658094514176,
  "created_at" : "2013-09-18 18:31:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oy66px21GF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yddfsMCA",
      "display_url" : "pastebin.com\/raw.php?i=yddf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380393058467979264",
  "text" : "http:\/\/t.co\/oy66px21GF Hashes: 305 Keywords: 0.08 #infoleak",
  "id" : 380393058467979264,
  "created_at" : "2013-09-18 18:09:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q3f1u2zan8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b7iumgQ8",
      "display_url" : "pastebin.com\/raw.php?i=b7iu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380384573755908096",
  "text" : "http:\/\/t.co\/Q3f1u2zan8 Emails: 85 Keywords: 0.0 #infoleak",
  "id" : 380384573755908096,
  "created_at" : "2013-09-18 17:35:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7Lj81QxReS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7qQpcZb5",
      "display_url" : "pastebin.com\/raw.php?i=7qQp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380383048258174976",
  "text" : "http:\/\/t.co\/7Lj81QxReS Emails: 383 Keywords: 0.3 #infoleak",
  "id" : 380383048258174976,
  "created_at" : "2013-09-18 17:29:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cjPEkA3Lo8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jC0F25gc",
      "display_url" : "pastebin.com\/raw.php?i=jC0F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380375998937575424",
  "text" : "http:\/\/t.co\/cjPEkA3Lo8 Emails: 26 Keywords: 0.11 #infoleak",
  "id" : 380375998937575424,
  "created_at" : "2013-09-18 17:01:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LqCuSwtmZw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ebtdT3sP",
      "display_url" : "pastebin.com\/raw.php?i=ebtd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380373391938580480",
  "text" : "http:\/\/t.co\/LqCuSwtmZw Possible cisco configuration #infoleak",
  "id" : 380373391938580480,
  "created_at" : "2013-09-18 16:50:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QqDczuYWt5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zrNMMDYc",
      "display_url" : "pastebin.com\/raw.php?i=zrNM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380369844543053826",
  "text" : "http:\/\/t.co\/QqDczuYWt5 Hashes: 53 Keywords: 0.0 #infoleak",
  "id" : 380369844543053826,
  "created_at" : "2013-09-18 16:36:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/leq81KEvfw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hkQSwEHE",
      "display_url" : "pastebin.com\/raw.php?i=hkQS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380353342355955712",
  "text" : "http:\/\/t.co\/leq81KEvfw Found possible Google API key(s) #infoleak",
  "id" : 380353342355955712,
  "created_at" : "2013-09-18 15:31:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ftMZWSMEHi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QLzRdEY0",
      "display_url" : "pastebin.com\/raw.php?i=QLzR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380353295253897216",
  "text" : "http:\/\/t.co\/ftMZWSMEHi Hashes: 114 Keywords: -0.2 #infoleak",
  "id" : 380353295253897216,
  "created_at" : "2013-09-18 15:31:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xj0Z5LxnBR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jVsAbRZa",
      "display_url" : "pastebin.com\/raw.php?i=jVsA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380340907104407552",
  "text" : "http:\/\/t.co\/xj0Z5LxnBR Hashes: 170 Keywords: -0.03 #infoleak",
  "id" : 380340907104407552,
  "created_at" : "2013-09-18 14:41:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2owpj3dtiM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bAKjBx1Z",
      "display_url" : "pastebin.com\/raw.php?i=bAKj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380335559136145409",
  "text" : "http:\/\/t.co\/2owpj3dtiM Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 380335559136145409,
  "created_at" : "2013-09-18 14:20:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aQIJxXRUhl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CwFXRByx",
      "display_url" : "pastebin.com\/raw.php?i=CwFX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380330341614882817",
  "text" : "http:\/\/t.co\/aQIJxXRUhl Emails: 51 Hashes: 54 E\/H: 0.94 Keywords: 0.08 #infoleak",
  "id" : 380330341614882817,
  "created_at" : "2013-09-18 13:59:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HouGAdwHfw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=he70J1EZ",
      "display_url" : "pastebin.com\/raw.php?i=he70\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380325161737519104",
  "text" : "http:\/\/t.co\/HouGAdwHfw Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 380325161737519104,
  "created_at" : "2013-09-18 13:39:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZM4wPQzJ7B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Sm1Bik7C",
      "display_url" : "pastebin.com\/raw.php?i=Sm1B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380324872351514624",
  "text" : "http:\/\/t.co\/ZM4wPQzJ7B Keywords: 0.55 #infoleak",
  "id" : 380324872351514624,
  "created_at" : "2013-09-18 13:38:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bUh44zBeqc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CvAPKb1s",
      "display_url" : "pastebin.com\/raw.php?i=CvAP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380322756358717441",
  "text" : "http:\/\/t.co\/bUh44zBeqc Emails: 1 Hashes: 2980 E\/H: 0.0 Keywords: 0.33 #infoleak",
  "id" : 380322756358717441,
  "created_at" : "2013-09-18 13:29:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gSlddO5X9p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a2HjjHW0",
      "display_url" : "pastebin.com\/raw.php?i=a2Hj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380321785398321154",
  "text" : "http:\/\/t.co\/gSlddO5X9p Emails: 2765 Keywords: 0.22 #infoleak",
  "id" : 380321785398321154,
  "created_at" : "2013-09-18 13:25:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d2RnkJdhEJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FTqC934s",
      "display_url" : "pastebin.com\/raw.php?i=FTqC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380321085645783041",
  "text" : "http:\/\/t.co\/d2RnkJdhEJ Emails: 2325 Keywords: 0.22 #infoleak",
  "id" : 380321085645783041,
  "created_at" : "2013-09-18 13:23:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FiTyyjKp0Q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jmKe2J2q",
      "display_url" : "pastebin.com\/raw.php?i=jmKe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380320557327081474",
  "text" : "http:\/\/t.co\/FiTyyjKp0Q Emails: 1851 Keywords: 0.0 #infoleak",
  "id" : 380320557327081474,
  "created_at" : "2013-09-18 13:21:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lNNzJ46tvs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a81qxcEC",
      "display_url" : "pastebin.com\/raw.php?i=a81q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380310050884968448",
  "text" : "http:\/\/t.co\/lNNzJ46tvs Emails: 144 Keywords: 0.22 #infoleak",
  "id" : 380310050884968448,
  "created_at" : "2013-09-18 12:39:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HxJggBxE1A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3wjk2MnX",
      "display_url" : "pastebin.com\/raw.php?i=3wjk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380297676270473216",
  "text" : "http:\/\/t.co\/HxJggBxE1A Found possible Google API key(s) #infoleak",
  "id" : 380297676270473216,
  "created_at" : "2013-09-18 11:50:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zIpc62ozEl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DGX7aji9",
      "display_url" : "pastebin.com\/raw.php?i=DGX7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380294531427471360",
  "text" : "http:\/\/t.co\/zIpc62ozEl Hashes: 114 Keywords: -0.2 #infoleak",
  "id" : 380294531427471360,
  "created_at" : "2013-09-18 11:37:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jbv3m78BfU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QtcMMqS8",
      "display_url" : "pastebin.com\/raw.php?i=QtcM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380292307351650304",
  "text" : "http:\/\/t.co\/jbv3m78BfU Hashes: 114 Keywords: -0.2 #infoleak",
  "id" : 380292307351650304,
  "created_at" : "2013-09-18 11:28:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0vDRm5Kf9O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3gDBLCyS",
      "display_url" : "pastebin.com\/raw.php?i=3gDB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380271798706647040",
  "text" : "http:\/\/t.co\/0vDRm5Kf9O Emails: 235 Keywords: 0.0 #infoleak",
  "id" : 380271798706647040,
  "created_at" : "2013-09-18 10:07:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7n6uMjey8Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wW4a4850",
      "display_url" : "pastebin.com\/raw.php?i=wW4a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380271025335697408",
  "text" : "http:\/\/t.co\/7n6uMjey8Y Emails: 235 Keywords: 0.0 #infoleak",
  "id" : 380271025335697408,
  "created_at" : "2013-09-18 10:04:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z7JzjQWQaj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=06ab5wSQ",
      "display_url" : "pastebin.com\/raw.php?i=06ab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380260802168516608",
  "text" : "http:\/\/t.co\/z7JzjQWQaj Emails: 1812 Keywords: 0.52 #infoleak",
  "id" : 380260802168516608,
  "created_at" : "2013-09-18 09:23:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jbCoOd8Eyd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C0DcBUW4",
      "display_url" : "pastebin.com\/raw.php?i=C0Dc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380255812150521856",
  "text" : "http:\/\/t.co\/jbCoOd8Eyd Hashes: 149 Keywords: -0.03 #infoleak",
  "id" : 380255812150521856,
  "created_at" : "2013-09-18 09:03:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DPCckDrcAm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TFCeyJsR",
      "display_url" : "pastebin.com\/raw.php?i=TFCe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380243958506336256",
  "text" : "http:\/\/t.co\/DPCckDrcAm Emails: 40 Keywords: -0.03 #infoleak",
  "id" : 380243958506336256,
  "created_at" : "2013-09-18 08:16:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h7xjhZ0nJf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VfSD32Ed",
      "display_url" : "pastebin.com\/raw.php?i=VfSD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380221836895596544",
  "text" : "http:\/\/t.co\/h7xjhZ0nJf Emails: 4 Hashes: 48 E\/H: 0.08 Keywords: 0.22 #infoleak",
  "id" : 380221836895596544,
  "created_at" : "2013-09-18 06:48:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NpNRmhdXRq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D2HdGJZh",
      "display_url" : "pastebin.com\/raw.php?i=D2Hd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380211886442024960",
  "text" : "http:\/\/t.co\/NpNRmhdXRq Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 380211886442024960,
  "created_at" : "2013-09-18 06:09:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uvqiEoy6Nz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XjD83TTT",
      "display_url" : "pastebin.com\/raw.php?i=XjD8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380211434329624576",
  "text" : "http:\/\/t.co\/uvqiEoy6Nz Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 380211434329624576,
  "created_at" : "2013-09-18 06:07:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P554dy5RU3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TJ0fjw7h",
      "display_url" : "pastebin.com\/raw.php?i=TJ0f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380209140192120832",
  "text" : "http:\/\/t.co\/P554dy5RU3 Hashes: 169 Keywords: 0.08 #infoleak",
  "id" : 380209140192120832,
  "created_at" : "2013-09-18 05:58:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IOkUBaprir",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mkyex4i4",
      "display_url" : "pastebin.com\/raw.php?i=Mkye\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380195348150382592",
  "text" : "http:\/\/t.co\/IOkUBaprir Emails: 1 Hashes: 1 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 380195348150382592,
  "created_at" : "2013-09-18 05:03:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jyTgnrWUsT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9cLxa8HM",
      "display_url" : "pastebin.com\/raw.php?i=9cLx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380192758188625921",
  "text" : "http:\/\/t.co\/jyTgnrWUsT Emails: 57 Keywords: 0.0 #infoleak",
  "id" : 380192758188625921,
  "created_at" : "2013-09-18 04:53:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tjFgl6c6Nk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YfHYrtY6",
      "display_url" : "pastebin.com\/raw.php?i=YfHY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380192308412444673",
  "text" : "http:\/\/t.co\/tjFgl6c6Nk Emails: 145 Keywords: 0.0 #infoleak",
  "id" : 380192308412444673,
  "created_at" : "2013-09-18 04:51:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qcZD5CT4bm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uaMHmNP4",
      "display_url" : "pastebin.com\/raw.php?i=uaMH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380191568222629888",
  "text" : "http:\/\/t.co\/qcZD5CT4bm Emails: 104 Keywords: 0.0 #infoleak",
  "id" : 380191568222629888,
  "created_at" : "2013-09-18 04:48:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wWQETyNuS4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z3Wv9ByL",
      "display_url" : "pastebin.com\/raw.php?i=Z3Wv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380182269765246976",
  "text" : "http:\/\/t.co\/wWQETyNuS4 Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 380182269765246976,
  "created_at" : "2013-09-18 04:11:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pKNu0oCdJa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fm5PveaY",
      "display_url" : "pastebin.com\/raw.php?i=fm5P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380176396779143168",
  "text" : "http:\/\/t.co\/pKNu0oCdJa Emails: 381 Keywords: 0.11 #infoleak",
  "id" : 380176396779143168,
  "created_at" : "2013-09-18 03:48:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s4BSgX5wJq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TfMqYXgQ",
      "display_url" : "pastebin.com\/raw.php?i=TfMq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380174603160539136",
  "text" : "http:\/\/t.co\/s4BSgX5wJq Hashes: 686 Keywords: 0.22 #infoleak",
  "id" : 380174603160539136,
  "created_at" : "2013-09-18 03:41:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oSYOFFB8rX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jjSwi0RN",
      "display_url" : "pastebin.com\/raw.php?i=jjSw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380152498092138497",
  "text" : "http:\/\/t.co\/oSYOFFB8rX Emails: 36 Keywords: 0.44 #infoleak",
  "id" : 380152498092138497,
  "created_at" : "2013-09-18 02:13:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F32q2qZVY1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B4hFQLmW",
      "display_url" : "pastebin.com\/raw.php?i=B4hF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380151567682269184",
  "text" : "http:\/\/t.co\/F32q2qZVY1 Emails: 6 Hashes: 128 E\/H: 0.05 Keywords: 0.16 #infoleak",
  "id" : 380151567682269184,
  "created_at" : "2013-09-18 02:09:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N1P9wHng3s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bk1EeivZ",
      "display_url" : "pastebin.com\/raw.php?i=Bk1E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380148470201344000",
  "text" : "http:\/\/t.co\/N1P9wHng3s Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 380148470201344000,
  "created_at" : "2013-09-18 01:57:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/brXvQrsxkr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ubadjgke",
      "display_url" : "pastebin.com\/raw.php?i=Ubad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380122437083336704",
  "text" : "http:\/\/t.co\/brXvQrsxkr Emails: 626 Keywords: 0.22 #infoleak",
  "id" : 380122437083336704,
  "created_at" : "2013-09-18 00:13:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q3fHDn8eTe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N8XjsutG",
      "display_url" : "pastebin.com\/raw.php?i=N8Xj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380119703621890049",
  "text" : "http:\/\/t.co\/q3fHDn8eTe Emails: 1016 Keywords: 0.11 #infoleak",
  "id" : 380119703621890049,
  "created_at" : "2013-09-18 00:02:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oQbDy9DxJl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F25vDvWT",
      "display_url" : "pastebin.com\/raw.php?i=F25v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380103497280020481",
  "text" : "http:\/\/t.co\/oQbDy9DxJl Hashes: 141 Keywords: 0.0 #infoleak",
  "id" : 380103497280020481,
  "created_at" : "2013-09-17 22:58:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vUS7uQ1VtC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZvYCNVNj",
      "display_url" : "pastebin.com\/raw.php?i=ZvYC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380102904519995392",
  "text" : "http:\/\/t.co\/vUS7uQ1VtC Emails: 1995 Hashes: 2000 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 380102904519995392,
  "created_at" : "2013-09-17 22:56:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y5C9S3Ddts",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fmXkBqeF",
      "display_url" : "pastebin.com\/raw.php?i=fmXk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380092062961369088",
  "text" : "http:\/\/t.co\/Y5C9S3Ddts Emails: 180 Hashes: 178 E\/H: 1.01 Keywords: -0.03 #infoleak",
  "id" : 380092062961369088,
  "created_at" : "2013-09-17 22:13:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XWiThTascJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SSh8eUNH",
      "display_url" : "pastebin.com\/raw.php?i=SSh8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380087462845894656",
  "text" : "http:\/\/t.co\/XWiThTascJ Emails: 968 Keywords: 0.44 #infoleak",
  "id" : 380087462845894656,
  "created_at" : "2013-09-17 21:54:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A06ZX158bX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uWb99Y31",
      "display_url" : "pastebin.com\/raw.php?i=uWb9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380081462231318529",
  "text" : "http:\/\/t.co\/A06ZX158bX Keywords: 0.55 #infoleak",
  "id" : 380081462231318529,
  "created_at" : "2013-09-17 21:30:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sssimysMhy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FgFSmnRJ",
      "display_url" : "pastebin.com\/raw.php?i=FgFS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380077605942087680",
  "text" : "http:\/\/t.co\/sssimysMhy Keywords: 0.66 #infoleak",
  "id" : 380077605942087680,
  "created_at" : "2013-09-17 21:15:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1BnwBwpkOT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i66BfEJJ",
      "display_url" : "pastebin.com\/raw.php?i=i66B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380076923000336385",
  "text" : "http:\/\/t.co\/1BnwBwpkOT Hashes: 112 Keywords: 0.0 #infoleak",
  "id" : 380076923000336385,
  "created_at" : "2013-09-17 21:12:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bsQ3yPsSyN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zfzLzK7N",
      "display_url" : "pastebin.com\/raw.php?i=zfzL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380074850192089088",
  "text" : "http:\/\/t.co\/bsQ3yPsSyN Emails: 5 Hashes: 160 E\/H: 0.03 Keywords: 0.05 #infoleak",
  "id" : 380074850192089088,
  "created_at" : "2013-09-17 21:04:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LaHqbh6Mx2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=frp7NVed",
      "display_url" : "pastebin.com\/raw.php?i=frp7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380066127977541632",
  "text" : "http:\/\/t.co\/LaHqbh6Mx2 Hashes: 2 Keywords: 0.55 #infoleak",
  "id" : 380066127977541632,
  "created_at" : "2013-09-17 20:30:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6ZcEmI3Ixp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HLJ6ET1G",
      "display_url" : "pastebin.com\/raw.php?i=HLJ6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380062323416649729",
  "text" : "http:\/\/t.co\/6ZcEmI3Ixp Keywords: 0.77 #infoleak",
  "id" : 380062323416649729,
  "created_at" : "2013-09-17 20:14:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hlq8CkDf5p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KLyKfvi2",
      "display_url" : "pastebin.com\/raw.php?i=KLyK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380059914783031296",
  "text" : "http:\/\/t.co\/hlq8CkDf5p Hashes: 33 Keywords: 0.0 #infoleak",
  "id" : 380059914783031296,
  "created_at" : "2013-09-17 20:05:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WvFqNqvGNY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ENdHcHaR",
      "display_url" : "pastebin.com\/raw.php?i=ENdH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380053231948152832",
  "text" : "http:\/\/t.co\/WvFqNqvGNY Emails: 3622 Hashes: 648 E\/H: 5.59 Keywords: 0.19 #infoleak",
  "id" : 380053231948152832,
  "created_at" : "2013-09-17 19:38:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9dSqq8S6PW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4ttebAzf",
      "display_url" : "pastebin.com\/raw.php?i=4tte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380052983137845248",
  "text" : "http:\/\/t.co\/9dSqq8S6PW Hashes: 2 Keywords: 0.55 #infoleak",
  "id" : 380052983137845248,
  "created_at" : "2013-09-17 19:37:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/avZC095GsC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NRDukL4r",
      "display_url" : "pastebin.com\/raw.php?i=NRDu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380050786924773376",
  "text" : "http:\/\/t.co\/avZC095GsC Hashes: 617 Keywords: 0.22 #infoleak",
  "id" : 380050786924773376,
  "created_at" : "2013-09-17 19:29:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/62yC6w2FRl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tuPvmzb9",
      "display_url" : "pastebin.com\/raw.php?i=tuPv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380036206165110785",
  "text" : "http:\/\/t.co\/62yC6w2FRl Emails: 2 Hashes: 47 E\/H: 0.04 Keywords: 0.22 #infoleak",
  "id" : 380036206165110785,
  "created_at" : "2013-09-17 18:31:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W9J11dfKv6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ME4Zf0zv",
      "display_url" : "pastebin.com\/raw.php?i=ME4Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380030243332841472",
  "text" : "http:\/\/t.co\/W9J11dfKv6 Emails: 24 Hashes: 63 E\/H: 0.38 Keywords: 0.3 #infoleak",
  "id" : 380030243332841472,
  "created_at" : "2013-09-17 18:07:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y1uC5J24IT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e1L0q6HK",
      "display_url" : "pastebin.com\/raw.php?i=e1L0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380025604902371328",
  "text" : "http:\/\/t.co\/y1uC5J24IT Emails: 1 Hashes: 215 E\/H: 0.0 Keywords: 0.44 #infoleak",
  "id" : 380025604902371328,
  "created_at" : "2013-09-17 17:48:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nacl5GQ2DF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iYurbRA4",
      "display_url" : "pastebin.com\/raw.php?i=iYur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380018149778681856",
  "text" : "http:\/\/t.co\/nacl5GQ2DF Hashes: 171 Keywords: 0.11 #infoleak",
  "id" : 380018149778681856,
  "created_at" : "2013-09-17 17:19:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3qcFH1KxfA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3Y6HJngM",
      "display_url" : "pastebin.com\/raw.php?i=3Y6H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380004240006987776",
  "text" : "http:\/\/t.co\/3qcFH1KxfA Emails: 158 Hashes: 3 E\/H: 52.67 Keywords: 0.52 #infoleak",
  "id" : 380004240006987776,
  "created_at" : "2013-09-17 16:24:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XrsRBAjB4p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U4LpLgsk",
      "display_url" : "pastebin.com\/raw.php?i=U4Lp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379995386766573568",
  "text" : "http:\/\/t.co\/XrsRBAjB4p Found possible Google API key(s) #infoleak",
  "id" : 379995386766573568,
  "created_at" : "2013-09-17 15:48:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Oty5ICKyo8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mbZDUMSv",
      "display_url" : "pastebin.com\/raw.php?i=mbZD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379994079800483840",
  "text" : "http:\/\/t.co\/Oty5ICKyo8 Emails: 63 Keywords: 0.11 #infoleak",
  "id" : 379994079800483840,
  "created_at" : "2013-09-17 15:43:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3K5c0SxC7r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cvvi6J2M",
      "display_url" : "pastebin.com\/raw.php?i=Cvvi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379927378538934272",
  "text" : "http:\/\/t.co\/3K5c0SxC7r Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 379927378538934272,
  "created_at" : "2013-09-17 11:18:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ugJqqP9R0k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rfWsUrX4",
      "display_url" : "pastebin.com\/raw.php?i=rfWs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379919517222064129",
  "text" : "http:\/\/t.co\/ugJqqP9R0k Hashes: 242 Keywords: 0.05 #infoleak",
  "id" : 379919517222064129,
  "created_at" : "2013-09-17 10:47:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9BJYw5MypC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8U4eVwJE",
      "display_url" : "pastebin.com\/raw.php?i=8U4e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379918478569783296",
  "text" : "http:\/\/t.co\/9BJYw5MypC Emails: 73 Keywords: -0.03 #infoleak",
  "id" : 379918478569783296,
  "created_at" : "2013-09-17 10:43:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D0Y79BJxMr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h2WBKvJ0",
      "display_url" : "pastebin.com\/raw.php?i=h2WB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379917163819040768",
  "text" : "http:\/\/t.co\/D0Y79BJxMr Keywords: 0.55 #infoleak",
  "id" : 379917163819040768,
  "created_at" : "2013-09-17 10:38:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oVVSW6fUdv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FXh9x44f",
      "display_url" : "pastebin.com\/raw.php?i=FXh9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379916607411064832",
  "text" : "http:\/\/t.co\/oVVSW6fUdv Emails: 109 Keywords: 0.0 #infoleak",
  "id" : 379916607411064832,
  "created_at" : "2013-09-17 10:35:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/02PemXiLqV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Vwd8tD6f",
      "display_url" : "pastebin.com\/raw.php?i=Vwd8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379911831986257921",
  "text" : "http:\/\/t.co\/02PemXiLqV Emails: 77 Keywords: 0.0 #infoleak",
  "id" : 379911831986257921,
  "created_at" : "2013-09-17 10:16:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c18FtbqVkB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ysS3HK0f",
      "display_url" : "pastebin.com\/raw.php?i=ysS3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379910294585106432",
  "text" : "http:\/\/t.co\/c18FtbqVkB Hashes: 289 Keywords: 0.22 #infoleak",
  "id" : 379910294585106432,
  "created_at" : "2013-09-17 10:10:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1ReZ38197u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B32XfTdy",
      "display_url" : "pastebin.com\/raw.php?i=B32X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379907934584463360",
  "text" : "http:\/\/t.co\/1ReZ38197u Hashes: 33 Keywords: 0.0 #infoleak",
  "id" : 379907934584463360,
  "created_at" : "2013-09-17 10:01:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ljc3tCVBtJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0p12vYJc",
      "display_url" : "pastebin.com\/raw.php?i=0p12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379902533868593153",
  "text" : "http:\/\/t.co\/ljc3tCVBtJ Keywords: 0.66 #infoleak",
  "id" : 379902533868593153,
  "created_at" : "2013-09-17 09:39:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bh8NogIz3o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=36n17agH",
      "display_url" : "pastebin.com\/raw.php?i=36n1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379887524258136065",
  "text" : "http:\/\/t.co\/bh8NogIz3o Emails: 53 Keywords: 0.0 #infoleak",
  "id" : 379887524258136065,
  "created_at" : "2013-09-17 08:40:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0mDpgF3jgd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nWyTMwTF",
      "display_url" : "pastebin.com\/raw.php?i=nWyT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379874332022816768",
  "text" : "http:\/\/t.co\/0mDpgF3jgd Hashes: 249 Keywords: 0.22 #infoleak",
  "id" : 379874332022816768,
  "created_at" : "2013-09-17 07:47:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V4sllJUTpz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GqWnFFXQ",
      "display_url" : "pastebin.com\/raw.php?i=GqWn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379864857731821569",
  "text" : "http:\/\/t.co\/V4sllJUTpz Hashes: 268 Keywords: 0.08 #infoleak",
  "id" : 379864857731821569,
  "created_at" : "2013-09-17 07:10:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xqSSmR1Ukh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=svA2iUhv",
      "display_url" : "pastebin.com\/raw.php?i=svA2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379862478009544704",
  "text" : "http:\/\/t.co\/xqSSmR1Ukh Hashes: 227 Keywords: 0.08 #infoleak",
  "id" : 379862478009544704,
  "created_at" : "2013-09-17 07:00:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s2doE1n2S4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YKyiEhYd",
      "display_url" : "pastebin.com\/raw.php?i=YKyi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379860596692238336",
  "text" : "http:\/\/t.co\/s2doE1n2S4 Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 379860596692238336,
  "created_at" : "2013-09-17 06:53:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i1VIUqhtwd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9fBdxfYt",
      "display_url" : "pastebin.com\/raw.php?i=9fBd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379859709961842688",
  "text" : "http:\/\/t.co\/i1VIUqhtwd Hashes: 51 Keywords: 0.08 #infoleak",
  "id" : 379859709961842688,
  "created_at" : "2013-09-17 06:49:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jIuHIWSQY7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5iFeN1hC",
      "display_url" : "pastebin.com\/raw.php?i=5iFe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379857203861012480",
  "text" : "http:\/\/t.co\/jIuHIWSQY7 Hashes: 362 Keywords: 0.05 #infoleak",
  "id" : 379857203861012480,
  "created_at" : "2013-09-17 06:39:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YeWVPc13q3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qHheH4at",
      "display_url" : "pastebin.com\/raw.php?i=qHhe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379853941694939136",
  "text" : "http:\/\/t.co\/YeWVPc13q3 Emails: 400 Keywords: 0.11 #infoleak",
  "id" : 379853941694939136,
  "created_at" : "2013-09-17 06:26:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N2XUohOKj0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AdLiu41L",
      "display_url" : "pastebin.com\/raw.php?i=AdLi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379851242475761664",
  "text" : "http:\/\/t.co\/N2XUohOKj0 Emails: 1869 Keywords: 0.22 #infoleak",
  "id" : 379851242475761664,
  "created_at" : "2013-09-17 06:16:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OZRFsGw9h0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eFJKfAre",
      "display_url" : "pastebin.com\/raw.php?i=eFJK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379849360965521408",
  "text" : "http:\/\/t.co\/OZRFsGw9h0 Emails: 236 Keywords: 0.0 #infoleak",
  "id" : 379849360965521408,
  "created_at" : "2013-09-17 06:08:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XyUumu7Zf4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U70csNFg",
      "display_url" : "pastebin.com\/raw.php?i=U70c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379847624406216704",
  "text" : "http:\/\/t.co\/XyUumu7Zf4 Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 379847624406216704,
  "created_at" : "2013-09-17 06:01:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PuGuhYPVhG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UjKrdne3",
      "display_url" : "pastebin.com\/raw.php?i=UjKr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379844061823127552",
  "text" : "http:\/\/t.co\/PuGuhYPVhG Emails: 29 Keywords: 0.08 #infoleak",
  "id" : 379844061823127552,
  "created_at" : "2013-09-17 05:47:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8V8xmspVPy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZPGn3NXr",
      "display_url" : "pastebin.com\/raw.php?i=ZPGn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379841676413382656",
  "text" : "http:\/\/t.co\/8V8xmspVPy Emails: 21 Keywords: 0.11 #infoleak",
  "id" : 379841676413382656,
  "created_at" : "2013-09-17 05:38:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z4ZdRKMRnW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aFuLqRMp",
      "display_url" : "pastebin.com\/raw.php?i=aFuL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379799028172468224",
  "text" : "http:\/\/t.co\/z4ZdRKMRnW Found possible Google API key(s) #infoleak",
  "id" : 379799028172468224,
  "created_at" : "2013-09-17 02:48:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tXsbJ2cssG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pxKuFMu3",
      "display_url" : "pastebin.com\/raw.php?i=pxKu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379791434611560448",
  "text" : "http:\/\/t.co\/tXsbJ2cssG Emails: 2469 Keywords: 0.19 #infoleak",
  "id" : 379791434611560448,
  "created_at" : "2013-09-17 02:18:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cWnGFXAhRj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uB7s5tWv",
      "display_url" : "pastebin.com\/raw.php?i=uB7s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379784328990830592",
  "text" : "http:\/\/t.co\/cWnGFXAhRj Emails: 31 Keywords: -0.03 #infoleak",
  "id" : 379784328990830592,
  "created_at" : "2013-09-17 01:50:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ts01sxWNmc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=THiVf1qr",
      "display_url" : "pastebin.com\/raw.php?i=THiV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379777781078294529",
  "text" : "http:\/\/t.co\/ts01sxWNmc Emails: 175 Hashes: 176 E\/H: 0.99 Keywords: 0.11 #infoleak",
  "id" : 379777781078294529,
  "created_at" : "2013-09-17 01:24:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oPEBSIqCpx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eDSu5czL",
      "display_url" : "pastebin.com\/raw.php?i=eDSu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379776925134098432",
  "text" : "http:\/\/t.co\/oPEBSIqCpx Emails: 3 Hashes: 1 E\/H: 3.0 Keywords: 0.55 #infoleak",
  "id" : 379776925134098432,
  "created_at" : "2013-09-17 01:20:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SQRlfmLx8a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uuXVP3bq",
      "display_url" : "pastebin.com\/raw.php?i=uuXV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379771843978080256",
  "text" : "http:\/\/t.co\/SQRlfmLx8a Hashes: 365 Keywords: -0.03 #infoleak",
  "id" : 379771843978080256,
  "created_at" : "2013-09-17 01:00:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FNVazhAJqU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mKta3s66",
      "display_url" : "pastebin.com\/raw.php?i=mKta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379769361327607809",
  "text" : "http:\/\/t.co\/FNVazhAJqU Emails: 1161 Keywords: 0.11 #infoleak",
  "id" : 379769361327607809,
  "created_at" : "2013-09-17 00:50:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WQRIFBoslD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x4HD5XzC",
      "display_url" : "pastebin.com\/raw.php?i=x4HD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379764523856453632",
  "text" : "http:\/\/t.co\/WQRIFBoslD Emails: 104 Hashes: 1 E\/H: 104.0 Keywords: 0.44 #infoleak",
  "id" : 379764523856453632,
  "created_at" : "2013-09-17 00:31:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HJDC1Bv7Kn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ub1N266p",
      "display_url" : "pastebin.com\/raw.php?i=Ub1N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379760848555626496",
  "text" : "http:\/\/t.co\/HJDC1Bv7Kn Emails: 48 Keywords: 0.11 #infoleak",
  "id" : 379760848555626496,
  "created_at" : "2013-09-17 00:16:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LvdNZItAJZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tdf742px",
      "display_url" : "pastebin.com\/raw.php?i=Tdf7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379759562678476800",
  "text" : "http:\/\/t.co\/LvdNZItAJZ Emails: 48 Keywords: 0.11 #infoleak",
  "id" : 379759562678476800,
  "created_at" : "2013-09-17 00:11:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KqDz4wtlTT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1jjNLGi0",
      "display_url" : "pastebin.com\/raw.php?i=1jjN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379758429314617344",
  "text" : "http:\/\/t.co\/KqDz4wtlTT Hashes: 63 Keywords: -0.03 #infoleak",
  "id" : 379758429314617344,
  "created_at" : "2013-09-17 00:07:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7H7RJvlqxE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ckpGzSEd",
      "display_url" : "pastebin.com\/raw.php?i=ckpG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379757286077382656",
  "text" : "http:\/\/t.co\/7H7RJvlqxE Emails: 295 Hashes: 295 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 379757286077382656,
  "created_at" : "2013-09-17 00:02:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WyG65GiFUO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hKSfXM7d",
      "display_url" : "pastebin.com\/raw.php?i=hKSf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379737592230457344",
  "text" : "http:\/\/t.co\/WyG65GiFUO Emails: 48 Keywords: 0.0 #infoleak",
  "id" : 379737592230457344,
  "created_at" : "2013-09-16 22:44:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JszeLu9wqs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wfnqf8aB",
      "display_url" : "pastebin.com\/raw.php?i=wfnq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379686974690709505",
  "text" : "http:\/\/t.co\/JszeLu9wqs Emails: 1485 Keywords: 0.19 #infoleak",
  "id" : 379686974690709505,
  "created_at" : "2013-09-16 19:23:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i68BLThNFz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UAXi8qMe",
      "display_url" : "pastebin.com\/raw.php?i=UAXi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379685097500594176",
  "text" : "http:\/\/t.co\/i68BLThNFz Hashes: 48 Keywords: 0.0 #infoleak",
  "id" : 379685097500594176,
  "created_at" : "2013-09-16 19:15:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l3ajGcT0Rd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PD2GGHRL",
      "display_url" : "pastebin.com\/raw.php?i=PD2G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379684896350158848",
  "text" : "http:\/\/t.co\/l3ajGcT0Rd Possible cisco configuration #infoleak",
  "id" : 379684896350158848,
  "created_at" : "2013-09-16 19:15:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zIXLBZnF9W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g8reficu",
      "display_url" : "pastebin.com\/raw.php?i=g8re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379677237521690625",
  "text" : "http:\/\/t.co\/zIXLBZnF9W Hashes: 1 Keywords: 0.77 #infoleak",
  "id" : 379677237521690625,
  "created_at" : "2013-09-16 18:44:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7QTKOnZVt0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mH0rDYff",
      "display_url" : "pastebin.com\/raw.php?i=mH0r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379669725800058880",
  "text" : "http:\/\/t.co\/7QTKOnZVt0 Found possible Google API key(s) #infoleak",
  "id" : 379669725800058880,
  "created_at" : "2013-09-16 18:14:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6Bi2AQqh8M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HP8qJrqc",
      "display_url" : "pastebin.com\/raw.php?i=HP8q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379667544782938112",
  "text" : "http:\/\/t.co\/6Bi2AQqh8M Emails: 44 Keywords: 0.0 #infoleak",
  "id" : 379667544782938112,
  "created_at" : "2013-09-16 18:06:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W7MEM4WQiO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dc67ycDu",
      "display_url" : "pastebin.com\/raw.php?i=Dc67\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379660705836064769",
  "text" : "http:\/\/t.co\/W7MEM4WQiO Emails: 20 Keywords: -0.03 #infoleak",
  "id" : 379660705836064769,
  "created_at" : "2013-09-16 17:39:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lb13BrK97p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X5EdXJag",
      "display_url" : "pastebin.com\/raw.php?i=X5Ed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379641693135335424",
  "text" : "http:\/\/t.co\/lb13BrK97p Hashes: 148 Keywords: 0.11 #infoleak",
  "id" : 379641693135335424,
  "created_at" : "2013-09-16 16:23:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9Q5CocjcYL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HGZL9BFV",
      "display_url" : "pastebin.com\/raw.php?i=HGZL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379632194462826496",
  "text" : "http:\/\/t.co\/9Q5CocjcYL Emails: 20 Keywords: 0.22 #infoleak",
  "id" : 379632194462826496,
  "created_at" : "2013-09-16 15:45:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RsjKVX6u8e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2bReWMke",
      "display_url" : "pastebin.com\/raw.php?i=2bRe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379629028975468544",
  "text" : "http:\/\/t.co\/RsjKVX6u8e Emails: 2508 Keywords: 0.19 #infoleak",
  "id" : 379629028975468544,
  "created_at" : "2013-09-16 15:33:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z1JYlqpT1g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6Wt5Qbiv",
      "display_url" : "pastebin.com\/raw.php?i=6Wt5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379627987521396736",
  "text" : "http:\/\/t.co\/z1JYlqpT1g Emails: 4512 Keywords: 0.44 #infoleak",
  "id" : 379627987521396736,
  "created_at" : "2013-09-16 15:29:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uOcQl3VXmI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cvjNjBuD",
      "display_url" : "pastebin.com\/raw.php?i=cvjN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379619320415793152",
  "text" : "http:\/\/t.co\/uOcQl3VXmI Keywords: 0.77 #infoleak",
  "id" : 379619320415793152,
  "created_at" : "2013-09-16 14:54:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XQOhrg8LCn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iP8ZEyw2",
      "display_url" : "pastebin.com\/raw.php?i=iP8Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379616533078867968",
  "text" : "http:\/\/t.co\/XQOhrg8LCn Emails: 108 Keywords: 0.22 #infoleak",
  "id" : 379616533078867968,
  "created_at" : "2013-09-16 14:43:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wDiklJccNe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vVYjkFG4",
      "display_url" : "pastebin.com\/raw.php?i=vVYj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379567306793177089",
  "text" : "http:\/\/t.co\/wDiklJccNe Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 379567306793177089,
  "created_at" : "2013-09-16 11:27:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cjIdx61NZh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BRaJwCTs",
      "display_url" : "pastebin.com\/raw.php?i=BRaJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379566809373888513",
  "text" : "http:\/\/t.co\/cjIdx61NZh Emails: 433 Keywords: 0.22 #infoleak",
  "id" : 379566809373888513,
  "created_at" : "2013-09-16 11:25:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2ik258Lp2y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dqw0Zx15",
      "display_url" : "pastebin.com\/raw.php?i=Dqw0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379564951444021248",
  "text" : "http:\/\/t.co\/2ik258Lp2y Hashes: 69 Keywords: -0.03 #infoleak",
  "id" : 379564951444021248,
  "created_at" : "2013-09-16 11:18:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VrG5r3AhIb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=39sATZ2t",
      "display_url" : "pastebin.com\/raw.php?i=39sA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379542138884599808",
  "text" : "http:\/\/t.co\/VrG5r3AhIb Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 379542138884599808,
  "created_at" : "2013-09-16 09:47:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4iUTJjsFT1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jkSdMDE5",
      "display_url" : "pastebin.com\/raw.php?i=jkSd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379534101536968705",
  "text" : "http:\/\/t.co\/4iUTJjsFT1 Hashes: 47 Keywords: 0.0 #infoleak",
  "id" : 379534101536968705,
  "created_at" : "2013-09-16 09:15:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IdEqgeIHMv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Vfh5W8Wc",
      "display_url" : "pastebin.com\/raw.php?i=Vfh5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379526168484904960",
  "text" : "http:\/\/t.co\/IdEqgeIHMv Emails: 108 Keywords: 0.22 #infoleak",
  "id" : 379526168484904960,
  "created_at" : "2013-09-16 08:44:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hivwLfQRlp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P4RDc6m1",
      "display_url" : "pastebin.com\/raw.php?i=P4RD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379521329780621313",
  "text" : "http:\/\/t.co\/hivwLfQRlp Emails: 200 Keywords: 0.11 #infoleak",
  "id" : 379521329780621313,
  "created_at" : "2013-09-16 08:25:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LEewIjOuQb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TfRrsJYD",
      "display_url" : "pastebin.com\/raw.php?i=TfRr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379347906857156608",
  "text" : "http:\/\/t.co\/LEewIjOuQb Emails: 72 Keywords: 0.11 #infoleak",
  "id" : 379347906857156608,
  "created_at" : "2013-09-15 20:56:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9VCIsI0wLq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bfAPX9jR",
      "display_url" : "pastebin.com\/raw.php?i=bfAP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379342452772966400",
  "text" : "http:\/\/t.co\/9VCIsI0wLq Hashes: 54 Keywords: 0.08 #infoleak",
  "id" : 379342452772966400,
  "created_at" : "2013-09-15 20:34:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rbU9ad0PbP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a4ZmKz0M",
      "display_url" : "pastebin.com\/raw.php?i=a4Zm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379320668942110720",
  "text" : "http:\/\/t.co\/rbU9ad0PbP Emails: 3625 Keywords: -0.03 #infoleak",
  "id" : 379320668942110720,
  "created_at" : "2013-09-15 19:07:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n5EEE0WAHX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xek1RUTj",
      "display_url" : "pastebin.com\/raw.php?i=xek1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379308729520254976",
  "text" : "http:\/\/t.co\/n5EEE0WAHX Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 379308729520254976,
  "created_at" : "2013-09-15 18:20:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kay02vG95x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fMd3R6sF",
      "display_url" : "pastebin.com\/raw.php?i=fMd3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379301815449161728",
  "text" : "http:\/\/t.co\/Kay02vG95x Emails: 15 Hashes: 15 E\/H: 1.0 Keywords: 0.77 #infoleak",
  "id" : 379301815449161728,
  "created_at" : "2013-09-15 17:52:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b5l5aUKQSm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a45PHRdh",
      "display_url" : "pastebin.com\/raw.php?i=a45P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379296987960459265",
  "text" : "http:\/\/t.co\/b5l5aUKQSm Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.44 #infoleak",
  "id" : 379296987960459265,
  "created_at" : "2013-09-15 17:33:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hdJpihjCVP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=erEzfApR",
      "display_url" : "pastebin.com\/raw.php?i=erEz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379287871372275712",
  "text" : "http:\/\/t.co\/hdJpihjCVP Emails: 21 Keywords: 0.22 #infoleak",
  "id" : 379287871372275712,
  "created_at" : "2013-09-15 16:57:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Iay892vPNf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7czecwMH",
      "display_url" : "pastebin.com\/raw.php?i=7cze\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379275542639296513",
  "text" : "http:\/\/t.co\/Iay892vPNf Emails: 151 Hashes: 181 E\/H: 0.83 Keywords: 0.08 #infoleak",
  "id" : 379275542639296513,
  "created_at" : "2013-09-15 16:08:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P4hWin04eR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0i4mdyJH",
      "display_url" : "pastebin.com\/raw.php?i=0i4m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379269466124591106",
  "text" : "http:\/\/t.co\/P4hWin04eR Emails: 340 Keywords: 0.33 #infoleak",
  "id" : 379269466124591106,
  "created_at" : "2013-09-15 15:44:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VsGqChAcP7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9356PdF6",
      "display_url" : "pastebin.com\/raw.php?i=9356\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379263157371297793",
  "text" : "http:\/\/t.co\/VsGqChAcP7 Emails: 30 Keywords: 0.33 #infoleak",
  "id" : 379263157371297793,
  "created_at" : "2013-09-15 15:19:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S0pyxEwvuA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YNrEAn6x",
      "display_url" : "pastebin.com\/raw.php?i=YNrE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379257518196674560",
  "text" : "http:\/\/t.co\/S0pyxEwvuA Emails: 21 Keywords: -0.14 #infoleak",
  "id" : 379257518196674560,
  "created_at" : "2013-09-15 14:56:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CbKwBuiaT5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dyruush7",
      "display_url" : "pastebin.com\/raw.php?i=dyru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379247139294965761",
  "text" : "http:\/\/t.co\/CbKwBuiaT5 Hashes: 1 Keywords: 0.66 #infoleak",
  "id" : 379247139294965761,
  "created_at" : "2013-09-15 14:15:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gh6uKtaxlt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mxGDuMpQ",
      "display_url" : "pastebin.com\/raw.php?i=mxGD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379244572955525120",
  "text" : "http:\/\/t.co\/gh6uKtaxlt Emails: 1 Hashes: 1 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 379244572955525120,
  "created_at" : "2013-09-15 14:05:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5UDc0zhST0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VXRRhDZX",
      "display_url" : "pastebin.com\/raw.php?i=VXRR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379227427613851651",
  "text" : "http:\/\/t.co\/5UDc0zhST0 Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 379227427613851651,
  "created_at" : "2013-09-15 12:57:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xKmAl1L42m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6cVcGFUv",
      "display_url" : "pastebin.com\/raw.php?i=6cVc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379223695056592896",
  "text" : "http:\/\/t.co\/xKmAl1L42m Emails: 260 Keywords: 0.66 #infoleak",
  "id" : 379223695056592896,
  "created_at" : "2013-09-15 12:42:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7NVR2GRi8B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hYFkcPUy",
      "display_url" : "pastebin.com\/raw.php?i=hYFk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379223265169780736",
  "text" : "http:\/\/t.co\/7NVR2GRi8B Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 379223265169780736,
  "created_at" : "2013-09-15 12:40:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NEOPCUr4pV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W5avh685",
      "display_url" : "pastebin.com\/raw.php?i=W5av\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379222544865189888",
  "text" : "http:\/\/t.co\/NEOPCUr4pV Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 379222544865189888,
  "created_at" : "2013-09-15 12:37:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xx49Na4ckQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2ecQCZtJ",
      "display_url" : "pastebin.com\/raw.php?i=2ecQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379211890376716289",
  "text" : "http:\/\/t.co\/xx49Na4ckQ Emails: 440 Keywords: 0.66 #infoleak",
  "id" : 379211890376716289,
  "created_at" : "2013-09-15 11:55:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n2O0OtOKVe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UA73Dh7X",
      "display_url" : "pastebin.com\/raw.php?i=UA73\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379209438134947841",
  "text" : "http:\/\/t.co\/n2O0OtOKVe Emails: 188 Keywords: 0.19 #infoleak",
  "id" : 379209438134947841,
  "created_at" : "2013-09-15 11:45:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u9KtVBEtQa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h67FFL8Y",
      "display_url" : "pastebin.com\/raw.php?i=h67F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379198303226699777",
  "text" : "http:\/\/t.co\/u9KtVBEtQa Emails: 99 Keywords: -0.03 #infoleak",
  "id" : 379198303226699777,
  "created_at" : "2013-09-15 11:01:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SHiUKQsjDl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U39vH0jp",
      "display_url" : "pastebin.com\/raw.php?i=U39v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379046876441362435",
  "text" : "http:\/\/t.co\/SHiUKQsjDl Keywords: 0.66 #infoleak",
  "id" : 379046876441362435,
  "created_at" : "2013-09-15 00:59:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2ddf3oW1Lp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7FZh8M70",
      "display_url" : "pastebin.com\/raw.php?i=7FZh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379045230701314048",
  "text" : "http:\/\/t.co\/2ddf3oW1Lp Emails: 84 Keywords: 0.19 #infoleak",
  "id" : 379045230701314048,
  "created_at" : "2013-09-15 00:53:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RDOPGq6CgJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=08TzccTy",
      "display_url" : "pastebin.com\/raw.php?i=08Tz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379043227682488320",
  "text" : "http:\/\/t.co\/RDOPGq6CgJ Keywords: 0.88 #infoleak",
  "id" : 379043227682488320,
  "created_at" : "2013-09-15 00:45:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QgMtVohf3H",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BMMifTxX",
      "display_url" : "pastebin.com\/raw.php?i=BMMi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379020805369110528",
  "text" : "http:\/\/t.co\/QgMtVohf3H Hashes: 123 Keywords: 0.0 #infoleak",
  "id" : 379020805369110528,
  "created_at" : "2013-09-14 23:16:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bC4L9b7APy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i8bpNpRY",
      "display_url" : "pastebin.com\/raw.php?i=i8bp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379013615824539649",
  "text" : "http:\/\/t.co\/bC4L9b7APy Hashes: 64 Keywords: -0.14 #infoleak",
  "id" : 379013615824539649,
  "created_at" : "2013-09-14 22:47:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dLh8XJqYJu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pvJcRgkG",
      "display_url" : "pastebin.com\/raw.php?i=pvJc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379011752362377216",
  "text" : "http:\/\/t.co\/dLh8XJqYJu Hashes: 32 Keywords: -0.14 #infoleak",
  "id" : 379011752362377216,
  "created_at" : "2013-09-14 22:40:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ITMiKKNzdJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dgrc2HGW",
      "display_url" : "pastebin.com\/raw.php?i=Dgrc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379011356835328000",
  "text" : "http:\/\/t.co\/ITMiKKNzdJ Hashes: 32 Keywords: -0.14 #infoleak",
  "id" : 379011356835328000,
  "created_at" : "2013-09-14 22:38:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vKbGHxJSR7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=enD5JPBJ",
      "display_url" : "pastebin.com\/raw.php?i=enD5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378986812506517506",
  "text" : "http:\/\/t.co\/vKbGHxJSR7 Emails: 44 Keywords: 0.22 #infoleak",
  "id" : 378986812506517506,
  "created_at" : "2013-09-14 21:01:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J9cAYAiYhr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qgW0HVK2",
      "display_url" : "pastebin.com\/raw.php?i=qgW0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378976651251429376",
  "text" : "http:\/\/t.co\/J9cAYAiYhr Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 378976651251429376,
  "created_at" : "2013-09-14 20:20:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cWULFWeawC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=esDzRQLs",
      "display_url" : "pastebin.com\/raw.php?i=esDz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378949791427727360",
  "text" : "http:\/\/t.co\/cWULFWeawC Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 378949791427727360,
  "created_at" : "2013-09-14 18:34:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VyFQcVzem8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i558nRjN",
      "display_url" : "pastebin.com\/raw.php?i=i558\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378945981040959489",
  "text" : "http:\/\/t.co\/VyFQcVzem8 Emails: 3 Hashes: 72 E\/H: 0.04 Keywords: 0.44 #infoleak",
  "id" : 378945981040959489,
  "created_at" : "2013-09-14 18:18:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3UGhu9h1hf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XzjyPYm3",
      "display_url" : "pastebin.com\/raw.php?i=Xzjy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378945279828848640",
  "text" : "http:\/\/t.co\/3UGhu9h1hf Emails: 416 Keywords: 0.22 #infoleak",
  "id" : 378945279828848640,
  "created_at" : "2013-09-14 18:16:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NfyCPGj7KC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ML9RKKa8",
      "display_url" : "pastebin.com\/raw.php?i=ML9R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378940936954195969",
  "text" : "http:\/\/t.co\/NfyCPGj7KC Hashes: 130 Keywords: 0.11 #infoleak",
  "id" : 378940936954195969,
  "created_at" : "2013-09-14 17:58:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OIvKWo1uuH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6NhfgBXf",
      "display_url" : "pastebin.com\/raw.php?i=6Nhf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378936002795929600",
  "text" : "http:\/\/t.co\/OIvKWo1uuH Emails: 428 Keywords: 0.08 #infoleak",
  "id" : 378936002795929600,
  "created_at" : "2013-09-14 17:39:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XtJdtOkQhx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MKyggfrB",
      "display_url" : "pastebin.com\/raw.php?i=MKyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378928732188061696",
  "text" : "http:\/\/t.co\/XtJdtOkQhx Emails: 3124 Keywords: 0.22 #infoleak",
  "id" : 378928732188061696,
  "created_at" : "2013-09-14 17:10:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sUQv0DbKs1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TykbCk7n",
      "display_url" : "pastebin.com\/raw.php?i=Tykb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378896797361385473",
  "text" : "http:\/\/t.co\/sUQv0DbKs1 Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 378896797361385473,
  "created_at" : "2013-09-14 15:03:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mgaa7dNjFZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2ByWFc0a",
      "display_url" : "pastebin.com\/raw.php?i=2ByW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378895841768910849",
  "text" : "http:\/\/t.co\/Mgaa7dNjFZ Hashes: 1 Keywords: 0.77 #infoleak",
  "id" : 378895841768910849,
  "created_at" : "2013-09-14 14:59:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/091J4adBgD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gaDuBJE8",
      "display_url" : "pastebin.com\/raw.php?i=gaDu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378888289899380736",
  "text" : "http:\/\/t.co\/091J4adBgD Emails: 45 Keywords: 0.22 #infoleak",
  "id" : 378888289899380736,
  "created_at" : "2013-09-14 14:29:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aALpTLslxG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nXLCdu3Q",
      "display_url" : "pastebin.com\/raw.php?i=nXLC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378876203417206785",
  "text" : "http:\/\/t.co\/aALpTLslxG Possible cisco configuration #infoleak",
  "id" : 378876203417206785,
  "created_at" : "2013-09-14 13:41:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KY2nDMUkEg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PMrYyied",
      "display_url" : "pastebin.com\/raw.php?i=PMrY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378872071582785538",
  "text" : "http:\/\/t.co\/KY2nDMUkEg Emails: 169 Hashes: 336 E\/H: 0.5 Keywords: 0.08 #infoleak",
  "id" : 378872071582785538,
  "created_at" : "2013-09-14 13:25:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k86tMoiOta",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bPwWeeVY",
      "display_url" : "pastebin.com\/raw.php?i=bPwW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378870545669836802",
  "text" : "http:\/\/t.co\/k86tMoiOta Emails: 2600 Keywords: 0.11 #infoleak",
  "id" : 378870545669836802,
  "created_at" : "2013-09-14 13:19:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yP9DiV8Nlt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RKMpZZGE",
      "display_url" : "pastebin.com\/raw.php?i=RKMp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378862756595646466",
  "text" : "http:\/\/t.co\/yP9DiV8Nlt Emails: 21 Keywords: 0.22 #infoleak",
  "id" : 378862756595646466,
  "created_at" : "2013-09-14 12:48:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JXQWmOV2rm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vuWbmqk5",
      "display_url" : "pastebin.com\/raw.php?i=vuWb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378852138266284032",
  "text" : "http:\/\/t.co\/JXQWmOV2rm Emails: 767 Keywords: 0.22 #infoleak",
  "id" : 378852138266284032,
  "created_at" : "2013-09-14 12:06:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Je8fVBh9W0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dBdsK5e9",
      "display_url" : "pastebin.com\/raw.php?i=dBds\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378852080791715840",
  "text" : "http:\/\/t.co\/Je8fVBh9W0 Emails: 42 Keywords: 0.19 #infoleak",
  "id" : 378852080791715840,
  "created_at" : "2013-09-14 12:05:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/frIadToDeN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SasPigsY",
      "display_url" : "pastebin.com\/raw.php?i=SasP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378847373486608384",
  "text" : "http:\/\/t.co\/frIadToDeN Emails: 67 Keywords: 0.22 #infoleak",
  "id" : 378847373486608384,
  "created_at" : "2013-09-14 11:47:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aGdBq3FPT9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u9hSsh7c",
      "display_url" : "pastebin.com\/raw.php?i=u9hS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378788590240530432",
  "text" : "http:\/\/t.co\/aGdBq3FPT9 Emails: 1911 Hashes: 1912 E\/H: 1.0 Keywords: -0.03 #infoleak",
  "id" : 378788590240530432,
  "created_at" : "2013-09-14 07:53:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mSZbuGvMAV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xw6yMLTx",
      "display_url" : "pastebin.com\/raw.php?i=Xw6y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378703927207682048",
  "text" : "http:\/\/t.co\/mSZbuGvMAV Emails: 295 Keywords: 0.08 #infoleak",
  "id" : 378703927207682048,
  "created_at" : "2013-09-14 02:17:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H80RvlR6Ly",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QrivDxzz",
      "display_url" : "pastebin.com\/raw.php?i=Qriv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378543310740008960",
  "text" : "http:\/\/t.co\/H80RvlR6Ly Hashes: 48 Keywords: 0.22 #infoleak",
  "id" : 378543310740008960,
  "created_at" : "2013-09-13 15:38:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kwSofXFHLS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UPUYEMJ2",
      "display_url" : "pastebin.com\/raw.php?i=UPUY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378541081341607937",
  "text" : "http:\/\/t.co\/kwSofXFHLS Emails: 105 Keywords: 0.0 #infoleak",
  "id" : 378541081341607937,
  "created_at" : "2013-09-13 15:30:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BtrNQPhDBo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=agxjSSz1",
      "display_url" : "pastebin.com\/raw.php?i=agxj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378540736678879232",
  "text" : "http:\/\/t.co\/BtrNQPhDBo Emails: 2 Hashes: 82 E\/H: 0.02 Keywords: 0.22 #infoleak",
  "id" : 378540736678879232,
  "created_at" : "2013-09-13 15:28:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BKdR0jD6zs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g9cktV1h",
      "display_url" : "pastebin.com\/raw.php?i=g9ck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378538854606589954",
  "text" : "http:\/\/t.co\/BKdR0jD6zs Emails: 640 Keywords: 0.44 #infoleak",
  "id" : 378538854606589954,
  "created_at" : "2013-09-13 15:21:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qu9EUJgeTM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NCXMVnF2",
      "display_url" : "pastebin.com\/raw.php?i=NCXM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378534374230093826",
  "text" : "http:\/\/t.co\/qu9EUJgeTM Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 378534374230093826,
  "created_at" : "2013-09-13 15:03:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DtUff1ODkt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LAE4xkWT",
      "display_url" : "pastebin.com\/raw.php?i=LAE4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378531906414854144",
  "text" : "http:\/\/t.co\/DtUff1ODkt Hashes: 33 Keywords: 0.0 #infoleak",
  "id" : 378531906414854144,
  "created_at" : "2013-09-13 14:53:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IhJB0VEWSb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HFUACeiQ",
      "display_url" : "pastebin.com\/raw.php?i=HFUA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378519707533340673",
  "text" : "http:\/\/t.co\/IhJB0VEWSb Emails: 3084 Keywords: 0.08 #infoleak",
  "id" : 378519707533340673,
  "created_at" : "2013-09-13 14:05:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SeBYKl4Xqs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZczaAD0Q",
      "display_url" : "pastebin.com\/raw.php?i=Zcza\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378515250170966018",
  "text" : "http:\/\/t.co\/SeBYKl4Xqs Hashes: 62 Keywords: 0.0 #infoleak",
  "id" : 378515250170966018,
  "created_at" : "2013-09-13 13:47:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UYV3DTN7ny",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0AynH4aJ",
      "display_url" : "pastebin.com\/raw.php?i=0Ayn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378513563507126272",
  "text" : "http:\/\/t.co\/UYV3DTN7ny Hashes: 595 Keywords: 0.0 #infoleak",
  "id" : 378513563507126272,
  "created_at" : "2013-09-13 13:40:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pPRdFks37K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3GJv8Y8f",
      "display_url" : "pastebin.com\/raw.php?i=3GJv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378513132261367809",
  "text" : "http:\/\/t.co\/pPRdFks37K Hashes: 301 Keywords: 0.0 #infoleak",
  "id" : 378513132261367809,
  "created_at" : "2013-09-13 13:38:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AL09bwhN9e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MHALjnMA",
      "display_url" : "pastebin.com\/raw.php?i=MHAL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378499803543400449",
  "text" : "http:\/\/t.co\/AL09bwhN9e Hashes: 291 Keywords: 0.11 #infoleak",
  "id" : 378499803543400449,
  "created_at" : "2013-09-13 12:46:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MrTcmefiYS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W2nNZV8n",
      "display_url" : "pastebin.com\/raw.php?i=W2nN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378497774091644929",
  "text" : "http:\/\/t.co\/MrTcmefiYS Emails: 782 Keywords: 0.33 #infoleak",
  "id" : 378497774091644929,
  "created_at" : "2013-09-13 12:37:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HSf7ka5WPc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zt1BBiaM",
      "display_url" : "pastebin.com\/raw.php?i=Zt1B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378497640377245696",
  "text" : "http:\/\/t.co\/HSf7ka5WPc Emails: 4 Hashes: 6 E\/H: 0.67 Keywords: 0.66 #infoleak",
  "id" : 378497640377245696,
  "created_at" : "2013-09-13 12:37:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U8zA1Sh5Wk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T5A2aEH1",
      "display_url" : "pastebin.com\/raw.php?i=T5A2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378487618779897856",
  "text" : "http:\/\/t.co\/U8zA1Sh5Wk Emails: 274 Keywords: 0.41 #infoleak",
  "id" : 378487618779897856,
  "created_at" : "2013-09-13 11:57:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vh2CXrTQ8k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aqGaC2UA",
      "display_url" : "pastebin.com\/raw.php?i=aqGa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378486935729090560",
  "text" : "http:\/\/t.co\/vh2CXrTQ8k Possible cisco configuration #infoleak",
  "id" : 378486935729090560,
  "created_at" : "2013-09-13 11:54:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ap4zXcuaZ4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8rBZpnKW",
      "display_url" : "pastebin.com\/raw.php?i=8rBZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378486231375433728",
  "text" : "http:\/\/t.co\/Ap4zXcuaZ4 Possible cisco configuration #infoleak",
  "id" : 378486231375433728,
  "created_at" : "2013-09-13 11:52:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p5yrRyKGhD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bFJPb1JN",
      "display_url" : "pastebin.com\/raw.php?i=bFJP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378484812085882880",
  "text" : "http:\/\/t.co\/p5yrRyKGhD Keywords: 0.55 #infoleak",
  "id" : 378484812085882880,
  "created_at" : "2013-09-13 11:46:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B5TSii41Sm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Lg05jyDL",
      "display_url" : "pastebin.com\/raw.php?i=Lg05\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378482527901466624",
  "text" : "http:\/\/t.co\/B5TSii41Sm Emails: 5535 Hashes: 5463 E\/H: 1.01 Keywords: 0.41 #infoleak",
  "id" : 378482527901466624,
  "created_at" : "2013-09-13 11:37:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ruGPKfgJl5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U8cpDFag",
      "display_url" : "pastebin.com\/raw.php?i=U8cp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378481798319063040",
  "text" : "http:\/\/t.co\/ruGPKfgJl5 Emails: 72 Keywords: 0.44 #infoleak",
  "id" : 378481798319063040,
  "created_at" : "2013-09-13 11:34:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qf9Id3q2NF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aFGCEpkg",
      "display_url" : "pastebin.com\/raw.php?i=aFGC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378407754647351296",
  "text" : "http:\/\/t.co\/qf9Id3q2NF Hashes: 42 Keywords: 0.16 #infoleak",
  "id" : 378407754647351296,
  "created_at" : "2013-09-13 06:40:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mMR3sBR1Xd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=36PvjCND",
      "display_url" : "pastebin.com\/raw.php?i=36Pv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378392828583243776",
  "text" : "http:\/\/t.co\/mMR3sBR1Xd Keywords: 0.55 #infoleak",
  "id" : 378392828583243776,
  "created_at" : "2013-09-13 05:40:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kEy3N6pzhV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jFvNBeN2",
      "display_url" : "pastebin.com\/raw.php?i=jFvN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378322260584452097",
  "text" : "http:\/\/t.co\/kEy3N6pzhV Emails: 266 Keywords: 0.11 #infoleak",
  "id" : 378322260584452097,
  "created_at" : "2013-09-13 01:00:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kEvCm424DF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gfzuTavv",
      "display_url" : "pastebin.com\/raw.php?i=gfzu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378321237224603648",
  "text" : "http:\/\/t.co\/kEvCm424DF Emails: 93 Keywords: 0.11 #infoleak",
  "id" : 378321237224603648,
  "created_at" : "2013-09-13 00:56:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kJVooerxpk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9R3E5enF",
      "display_url" : "pastebin.com\/raw.php?i=9R3E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378321015266226176",
  "text" : "http:\/\/t.co\/kJVooerxpk Emails: 79 Keywords: 0.0 #infoleak",
  "id" : 378321015266226176,
  "created_at" : "2013-09-13 00:55:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WE33TSbs55",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zQ6qaweK",
      "display_url" : "pastebin.com\/raw.php?i=zQ6q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378320610352308224",
  "text" : "http:\/\/t.co\/WE33TSbs55 Emails: 71 Keywords: 0.0 #infoleak",
  "id" : 378320610352308224,
  "created_at" : "2013-09-13 00:53:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gJNUvcgq5Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Sp47dQHX",
      "display_url" : "pastebin.com\/raw.php?i=Sp47\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378320398334455808",
  "text" : "http:\/\/t.co\/gJNUvcgq5Z Emails: 3542 Keywords: 0.11 #infoleak",
  "id" : 378320398334455808,
  "created_at" : "2013-09-13 00:53:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q1853vqc62",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=njBMzEuh",
      "display_url" : "pastebin.com\/raw.php?i=njBM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378309374281654272",
  "text" : "http:\/\/t.co\/q1853vqc62 Emails: 340 Keywords: 0.0 #infoleak",
  "id" : 378309374281654272,
  "created_at" : "2013-09-13 00:09:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HaGcSxAe2d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9AqnZVK4",
      "display_url" : "pastebin.com\/raw.php?i=9Aqn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378274525462269952",
  "text" : "http:\/\/t.co\/HaGcSxAe2d Emails: 2 Hashes: 124 E\/H: 0.02 Keywords: 0.16 #infoleak",
  "id" : 378274525462269952,
  "created_at" : "2013-09-12 21:50:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TDlEHWaJY0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k0YaP6C4",
      "display_url" : "pastebin.com\/raw.php?i=k0Ya\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378268076803756032",
  "text" : "http:\/\/t.co\/TDlEHWaJY0 Possible cisco configuration #infoleak",
  "id" : 378268076803756032,
  "created_at" : "2013-09-12 21:25:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GBB9bpAvBw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CnLQcaQc",
      "display_url" : "pastebin.com\/raw.php?i=CnLQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378266426852659200",
  "text" : "http:\/\/t.co\/GBB9bpAvBw Emails: 96 Keywords: 0.0 #infoleak",
  "id" : 378266426852659200,
  "created_at" : "2013-09-12 21:18:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JapwGa7eVO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TJExCgg3",
      "display_url" : "pastebin.com\/raw.php?i=TJEx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378264082123456512",
  "text" : "http:\/\/t.co\/JapwGa7eVO Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 378264082123456512,
  "created_at" : "2013-09-12 21:09:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gwvcktuEX3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kZEmU1HV",
      "display_url" : "pastebin.com\/raw.php?i=kZEm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378263701574258688",
  "text" : "http:\/\/t.co\/gwvcktuEX3 Emails: 252 Hashes: 253 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 378263701574258688,
  "created_at" : "2013-09-12 21:07:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xKcFh7WDFo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qF7FBNxP",
      "display_url" : "pastebin.com\/raw.php?i=qF7F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378201128887779329",
  "text" : "http:\/\/t.co\/xKcFh7WDFo Emails: 69 Keywords: 0.0 #infoleak",
  "id" : 378201128887779329,
  "created_at" : "2013-09-12 16:59:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kNwnrZDMfw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JNLRJzH8",
      "display_url" : "pastebin.com\/raw.php?i=JNLR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378200886184394752",
  "text" : "http:\/\/t.co\/kNwnrZDMfw Hashes: 1073 Keywords: 0.0 #infoleak",
  "id" : 378200886184394752,
  "created_at" : "2013-09-12 16:58:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/80AbCierWO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hydxj5PA",
      "display_url" : "pastebin.com\/raw.php?i=Hydx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378163529099907072",
  "text" : "http:\/\/t.co\/80AbCierWO Found possible Google API key(s) #infoleak",
  "id" : 378163529099907072,
  "created_at" : "2013-09-12 14:29:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ox7OmjvUDO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6jQ8Ybi2",
      "display_url" : "pastebin.com\/raw.php?i=6jQ8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377960465009082368",
  "text" : "http:\/\/t.co\/Ox7OmjvUDO Emails: 35 Keywords: -0.03 #infoleak",
  "id" : 377960465009082368,
  "created_at" : "2013-09-12 01:02:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5jVntvFgWr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9fr8iYL9",
      "display_url" : "pastebin.com\/raw.php?i=9fr8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377954004967653377",
  "text" : "http:\/\/t.co\/5jVntvFgWr Emails: 100 Hashes: 99 E\/H: 1.01 Keywords: 0.33 #infoleak",
  "id" : 377954004967653377,
  "created_at" : "2013-09-12 00:37:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pBzkIGyVT4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DPNsQ2fx",
      "display_url" : "pastebin.com\/raw.php?i=DPNs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377953583821770752",
  "text" : "http:\/\/t.co\/pBzkIGyVT4 Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 377953583821770752,
  "created_at" : "2013-09-12 00:35:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xhK30DQi1y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tEkHSkA7",
      "display_url" : "pastebin.com\/raw.php?i=tEkH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377944359154749440",
  "text" : "http:\/\/t.co\/xhK30DQi1y Emails: 30 Keywords: 0.33 #infoleak",
  "id" : 377944359154749440,
  "created_at" : "2013-09-11 23:58:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g6pEAGXu7g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fXFenZK4",
      "display_url" : "pastebin.com\/raw.php?i=fXFe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377941403403571200",
  "text" : "http:\/\/t.co\/g6pEAGXu7g Emails: 980 Keywords: 0.11 #infoleak",
  "id" : 377941403403571200,
  "created_at" : "2013-09-11 23:47:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qybOORiY0A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WtFMH9Z7",
      "display_url" : "pastebin.com\/raw.php?i=WtFM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377940479712968705",
  "text" : "http:\/\/t.co\/qybOORiY0A Emails: 298 Keywords: 0.11 #infoleak",
  "id" : 377940479712968705,
  "created_at" : "2013-09-11 23:43:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tTTncuM6fH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RgFK5m0h",
      "display_url" : "pastebin.com\/raw.php?i=RgFK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377933861910757377",
  "text" : "http:\/\/t.co\/tTTncuM6fH Emails: 32 Hashes: 1 E\/H: 32.0 Keywords: 0.0 #infoleak",
  "id" : 377933861910757377,
  "created_at" : "2013-09-11 23:17:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m9HVDEQLDh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ihTabhZs",
      "display_url" : "pastebin.com\/raw.php?i=ihTa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377933530745274368",
  "text" : "http:\/\/t.co\/m9HVDEQLDh Emails: 119 Keywords: 0.0 #infoleak",
  "id" : 377933530745274368,
  "created_at" : "2013-09-11 23:15:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Lu7pnB9ZA6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7L7GDwd0",
      "display_url" : "pastebin.com\/raw.php?i=7L7G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377932548166668288",
  "text" : "http:\/\/t.co\/Lu7pnB9ZA6 Emails: 979 Keywords: 0.22 #infoleak",
  "id" : 377932548166668288,
  "created_at" : "2013-09-11 23:11:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2GDWAOphcR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VcGFw591",
      "display_url" : "pastebin.com\/raw.php?i=VcGF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377926853648187392",
  "text" : "http:\/\/t.co\/2GDWAOphcR Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 377926853648187392,
  "created_at" : "2013-09-11 22:49:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IVqftwdqnH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pnrBgFZd",
      "display_url" : "pastebin.com\/raw.php?i=pnrB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377921098312318976",
  "text" : "http:\/\/t.co\/IVqftwdqnH Hashes: 34 Keywords: 0.11 #infoleak",
  "id" : 377921098312318976,
  "created_at" : "2013-09-11 22:26:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rbPNkX4y6B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aTcMJDLr",
      "display_url" : "pastebin.com\/raw.php?i=aTcM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377919779434414080",
  "text" : "http:\/\/t.co\/rbPNkX4y6B Emails: 58 Keywords: 0.11 #infoleak",
  "id" : 377919779434414080,
  "created_at" : "2013-09-11 22:21:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xmPheUlMop",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LSUwgxvn",
      "display_url" : "pastebin.com\/raw.php?i=LSUw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377908686607613952",
  "text" : "http:\/\/t.co\/xmPheUlMop Emails: 119 Keywords: 0.08 #infoleak",
  "id" : 377908686607613952,
  "created_at" : "2013-09-11 21:37:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EtrHulVGSH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jxHyzp7z",
      "display_url" : "pastebin.com\/raw.php?i=jxHy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377899902174777344",
  "text" : "http:\/\/t.co\/EtrHulVGSH Emails: 506 Hashes: 39 E\/H: 12.97 Keywords: 0.22 #infoleak",
  "id" : 377899902174777344,
  "created_at" : "2013-09-11 21:02:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rrmIueBryW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fBWEhu25",
      "display_url" : "pastebin.com\/raw.php?i=fBWE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377898637097177088",
  "text" : "http:\/\/t.co\/rrmIueBryW Emails: 24 Keywords: 0.11 #infoleak",
  "id" : 377898637097177088,
  "created_at" : "2013-09-11 20:57:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NDZ0pvDdnm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G6T5fRcb",
      "display_url" : "pastebin.com\/raw.php?i=G6T5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377879541639020544",
  "text" : "http:\/\/t.co\/NDZ0pvDdnm Hashes: 65 Keywords: 0.08 #infoleak",
  "id" : 377879541639020544,
  "created_at" : "2013-09-11 19:41:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lztiVTFAXM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xCnrKijF",
      "display_url" : "pastebin.com\/raw.php?i=xCnr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377877802332459009",
  "text" : "http:\/\/t.co\/lztiVTFAXM Emails: 2132 Keywords: 0.33 #infoleak",
  "id" : 377877802332459009,
  "created_at" : "2013-09-11 19:34:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZcGXQZwqnf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nKZs8wXK",
      "display_url" : "pastebin.com\/raw.php?i=nKZs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377875525131599872",
  "text" : "http:\/\/t.co\/ZcGXQZwqnf Emails: 60 Keywords: 0.22 #infoleak",
  "id" : 377875525131599872,
  "created_at" : "2013-09-11 19:25:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2b6k9E8eSu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YdnHP9dK",
      "display_url" : "pastebin.com\/raw.php?i=YdnH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377870108112482304",
  "text" : "http:\/\/t.co\/2b6k9E8eSu Hashes: 180 Keywords: 0.0 #infoleak",
  "id" : 377870108112482304,
  "created_at" : "2013-09-11 19:03:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5tomafQZ9G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TW6yg1LN",
      "display_url" : "pastebin.com\/raw.php?i=TW6y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377869984028196864",
  "text" : "http:\/\/t.co\/5tomafQZ9G Hashes: 340 Keywords: 0.0 #infoleak",
  "id" : 377869984028196864,
  "created_at" : "2013-09-11 19:03:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NrD5T5NAHm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XnMVj7Jh",
      "display_url" : "pastebin.com\/raw.php?i=XnMV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377863443237584896",
  "text" : "http:\/\/t.co\/NrD5T5NAHm Keywords: 0.55 #infoleak",
  "id" : 377863443237584896,
  "created_at" : "2013-09-11 18:37:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w46l73mlu4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MuyrqQ5Z",
      "display_url" : "pastebin.com\/raw.php?i=Muyr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377854323029733376",
  "text" : "http:\/\/t.co\/w46l73mlu4 Emails: 74 Keywords: 0.0 #infoleak",
  "id" : 377854323029733376,
  "created_at" : "2013-09-11 18:01:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vDr3YbcKAd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8QRZgZkt",
      "display_url" : "pastebin.com\/raw.php?i=8QRZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377852306009911297",
  "text" : "http:\/\/t.co\/vDr3YbcKAd Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 377852306009911297,
  "created_at" : "2013-09-11 17:53:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uSsJ7WdIMy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s31mEmAt",
      "display_url" : "pastebin.com\/raw.php?i=s31m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377841974973575168",
  "text" : "http:\/\/t.co\/uSsJ7WdIMy Hashes: 64 Keywords: 0.11 #infoleak",
  "id" : 377841974973575168,
  "created_at" : "2013-09-11 17:12:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YF220hmNbb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FP3kzMLY",
      "display_url" : "pastebin.com\/raw.php?i=FP3k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377840875768135680",
  "text" : "http:\/\/t.co\/YF220hmNbb Emails: 59 Keywords: 0.44 #infoleak",
  "id" : 377840875768135680,
  "created_at" : "2013-09-11 17:07:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/noyLkNUhDf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tgb4xaFM",
      "display_url" : "pastebin.com\/raw.php?i=tgb4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377835095547449344",
  "text" : "http:\/\/t.co\/noyLkNUhDf Emails: 51 Keywords: 0.44 #infoleak",
  "id" : 377835095547449344,
  "created_at" : "2013-09-11 16:44:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kKjJs0aCwz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z2j7qhu3",
      "display_url" : "pastebin.com\/raw.php?i=z2j7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377833039210217472",
  "text" : "http:\/\/t.co\/kKjJs0aCwz Emails: 300 Hashes: 299 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 377833039210217472,
  "created_at" : "2013-09-11 16:36:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3Ks3hU6Hjv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mvXZxi1Z",
      "display_url" : "pastebin.com\/raw.php?i=mvXZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377830845266280448",
  "text" : "http:\/\/t.co\/3Ks3hU6Hjv Emails: 126 Keywords: 0.0 #infoleak",
  "id" : 377830845266280448,
  "created_at" : "2013-09-11 16:27:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Lq00HHAB8q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Kjbm2xCG",
      "display_url" : "pastebin.com\/raw.php?i=Kjbm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377821071690727426",
  "text" : "http:\/\/t.co\/Lq00HHAB8q Emails: 59 Keywords: 0.0 #infoleak",
  "id" : 377821071690727426,
  "created_at" : "2013-09-11 15:48:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UGTL9LfTta",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jerMcqtM",
      "display_url" : "pastebin.com\/raw.php?i=jerM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377820379676696576",
  "text" : "http:\/\/t.co\/UGTL9LfTta Emails: 96 Keywords: 0.0 #infoleak",
  "id" : 377820379676696576,
  "created_at" : "2013-09-11 15:46:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wJGHstoKBl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BcE3qFGm",
      "display_url" : "pastebin.com\/raw.php?i=BcE3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377818568727232512",
  "text" : "http:\/\/t.co\/wJGHstoKBl Emails: 288 Keywords: 0.11 #infoleak",
  "id" : 377818568727232512,
  "created_at" : "2013-09-11 15:39:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i2K2QQ7B1y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TrqyPPus",
      "display_url" : "pastebin.com\/raw.php?i=Trqy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377803924633583616",
  "text" : "http:\/\/t.co\/i2K2QQ7B1y Hashes: 51 Keywords: -0.03 #infoleak",
  "id" : 377803924633583616,
  "created_at" : "2013-09-11 14:40:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QlN8blKTB7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5TaJ0XHq",
      "display_url" : "pastebin.com\/raw.php?i=5TaJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377798748510101506",
  "text" : "http:\/\/t.co\/QlN8blKTB7 Emails: 82 Keywords: 0.0 #infoleak",
  "id" : 377798748510101506,
  "created_at" : "2013-09-11 14:20:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ivJLXu9U95",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gr2Guz1i",
      "display_url" : "pastebin.com\/raw.php?i=Gr2G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377796617149374464",
  "text" : "http:\/\/t.co\/ivJLXu9U95 Emails: 654 Keywords: 0.11 #infoleak",
  "id" : 377796617149374464,
  "created_at" : "2013-09-11 14:11:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rIH5BulORN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kwqs8JNN",
      "display_url" : "pastebin.com\/raw.php?i=kwqs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377791943411261443",
  "text" : "http:\/\/t.co\/rIH5BulORN Hashes: 60 Keywords: -0.03 #infoleak",
  "id" : 377791943411261443,
  "created_at" : "2013-09-11 13:53:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kAfKLzqNy1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ME5Ckd0T",
      "display_url" : "pastebin.com\/raw.php?i=ME5C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377790963156267008",
  "text" : "http:\/\/t.co\/kAfKLzqNy1 Emails: 3201 Keywords: 0.3 #infoleak",
  "id" : 377790963156267008,
  "created_at" : "2013-09-11 13:49:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oEYLj0JxAz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zekxn8jf",
      "display_url" : "pastebin.com\/raw.php?i=Zekx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377724998154477568",
  "text" : "http:\/\/t.co\/oEYLj0JxAz Emails: 43 Keywords: 0.44 #infoleak",
  "id" : 377724998154477568,
  "created_at" : "2013-09-11 09:27:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wyZhqo0Seh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g08gMtSn",
      "display_url" : "pastebin.com\/raw.php?i=g08g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377723621491609602",
  "text" : "http:\/\/t.co\/wyZhqo0Seh Emails: 1875 Keywords: 0.22 #infoleak",
  "id" : 377723621491609602,
  "created_at" : "2013-09-11 09:21:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wLrQ65E9zz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V5LRsadN",
      "display_url" : "pastebin.com\/raw.php?i=V5LR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377717880609316865",
  "text" : "http:\/\/t.co\/wLrQ65E9zz Emails: 53 Keywords: 0.19 #infoleak",
  "id" : 377717880609316865,
  "created_at" : "2013-09-11 08:58:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dtyyUT0efC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FGis5YRn",
      "display_url" : "pastebin.com\/raw.php?i=FGis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377698363527139328",
  "text" : "http:\/\/t.co\/dtyyUT0efC Emails: 3643 Keywords: 0.44 #infoleak",
  "id" : 377698363527139328,
  "created_at" : "2013-09-11 07:41:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KXM9PfyTYh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=shXmmtVf",
      "display_url" : "pastebin.com\/raw.php?i=shXm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377693206621990912",
  "text" : "http:\/\/t.co\/KXM9PfyTYh Hashes: 63 Keywords: 0.11 #infoleak",
  "id" : 377693206621990912,
  "created_at" : "2013-09-11 07:20:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cpzBivn2aC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fs8uyGzx",
      "display_url" : "pastebin.com\/raw.php?i=fs8u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377689296570183680",
  "text" : "http:\/\/t.co\/cpzBivn2aC Emails: 1713 Keywords: 0.55 #infoleak",
  "id" : 377689296570183680,
  "created_at" : "2013-09-11 07:05:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pCKO0aVVDB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tmhSpJvX",
      "display_url" : "pastebin.com\/raw.php?i=tmhS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377674583677353984",
  "text" : "http:\/\/t.co\/pCKO0aVVDB Emails: 69 Keywords: 0.3 #infoleak",
  "id" : 377674583677353984,
  "created_at" : "2013-09-11 06:06:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J5yhrfu2WD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zCa0j8cK",
      "display_url" : "pastebin.com\/raw.php?i=zCa0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377616801393549313",
  "text" : "http:\/\/t.co\/J5yhrfu2WD Emails: 1 Hashes: 32 E\/H: 0.03 Keywords: 0.0 #infoleak",
  "id" : 377616801393549313,
  "created_at" : "2013-09-11 02:17:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bmZ7C0ojBN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=32u4QTeP",
      "display_url" : "pastebin.com\/raw.php?i=32u4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377579556145991680",
  "text" : "http:\/\/t.co\/bmZ7C0ojBN Possible cisco configuration #infoleak",
  "id" : 377579556145991680,
  "created_at" : "2013-09-10 23:49:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EH4F2PYoj3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iSXCN8jG",
      "display_url" : "pastebin.com\/raw.php?i=iSXC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377579442430033920",
  "text" : "http:\/\/t.co\/EH4F2PYoj3 Emails: 4198 Hashes: 4199 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 377579442430033920,
  "created_at" : "2013-09-10 23:48:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cTWKSWi8jT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HEzuvA6E",
      "display_url" : "pastebin.com\/raw.php?i=HEzu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377575285375647744",
  "text" : "http:\/\/t.co\/cTWKSWi8jT Emails: 2 Keywords: 0.66 #infoleak",
  "id" : 377575285375647744,
  "created_at" : "2013-09-10 23:32:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1ka8eb4u2s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0EvfW6VH",
      "display_url" : "pastebin.com\/raw.php?i=0Evf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377560883280773121",
  "text" : "http:\/\/t.co\/1ka8eb4u2s Emails: 301 Keywords: 0.11 #infoleak",
  "id" : 377560883280773121,
  "created_at" : "2013-09-10 22:35:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QqKxL1315J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6ifruwgg",
      "display_url" : "pastebin.com\/raw.php?i=6ifr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377559720573157376",
  "text" : "http:\/\/t.co\/QqKxL1315J Emails: 231 Keywords: 0.11 #infoleak",
  "id" : 377559720573157376,
  "created_at" : "2013-09-10 22:30:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7GbG0A1maJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yU6j82Un",
      "display_url" : "pastebin.com\/raw.php?i=yU6j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377558228504023040",
  "text" : "http:\/\/t.co\/7GbG0A1maJ Emails: 259 Keywords: 0.11 #infoleak",
  "id" : 377558228504023040,
  "created_at" : "2013-09-10 22:24:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5clVVvBvyM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yXGacV2L",
      "display_url" : "pastebin.com\/raw.php?i=yXGa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377556861878550528",
  "text" : "http:\/\/t.co\/5clVVvBvyM Emails: 366 Keywords: 0.11 #infoleak",
  "id" : 377556861878550528,
  "created_at" : "2013-09-10 22:19:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ygiX7QViaT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t2znsTbY",
      "display_url" : "pastebin.com\/raw.php?i=t2zn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377553658495238144",
  "text" : "http:\/\/t.co\/ygiX7QViaT Emails: 163 Keywords: 0.0 #infoleak",
  "id" : 377553658495238144,
  "created_at" : "2013-09-10 22:06:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/apjYdzhK0S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ScRzhYR0",
      "display_url" : "pastebin.com\/raw.php?i=ScRz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377549918615113729",
  "text" : "http:\/\/t.co\/apjYdzhK0S Emails: 654 Keywords: 0.22 #infoleak",
  "id" : 377549918615113729,
  "created_at" : "2013-09-10 21:51:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UFSCy2WK15",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qSAq7adp",
      "display_url" : "pastebin.com\/raw.php?i=qSAq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377548895468802048",
  "text" : "http:\/\/t.co\/UFSCy2WK15 Hashes: 338 Keywords: -0.03 #infoleak",
  "id" : 377548895468802048,
  "created_at" : "2013-09-10 21:47:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rxAjX0Pga0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TvLhxbSp",
      "display_url" : "pastebin.com\/raw.php?i=TvLh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377545315630727168",
  "text" : "http:\/\/t.co\/rxAjX0Pga0 Emails: 26 Hashes: 3 E\/H: 8.67 Keywords: 0.08 #infoleak",
  "id" : 377545315630727168,
  "created_at" : "2013-09-10 21:33:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j6KgG1rvbo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SBpcspNj",
      "display_url" : "pastebin.com\/raw.php?i=SBpc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377544571003342849",
  "text" : "http:\/\/t.co\/j6KgG1rvbo Emails: 654 Keywords: 0.22 #infoleak",
  "id" : 377544571003342849,
  "created_at" : "2013-09-10 21:30:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/265AGHtAGa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RLG2QXJj",
      "display_url" : "pastebin.com\/raw.php?i=RLG2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377542438027399168",
  "text" : "http:\/\/t.co\/265AGHtAGa Emails: 654 Keywords: 0.22 #infoleak",
  "id" : 377542438027399168,
  "created_at" : "2013-09-10 21:21:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Aq3ipeRibW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Yzmg6SFm",
      "display_url" : "pastebin.com\/raw.php?i=Yzmg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377534366882484224",
  "text" : "http:\/\/t.co\/Aq3ipeRibW Emails: 118 Hashes: 9 E\/H: 13.11 Keywords: 0.0 #infoleak",
  "id" : 377534366882484224,
  "created_at" : "2013-09-10 20:49:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AdxMiMvHbE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r1dyVbmG",
      "display_url" : "pastebin.com\/raw.php?i=r1dy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377533079319232512",
  "text" : "http:\/\/t.co\/AdxMiMvHbE Emails: 119 Keywords: 0.08 #infoleak",
  "id" : 377533079319232512,
  "created_at" : "2013-09-10 20:44:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HGeREETcl3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t4UguM0b",
      "display_url" : "pastebin.com\/raw.php?i=t4Ug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377531718892535808",
  "text" : "http:\/\/t.co\/HGeREETcl3 Hashes: 191 Keywords: -0.03 #infoleak",
  "id" : 377531718892535808,
  "created_at" : "2013-09-10 20:39:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/08WNF8z4KB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k2iZ4z6m",
      "display_url" : "pastebin.com\/raw.php?i=k2iZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377530847362301952",
  "text" : "http:\/\/t.co\/08WNF8z4KB Hashes: 343 Keywords: -0.06 #infoleak",
  "id" : 377530847362301952,
  "created_at" : "2013-09-10 20:35:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ChVURdeOZz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hFy2tbt1",
      "display_url" : "pastebin.com\/raw.php?i=hFy2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377519929408249857",
  "text" : "http:\/\/t.co\/ChVURdeOZz Emails: 183 Keywords: 0.0 #infoleak",
  "id" : 377519929408249857,
  "created_at" : "2013-09-10 19:52:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I4AzEWwHqq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jP8S5440",
      "display_url" : "pastebin.com\/raw.php?i=jP8S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377517307243036672",
  "text" : "http:\/\/t.co\/I4AzEWwHqq Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 377517307243036672,
  "created_at" : "2013-09-10 19:41:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/19tzHR7DaW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BtESbfbE",
      "display_url" : "pastebin.com\/raw.php?i=BtES\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377508947017879552",
  "text" : "http:\/\/t.co\/19tzHR7DaW Emails: 183 Keywords: 0.0 #infoleak",
  "id" : 377508947017879552,
  "created_at" : "2013-09-10 19:08:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qYdVDTRbBy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vVa8bhMM",
      "display_url" : "pastebin.com\/raw.php?i=vVa8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377502909673783296",
  "text" : "http:\/\/t.co\/qYdVDTRbBy Emails: 81 Hashes: 81 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 377502909673783296,
  "created_at" : "2013-09-10 18:44:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nB0WkjzAPu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RTFg0rJj",
      "display_url" : "pastebin.com\/raw.php?i=RTFg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377496872925298688",
  "text" : "http:\/\/t.co\/nB0WkjzAPu Emails: 174 Keywords: 0.22 #infoleak",
  "id" : 377496872925298688,
  "created_at" : "2013-09-10 18:20:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FCd94FpzaK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s5cnf6a7",
      "display_url" : "pastebin.com\/raw.php?i=s5cn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377483053662494720",
  "text" : "http:\/\/t.co\/FCd94FpzaK Emails: 654 Hashes: 657 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 377483053662494720,
  "created_at" : "2013-09-10 17:25:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BLNjzyIt5P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XCUnmLec",
      "display_url" : "pastebin.com\/raw.php?i=XCUn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377481988128514048",
  "text" : "http:\/\/t.co\/BLNjzyIt5P Emails: 7 Hashes: 165 E\/H: 0.04 Keywords: 0.08 #infoleak",
  "id" : 377481988128514048,
  "created_at" : "2013-09-10 17:21:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9Ci3TYbaCn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mQRaPTJb",
      "display_url" : "pastebin.com\/raw.php?i=mQRa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377479715021676545",
  "text" : "http:\/\/t.co\/9Ci3TYbaCn Emails: 186 Hashes: 64 E\/H: 2.91 Keywords: 0.33 #infoleak",
  "id" : 377479715021676545,
  "created_at" : "2013-09-10 17:12:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LoYO4ITZ30",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=36W5eCgQ",
      "display_url" : "pastebin.com\/raw.php?i=36W5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377470467856031744",
  "text" : "http:\/\/t.co\/LoYO4ITZ30 Emails: 96 Keywords: 0.0 #infoleak",
  "id" : 377470467856031744,
  "created_at" : "2013-09-10 16:35:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ySrVCTPgIJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q8qaqpU7",
      "display_url" : "pastebin.com\/raw.php?i=Q8qa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377470301786755072",
  "text" : "http:\/\/t.co\/ySrVCTPgIJ Emails: 450 Keywords: 0.11 #infoleak",
  "id" : 377470301786755072,
  "created_at" : "2013-09-10 16:35:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QdZOBxE4M3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FfALbCUP",
      "display_url" : "pastebin.com\/raw.php?i=FfAL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377465541503356929",
  "text" : "http:\/\/t.co\/QdZOBxE4M3 Emails: 1239 Keywords: 0.11 #infoleak",
  "id" : 377465541503356929,
  "created_at" : "2013-09-10 16:16:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H5Y0tYBUsy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3sgZV8xc",
      "display_url" : "pastebin.com\/raw.php?i=3sgZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377463105116049408",
  "text" : "http:\/\/t.co\/H5Y0tYBUsy Emails: 91 Keywords: -0.14 #infoleak",
  "id" : 377463105116049408,
  "created_at" : "2013-09-10 16:06:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R6x48yG6UG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VQQQgcB7",
      "display_url" : "pastebin.com\/raw.php?i=VQQQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377412207895539712",
  "text" : "http:\/\/t.co\/R6x48yG6UG Hashes: 239 Keywords: 0.0 #infoleak",
  "id" : 377412207895539712,
  "created_at" : "2013-09-10 12:44:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yMu2YIDEq5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2TSQrhBk",
      "display_url" : "pastebin.com\/raw.php?i=2TSQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377408054414671872",
  "text" : "http:\/\/t.co\/yMu2YIDEq5 Found possible Google API key(s) #infoleak",
  "id" : 377408054414671872,
  "created_at" : "2013-09-10 12:27:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yawSphWQhD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ripn12PL",
      "display_url" : "pastebin.com\/raw.php?i=ripn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377406604821291008",
  "text" : "http:\/\/t.co\/yawSphWQhD Found possible Google API key(s) #infoleak",
  "id" : 377406604821291008,
  "created_at" : "2013-09-10 12:22:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QrWGmnpQTr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1dRYUrTH",
      "display_url" : "pastebin.com\/raw.php?i=1dRY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377406588316688384",
  "text" : "http:\/\/t.co\/QrWGmnpQTr Emails: 1 Hashes: 48 E\/H: 0.02 Keywords: 0.44 #infoleak",
  "id" : 377406588316688384,
  "created_at" : "2013-09-10 12:21:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4AANAAY3wN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XFTWnAMi",
      "display_url" : "pastebin.com\/raw.php?i=XFTW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377406461816483840",
  "text" : "http:\/\/t.co\/4AANAAY3wN Emails: 214 Keywords: 0.22 #infoleak",
  "id" : 377406461816483840,
  "created_at" : "2013-09-10 12:21:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MVKLAKM4W5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xAR3pHLT",
      "display_url" : "pastebin.com\/raw.php?i=xAR3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377403863827226624",
  "text" : "http:\/\/t.co\/MVKLAKM4W5 Hashes: 103 Keywords: -0.06 #infoleak",
  "id" : 377403863827226624,
  "created_at" : "2013-09-10 12:11:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/69eaO2escw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hBYZH3du",
      "display_url" : "pastebin.com\/raw.php?i=hBYZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377402238508863488",
  "text" : "http:\/\/t.co\/69eaO2escw Hashes: 38 Keywords: 0.0 #infoleak",
  "id" : 377402238508863488,
  "created_at" : "2013-09-10 12:04:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZUFM50brrr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rHgmg8iQ",
      "display_url" : "pastebin.com\/raw.php?i=rHgm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377398481482416128",
  "text" : "http:\/\/t.co\/ZUFM50brrr Emails: 1 Hashes: 64 E\/H: 0.02 Keywords: 0.11 #infoleak",
  "id" : 377398481482416128,
  "created_at" : "2013-09-10 11:49:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NQ7L91U1Fn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vkFdZiMq",
      "display_url" : "pastebin.com\/raw.php?i=vkFd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377372281724764160",
  "text" : "http:\/\/t.co\/NQ7L91U1Fn Emails: 253 Keywords: 0.3 #infoleak",
  "id" : 377372281724764160,
  "created_at" : "2013-09-10 10:05:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fhodkXepXf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jaShUhBS",
      "display_url" : "pastebin.com\/raw.php?i=jaSh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377363937064259584",
  "text" : "http:\/\/t.co\/fhodkXepXf Hashes: 253 Keywords: -0.03 #infoleak",
  "id" : 377363937064259584,
  "created_at" : "2013-09-10 09:32:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WaKU1uqdAz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jSbnyysU",
      "display_url" : "pastebin.com\/raw.php?i=jSbn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377342946653134848",
  "text" : "http:\/\/t.co\/WaKU1uqdAz Emails: 163 Keywords: 0.0 #infoleak",
  "id" : 377342946653134848,
  "created_at" : "2013-09-10 08:09:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4PwAqmxQbn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1HyKXiPk",
      "display_url" : "pastebin.com\/raw.php?i=1HyK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377341739603742720",
  "text" : "http:\/\/t.co\/4PwAqmxQbn Emails: 683 Keywords: 0.0 #infoleak",
  "id" : 377341739603742720,
  "created_at" : "2013-09-10 08:04:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0txVnvlYMK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z42EBXuV",
      "display_url" : "pastebin.com\/raw.php?i=z42E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377336763007901696",
  "text" : "http:\/\/t.co\/0txVnvlYMK Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 377336763007901696,
  "created_at" : "2013-09-10 07:44:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FwrpVkqp6I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bYRKpAjf",
      "display_url" : "pastebin.com\/raw.php?i=bYRK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377333507963383808",
  "text" : "http:\/\/t.co\/FwrpVkqp6I Emails: 65 Keywords: 0.19 #infoleak",
  "id" : 377333507963383808,
  "created_at" : "2013-09-10 07:31:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4BoTyMWaI2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aqc9tYnN",
      "display_url" : "pastebin.com\/raw.php?i=aqc9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377287787487055872",
  "text" : "http:\/\/t.co\/4BoTyMWaI2 Found possible Google API key(s) #infoleak",
  "id" : 377287787487055872,
  "created_at" : "2013-09-10 04:29:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hBj4jSTZkx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fsTyMPy4",
      "display_url" : "pastebin.com\/raw.php?i=fsTy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377284655663157249",
  "text" : "http:\/\/t.co\/hBj4jSTZkx Emails: 1300 Keywords: 0.33 #infoleak",
  "id" : 377284655663157249,
  "created_at" : "2013-09-10 04:17:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UrVp1SnMDj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CvuajRmv",
      "display_url" : "pastebin.com\/raw.php?i=Cvua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377282830767648768",
  "text" : "http:\/\/t.co\/UrVp1SnMDj Hashes: 41 Keywords: -0.14 #infoleak",
  "id" : 377282830767648768,
  "created_at" : "2013-09-10 04:10:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QSHW2Y0XFo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zcis0Fnv",
      "display_url" : "pastebin.com\/raw.php?i=zcis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377277860735512576",
  "text" : "http:\/\/t.co\/QSHW2Y0XFo Emails: 998 Keywords: 0.08 #infoleak",
  "id" : 377277860735512576,
  "created_at" : "2013-09-10 03:50:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hjH5s5ngpt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0LJ0wNBc",
      "display_url" : "pastebin.com\/raw.php?i=0LJ0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377275726434938880",
  "text" : "http:\/\/t.co\/hjH5s5ngpt Emails: 27 Keywords: -0.14 #infoleak",
  "id" : 377275726434938880,
  "created_at" : "2013-09-10 03:41:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tejj4F95mY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PmuDtuw0",
      "display_url" : "pastebin.com\/raw.php?i=PmuD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377274156305641472",
  "text" : "http:\/\/t.co\/tejj4F95mY Hashes: 164 Keywords: 0.11 #infoleak",
  "id" : 377274156305641472,
  "created_at" : "2013-09-10 03:35:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B2e3h3FLM5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SpeNuiBv",
      "display_url" : "pastebin.com\/raw.php?i=SpeN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377272849007775744",
  "text" : "http:\/\/t.co\/B2e3h3FLM5 Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 377272849007775744,
  "created_at" : "2013-09-10 03:30:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/axZz04jgIb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LQmCUuZU",
      "display_url" : "pastebin.com\/raw.php?i=LQmC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377268812715806722",
  "text" : "http:\/\/t.co\/axZz04jgIb Emails: 143 Keywords: 0.0 #infoleak",
  "id" : 377268812715806722,
  "created_at" : "2013-09-10 03:14:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lMUkewaxBX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nVEK2KhM",
      "display_url" : "pastebin.com\/raw.php?i=nVEK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377267574868021248",
  "text" : "http:\/\/t.co\/lMUkewaxBX Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 377267574868021248,
  "created_at" : "2013-09-10 03:09:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4H3tY5j6Z2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K7mn0Um1",
      "display_url" : "pastebin.com\/raw.php?i=K7mn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377251168293908480",
  "text" : "http:\/\/t.co\/4H3tY5j6Z2 Emails: 221 Keywords: 0.08 #infoleak",
  "id" : 377251168293908480,
  "created_at" : "2013-09-10 02:04:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5tj870efI4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YRD3MzSw",
      "display_url" : "pastebin.com\/raw.php?i=YRD3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377228645489987584",
  "text" : "http:\/\/t.co\/5tj870efI4 Emails: 730 Hashes: 729 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 377228645489987584,
  "created_at" : "2013-09-10 00:34:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e3L1NGyDkX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=STms2gS2",
      "display_url" : "pastebin.com\/raw.php?i=STms\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377225290008641537",
  "text" : "http:\/\/t.co\/e3L1NGyDkX Emails: 396 Hashes: 4 E\/H: 99.0 Keywords: 0.33 #infoleak",
  "id" : 377225290008641537,
  "created_at" : "2013-09-10 00:21:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/unzTruHhD7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=scVrzFrm",
      "display_url" : "pastebin.com\/raw.php?i=scVr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377210163888812032",
  "text" : "http:\/\/t.co\/unzTruHhD7 Emails: 93 Keywords: 0.0 #infoleak",
  "id" : 377210163888812032,
  "created_at" : "2013-09-09 23:21:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3euEeuQwvA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GC5jX1h2",
      "display_url" : "pastebin.com\/raw.php?i=GC5j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377200777594683392",
  "text" : "http:\/\/t.co\/3euEeuQwvA Emails: 683 Keywords: 0.0 #infoleak",
  "id" : 377200777594683392,
  "created_at" : "2013-09-09 22:44:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YJvg6bdd2e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y79YBnDf",
      "display_url" : "pastebin.com\/raw.php?i=y79Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377200339004297216",
  "text" : "http:\/\/t.co\/YJvg6bdd2e Emails: 55 Keywords: 0.0 #infoleak",
  "id" : 377200339004297216,
  "created_at" : "2013-09-09 22:42:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MsxOZNtFo9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dG2HWZpB",
      "display_url" : "pastebin.com\/raw.php?i=dG2H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377196810978091009",
  "text" : "http:\/\/t.co\/MsxOZNtFo9 Emails: 94 Keywords: -0.03 #infoleak",
  "id" : 377196810978091009,
  "created_at" : "2013-09-09 22:28:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BHedbNuRaT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CTNS5Lsj",
      "display_url" : "pastebin.com\/raw.php?i=CTNS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377187647761821696",
  "text" : "http:\/\/t.co\/BHedbNuRaT Emails: 1239 Keywords: 0.11 #infoleak",
  "id" : 377187647761821696,
  "created_at" : "2013-09-09 21:51:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j34Me7zZBJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X12MXYqV",
      "display_url" : "pastebin.com\/raw.php?i=X12M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377187582997585920",
  "text" : "http:\/\/t.co\/j34Me7zZBJ Emails: 20 Keywords: 0.08 #infoleak",
  "id" : 377187582997585920,
  "created_at" : "2013-09-09 21:51:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NbUMNZ60Bo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wH3Cik1U",
      "display_url" : "pastebin.com\/raw.php?i=wH3C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377186066010497024",
  "text" : "http:\/\/t.co\/NbUMNZ60Bo Hashes: 69 Keywords: 0.11 #infoleak",
  "id" : 377186066010497024,
  "created_at" : "2013-09-09 21:45:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oJ0zKxaL3Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zs0RmMCA",
      "display_url" : "pastebin.com\/raw.php?i=Zs0R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377171468762615808",
  "text" : "http:\/\/t.co\/oJ0zKxaL3Z Possible cisco configuration #infoleak",
  "id" : 377171468762615808,
  "created_at" : "2013-09-09 20:47:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rmoM9L8KQ8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NYSN0y1E",
      "display_url" : "pastebin.com\/raw.php?i=NYSN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377161980119117824",
  "text" : "http:\/\/t.co\/rmoM9L8KQ8 Emails: 70 Keywords: 0.22 #infoleak",
  "id" : 377161980119117824,
  "created_at" : "2013-09-09 20:09:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VSRtAzwsNM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vQP6t5d6",
      "display_url" : "pastebin.com\/raw.php?i=vQP6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377160781059878912",
  "text" : "http:\/\/t.co\/VSRtAzwsNM Emails: 1248 Keywords: 0.33 #infoleak",
  "id" : 377160781059878912,
  "created_at" : "2013-09-09 20:05:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tjbJTXx9Gy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CpYmdcvc",
      "display_url" : "pastebin.com\/raw.php?i=CpYm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377113314607644672",
  "text" : "http:\/\/t.co\/tjbJTXx9Gy Possible cisco configuration #infoleak",
  "id" : 377113314607644672,
  "created_at" : "2013-09-09 16:56:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HDcaPUN661",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aujnC5iy",
      "display_url" : "pastebin.com\/raw.php?i=aujn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377111855526715392",
  "text" : "http:\/\/t.co\/HDcaPUN661 Hashes: 30 Keywords: 0.33 #infoleak",
  "id" : 377111855526715392,
  "created_at" : "2013-09-09 16:50:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/up9bW8xOqn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9rWQH6ZE",
      "display_url" : "pastebin.com\/raw.php?i=9rWQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377100578234458113",
  "text" : "http:\/\/t.co\/up9bW8xOqn Emails: 6 Keywords: 0.66 #infoleak",
  "id" : 377100578234458113,
  "created_at" : "2013-09-09 16:05:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AhOym0EyxY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bjcZn6hn",
      "display_url" : "pastebin.com\/raw.php?i=bjcZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377099106100850690",
  "text" : "http:\/\/t.co\/AhOym0EyxY Emails: 1248 Keywords: 0.33 #infoleak",
  "id" : 377099106100850690,
  "created_at" : "2013-09-09 16:00:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HWNGHVQYga",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UyJiddmp",
      "display_url" : "pastebin.com\/raw.php?i=UyJi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377097775755706368",
  "text" : "http:\/\/t.co\/HWNGHVQYga Emails: 1429 Keywords: 0.11 #infoleak",
  "id" : 377097775755706368,
  "created_at" : "2013-09-09 15:54:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gIvChQxsD0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S3wWZWTw",
      "display_url" : "pastebin.com\/raw.php?i=S3wW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377091192552300544",
  "text" : "http:\/\/t.co\/gIvChQxsD0 Hashes: 1 Keywords: 0.55 #infoleak",
  "id" : 377091192552300544,
  "created_at" : "2013-09-09 15:28:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4HN8x201um",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=saQZQENN",
      "display_url" : "pastebin.com\/raw.php?i=saQZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377079078576082944",
  "text" : "http:\/\/t.co\/4HN8x201um Possible cisco configuration #infoleak",
  "id" : 377079078576082944,
  "created_at" : "2013-09-09 14:40:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bwSPcLQqoc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u02pBYzk",
      "display_url" : "pastebin.com\/raw.php?i=u02p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377066706385911809",
  "text" : "http:\/\/t.co\/bwSPcLQqoc Emails: 313 Keywords: 0.0 #infoleak",
  "id" : 377066706385911809,
  "created_at" : "2013-09-09 13:51:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zc9oqH1S8z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YDtdUf7T",
      "display_url" : "pastebin.com\/raw.php?i=YDtd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377056373864820736",
  "text" : "http:\/\/t.co\/Zc9oqH1S8z Emails: 42 Keywords: -0.17 #infoleak",
  "id" : 377056373864820736,
  "created_at" : "2013-09-09 13:10:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ga4eJvh0m9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yaitE8Xd",
      "display_url" : "pastebin.com\/raw.php?i=yait\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377043426065145856",
  "text" : "http:\/\/t.co\/ga4eJvh0m9 Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 377043426065145856,
  "created_at" : "2013-09-09 12:18:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kk0S9YHXkv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uMFYMxcG",
      "display_url" : "pastebin.com\/raw.php?i=uMFY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377039713908948992",
  "text" : "http:\/\/t.co\/kk0S9YHXkv Emails: 40 Hashes: 38 E\/H: 1.05 Keywords: 0.22 #infoleak",
  "id" : 377039713908948992,
  "created_at" : "2013-09-09 12:04:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K6imjALS8i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zjpYP01J",
      "display_url" : "pastebin.com\/raw.php?i=zjpY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377029115875848192",
  "text" : "http:\/\/t.co\/K6imjALS8i Emails: 123 Keywords: 0.0 #infoleak",
  "id" : 377029115875848192,
  "created_at" : "2013-09-09 11:22:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HwAz0iOnKO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fKVhA3Su",
      "display_url" : "pastebin.com\/raw.php?i=fKVh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377024454959693824",
  "text" : "http:\/\/t.co\/HwAz0iOnKO Emails: 96 Keywords: 0.11 #infoleak",
  "id" : 377024454959693824,
  "created_at" : "2013-09-09 11:03:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x6kbjCzYjB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0UjhLTcC",
      "display_url" : "pastebin.com\/raw.php?i=0Ujh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376848077895647232",
  "text" : "http:\/\/t.co\/x6kbjCzYjB Emails: 331 Keywords: 0.08 #infoleak",
  "id" : 376848077895647232,
  "created_at" : "2013-09-08 23:22:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9SHcUBHgm9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u06MLThG",
      "display_url" : "pastebin.com\/raw.php?i=u06M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376845057799626752",
  "text" : "http:\/\/t.co\/9SHcUBHgm9 Emails: 1802 Keywords: 0.0 #infoleak",
  "id" : 376845057799626752,
  "created_at" : "2013-09-08 23:10:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/azuaoC64L0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CD5eP1i8",
      "display_url" : "pastebin.com\/raw.php?i=CD5e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376841025513222144",
  "text" : "http:\/\/t.co\/azuaoC64L0 Emails: 20 Keywords: -0.03 #infoleak",
  "id" : 376841025513222144,
  "created_at" : "2013-09-08 22:54:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xkQRlMzafV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cpBBZZ1q",
      "display_url" : "pastebin.com\/raw.php?i=cpBB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376835033945747456",
  "text" : "http:\/\/t.co\/xkQRlMzafV Emails: 119 Keywords: 0.19 #infoleak",
  "id" : 376835033945747456,
  "created_at" : "2013-09-08 22:30:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pebagkPS5s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vc0TEjUS",
      "display_url" : "pastebin.com\/raw.php?i=vc0T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376832410576367617",
  "text" : "http:\/\/t.co\/pebagkPS5s Emails: 24 Keywords: -0.03 #infoleak",
  "id" : 376832410576367617,
  "created_at" : "2013-09-08 22:20:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D6L5KZ5pPa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JFFY4RfB",
      "display_url" : "pastebin.com\/raw.php?i=JFFY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376819979993108480",
  "text" : "http:\/\/t.co\/D6L5KZ5pPa Emails: 96 Keywords: 0.0 #infoleak",
  "id" : 376819979993108480,
  "created_at" : "2013-09-08 21:30:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A3z3LLYr3H",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8jVrsN0Z",
      "display_url" : "pastebin.com\/raw.php?i=8jVr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376811716996116480",
  "text" : "http:\/\/t.co\/A3z3LLYr3H Found possible Google API key(s) #infoleak",
  "id" : 376811716996116480,
  "created_at" : "2013-09-08 20:58:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iG1Pg0ky4c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5c6rGN3e",
      "display_url" : "pastebin.com\/raw.php?i=5c6r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376810151828664320",
  "text" : "http:\/\/t.co\/iG1Pg0ky4c Emails: 108 Keywords: 0.11 #infoleak",
  "id" : 376810151828664320,
  "created_at" : "2013-09-08 20:51:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SqBYTC1vRg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PJVMiCDd",
      "display_url" : "pastebin.com\/raw.php?i=PJVM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376809953433890817",
  "text" : "http:\/\/t.co\/SqBYTC1vRg Found possible Google API key(s) #infoleak",
  "id" : 376809953433890817,
  "created_at" : "2013-09-08 20:51:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C1kGPRuwfb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6RwNUbNe",
      "display_url" : "pastebin.com\/raw.php?i=6RwN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376801821961908224",
  "text" : "http:\/\/t.co\/C1kGPRuwfb Emails: 21 Keywords: -0.14 #infoleak",
  "id" : 376801821961908224,
  "created_at" : "2013-09-08 20:18:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MsAAvnga55",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tKYTRGas",
      "display_url" : "pastebin.com\/raw.php?i=tKYT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376795774866059264",
  "text" : "http:\/\/t.co\/MsAAvnga55 Emails: 1004 Hashes: 801 E\/H: 1.25 Keywords: 0.19 #infoleak",
  "id" : 376795774866059264,
  "created_at" : "2013-09-08 19:54:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yrvNuWMlr0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=07BGnVmp",
      "display_url" : "pastebin.com\/raw.php?i=07BG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376787606077317120",
  "text" : "http:\/\/t.co\/yrvNuWMlr0 Emails: 109 Keywords: 0.33 #infoleak",
  "id" : 376787606077317120,
  "created_at" : "2013-09-08 19:22:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SCCZYbYwD8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GqpNLfvg",
      "display_url" : "pastebin.com\/raw.php?i=GqpN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376781582301818881",
  "text" : "http:\/\/t.co\/SCCZYbYwD8 Emails: 188 Keywords: 0.19 #infoleak",
  "id" : 376781582301818881,
  "created_at" : "2013-09-08 18:58:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DWt8SLSyzR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B0jRutnV",
      "display_url" : "pastebin.com\/raw.php?i=B0jR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376755165950259201",
  "text" : "http:\/\/t.co\/DWt8SLSyzR Hashes: 7 Keywords: 0.55 #infoleak",
  "id" : 376755165950259201,
  "created_at" : "2013-09-08 17:13:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1isMBZrTxR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iYnrS2zc",
      "display_url" : "pastebin.com\/raw.php?i=iYnr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376752489212542977",
  "text" : "http:\/\/t.co\/1isMBZrTxR Emails: 662 Keywords: 0.0 #infoleak",
  "id" : 376752489212542977,
  "created_at" : "2013-09-08 17:02:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EdsEwH4Uur",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZrUJtUC8",
      "display_url" : "pastebin.com\/raw.php?i=ZrUJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376747999612768256",
  "text" : "http:\/\/t.co\/EdsEwH4Uur Emails: 82 Keywords: 0.44 #infoleak",
  "id" : 376747999612768256,
  "created_at" : "2013-09-08 16:44:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ndzxQetA0C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qt8mE30u",
      "display_url" : "pastebin.com\/raw.php?i=qt8m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376747426943479808",
  "text" : "http:\/\/t.co\/ndzxQetA0C Emails: 34 Keywords: 0.33 #infoleak",
  "id" : 376747426943479808,
  "created_at" : "2013-09-08 16:42:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uAUNrestHP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ddAm6b50",
      "display_url" : "pastebin.com\/raw.php?i=ddAm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376743976113418240",
  "text" : "http:\/\/t.co\/uAUNrestHP Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 376743976113418240,
  "created_at" : "2013-09-08 16:28:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pY9oQkfNwo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PJH4tFLA",
      "display_url" : "pastebin.com\/raw.php?i=PJH4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376732492742402049",
  "text" : "http:\/\/t.co\/pY9oQkfNwo Emails: 77 Keywords: -0.17 #infoleak",
  "id" : 376732492742402049,
  "created_at" : "2013-09-08 15:43:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LSp4rcsFIs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k0WA7Ccc",
      "display_url" : "pastebin.com\/raw.php?i=k0WA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376731486004584448",
  "text" : "http:\/\/t.co\/LSp4rcsFIs Possible cisco configuration #infoleak",
  "id" : 376731486004584448,
  "created_at" : "2013-09-08 15:39:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U46enSmQKl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hhTRLyPF",
      "display_url" : "pastebin.com\/raw.php?i=hhTR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376688443541053440",
  "text" : "http:\/\/t.co\/U46enSmQKl Found possible Google API key(s) #infoleak",
  "id" : 376688443541053440,
  "created_at" : "2013-09-08 12:48:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UWWkVAdVgD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4dyz4ACg",
      "display_url" : "pastebin.com\/raw.php?i=4dyz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376683367749521408",
  "text" : "http:\/\/t.co\/UWWkVAdVgD Emails: 3 Hashes: 1 E\/H: 3.0 Keywords: 0.55 #infoleak",
  "id" : 376683367749521408,
  "created_at" : "2013-09-08 12:28:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JT5StbAEr4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U7Z0jtXV",
      "display_url" : "pastebin.com\/raw.php?i=U7Z0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376682138831040512",
  "text" : "http:\/\/t.co\/JT5StbAEr4 Emails: 1258 Keywords: 0.11 #infoleak",
  "id" : 376682138831040512,
  "created_at" : "2013-09-08 12:23:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m68azvCunE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wu9twU1Y",
      "display_url" : "pastebin.com\/raw.php?i=wu9t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376677712225525760",
  "text" : "http:\/\/t.co\/m68azvCunE Emails: 2843 Keywords: 0.44 #infoleak",
  "id" : 376677712225525760,
  "created_at" : "2013-09-08 12:05:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oig0NeEdwI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LfWxAxFy",
      "display_url" : "pastebin.com\/raw.php?i=LfWx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376594787396120576",
  "text" : "http:\/\/t.co\/oig0NeEdwI Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 376594787396120576,
  "created_at" : "2013-09-08 06:36:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mAG9pVp27p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nGSXRF8F",
      "display_url" : "pastebin.com\/raw.php?i=nGSX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376588917933219840",
  "text" : "http:\/\/t.co\/mAG9pVp27p Found possible Google API key(s) #infoleak",
  "id" : 376588917933219840,
  "created_at" : "2013-09-08 06:12:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2gvCcmyi4z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dqx9jk17",
      "display_url" : "pastebin.com\/raw.php?i=Dqx9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376586798408814592",
  "text" : "http:\/\/t.co\/2gvCcmyi4z Emails: 582 Keywords: -0.03 #infoleak",
  "id" : 376586798408814592,
  "created_at" : "2013-09-08 06:04:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gojxfqa60z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hRnSywLg",
      "display_url" : "pastebin.com\/raw.php?i=hRnS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376582389218037760",
  "text" : "http:\/\/t.co\/gojxfqa60z Emails: 28 Hashes: 1 E\/H: 28.0 Keywords: 0.11 #infoleak",
  "id" : 376582389218037760,
  "created_at" : "2013-09-08 05:46:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ROzSIT4Tal",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=paPnZ3uh",
      "display_url" : "pastebin.com\/raw.php?i=paPn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376580210574905344",
  "text" : "http:\/\/t.co\/ROzSIT4Tal Emails: 1032 Keywords: 0.11 #infoleak",
  "id" : 376580210574905344,
  "created_at" : "2013-09-08 05:38:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9aYN0NbzNQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PSgqZAB1",
      "display_url" : "pastebin.com\/raw.php?i=PSgq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376573362958372864",
  "text" : "http:\/\/t.co\/9aYN0NbzNQ Emails: 15062 Keywords: 0.19 #infoleak",
  "id" : 376573362958372864,
  "created_at" : "2013-09-08 05:11:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2RVmNCsSe5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BHrrStiN",
      "display_url" : "pastebin.com\/raw.php?i=BHrr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376573000260149248",
  "text" : "http:\/\/t.co\/2RVmNCsSe5 Possible cisco configuration #infoleak",
  "id" : 376573000260149248,
  "created_at" : "2013-09-08 05:09:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1fkRv8PHjw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m4gXcz8G",
      "display_url" : "pastebin.com\/raw.php?i=m4gX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376508136158294017",
  "text" : "http:\/\/t.co\/1fkRv8PHjw Emails: 91 Keywords: 0.22 #infoleak",
  "id" : 376508136158294017,
  "created_at" : "2013-09-08 00:51:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qFE2CMNL2A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GvAmPhbn",
      "display_url" : "pastebin.com\/raw.php?i=GvAm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376502703754448897",
  "text" : "http:\/\/t.co\/qFE2CMNL2A Emails: 711 Hashes: 38 E\/H: 18.71 Keywords: 0.08 #infoleak",
  "id" : 376502703754448897,
  "created_at" : "2013-09-08 00:30:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R0RkWJCoWi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=848u99Ax",
      "display_url" : "pastebin.com\/raw.php?i=848u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376494881549479936",
  "text" : "http:\/\/t.co\/R0RkWJCoWi Emails: 146 Keywords: 0.11 #infoleak",
  "id" : 376494881549479936,
  "created_at" : "2013-09-07 23:59:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fbi4lWqvIx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JZUN2LAv",
      "display_url" : "pastebin.com\/raw.php?i=JZUN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376489792793374720",
  "text" : "http:\/\/t.co\/fbi4lWqvIx Emails: 27 Keywords: -0.03 #infoleak",
  "id" : 376489792793374720,
  "created_at" : "2013-09-07 23:38:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kszDHeMln0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jNdgHJUq",
      "display_url" : "pastebin.com\/raw.php?i=jNdg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376481677339418624",
  "text" : "http:\/\/t.co\/kszDHeMln0 Emails: 72 Hashes: 102 E\/H: 0.71 Keywords: 0.66 #infoleak",
  "id" : 376481677339418624,
  "created_at" : "2013-09-07 23:06:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8VWWSlEccF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0xVJZ93h",
      "display_url" : "pastebin.com\/raw.php?i=0xVJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376477777374892032",
  "text" : "http:\/\/t.co\/8VWWSlEccF Emails: 59 Keywords: 0.11 #infoleak",
  "id" : 376477777374892032,
  "created_at" : "2013-09-07 22:51:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XOxCjkPfJK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dvimfaLa",
      "display_url" : "pastebin.com\/raw.php?i=dvim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376473849161732096",
  "text" : "http:\/\/t.co\/XOxCjkPfJK Emails: 54 Keywords: -0.14 #infoleak",
  "id" : 376473849161732096,
  "created_at" : "2013-09-07 22:35:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KY5w6tMNY4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eiurUzN3",
      "display_url" : "pastebin.com\/raw.php?i=eiur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376463120996134912",
  "text" : "http:\/\/t.co\/KY5w6tMNY4 Keywords: 0.66 #infoleak",
  "id" : 376463120996134912,
  "created_at" : "2013-09-07 21:52:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LvRYtZywhz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H8k0XTmr",
      "display_url" : "pastebin.com\/raw.php?i=H8k0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376460205589942272",
  "text" : "http:\/\/t.co\/LvRYtZywhz Emails: 45 Keywords: 0.33 #infoleak",
  "id" : 376460205589942272,
  "created_at" : "2013-09-07 21:41:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oMMdqBhflw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LCS9J7Gm",
      "display_url" : "pastebin.com\/raw.php?i=LCS9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376458321542123520",
  "text" : "http:\/\/t.co\/oMMdqBhflw Emails: 21 Keywords: 0.11 #infoleak",
  "id" : 376458321542123520,
  "created_at" : "2013-09-07 21:33:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W63FP94gW0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9UDY41Ns",
      "display_url" : "pastebin.com\/raw.php?i=9UDY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376456111613685761",
  "text" : "http:\/\/t.co\/W63FP94gW0 Hashes: 204 Keywords: 0.33 #infoleak",
  "id" : 376456111613685761,
  "created_at" : "2013-09-07 21:25:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LxdVOIRcH2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hSxT8ENb",
      "display_url" : "pastebin.com\/raw.php?i=hSxT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376446456497860608",
  "text" : "http:\/\/t.co\/LxdVOIRcH2 Emails: 26 Keywords: 0.44 #infoleak",
  "id" : 376446456497860608,
  "created_at" : "2013-09-07 20:46:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kLG2v6tdoQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GxBCcNRj",
      "display_url" : "pastebin.com\/raw.php?i=GxBC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376445298463080448",
  "text" : "http:\/\/t.co\/kLG2v6tdoQ Hashes: 149 Keywords: 0.0 #infoleak",
  "id" : 376445298463080448,
  "created_at" : "2013-09-07 20:42:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UWpgOUmKAe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=12LEcMx4",
      "display_url" : "pastebin.com\/raw.php?i=12LE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376442984008384513",
  "text" : "http:\/\/t.co\/UWpgOUmKAe Emails: 94 Hashes: 90 E\/H: 1.04 Keywords: 0.44 #infoleak",
  "id" : 376442984008384513,
  "created_at" : "2013-09-07 20:32:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rHDqJO6cM4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PzuvV7Gf",
      "display_url" : "pastebin.com\/raw.php?i=Pzuv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376432431579934720",
  "text" : "http:\/\/t.co\/rHDqJO6cM4 Hashes: 30 Keywords: 0.44 #infoleak",
  "id" : 376432431579934720,
  "created_at" : "2013-09-07 19:51:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yO6y4K26QU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4TizQewe",
      "display_url" : "pastebin.com\/raw.php?i=4Tiz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376429317003018240",
  "text" : "http:\/\/t.co\/yO6y4K26QU Hashes: 8 Keywords: 0.77 #infoleak",
  "id" : 376429317003018240,
  "created_at" : "2013-09-07 19:38:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ekSRtwjSKM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4Rd6qq3D",
      "display_url" : "pastebin.com\/raw.php?i=4Rd6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376427205191942144",
  "text" : "http:\/\/t.co\/ekSRtwjSKM Emails: 57 Keywords: 0.22 #infoleak",
  "id" : 376427205191942144,
  "created_at" : "2013-09-07 19:30:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zJACrrmrOs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7FRGw3ip",
      "display_url" : "pastebin.com\/raw.php?i=7FRG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376419045446148096",
  "text" : "http:\/\/t.co\/zJACrrmrOs Keywords: 0.55 #infoleak",
  "id" : 376419045446148096,
  "created_at" : "2013-09-07 18:57:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yiSyZyMECf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GEMcFHYU",
      "display_url" : "pastebin.com\/raw.php?i=GEMc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376417885804969984",
  "text" : "http:\/\/t.co\/yiSyZyMECf Emails: 60 Keywords: 0.11 #infoleak",
  "id" : 376417885804969984,
  "created_at" : "2013-09-07 18:53:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RXz5IBcZUd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8djpjQTC",
      "display_url" : "pastebin.com\/raw.php?i=8djp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376414103067049984",
  "text" : "http:\/\/t.co\/RXz5IBcZUd Found possible Google API key(s) #infoleak",
  "id" : 376414103067049984,
  "created_at" : "2013-09-07 18:38:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/52cnKQkGKI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MS1mCCvQ",
      "display_url" : "pastebin.com\/raw.php?i=MS1m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376412243606249473",
  "text" : "http:\/\/t.co\/52cnKQkGKI Found possible Google API key(s) #infoleak",
  "id" : 376412243606249473,
  "created_at" : "2013-09-07 18:30:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QgbB8SH5cn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xttAurMq",
      "display_url" : "pastebin.com\/raw.php?i=xttA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376410113495400448",
  "text" : "http:\/\/t.co\/QgbB8SH5cn Emails: 33 Hashes: 33 E\/H: 1.0 Keywords: 0.44 #infoleak",
  "id" : 376410113495400448,
  "created_at" : "2013-09-07 18:22:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5kJieanYLS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zgv138yZ",
      "display_url" : "pastebin.com\/raw.php?i=zgv1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376403302352568320",
  "text" : "http:\/\/t.co\/5kJieanYLS Keywords: 0.66 #infoleak",
  "id" : 376403302352568320,
  "created_at" : "2013-09-07 17:55:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o0DcpU1OT0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q7iXaAkr",
      "display_url" : "pastebin.com\/raw.php?i=q7iX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376402814542426112",
  "text" : "http:\/\/t.co\/o0DcpU1OT0 Hashes: 42 Keywords: 0.08 #infoleak",
  "id" : 376402814542426112,
  "created_at" : "2013-09-07 17:53:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cgvyBnLY2J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZgyVMtPi",
      "display_url" : "pastebin.com\/raw.php?i=ZgyV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376388005943996416",
  "text" : "http:\/\/t.co\/cgvyBnLY2J Keywords: 0.66 #infoleak",
  "id" : 376388005943996416,
  "created_at" : "2013-09-07 16:54:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BM6afB2L5a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yjM8Ynus",
      "display_url" : "pastebin.com\/raw.php?i=yjM8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376385740973690880",
  "text" : "http:\/\/t.co\/BM6afB2L5a Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 376385740973690880,
  "created_at" : "2013-09-07 16:45:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tx2OP71oLg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f5K2tLfD",
      "display_url" : "pastebin.com\/raw.php?i=f5K2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376384791278415872",
  "text" : "http:\/\/t.co\/Tx2OP71oLg Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 376384791278415872,
  "created_at" : "2013-09-07 16:41:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kOPQlO3uSl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rkhnKzM2",
      "display_url" : "pastebin.com\/raw.php?i=rkhn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376347009113792512",
  "text" : "http:\/\/t.co\/kOPQlO3uSl Found possible Google API key(s) #infoleak",
  "id" : 376347009113792512,
  "created_at" : "2013-09-07 14:11:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CCLcnuJJE6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FvJMFQxe",
      "display_url" : "pastebin.com\/raw.php?i=FvJM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376342434885541889",
  "text" : "http:\/\/t.co\/CCLcnuJJE6 Emails: 58 Hashes: 1 E\/H: 58.0 Keywords: 0.55 #infoleak",
  "id" : 376342434885541889,
  "created_at" : "2013-09-07 13:53:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wLoqmaKEGt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qXX7z746",
      "display_url" : "pastebin.com\/raw.php?i=qXX7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376334179836760064",
  "text" : "http:\/\/t.co\/wLoqmaKEGt Hashes: 202 Keywords: 0.0 #infoleak",
  "id" : 376334179836760064,
  "created_at" : "2013-09-07 13:20:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RJ7KBHPosJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2yid9pBU",
      "display_url" : "pastebin.com\/raw.php?i=2yid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376318674992250881",
  "text" : "http:\/\/t.co\/RJ7KBHPosJ Keywords: 0.55 #infoleak",
  "id" : 376318674992250881,
  "created_at" : "2013-09-07 12:18:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nplUsFe0MO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q4UWZ3gh",
      "display_url" : "pastebin.com\/raw.php?i=Q4UW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376318315519438848",
  "text" : "http:\/\/t.co\/nplUsFe0MO Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 376318315519438848,
  "created_at" : "2013-09-07 12:17:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QQLo3ra7Ok",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zDDpvTU3",
      "display_url" : "pastebin.com\/raw.php?i=zDDp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376315321201590273",
  "text" : "http:\/\/t.co\/QQLo3ra7Ok Emails: 414 Keywords: 0.33 #infoleak",
  "id" : 376315321201590273,
  "created_at" : "2013-09-07 12:05:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ly6M1khU4g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zrSyRKs3",
      "display_url" : "pastebin.com\/raw.php?i=zrSy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376296675452538880",
  "text" : "http:\/\/t.co\/ly6M1khU4g Found possible Google API key(s) #infoleak",
  "id" : 376296675452538880,
  "created_at" : "2013-09-07 10:51:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wgY9MhOJKU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1tsxGwcU",
      "display_url" : "pastebin.com\/raw.php?i=1tsx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376291211717267456",
  "text" : "http:\/\/t.co\/wgY9MhOJKU Emails: 72 Hashes: 102 E\/H: 0.71 Keywords: 0.66 #infoleak",
  "id" : 376291211717267456,
  "created_at" : "2013-09-07 10:29:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VoWAFYroRJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U6i9FCz1",
      "display_url" : "pastebin.com\/raw.php?i=U6i9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376289940805406720",
  "text" : "http:\/\/t.co\/VoWAFYroRJ Emails: 72 Hashes: 102 E\/H: 0.71 Keywords: 0.66 #infoleak",
  "id" : 376289940805406720,
  "created_at" : "2013-09-07 10:24:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T0Up3bbhGq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yccCMCjF",
      "display_url" : "pastebin.com\/raw.php?i=yccC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376288673001517056",
  "text" : "http:\/\/t.co\/T0Up3bbhGq Possible cisco configuration #infoleak",
  "id" : 376288673001517056,
  "created_at" : "2013-09-07 10:19:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KaYRYdOOzt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cYU2fXkS",
      "display_url" : "pastebin.com\/raw.php?i=cYU2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376272366134775808",
  "text" : "http:\/\/t.co\/KaYRYdOOzt Emails: 536 Keywords: 0.11 #infoleak",
  "id" : 376272366134775808,
  "created_at" : "2013-09-07 09:14:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yz6UdUg5iB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1jzm6UKc",
      "display_url" : "pastebin.com\/raw.php?i=1jzm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376234598339854337",
  "text" : "http:\/\/t.co\/Yz6UdUg5iB Emails: 21 Keywords: 0.22 #infoleak",
  "id" : 376234598339854337,
  "created_at" : "2013-09-07 06:44:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yCNDOj7mpX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YgfGvjQn",
      "display_url" : "pastebin.com\/raw.php?i=YgfG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376227424679112705",
  "text" : "http:\/\/t.co\/yCNDOj7mpX Found possible Google API key(s) #infoleak",
  "id" : 376227424679112705,
  "created_at" : "2013-09-07 06:16:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cJ5imMQagk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pmmzvkkL",
      "display_url" : "pastebin.com\/raw.php?i=pmmz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376173777970663424",
  "text" : "http:\/\/t.co\/cJ5imMQagk Emails: 5241 Keywords: 0.22 #infoleak",
  "id" : 376173777970663424,
  "created_at" : "2013-09-07 02:43:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MjxwisPRk6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UudF7aVY",
      "display_url" : "pastebin.com\/raw.php?i=UudF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376167045022232576",
  "text" : "http:\/\/t.co\/MjxwisPRk6 Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 376167045022232576,
  "created_at" : "2013-09-07 02:16:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/knZ7yyqoR1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Sg0gn78i",
      "display_url" : "pastebin.com\/raw.php?i=Sg0g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376159092814774272",
  "text" : "http:\/\/t.co\/knZ7yyqoR1 Emails: 861 Keywords: 0.33 #infoleak",
  "id" : 376159092814774272,
  "created_at" : "2013-09-07 01:44:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RDbDGwU2zE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R3Lj5MXz",
      "display_url" : "pastebin.com\/raw.php?i=R3Lj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376128765115375616",
  "text" : "http:\/\/t.co\/RDbDGwU2zE Emails: 3814 Hashes: 3786 E\/H: 1.01 Keywords: 0.22 #infoleak",
  "id" : 376128765115375616,
  "created_at" : "2013-09-06 23:44:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/up8x8j5LyB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dUHWdeb4",
      "display_url" : "pastebin.com\/raw.php?i=dUHW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376034265353289729",
  "text" : "http:\/\/t.co\/up8x8j5LyB Hashes: 32 Keywords: 0.11 #infoleak",
  "id" : 376034265353289729,
  "created_at" : "2013-09-06 17:28:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h2PbmJqd8r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PXF52CQ5",
      "display_url" : "pastebin.com\/raw.php?i=PXF5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376030473505345536",
  "text" : "http:\/\/t.co\/h2PbmJqd8r Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 376030473505345536,
  "created_at" : "2013-09-06 17:13:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZVTBh5OnY0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SwFEWCNY",
      "display_url" : "pastebin.com\/raw.php?i=SwFE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376019198213779457",
  "text" : "http:\/\/t.co\/ZVTBh5OnY0 Emails: 1 Hashes: 42 E\/H: 0.02 Keywords: 0.11 #infoleak",
  "id" : 376019198213779457,
  "created_at" : "2013-09-06 16:28:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BSNgE5Uhch",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YFVqu8Pa",
      "display_url" : "pastebin.com\/raw.php?i=YFVq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376018793958350849",
  "text" : "http:\/\/t.co\/BSNgE5Uhch Emails: 1 Hashes: 42 E\/H: 0.02 Keywords: 0.0 #infoleak",
  "id" : 376018793958350849,
  "created_at" : "2013-09-06 16:27:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zk9E8E2h0x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EJz60spH",
      "display_url" : "pastebin.com\/raw.php?i=EJz6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376015258646618112",
  "text" : "http:\/\/t.co\/zk9E8E2h0x Emails: 748 Keywords: 0.0 #infoleak",
  "id" : 376015258646618112,
  "created_at" : "2013-09-06 16:13:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I9ub3VLJ1f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FHZPkUP0",
      "display_url" : "pastebin.com\/raw.php?i=FHZP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376011210602213376",
  "text" : "http:\/\/t.co\/I9ub3VLJ1f Emails: 113 Keywords: 0.0 #infoleak",
  "id" : 376011210602213376,
  "created_at" : "2013-09-06 15:57:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nO6DDM4ksa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=51DkbLq5",
      "display_url" : "pastebin.com\/raw.php?i=51Dk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376008565388881920",
  "text" : "http:\/\/t.co\/nO6DDM4ksa Keywords: 0.63 #infoleak",
  "id" : 376008565388881920,
  "created_at" : "2013-09-06 15:46:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HpTfJ64J98",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u3YVYaJh",
      "display_url" : "pastebin.com\/raw.php?i=u3YV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375965343413305344",
  "text" : "http:\/\/t.co\/HpTfJ64J98 Emails: 53 Keywords: 0.08 #infoleak",
  "id" : 375965343413305344,
  "created_at" : "2013-09-06 12:54:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CQ1TwHKc8t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tizWQMzu",
      "display_url" : "pastebin.com\/raw.php?i=tizW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375965144301322240",
  "text" : "http:\/\/t.co\/CQ1TwHKc8t Found possible Google API key(s) #infoleak",
  "id" : 375965144301322240,
  "created_at" : "2013-09-06 12:54:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JpcrsqQAp7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0M4x08SU",
      "display_url" : "pastebin.com\/raw.php?i=0M4x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375961199860396032",
  "text" : "http:\/\/t.co\/JpcrsqQAp7 Emails: 50 Keywords: 0.16 #infoleak",
  "id" : 375961199860396032,
  "created_at" : "2013-09-06 12:38:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z1V5EXsJQQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sVabyjni",
      "display_url" : "pastebin.com\/raw.php?i=sVab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375955222889132034",
  "text" : "http:\/\/t.co\/z1V5EXsJQQ Emails: 11505 Keywords: 0.44 #infoleak",
  "id" : 375955222889132034,
  "created_at" : "2013-09-06 12:14:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7lEgJilAFB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WUhrDQe2",
      "display_url" : "pastebin.com\/raw.php?i=WUhr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375947428165214208",
  "text" : "http:\/\/t.co\/7lEgJilAFB Found possible Google API key(s) #infoleak",
  "id" : 375947428165214208,
  "created_at" : "2013-09-06 11:43:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g0g45PBj4I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hd3xW8u1",
      "display_url" : "pastebin.com\/raw.php?i=Hd3x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375931917637394432",
  "text" : "http:\/\/t.co\/g0g45PBj4I Emails: 107 Hashes: 214 E\/H: 0.5 Keywords: 0.0 #infoleak",
  "id" : 375931917637394432,
  "created_at" : "2013-09-06 10:42:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c2zpkJjT5u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VDn50u8t",
      "display_url" : "pastebin.com\/raw.php?i=VDn5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375926398445039616",
  "text" : "http:\/\/t.co\/c2zpkJjT5u Emails: 40 Keywords: 0.0 #infoleak",
  "id" : 375926398445039616,
  "created_at" : "2013-09-06 10:20:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Cc1Y9cjnYq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eS6bt0NX",
      "display_url" : "pastebin.com\/raw.php?i=eS6b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375926372633284608",
  "text" : "http:\/\/t.co\/Cc1Y9cjnYq Emails: 11982 Keywords: 0.08 #infoleak",
  "id" : 375926372633284608,
  "created_at" : "2013-09-06 10:20:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BiVkz21yAb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w0U0Dn9k",
      "display_url" : "pastebin.com\/raw.php?i=w0U0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375924694760701953",
  "text" : "http:\/\/t.co\/BiVkz21yAb Hashes: 312 Keywords: 0.22 #infoleak",
  "id" : 375924694760701953,
  "created_at" : "2013-09-06 10:13:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g9lxvoQrFI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Pgy1a07a",
      "display_url" : "pastebin.com\/raw.php?i=Pgy1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375918572339347457",
  "text" : "http:\/\/t.co\/g9lxvoQrFI Found possible Google API key(s) #infoleak",
  "id" : 375918572339347457,
  "created_at" : "2013-09-06 09:49:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XBueL1oUF0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=APcimwYU",
      "display_url" : "pastebin.com\/raw.php?i=APci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375916587938631680",
  "text" : "http:\/\/t.co\/XBueL1oUF0 Emails: 82 Keywords: 0.0 #infoleak",
  "id" : 375916587938631680,
  "created_at" : "2013-09-06 09:41:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6ZM3618har",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GteFtuH7",
      "display_url" : "pastebin.com\/raw.php?i=GteF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375916486876856321",
  "text" : "http:\/\/t.co\/6ZM3618har Emails: 123 Keywords: 0.0 #infoleak",
  "id" : 375916486876856321,
  "created_at" : "2013-09-06 09:40:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0SzBkzzhqK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qY4ZjN2k",
      "display_url" : "pastebin.com\/raw.php?i=qY4Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375907121465802752",
  "text" : "http:\/\/t.co\/0SzBkzzhqK Found possible Google API key(s) #infoleak",
  "id" : 375907121465802752,
  "created_at" : "2013-09-06 09:03:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/auL8YF3S1W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZibPkS5a",
      "display_url" : "pastebin.com\/raw.php?i=ZibP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375901990414336000",
  "text" : "http:\/\/t.co\/auL8YF3S1W Hashes: 295 Keywords: 0.22 #infoleak",
  "id" : 375901990414336000,
  "created_at" : "2013-09-06 08:43:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oDnFOZTR31",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JXv0erNc",
      "display_url" : "pastebin.com\/raw.php?i=JXv0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375897675637338112",
  "text" : "http:\/\/t.co\/oDnFOZTR31 Found possible Google API key(s) #infoleak",
  "id" : 375897675637338112,
  "created_at" : "2013-09-06 08:26:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JJb6ijnBVf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gZ1A08F2",
      "display_url" : "pastebin.com\/raw.php?i=gZ1A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375867752939933696",
  "text" : "http:\/\/t.co\/JJb6ijnBVf Found possible Google API key(s) #infoleak",
  "id" : 375867752939933696,
  "created_at" : "2013-09-06 06:27:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7367Ryb243",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DZ8XNaQA",
      "display_url" : "pastebin.com\/raw.php?i=DZ8X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375857981843193856",
  "text" : "http:\/\/t.co\/7367Ryb243 Emails: 43 Keywords: -0.14 #infoleak",
  "id" : 375857981843193856,
  "created_at" : "2013-09-06 05:48:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MGn3OW5fWI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=itB7c4fm",
      "display_url" : "pastebin.com\/raw.php?i=itB7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375846695428317184",
  "text" : "http:\/\/t.co\/MGn3OW5fWI Keywords: 0.55 #infoleak",
  "id" : 375846695428317184,
  "created_at" : "2013-09-06 05:03:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9LSCxst6sG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dy5SRkCM",
      "display_url" : "pastebin.com\/raw.php?i=dy5S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375846569427611649",
  "text" : "http:\/\/t.co\/9LSCxst6sG Found possible Google API key(s) #infoleak",
  "id" : 375846569427611649,
  "created_at" : "2013-09-06 05:02:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k27hzLAcXI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dwf1UCSw",
      "display_url" : "pastebin.com\/raw.php?i=dwf1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375834513995087873",
  "text" : "http:\/\/t.co\/k27hzLAcXI Emails: 28 Keywords: -0.03 #infoleak",
  "id" : 375834513995087873,
  "created_at" : "2013-09-06 04:15:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/viGJXRLvbF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KRd5Nz1K",
      "display_url" : "pastebin.com\/raw.php?i=KRd5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375832981845204992",
  "text" : "http:\/\/t.co\/viGJXRLvbF Found possible Google API key(s) #infoleak",
  "id" : 375832981845204992,
  "created_at" : "2013-09-06 04:09:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sjrFIujOzq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P9V0C7Pu",
      "display_url" : "pastebin.com\/raw.php?i=P9V0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375796601135984640",
  "text" : "http:\/\/t.co\/sjrFIujOzq Emails: 67 Keywords: 0.33 #infoleak",
  "id" : 375796601135984640,
  "created_at" : "2013-09-06 01:44:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z4iEnr4eHc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ne63wUS8",
      "display_url" : "pastebin.com\/raw.php?i=ne63\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375783043203489792",
  "text" : "http:\/\/t.co\/z4iEnr4eHc Emails: 844 Keywords: 0.33 #infoleak",
  "id" : 375783043203489792,
  "created_at" : "2013-09-06 00:50:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ti0L5T4xog",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=auWswJuv",
      "display_url" : "pastebin.com\/raw.php?i=auWs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375780432005980160",
  "text" : "http:\/\/t.co\/ti0L5T4xog Hashes: 33 Keywords: 0.11 #infoleak",
  "id" : 375780432005980160,
  "created_at" : "2013-09-06 00:40:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ek7mBsHEwC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=22JdgxFG",
      "display_url" : "pastebin.com\/raw.php?i=22Jd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375775783538524160",
  "text" : "http:\/\/t.co\/ek7mBsHEwC Hashes: 37 Keywords: 0.22 #infoleak",
  "id" : 375775783538524160,
  "created_at" : "2013-09-06 00:21:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TxJkuVtHTM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A1DS26pv",
      "display_url" : "pastebin.com\/raw.php?i=A1DS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375766266989924354",
  "text" : "http:\/\/t.co\/TxJkuVtHTM Emails: 4111 Hashes: 4236 E\/H: 0.97 Keywords: 0.55 #infoleak",
  "id" : 375766266989924354,
  "created_at" : "2013-09-05 23:43:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B4gd52m2dv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V7t5DScV",
      "display_url" : "pastebin.com\/raw.php?i=V7t5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375765975859093504",
  "text" : "http:\/\/t.co\/B4gd52m2dv Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 375765975859093504,
  "created_at" : "2013-09-05 23:42:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kQaQNK9zWy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p4m0TWdB",
      "display_url" : "pastebin.com\/raw.php?i=p4m0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375746415529451521",
  "text" : "http:\/\/t.co\/kQaQNK9zWy Keywords: 0.66 #infoleak",
  "id" : 375746415529451521,
  "created_at" : "2013-09-05 22:25:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HSRZkWjqYQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cc1sJC7x",
      "display_url" : "pastebin.com\/raw.php?i=Cc1s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375732654454218752",
  "text" : "http:\/\/t.co\/HSRZkWjqYQ Found possible Google API key(s) #infoleak",
  "id" : 375732654454218752,
  "created_at" : "2013-09-05 21:30:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iT1usaFvxw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hg9aeHEd",
      "display_url" : "pastebin.com\/raw.php?i=Hg9a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375730424820936704",
  "text" : "http:\/\/t.co\/iT1usaFvxw Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 375730424820936704,
  "created_at" : "2013-09-05 21:21:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wNL75YodoJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YvxXTjFC",
      "display_url" : "pastebin.com\/raw.php?i=YvxX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375729747558268928",
  "text" : "http:\/\/t.co\/wNL75YodoJ Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 375729747558268928,
  "created_at" : "2013-09-05 21:18:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q111G7hKGs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f3trX3Cv",
      "display_url" : "pastebin.com\/raw.php?i=f3tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375716068100022272",
  "text" : "http:\/\/t.co\/Q111G7hKGs Emails: 3569 Keywords: 0.33 #infoleak",
  "id" : 375716068100022272,
  "created_at" : "2013-09-05 20:24:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eMqB34Iwct",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yeXBDQ3h",
      "display_url" : "pastebin.com\/raw.php?i=yeXB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375677918501810176",
  "text" : "http:\/\/t.co\/eMqB34Iwct Emails: 21 Keywords: -0.14 #infoleak",
  "id" : 375677918501810176,
  "created_at" : "2013-09-05 17:52:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aUN4eb4xkp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MuKhJUh9",
      "display_url" : "pastebin.com\/raw.php?i=MuKh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375677443421380608",
  "text" : "http:\/\/t.co\/aUN4eb4xkp Emails: 1719 Keywords: 0.11 #infoleak",
  "id" : 375677443421380608,
  "created_at" : "2013-09-05 17:50:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MmsgeIMQe3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dKqzFRg7",
      "display_url" : "pastebin.com\/raw.php?i=dKqz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375670380536422400",
  "text" : "http:\/\/t.co\/MmsgeIMQe3 Emails: 2 Hashes: 10 E\/H: 0.2 Keywords: 0.66 #infoleak",
  "id" : 375670380536422400,
  "created_at" : "2013-09-05 17:22:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zEwA4Mo9Zx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z3TNxh68",
      "display_url" : "pastebin.com\/raw.php?i=z3TN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375667237140439041",
  "text" : "http:\/\/t.co\/zEwA4Mo9Zx Emails: 2646 Keywords: 0.33 #infoleak",
  "id" : 375667237140439041,
  "created_at" : "2013-09-05 17:10:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hgupjrcqzs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dYd2kzpD",
      "display_url" : "pastebin.com\/raw.php?i=dYd2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375588454572122112",
  "text" : "http:\/\/t.co\/hgupjrcqzs Hashes: 61 Keywords: 0.33 #infoleak",
  "id" : 375588454572122112,
  "created_at" : "2013-09-05 11:57:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/419UiBrful",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9axFPKn6",
      "display_url" : "pastebin.com\/raw.php?i=9axF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375587826068234240",
  "text" : "http:\/\/t.co\/419UiBrful Hashes: 58 Keywords: 0.22 #infoleak",
  "id" : 375587826068234240,
  "created_at" : "2013-09-05 11:54:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ghxa9C0RGG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=edVL2Bkp",
      "display_url" : "pastebin.com\/raw.php?i=edVL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375510269960531968",
  "text" : "http:\/\/t.co\/Ghxa9C0RGG Found possible Google API key(s) #infoleak",
  "id" : 375510269960531968,
  "created_at" : "2013-09-05 06:46:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J6CeMFll2L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sFp2NKxL",
      "display_url" : "pastebin.com\/raw.php?i=sFp2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375508800238678016",
  "text" : "http:\/\/t.co\/J6CeMFll2L Possible cisco configuration #infoleak",
  "id" : 375508800238678016,
  "created_at" : "2013-09-05 06:40:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8dtVaRU21b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A20nDjBp",
      "display_url" : "pastebin.com\/raw.php?i=A20n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375508785206288384",
  "text" : "http:\/\/t.co\/8dtVaRU21b Emails: 189 Keywords: 0.19 #infoleak",
  "id" : 375508785206288384,
  "created_at" : "2013-09-05 06:40:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vvsM2lyrCO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vkCgAACr",
      "display_url" : "pastebin.com\/raw.php?i=vkCg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375505488269430786",
  "text" : "http:\/\/t.co\/vvsM2lyrCO Found possible Google API key(s) #infoleak",
  "id" : 375505488269430786,
  "created_at" : "2013-09-05 06:27:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yg4m07z49e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KvyZ6Dp5",
      "display_url" : "pastebin.com\/raw.php?i=KvyZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375501280157769728",
  "text" : "http:\/\/t.co\/Yg4m07z49e Emails: 198 Keywords: 0.3 #infoleak",
  "id" : 375501280157769728,
  "created_at" : "2013-09-05 06:10:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EDUfVaevN4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ta1Uxq0R",
      "display_url" : "pastebin.com\/raw.php?i=Ta1U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375483910974480384",
  "text" : "http:\/\/t.co\/EDUfVaevN4 Emails: 57 Keywords: -0.14 #infoleak",
  "id" : 375483910974480384,
  "created_at" : "2013-09-05 05:01:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wl3BlxEuX5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2sUzRbDW",
      "display_url" : "pastebin.com\/raw.php?i=2sUz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375480681150693376",
  "text" : "http:\/\/t.co\/Wl3BlxEuX5 Emails: 39 Keywords: 0.11 #infoleak",
  "id" : 375480681150693376,
  "created_at" : "2013-09-05 04:49:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rob8sJePnV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1PSNUBc4",
      "display_url" : "pastebin.com\/raw.php?i=1PSN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375478960970166272",
  "text" : "http:\/\/t.co\/rob8sJePnV Emails: 41 Hashes: 41 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 375478960970166272,
  "created_at" : "2013-09-05 04:42:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ME509a8lwo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VF7TPEaP",
      "display_url" : "pastebin.com\/raw.php?i=VF7T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375470082362580992",
  "text" : "http:\/\/t.co\/ME509a8lwo Emails: 268 Keywords: 0.11 #infoleak",
  "id" : 375470082362580992,
  "created_at" : "2013-09-05 04:06:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZKSYiFle6r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gb3g0JbH",
      "display_url" : "pastebin.com\/raw.php?i=gb3g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375467245775769600",
  "text" : "http:\/\/t.co\/ZKSYiFle6r Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 375467245775769600,
  "created_at" : "2013-09-05 03:55:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eFxgyjsCxW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nE18gCNw",
      "display_url" : "pastebin.com\/raw.php?i=nE18\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375416763090874368",
  "text" : "http:\/\/t.co\/eFxgyjsCxW Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 375416763090874368,
  "created_at" : "2013-09-05 00:35:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mBr0vqcjkS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XScJzyRE",
      "display_url" : "pastebin.com\/raw.php?i=XScJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375411866958192640",
  "text" : "http:\/\/t.co\/mBr0vqcjkS Emails: 111 Hashes: 129 E\/H: 0.86 Keywords: 0.08 #infoleak",
  "id" : 375411866958192640,
  "created_at" : "2013-09-05 00:15:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KFLo197O5i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yYdcTyPG",
      "display_url" : "pastebin.com\/raw.php?i=yYdc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375411064265256960",
  "text" : "http:\/\/t.co\/KFLo197O5i Emails: 428 Keywords: 0.08 #infoleak",
  "id" : 375411064265256960,
  "created_at" : "2013-09-05 00:12:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/waYHsAx9gW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=paAE5Rjp",
      "display_url" : "pastebin.com\/raw.php?i=paAE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375410079672987648",
  "text" : "http:\/\/t.co\/waYHsAx9gW Emails: 340 Hashes: 359 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 375410079672987648,
  "created_at" : "2013-09-05 00:08:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UogSSAfDhY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v8Qqed94",
      "display_url" : "pastebin.com\/raw.php?i=v8Qq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375405297746976768",
  "text" : "http:\/\/t.co\/UogSSAfDhY Emails: 23 Keywords: 0.33 #infoleak",
  "id" : 375405297746976768,
  "created_at" : "2013-09-04 23:49:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xqmbKYUyzc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=98yEhvvy",
      "display_url" : "pastebin.com\/raw.php?i=98yE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375396071112851458",
  "text" : "http:\/\/t.co\/xqmbKYUyzc Keywords: 0.88 #infoleak",
  "id" : 375396071112851458,
  "created_at" : "2013-09-04 23:12:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8ZaRMzB5zX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=36Zwpah2",
      "display_url" : "pastebin.com\/raw.php?i=36Zw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375387754646888448",
  "text" : "http:\/\/t.co\/8ZaRMzB5zX Emails: 3 Hashes: 35 E\/H: 0.09 Keywords: 0.27 #infoleak",
  "id" : 375387754646888448,
  "created_at" : "2013-09-04 22:39:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FZlF1ft8Sv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6REeyCDJ",
      "display_url" : "pastebin.com\/raw.php?i=6REe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375380872913879042",
  "text" : "http:\/\/t.co\/FZlF1ft8Sv Hashes: 42 Keywords: -0.03 #infoleak",
  "id" : 375380872913879042,
  "created_at" : "2013-09-04 22:12:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xhMkxUh4mK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7FufZTEh",
      "display_url" : "pastebin.com\/raw.php?i=7Fuf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375380317579649024",
  "text" : "http:\/\/t.co\/xhMkxUh4mK Keywords: 0.66 #infoleak",
  "id" : 375380317579649024,
  "created_at" : "2013-09-04 22:10:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tgUWOGb0TH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Exg7tN2p",
      "display_url" : "pastebin.com\/raw.php?i=Exg7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375375437985112064",
  "text" : "http:\/\/t.co\/tgUWOGb0TH Emails: 49 Keywords: -0.14 #infoleak",
  "id" : 375375437985112064,
  "created_at" : "2013-09-04 21:50:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UL1XMCoCzc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y6Jgcm8c",
      "display_url" : "pastebin.com\/raw.php?i=Y6Jg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375374869342339073",
  "text" : "http:\/\/t.co\/UL1XMCoCzc Emails: 25 Keywords: -0.14 #infoleak",
  "id" : 375374869342339073,
  "created_at" : "2013-09-04 21:48:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3gotZjvsxl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K1pNHRif",
      "display_url" : "pastebin.com\/raw.php?i=K1pN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375370223232110592",
  "text" : "http:\/\/t.co\/3gotZjvsxl Possible cisco configuration #infoleak",
  "id" : 375370223232110592,
  "created_at" : "2013-09-04 21:30:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m7qxjGwjMw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2UeDc3Zd",
      "display_url" : "pastebin.com\/raw.php?i=2UeD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375369516764524544",
  "text" : "http:\/\/t.co\/m7qxjGwjMw Possible cisco configuration #infoleak",
  "id" : 375369516764524544,
  "created_at" : "2013-09-04 21:27:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mCmrzZkolZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rzzfH6iD",
      "display_url" : "pastebin.com\/raw.php?i=rzzf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375361662590525441",
  "text" : "http:\/\/t.co\/mCmrzZkolZ Emails: 21 Keywords: -0.03 #infoleak",
  "id" : 375361662590525441,
  "created_at" : "2013-09-04 20:56:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3fh976uEN1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J7djdhBE",
      "display_url" : "pastebin.com\/raw.php?i=J7dj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375348318848557056",
  "text" : "http:\/\/t.co\/3fh976uEN1 Keywords: 0.66 #infoleak",
  "id" : 375348318848557056,
  "created_at" : "2013-09-04 20:03:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Cp1mifGpnh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B0RixjnH",
      "display_url" : "pastebin.com\/raw.php?i=B0Ri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375348292403474432",
  "text" : "http:\/\/t.co\/Cp1mifGpnh Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 375348292403474432,
  "created_at" : "2013-09-04 20:03:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Th8BjDjuLb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FtdYR2qH",
      "display_url" : "pastebin.com\/raw.php?i=FtdY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375344318816333825",
  "text" : "http:\/\/t.co\/Th8BjDjuLb Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 375344318816333825,
  "created_at" : "2013-09-04 19:47:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RWQWjdru7l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mcfTaWqS",
      "display_url" : "pastebin.com\/raw.php?i=mcfT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375344178525245441",
  "text" : "http:\/\/t.co\/RWQWjdru7l Emails: 238 Keywords: 0.11 #infoleak",
  "id" : 375344178525245441,
  "created_at" : "2013-09-04 19:46:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PB1XfaQcjW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7jadFWWL",
      "display_url" : "pastebin.com\/raw.php?i=7jad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375343496300736512",
  "text" : "http:\/\/t.co\/PB1XfaQcjW Hashes: 282 Keywords: 0.11 #infoleak",
  "id" : 375343496300736512,
  "created_at" : "2013-09-04 19:43:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i2KwpkSv0J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MzWFBDjq",
      "display_url" : "pastebin.com\/raw.php?i=MzWF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375342845739012096",
  "text" : "http:\/\/t.co\/i2KwpkSv0J Possible cisco configuration #infoleak",
  "id" : 375342845739012096,
  "created_at" : "2013-09-04 19:41:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rE0t5QZ8kH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KhekD559",
      "display_url" : "pastebin.com\/raw.php?i=Khek\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375337054667673600",
  "text" : "http:\/\/t.co\/rE0t5QZ8kH Emails: 286 Keywords: 0.11 #infoleak",
  "id" : 375337054667673600,
  "created_at" : "2013-09-04 19:18:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9jO10NWYqX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fPiMH6hV",
      "display_url" : "pastebin.com\/raw.php?i=fPiM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375333314682318848",
  "text" : "http:\/\/t.co\/9jO10NWYqX Emails: 32 Hashes: 31 E\/H: 1.03 Keywords: 0.0 #infoleak",
  "id" : 375333314682318848,
  "created_at" : "2013-09-04 19:03:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wK2Jce63N3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7sE1DVZc",
      "display_url" : "pastebin.com\/raw.php?i=7sE1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375296124220735488",
  "text" : "http:\/\/t.co\/wK2Jce63N3 Emails: 506 Keywords: 0.0 #infoleak",
  "id" : 375296124220735488,
  "created_at" : "2013-09-04 16:35:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yTvghenEPT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=47v5ztmA",
      "display_url" : "pastebin.com\/raw.php?i=47v5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375282102570209280",
  "text" : "http:\/\/t.co\/yTvghenEPT Emails: 33 Keywords: 0.19 #infoleak",
  "id" : 375282102570209280,
  "created_at" : "2013-09-04 15:40:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fvnR67y9gN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6KXp3CTX",
      "display_url" : "pastebin.com\/raw.php?i=6KXp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375281826983444480",
  "text" : "http:\/\/t.co\/fvnR67y9gN Hashes: 38 Keywords: 0.08 #infoleak",
  "id" : 375281826983444480,
  "created_at" : "2013-09-04 15:38:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GyxKmlEMNg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CUwWTd4F",
      "display_url" : "pastebin.com\/raw.php?i=CUwW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375209745520394241",
  "text" : "http:\/\/t.co\/GyxKmlEMNg Hashes: 65 Keywords: 0.11 #infoleak",
  "id" : 375209745520394241,
  "created_at" : "2013-09-04 10:52:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xbyRqWMzDB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6RT1qMGL",
      "display_url" : "pastebin.com\/raw.php?i=6RT1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375207365701672960",
  "text" : "http:\/\/t.co\/xbyRqWMzDB Emails: 4 Hashes: 73 E\/H: 0.05 Keywords: 0.22 #infoleak",
  "id" : 375207365701672960,
  "created_at" : "2013-09-04 10:43:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JRWl4idy62",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SvgTJWh1",
      "display_url" : "pastebin.com\/raw.php?i=SvgT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375176741670502400",
  "text" : "http:\/\/t.co\/JRWl4idy62 Emails: 4994 Hashes: 4999 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 375176741670502400,
  "created_at" : "2013-09-04 08:41:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lAu7OOgRlb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zUEdBFep",
      "display_url" : "pastebin.com\/raw.php?i=zUEd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375168725256634368",
  "text" : "http:\/\/t.co\/lAu7OOgRlb Emails: 96 Hashes: 1 E\/H: 96.0 Keywords: 0.11 #infoleak",
  "id" : 375168725256634368,
  "created_at" : "2013-09-04 08:09:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OHL3lsMYfi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2XcUmdjg",
      "display_url" : "pastebin.com\/raw.php?i=2XcU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375166889837596672",
  "text" : "http:\/\/t.co\/OHL3lsMYfi Keywords: 0.55 #infoleak",
  "id" : 375166889837596672,
  "created_at" : "2013-09-04 08:02:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sJRvlDCC3c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WVuR8Mwp",
      "display_url" : "pastebin.com\/raw.php?i=WVuR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375155591099867136",
  "text" : "http:\/\/t.co\/sJRvlDCC3c Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 375155591099867136,
  "created_at" : "2013-09-04 07:17:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fOtkezV0u9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6SZXDfR3",
      "display_url" : "pastebin.com\/raw.php?i=6SZX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375147334817947649",
  "text" : "http:\/\/t.co\/fOtkezV0u9 Found possible Google API key(s) #infoleak",
  "id" : 375147334817947649,
  "created_at" : "2013-09-04 06:44:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LuWmCwkfCU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P6fvWpbP",
      "display_url" : "pastebin.com\/raw.php?i=P6fv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375144109700153344",
  "text" : "http:\/\/t.co\/LuWmCwkfCU Found possible Google API key(s) #infoleak",
  "id" : 375144109700153344,
  "created_at" : "2013-09-04 06:31:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6WvJ1vRkaa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p02EbyDu",
      "display_url" : "pastebin.com\/raw.php?i=p02E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375122578521591809",
  "text" : "http:\/\/t.co\/6WvJ1vRkaa Found possible Google API key(s) #infoleak",
  "id" : 375122578521591809,
  "created_at" : "2013-09-04 05:06:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aodQFVvg4C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g2vME7nc",
      "display_url" : "pastebin.com\/raw.php?i=g2vM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375116447229300737",
  "text" : "http:\/\/t.co\/aodQFVvg4C Emails: 38 Hashes: 2 E\/H: 19.0 Keywords: 0.22 #infoleak",
  "id" : 375116447229300737,
  "created_at" : "2013-09-04 04:41:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jgtYjdUp0I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qwSdJ9KP",
      "display_url" : "pastebin.com\/raw.php?i=qwSd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375107995799023616",
  "text" : "http:\/\/t.co\/jgtYjdUp0I Emails: 148 Keywords: 0.11 #infoleak",
  "id" : 375107995799023616,
  "created_at" : "2013-09-04 04:08:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zm776LMiQM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EnNHeRre",
      "display_url" : "pastebin.com\/raw.php?i=EnNH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375047742709456896",
  "text" : "http:\/\/t.co\/zm776LMiQM Found possible Google API key(s) #infoleak",
  "id" : 375047742709456896,
  "created_at" : "2013-09-04 00:08:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iqcikmhNWC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SDgB2b0y",
      "display_url" : "pastebin.com\/raw.php?i=SDgB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375047522349105152",
  "text" : "http:\/\/t.co\/iqcikmhNWC Emails: 215 Keywords: 0.22 #infoleak",
  "id" : 375047522349105152,
  "created_at" : "2013-09-04 00:07:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/szDpYfXDaS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AKXkqDgf",
      "display_url" : "pastebin.com\/raw.php?i=AKXk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375039836844855297",
  "text" : "http:\/\/t.co\/szDpYfXDaS Keywords: 0.66 #infoleak",
  "id" : 375039836844855297,
  "created_at" : "2013-09-03 23:37:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a62vMit17v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ddu5Dv4g",
      "display_url" : "pastebin.com\/raw.php?i=Ddu5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375036269840969728",
  "text" : "http:\/\/t.co\/a62vMit17v Keywords: 0.66 #infoleak",
  "id" : 375036269840969728,
  "created_at" : "2013-09-03 23:23:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T1awiNy6pU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mE0UKFM2",
      "display_url" : "pastebin.com\/raw.php?i=mE0U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374990811920105472",
  "text" : "http:\/\/t.co\/T1awiNy6pU Emails: 72 Keywords: 0.0 #infoleak",
  "id" : 374990811920105472,
  "created_at" : "2013-09-03 20:22:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GD0s5s2PcV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=550LAG4a",
      "display_url" : "pastebin.com\/raw.php?i=550L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374989269984878593",
  "text" : "http:\/\/t.co\/GD0s5s2PcV Keywords: 0.77 #infoleak",
  "id" : 374989269984878593,
  "created_at" : "2013-09-03 20:16:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ICm1noxhnQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yU0STfXd",
      "display_url" : "pastebin.com\/raw.php?i=yU0S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374988488682528768",
  "text" : "http:\/\/t.co\/ICm1noxhnQ Hashes: 45 Keywords: 0.08 #infoleak",
  "id" : 374988488682528768,
  "created_at" : "2013-09-03 20:13:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mf8QQX1sbj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jCn9ypZs",
      "display_url" : "pastebin.com\/raw.php?i=jCn9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374943221375188992",
  "text" : "http:\/\/t.co\/mf8QQX1sbj Emails: 169 Keywords: 0.0 #infoleak",
  "id" : 374943221375188992,
  "created_at" : "2013-09-03 17:13:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2zhEX6Z7XO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4q1FN7iR",
      "display_url" : "pastebin.com\/raw.php?i=4q1F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374938437519818752",
  "text" : "http:\/\/t.co\/2zhEX6Z7XO Emails: 730 Hashes: 729 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 374938437519818752,
  "created_at" : "2013-09-03 16:54:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pLxhVlMxZa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9jt16Y4a",
      "display_url" : "pastebin.com\/raw.php?i=9jt1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374931003615100928",
  "text" : "http:\/\/t.co\/pLxhVlMxZa Emails: 42 Keywords: 0.22 #infoleak",
  "id" : 374931003615100928,
  "created_at" : "2013-09-03 16:24:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JycVMLkE9a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FXzSNcBK",
      "display_url" : "pastebin.com\/raw.php?i=FXzS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374924966799503360",
  "text" : "http:\/\/t.co\/JycVMLkE9a Found possible Google API key(s) #infoleak",
  "id" : 374924966799503360,
  "created_at" : "2013-09-03 16:00:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WgzDi7UBZL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rVtUkzX4",
      "display_url" : "pastebin.com\/raw.php?i=rVtU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374908575920816129",
  "text" : "http:\/\/t.co\/WgzDi7UBZL Emails: 1059 Hashes: 1060 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 374908575920816129,
  "created_at" : "2013-09-03 14:55:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B6pPu7sDW5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1rLvBh1C",
      "display_url" : "pastebin.com\/raw.php?i=1rLv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374866256219738112",
  "text" : "http:\/\/t.co\/B6pPu7sDW5 Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 374866256219738112,
  "created_at" : "2013-09-03 12:07:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PfVaRqUema",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xXHm1Bpp",
      "display_url" : "pastebin.com\/raw.php?i=xXHm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374861028112084992",
  "text" : "http:\/\/t.co\/PfVaRqUema Emails: 293 Hashes: 291 E\/H: 1.01 Keywords: 0.52 #infoleak",
  "id" : 374861028112084992,
  "created_at" : "2013-09-03 11:46:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PrRPYIB2fN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8GxTqyUj",
      "display_url" : "pastebin.com\/raw.php?i=8GxT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374843124264091648",
  "text" : "http:\/\/t.co\/PrRPYIB2fN Emails: 601 Hashes: 591 E\/H: 1.02 Keywords: 0.19 #infoleak",
  "id" : 374843124264091648,
  "created_at" : "2013-09-03 10:35:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lWC54usLr0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k79eiAEt",
      "display_url" : "pastebin.com\/raw.php?i=k79e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374824776998465536",
  "text" : "http:\/\/t.co\/lWC54usLr0 Emails: 2 Hashes: 621 E\/H: 0.0 Keywords: 0.19 #infoleak",
  "id" : 374824776998465536,
  "created_at" : "2013-09-03 09:22:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qi4lM2ARmY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tW2YkBCZ",
      "display_url" : "pastebin.com\/raw.php?i=tW2Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374818998564560896",
  "text" : "http:\/\/t.co\/Qi4lM2ARmY Emails: 491 Hashes: 491 E\/H: 1.0 Keywords: 0.19 #infoleak",
  "id" : 374818998564560896,
  "created_at" : "2013-09-03 08:59:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pscm0VldTd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QZiars0f",
      "display_url" : "pastebin.com\/raw.php?i=QZia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374804930411769856",
  "text" : "http:\/\/t.co\/pscm0VldTd Emails: 37 Keywords: 0.33 #infoleak",
  "id" : 374804930411769856,
  "created_at" : "2013-09-03 08:03:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yuNTUGCXCg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1674Rb0n",
      "display_url" : "pastebin.com\/raw.php?i=1674\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374800681669885952",
  "text" : "http:\/\/t.co\/yuNTUGCXCg Emails: 41 Hashes: 44 E\/H: 0.93 Keywords: 0.33 #infoleak",
  "id" : 374800681669885952,
  "created_at" : "2013-09-03 07:47:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LJW29oyJgt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0nF6THv7",
      "display_url" : "pastebin.com\/raw.php?i=0nF6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374799958475415552",
  "text" : "http:\/\/t.co\/LJW29oyJgt Emails: 511 Keywords: 0.22 #infoleak",
  "id" : 374799958475415552,
  "created_at" : "2013-09-03 07:44:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3eIiDY8bk3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e6FC2quT",
      "display_url" : "pastebin.com\/raw.php?i=e6FC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374793773160480768",
  "text" : "http:\/\/t.co\/3eIiDY8bk3 Found possible Google API key(s) #infoleak",
  "id" : 374793773160480768,
  "created_at" : "2013-09-03 07:19:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rM1PAm8tU4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9YNtH4sV",
      "display_url" : "pastebin.com\/raw.php?i=9YNt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374792166507163648",
  "text" : "http:\/\/t.co\/rM1PAm8tU4 Emails: 788 Keywords: 0.11 #infoleak",
  "id" : 374792166507163648,
  "created_at" : "2013-09-03 07:13:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ell3478JwQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6fHXqBp5",
      "display_url" : "pastebin.com\/raw.php?i=6fHX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374790945423642624",
  "text" : "http:\/\/t.co\/ell3478JwQ Emails: 63 Keywords: 0.22 #infoleak",
  "id" : 374790945423642624,
  "created_at" : "2013-09-03 07:08:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9PDjZVEx8b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xqJbfZAf",
      "display_url" : "pastebin.com\/raw.php?i=xqJb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374790903224750080",
  "text" : "http:\/\/t.co\/9PDjZVEx8b Emails: 54 Keywords: 0.33 #infoleak",
  "id" : 374790903224750080,
  "created_at" : "2013-09-03 07:08:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ikkM658lqL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S3duu2gu",
      "display_url" : "pastebin.com\/raw.php?i=S3du\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374789909271179264",
  "text" : "http:\/\/t.co\/ikkM658lqL Emails: 45 Keywords: 0.0 #infoleak",
  "id" : 374789909271179264,
  "created_at" : "2013-09-03 07:04:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kMtUnRVZ6I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ws013tGD",
      "display_url" : "pastebin.com\/raw.php?i=Ws01\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374690702300434432",
  "text" : "http:\/\/t.co\/kMtUnRVZ6I Found possible Google API key(s) #infoleak",
  "id" : 374690702300434432,
  "created_at" : "2013-09-03 00:29:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o9r3qwD57T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mxHMvpqE",
      "display_url" : "pastebin.com\/raw.php?i=mxHM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374678807061331968",
  "text" : "http:\/\/t.co\/o9r3qwD57T Emails: 340 Hashes: 359 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 374678807061331968,
  "created_at" : "2013-09-02 23:42:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SVbCyqL5oS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GXcZM0xK",
      "display_url" : "pastebin.com\/raw.php?i=GXcZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374672912197750786",
  "text" : "http:\/\/t.co\/SVbCyqL5oS Emails: 48 Keywords: 0.22 #infoleak",
  "id" : 374672912197750786,
  "created_at" : "2013-09-02 23:19:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1jmQ5ytEOp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4JP0z2BE",
      "display_url" : "pastebin.com\/raw.php?i=4JP0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374671826267295744",
  "text" : "http:\/\/t.co\/1jmQ5ytEOp Found possible Google API key(s) #infoleak",
  "id" : 374671826267295744,
  "created_at" : "2013-09-02 23:14:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/INoK9MrGTn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WyNxQuJP",
      "display_url" : "pastebin.com\/raw.php?i=WyNx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374671729290801152",
  "text" : "http:\/\/t.co\/INoK9MrGTn Found possible Google API key(s) #infoleak",
  "id" : 374671729290801152,
  "created_at" : "2013-09-02 23:14:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lK3MRdwCOf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4VjR1CBg",
      "display_url" : "pastebin.com\/raw.php?i=4VjR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374662850712592385",
  "text" : "http:\/\/t.co\/lK3MRdwCOf Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 374662850712592385,
  "created_at" : "2013-09-02 22:39:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0PNJSOgPIa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RcNi0ffS",
      "display_url" : "pastebin.com\/raw.php?i=RcNi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374655668034076672",
  "text" : "http:\/\/t.co\/0PNJSOgPIa Emails: 18 Keywords: 0.63 #infoleak",
  "id" : 374655668034076672,
  "created_at" : "2013-09-02 22:10:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oHnsY6Sbnf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FvpSBrQW",
      "display_url" : "pastebin.com\/raw.php?i=FvpS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374645870412578816",
  "text" : "http:\/\/t.co\/oHnsY6Sbnf Keywords: 0.66 #infoleak",
  "id" : 374645870412578816,
  "created_at" : "2013-09-02 21:31:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pw7WcOnstA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1ZEY8mSY",
      "display_url" : "pastebin.com\/raw.php?i=1ZEY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374637445725175808",
  "text" : "http:\/\/t.co\/pw7WcOnstA Emails: 24 Keywords: 0.22 #infoleak",
  "id" : 374637445725175808,
  "created_at" : "2013-09-02 20:58:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WS6FzNFgO3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MDpykYuB",
      "display_url" : "pastebin.com\/raw.php?i=MDpy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374604516873625600",
  "text" : "http:\/\/t.co\/WS6FzNFgO3 Hashes: 140 Keywords: 0.0 #infoleak",
  "id" : 374604516873625600,
  "created_at" : "2013-09-02 18:47:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/htWUncJ5NZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3g3jQ9Cj",
      "display_url" : "pastebin.com\/raw.php?i=3g3j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374598369701658625",
  "text" : "http:\/\/t.co\/htWUncJ5NZ Emails: 32 Keywords: 0.11 #infoleak",
  "id" : 374598369701658625,
  "created_at" : "2013-09-02 18:23:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oXrtUYTxWk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6SfNNnY3",
      "display_url" : "pastebin.com\/raw.php?i=6SfN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374595599913328640",
  "text" : "http:\/\/t.co\/oXrtUYTxWk Emails: 21 Keywords: 0.11 #infoleak",
  "id" : 374595599913328640,
  "created_at" : "2013-09-02 18:12:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YCBqgLyFNE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=93AcTu5T",
      "display_url" : "pastebin.com\/raw.php?i=93Ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374590469138681856",
  "text" : "http:\/\/t.co\/YCBqgLyFNE Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 374590469138681856,
  "created_at" : "2013-09-02 17:51:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w7j4X8ziAw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zy7pzUiX",
      "display_url" : "pastebin.com\/raw.php?i=zy7p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374570697344835584",
  "text" : "http:\/\/t.co\/w7j4X8ziAw Emails: 254 Hashes: 2 E\/H: 127.0 Keywords: 0.11 #infoleak",
  "id" : 374570697344835584,
  "created_at" : "2013-09-02 16:33:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FZTzCmmVjs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=01XQhWBJ",
      "display_url" : "pastebin.com\/raw.php?i=01XQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374568127083720704",
  "text" : "http:\/\/t.co\/FZTzCmmVjs Emails: 200 Keywords: 0.0 #infoleak",
  "id" : 374568127083720704,
  "created_at" : "2013-09-02 16:22:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cgMp8ZUctS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x3cfaq2C",
      "display_url" : "pastebin.com\/raw.php?i=x3cf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374565647927111680",
  "text" : "http:\/\/t.co\/cgMp8ZUctS Emails: 159 Hashes: 2 E\/H: 79.5 Keywords: 0.33 #infoleak",
  "id" : 374565647927111680,
  "created_at" : "2013-09-02 16:13:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mnK1tbUEX3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JMH9SqP8",
      "display_url" : "pastebin.com\/raw.php?i=JMH9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374564762744393728",
  "text" : "http:\/\/t.co\/mnK1tbUEX3 Emails: 110 Keywords: 0.19 #infoleak",
  "id" : 374564762744393728,
  "created_at" : "2013-09-02 16:09:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A216uEhtMk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JRjb1njM",
      "display_url" : "pastebin.com\/raw.php?i=JRjb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374416989554352128",
  "text" : "http:\/\/t.co\/A216uEhtMk Emails: 21 Keywords: 0.66 #infoleak",
  "id" : 374416989554352128,
  "created_at" : "2013-09-02 06:22:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zohPkFq7YV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YFqQhvjd",
      "display_url" : "pastebin.com\/raw.php?i=YFqQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374365678976774144",
  "text" : "http:\/\/t.co\/zohPkFq7YV Emails: 134 Keywords: 0.0 #infoleak",
  "id" : 374365678976774144,
  "created_at" : "2013-09-02 02:58:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QHKiDLMcQG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gcpu08iN",
      "display_url" : "pastebin.com\/raw.php?i=Gcpu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374351795906039808",
  "text" : "http:\/\/t.co\/QHKiDLMcQG Found possible Google API key(s) #infoleak",
  "id" : 374351795906039808,
  "created_at" : "2013-09-02 02:03:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U1HJJ0VL9X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RCpbuiRR",
      "display_url" : "pastebin.com\/raw.php?i=RCpb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374347731596087296",
  "text" : "http:\/\/t.co\/U1HJJ0VL9X Hashes: 41 Keywords: 0.11 #infoleak",
  "id" : 374347731596087296,
  "created_at" : "2013-09-02 01:47:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uCIjeaORG5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9rinjzmz",
      "display_url" : "pastebin.com\/raw.php?i=9rin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374341221365215232",
  "text" : "http:\/\/t.co\/uCIjeaORG5 Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 374341221365215232,
  "created_at" : "2013-09-02 01:21:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SP1EV7Rkcq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mLrPtTqa",
      "display_url" : "pastebin.com\/raw.php?i=mLrP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374338501107404800",
  "text" : "http:\/\/t.co\/SP1EV7Rkcq Keywords: 0.66 #infoleak",
  "id" : 374338501107404800,
  "created_at" : "2013-09-02 01:10:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qn3eV2F7DF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QJgw0w5s",
      "display_url" : "pastebin.com\/raw.php?i=QJgw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374338042216972288",
  "text" : "http:\/\/t.co\/Qn3eV2F7DF Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 374338042216972288,
  "created_at" : "2013-09-02 01:08:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0RTUdZlVwY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1jLzxxHs",
      "display_url" : "pastebin.com\/raw.php?i=1jLz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374324742473252864",
  "text" : "http:\/\/t.co\/0RTUdZlVwY Found possible Google API key(s) #infoleak",
  "id" : 374324742473252864,
  "created_at" : "2013-09-02 00:15:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C4xru4H2Ec",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tGnSWs5S",
      "display_url" : "pastebin.com\/raw.php?i=tGnS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374318804030869505",
  "text" : "http:\/\/t.co\/C4xru4H2Ec Found possible Google API key(s) #infoleak",
  "id" : 374318804030869505,
  "created_at" : "2013-09-01 23:52:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i8oT2zUA0k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JzP698vV",
      "display_url" : "pastebin.com\/raw.php?i=JzP6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374228813384650752",
  "text" : "http:\/\/t.co\/i8oT2zUA0k Emails: 836 Keywords: 0.08 #infoleak",
  "id" : 374228813384650752,
  "created_at" : "2013-09-01 17:54:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sH97ZEIbPY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xwC9Uuwt",
      "display_url" : "pastebin.com\/raw.php?i=xwC9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374225131435851776",
  "text" : "http:\/\/t.co\/sH97ZEIbPY Emails: 128 Keywords: 0.0 #infoleak",
  "id" : 374225131435851776,
  "created_at" : "2013-09-01 17:39:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C95Ce93sah",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HZEQEiT0",
      "display_url" : "pastebin.com\/raw.php?i=HZEQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374219901948264448",
  "text" : "http:\/\/t.co\/C95Ce93sah Emails: 45 Keywords: 0.0 #infoleak",
  "id" : 374219901948264448,
  "created_at" : "2013-09-01 17:19:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
} ]
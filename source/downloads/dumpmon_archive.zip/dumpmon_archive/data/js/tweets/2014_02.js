Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mlSb8VPwx7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pShY4x29",
      "display_url" : "pastebin.com\/raw.php?i=pShY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439620250259058688",
  "text" : "http:\/\/t.co\/mlSb8VPwx7 Hashes: 64 Keywords: 0.22 #infoleak",
  "id" : 439620250259058688,
  "created_at" : "2014-03-01 04:36:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wpRGV2xuwi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Kb346vqs",
      "display_url" : "pastebin.com\/raw.php?i=Kb34\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439611147361083392",
  "text" : "http:\/\/t.co\/wpRGV2xuwi Emails: 250 Keywords: 0.52 #infoleak",
  "id" : 439611147361083392,
  "created_at" : "2014-03-01 04:00:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L8EVS4YoI1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QnCZpZVd",
      "display_url" : "pastebin.com\/raw.php?i=QnCZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439606203035832320",
  "text" : "http:\/\/t.co\/L8EVS4YoI1 Emails: 498 Keywords: 0.0 #infoleak",
  "id" : 439606203035832320,
  "created_at" : "2014-03-01 03:41:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T5XRObkcdh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J0sECj0e",
      "display_url" : "pastebin.com\/raw.php?i=J0sE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439601951408275456",
  "text" : "http:\/\/t.co\/T5XRObkcdh Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 439601951408275456,
  "created_at" : "2014-03-01 03:24:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LqvwzaA3sc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TaRD7uCv",
      "display_url" : "pastebin.com\/raw.php?i=TaRD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439595571939008513",
  "text" : "http:\/\/t.co\/LqvwzaA3sc Emails: 253 Keywords: 0.52 #infoleak",
  "id" : 439595571939008513,
  "created_at" : "2014-03-01 02:58:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HbX6eCG5Eu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sMY7ZYnX",
      "display_url" : "pastebin.com\/raw.php?i=sMY7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439593705205284864",
  "text" : "http:\/\/t.co\/HbX6eCG5Eu Emails: 493 Keywords: 0.0 #infoleak",
  "id" : 439593705205284864,
  "created_at" : "2014-03-01 02:51:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wyVPOcpXlk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mM8Tt8Yf",
      "display_url" : "pastebin.com\/raw.php?i=mM8T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439593523084414977",
  "text" : "http:\/\/t.co\/wyVPOcpXlk Emails: 108 Keywords: 0.0 #infoleak",
  "id" : 439593523084414977,
  "created_at" : "2014-03-01 02:50:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AZXuF1NbrP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bAVaRzHT",
      "display_url" : "pastebin.com\/raw.php?i=bAVa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439587507995308033",
  "text" : "http:\/\/t.co\/AZXuF1NbrP Emails: 493 Keywords: 0.0 #infoleak",
  "id" : 439587507995308033,
  "created_at" : "2014-03-01 02:26:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LaZNlhOjTv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1AqL4AYh",
      "display_url" : "pastebin.com\/raw.php?i=1AqL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439574332268744704",
  "text" : "http:\/\/t.co\/LaZNlhOjTv Found possible Google API key(s) #infoleak",
  "id" : 439574332268744704,
  "created_at" : "2014-03-01 01:34:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GsvHGxpYci",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9gp0bbtD",
      "display_url" : "pastebin.com\/raw.php?i=9gp0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439571308225900544",
  "text" : "http:\/\/t.co\/GsvHGxpYci Emails: 492 Keywords: 0.0 #infoleak",
  "id" : 439571308225900544,
  "created_at" : "2014-03-01 01:22:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SToZBmFQnr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B2ULQ38c",
      "display_url" : "pastebin.com\/raw.php?i=B2UL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439567204397240320",
  "text" : "http:\/\/t.co\/SToZBmFQnr Found possible Google API key(s) #infoleak",
  "id" : 439567204397240320,
  "created_at" : "2014-03-01 01:06:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gQx5hqj87T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3CEyRfC6",
      "display_url" : "pastebin.com\/raw.php?i=3CEy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439562658887376896",
  "text" : "http:\/\/t.co\/gQx5hqj87T Found possible Google API key(s) #infoleak",
  "id" : 439562658887376896,
  "created_at" : "2014-03-01 00:47:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XWXVdebVJj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2SkWVayk",
      "display_url" : "pastebin.com\/raw.php?i=2SkW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439240779567865857",
  "text" : "http:\/\/t.co\/XWXVdebVJj Found possible Google API key(s) #infoleak",
  "id" : 439240779567865857,
  "created_at" : "2014-02-28 03:28:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439116553158918144",
  "geo" : { },
  "id_str" : "439127727052824576",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon Looks like a malware dump",
  "id" : 439127727052824576,
  "in_reply_to_status_id" : 439116553158918144,
  "created_at" : "2014-02-27 19:59:43 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vRors6CyZB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1Uxr9ia9",
      "display_url" : "pastebin.com\/raw.php?i=1Uxr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439116553158918144",
  "text" : "http:\/\/t.co\/vRors6CyZB Emails: 93 Hashes: 2 E\/H: 46.5 Keywords: 0.19 #infoleak",
  "id" : 439116553158918144,
  "created_at" : "2014-02-27 19:15:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H9plkvxZag",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XiN4keux",
      "display_url" : "pastebin.com\/raw.php?i=XiN4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439081713054924800",
  "text" : "http:\/\/t.co\/H9plkvxZag Emails: 227 Keywords: 0.11 #infoleak",
  "id" : 439081713054924800,
  "created_at" : "2014-02-27 16:56:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7ek1QRErKy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0QVSaScj",
      "display_url" : "pastebin.com\/raw.php?i=0QVS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439081394715623425",
  "text" : "http:\/\/t.co\/7ek1QRErKy Emails: 26 Keywords: 0.08 #infoleak",
  "id" : 439081394715623425,
  "created_at" : "2014-02-27 16:55:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tfIeB2bh4H",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TchrzUH2",
      "display_url" : "pastebin.com\/raw.php?i=Tchr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439080807454347264",
  "text" : "http:\/\/t.co\/tfIeB2bh4H Hashes: 68 Keywords: 0.22 #infoleak",
  "id" : 439080807454347264,
  "created_at" : "2014-02-27 16:53:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f1Fg45xiES",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sgnNT4HA",
      "display_url" : "pastebin.com\/raw.php?i=sgnN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439079922418860032",
  "text" : "http:\/\/t.co\/f1Fg45xiES Emails: 1000 Keywords: -0.03 #infoleak",
  "id" : 439079922418860032,
  "created_at" : "2014-02-27 16:49:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V2MmKt4Mm7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LQTXFGH1",
      "display_url" : "pastebin.com\/raw.php?i=LQTX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439078627817189376",
  "text" : "http:\/\/t.co\/V2MmKt4Mm7 Emails: 13 Hashes: 74 E\/H: 0.18 Keywords: 0.52 #infoleak",
  "id" : 439078627817189376,
  "created_at" : "2014-02-27 16:44:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x5BYjPoz6z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kzm6m8j4",
      "display_url" : "pastebin.com\/raw.php?i=kzm6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439076323554639872",
  "text" : "http:\/\/t.co\/x5BYjPoz6z Found possible Google API key(s) #infoleak",
  "id" : 439076323554639872,
  "created_at" : "2014-02-27 16:35:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/unfotkmPzo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KVd3H7Us",
      "display_url" : "pastebin.com\/raw.php?i=KVd3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439068946361118720",
  "text" : "http:\/\/t.co\/unfotkmPzo Keywords: 0.55 #infoleak",
  "id" : 439068946361118720,
  "created_at" : "2014-02-27 16:06:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7xf0soKM0F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y1kP5Wgk",
      "display_url" : "pastebin.com\/raw.php?i=Y1kP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439066866330238976",
  "text" : "http:\/\/t.co\/7xf0soKM0F Emails: 1546 Keywords: 0.08 #infoleak",
  "id" : 439066866330238976,
  "created_at" : "2014-02-27 15:57:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xyhHrYmgdH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8WcRRk35",
      "display_url" : "pastebin.com\/raw.php?i=8WcR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439063452078714880",
  "text" : "http:\/\/t.co\/xyhHrYmgdH Found possible Google API key(s) #infoleak",
  "id" : 439063452078714880,
  "created_at" : "2014-02-27 15:44:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Iyz5QwCs1S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x3a3KqZi",
      "display_url" : "pastebin.com\/raw.php?i=x3a3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439057258333212673",
  "text" : "http:\/\/t.co\/Iyz5QwCs1S Emails: 4 Hashes: 2 E\/H: 2.0 Keywords: 0.55 #infoleak",
  "id" : 439057258333212673,
  "created_at" : "2014-02-27 15:19:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9gPdVvrLdW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a8AqDbXF",
      "display_url" : "pastebin.com\/raw.php?i=a8Aq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439055698719043584",
  "text" : "http:\/\/t.co\/9gPdVvrLdW Emails: 3 Hashes: 2 E\/H: 1.5 Keywords: 0.55 #infoleak",
  "id" : 439055698719043584,
  "created_at" : "2014-02-27 15:13:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/635vbLyAYG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KwXLjD93",
      "display_url" : "pastebin.com\/raw.php?i=KwXL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439050681022812160",
  "text" : "http:\/\/t.co\/635vbLyAYG Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 439050681022812160,
  "created_at" : "2014-02-27 14:53:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9KMGPb11My",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pCeX3hNG",
      "display_url" : "pastebin.com\/raw.php?i=pCeX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439042686415159296",
  "text" : "http:\/\/t.co\/9KMGPb11My Emails: 4926 Keywords: 0.0 #infoleak",
  "id" : 439042686415159296,
  "created_at" : "2014-02-27 14:21:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hovJ62l0g0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B4PHtPwR",
      "display_url" : "pastebin.com\/raw.php?i=B4PH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439040956008898560",
  "text" : "http:\/\/t.co\/hovJ62l0g0 Emails: 10357 Keywords: 0.08 #infoleak",
  "id" : 439040956008898560,
  "created_at" : "2014-02-27 14:14:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t2nVpNjjYc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FqvLfzRW",
      "display_url" : "pastebin.com\/raw.php?i=FqvL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439036495228203008",
  "text" : "http:\/\/t.co\/t2nVpNjjYc Emails: 481 Keywords: 0.0 #infoleak",
  "id" : 439036495228203008,
  "created_at" : "2014-02-27 13:57:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/06qGk7toHE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zy6eKdCq",
      "display_url" : "pastebin.com\/raw.php?i=zy6e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439026088497278976",
  "text" : "http:\/\/t.co\/06qGk7toHE Hashes: 249 Keywords: -0.2 #infoleak",
  "id" : 439026088497278976,
  "created_at" : "2014-02-27 13:15:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vOZgJF44yb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c1pFqPRg",
      "display_url" : "pastebin.com\/raw.php?i=c1pF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439018995685933056",
  "text" : "http:\/\/t.co\/vOZgJF44yb Emails: 997 Keywords: 0.11 #infoleak",
  "id" : 439018995685933056,
  "created_at" : "2014-02-27 12:47:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BGBmmdvxVu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YUcqVm6y",
      "display_url" : "pastebin.com\/raw.php?i=YUcq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439017651654774784",
  "text" : "http:\/\/t.co\/BGBmmdvxVu Emails: 7859 Keywords: 0.22 #infoleak",
  "id" : 439017651654774784,
  "created_at" : "2014-02-27 12:42:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WzMAd7N8p0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HCe7PE9m",
      "display_url" : "pastebin.com\/raw.php?i=HCe7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439010931587039232",
  "text" : "http:\/\/t.co\/WzMAd7N8p0 Emails: 72 Hashes: 1 E\/H: 72.0 Keywords: 0.44 #infoleak",
  "id" : 439010931587039232,
  "created_at" : "2014-02-27 12:15:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qPSBiUqLQi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zVbBGNNP",
      "display_url" : "pastebin.com\/raw.php?i=zVbB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439004425231679490",
  "text" : "http:\/\/t.co\/qPSBiUqLQi Hashes: 50 Keywords: 0.22 #infoleak",
  "id" : 439004425231679490,
  "created_at" : "2014-02-27 11:49:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j8GWaiYH2O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CA0X2hx8",
      "display_url" : "pastebin.com\/raw.php?i=CA0X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439003787957530624",
  "text" : "http:\/\/t.co\/j8GWaiYH2O Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 439003787957530624,
  "created_at" : "2014-02-27 11:47:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mYPUBLGRnV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mFBhM40R",
      "display_url" : "pastebin.com\/raw.php?i=mFBh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439000935239806976",
  "text" : "http:\/\/t.co\/mYPUBLGRnV Keywords: 0.55 #infoleak",
  "id" : 439000935239806976,
  "created_at" : "2014-02-27 11:35:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wmcYgkCxlZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pxB1BBX3",
      "display_url" : "pastebin.com\/raw.php?i=pxB1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438995557890011136",
  "text" : "http:\/\/t.co\/wmcYgkCxlZ Hashes: 93 Keywords: 0.22 #infoleak",
  "id" : 438995557890011136,
  "created_at" : "2014-02-27 11:14:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ijSS2IkAwO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rJ0bzBhX",
      "display_url" : "pastebin.com\/raw.php?i=rJ0b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438914681541898240",
  "text" : "http:\/\/t.co\/ijSS2IkAwO Keywords: 0.55 #infoleak",
  "id" : 438914681541898240,
  "created_at" : "2014-02-27 05:53:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fcIN7qLeMh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6fbLzYT8",
      "display_url" : "pastebin.com\/raw.php?i=6fbL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438907700814954496",
  "text" : "http:\/\/t.co\/fcIN7qLeMh Emails: 201 Keywords: 0.0 #infoleak",
  "id" : 438907700814954496,
  "created_at" : "2014-02-27 05:25:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LfGUG13LcE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1882BJjU",
      "display_url" : "pastebin.com\/raw.php?i=1882\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438906331123023872",
  "text" : "http:\/\/t.co\/LfGUG13LcE Emails: 1474 Keywords: 0.0 #infoleak",
  "id" : 438906331123023872,
  "created_at" : "2014-02-27 05:19:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NFNJvt1DHU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8RyafxTR",
      "display_url" : "pastebin.com\/raw.php?i=8Rya\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438902501769625600",
  "text" : "http:\/\/t.co\/NFNJvt1DHU Hashes: 60 Keywords: 0.08 #infoleak",
  "id" : 438902501769625600,
  "created_at" : "2014-02-27 05:04:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O30hLdvl4B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7DAjxwDX",
      "display_url" : "pastebin.com\/raw.php?i=7DAj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438898820449968128",
  "text" : "http:\/\/t.co\/O30hLdvl4B Emails: 29 Keywords: 0.22 #infoleak",
  "id" : 438898820449968128,
  "created_at" : "2014-02-27 04:50:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tae7ZBV701",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i5j37PWA",
      "display_url" : "pastebin.com\/raw.php?i=i5j3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438891361371054080",
  "text" : "http:\/\/t.co\/tae7ZBV701 Emails: 687 Hashes: 3 E\/H: 229.0 Keywords: 0.0 #infoleak",
  "id" : 438891361371054080,
  "created_at" : "2014-02-27 04:20:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7OkxCkxie3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qnvqBzzm",
      "display_url" : "pastebin.com\/raw.php?i=qnvq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438882007276216320",
  "text" : "http:\/\/t.co\/7OkxCkxie3 Emails: 33 Hashes: 3 E\/H: 11.0 Keywords: 0.3 #infoleak",
  "id" : 438882007276216320,
  "created_at" : "2014-02-27 03:43:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m8r6cZ6Hy5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pLUqU2qw",
      "display_url" : "pastebin.com\/raw.php?i=pLUq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438881851503951872",
  "text" : "http:\/\/t.co\/m8r6cZ6Hy5 Hashes: 92 Keywords: 0.08 #infoleak",
  "id" : 438881851503951872,
  "created_at" : "2014-02-27 03:42:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lBL3wia54X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BmKTD2Js",
      "display_url" : "pastebin.com\/raw.php?i=BmKT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438881333872316416",
  "text" : "http:\/\/t.co\/lBL3wia54X Emails: 1 Hashes: 2 E\/H: 0.5 Keywords: 0.66 #infoleak",
  "id" : 438881333872316416,
  "created_at" : "2014-02-27 03:40:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t9cgIklVkb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tgr3f9Rs",
      "display_url" : "pastebin.com\/raw.php?i=Tgr3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438877738305216513",
  "text" : "http:\/\/t.co\/t9cgIklVkb Emails: 24 Hashes: 3 E\/H: 8.0 Keywords: 0.3 #infoleak",
  "id" : 438877738305216513,
  "created_at" : "2014-02-27 03:26:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oT5U0vFJ1N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KhVr1Ush",
      "display_url" : "pastebin.com\/raw.php?i=KhVr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438877118949126145",
  "text" : "http:\/\/t.co\/oT5U0vFJ1N Emails: 1340 Keywords: 0.33 #infoleak",
  "id" : 438877118949126145,
  "created_at" : "2014-02-27 03:23:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P4KAphchVJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZjgYa2yU",
      "display_url" : "pastebin.com\/raw.php?i=ZjgY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438872589780254720",
  "text" : "http:\/\/t.co\/P4KAphchVJ Emails: 1066 Hashes: 718 E\/H: 1.48 Keywords: 0.22 #infoleak",
  "id" : 438872589780254720,
  "created_at" : "2014-02-27 03:05:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EzBGziNRDA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7baKasrx",
      "display_url" : "pastebin.com\/raw.php?i=7baK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438859086205968384",
  "text" : "http:\/\/t.co\/EzBGziNRDA Keywords: 0.55 #infoleak",
  "id" : 438859086205968384,
  "created_at" : "2014-02-27 02:12:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o4qV48OV8C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZrgERaCL",
      "display_url" : "pastebin.com\/raw.php?i=ZrgE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438850046826516480",
  "text" : "http:\/\/t.co\/o4qV48OV8C Hashes: 75 Keywords: 0.0 #infoleak",
  "id" : 438850046826516480,
  "created_at" : "2014-02-27 01:36:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wGrjzLWm5n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XyYYAU0n",
      "display_url" : "pastebin.com\/raw.php?i=XyYY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438842440733032448",
  "text" : "http:\/\/t.co\/wGrjzLWm5n Emails: 35 Keywords: 0.66 #infoleak",
  "id" : 438842440733032448,
  "created_at" : "2014-02-27 01:06:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4HastgUj3c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sq6L7bsU",
      "display_url" : "pastebin.com\/raw.php?i=sq6L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438830901502304256",
  "text" : "http:\/\/t.co\/4HastgUj3c Found possible Google API key(s) #infoleak",
  "id" : 438830901502304256,
  "created_at" : "2014-02-27 00:20:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ThhJtEwZsA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M28Upz06",
      "display_url" : "pastebin.com\/raw.php?i=M28U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438822671694823424",
  "text" : "http:\/\/t.co\/ThhJtEwZsA Emails: 163 Hashes: 10 E\/H: 16.3 Keywords: 0.08 #infoleak",
  "id" : 438822671694823424,
  "created_at" : "2014-02-26 23:47:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tHaogVOzSF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c9ABUpE7",
      "display_url" : "pastebin.com\/raw.php?i=c9AB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438822146425364481",
  "text" : "http:\/\/t.co\/tHaogVOzSF Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 438822146425364481,
  "created_at" : "2014-02-26 23:45:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q5hpu5UuqV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PzZa9sCp",
      "display_url" : "pastebin.com\/raw.php?i=PzZa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438820875098288128",
  "text" : "http:\/\/t.co\/q5hpu5UuqV Hashes: 40 Keywords: 0.08 #infoleak",
  "id" : 438820875098288128,
  "created_at" : "2014-02-26 23:40:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2sUFiZ4AIg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=my5QDsS3",
      "display_url" : "pastebin.com\/raw.php?i=my5Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438818720937287681",
  "text" : "http:\/\/t.co\/2sUFiZ4AIg Hashes: 34 Keywords: 0.0 #infoleak",
  "id" : 438818720937287681,
  "created_at" : "2014-02-26 23:31:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WPoXXcNkUe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pbNAV0Bt",
      "display_url" : "pastebin.com\/raw.php?i=pbNA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438815195285041152",
  "text" : "http:\/\/t.co\/WPoXXcNkUe Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 438815195285041152,
  "created_at" : "2014-02-26 23:17:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OERc4yEX40",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=67sXwcer",
      "display_url" : "pastebin.com\/raw.php?i=67sX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438814821195083776",
  "text" : "http:\/\/t.co\/OERc4yEX40 Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 438814821195083776,
  "created_at" : "2014-02-26 23:16:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IOBCsNFtkK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hRzZnfZ8",
      "display_url" : "pastebin.com\/raw.php?i=hRzZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438803393176276992",
  "text" : "http:\/\/t.co\/IOBCsNFtkK Emails: 9953 Keywords: 0.22 #infoleak",
  "id" : 438803393176276992,
  "created_at" : "2014-02-26 22:30:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sKBgoASUfg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AvWgYREb",
      "display_url" : "pastebin.com\/raw.php?i=AvWg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438798127294730240",
  "text" : "http:\/\/t.co\/sKBgoASUfg Keywords: 0.55 #infoleak",
  "id" : 438798127294730240,
  "created_at" : "2014-02-26 22:10:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6TaB29jHlE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=99NBZZ41",
      "display_url" : "pastebin.com\/raw.php?i=99NB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438796729136070656",
  "text" : "http:\/\/t.co\/6TaB29jHlE Hashes: 1371 Keywords: 0.08 #infoleak",
  "id" : 438796729136070656,
  "created_at" : "2014-02-26 22:04:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ljyp6lGQaL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=txsNcJqM",
      "display_url" : "pastebin.com\/raw.php?i=txsN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438793373453795328",
  "text" : "http:\/\/t.co\/ljyp6lGQaL Found possible Google API key(s) #infoleak",
  "id" : 438793373453795328,
  "created_at" : "2014-02-26 21:51:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iNEoplE9eV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pQJ9zvVC",
      "display_url" : "pastebin.com\/raw.php?i=pQJ9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438785590754942978",
  "text" : "http:\/\/t.co\/iNEoplE9eV Hashes: 995 Keywords: -0.06 #infoleak",
  "id" : 438785590754942978,
  "created_at" : "2014-02-26 21:20:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EVjsXTg3wO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C5VaTSuA",
      "display_url" : "pastebin.com\/raw.php?i=C5Va\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438783636611923968",
  "text" : "http:\/\/t.co\/EVjsXTg3wO Emails: 1037 Hashes: 1037 E\/H: 1.0 Keywords: 0.19 #infoleak",
  "id" : 438783636611923968,
  "created_at" : "2014-02-26 21:12:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9KahAvOBFx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dp3fLGqn",
      "display_url" : "pastebin.com\/raw.php?i=Dp3f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438761505748549632",
  "text" : "http:\/\/t.co\/9KahAvOBFx Hashes: 44 Keywords: 0.22 #infoleak",
  "id" : 438761505748549632,
  "created_at" : "2014-02-26 19:44:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6b0ujgGgjN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d9SsWgiH",
      "display_url" : "pastebin.com\/raw.php?i=d9Ss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438760438117834753",
  "text" : "http:\/\/t.co\/6b0ujgGgjN Emails: 26 Keywords: -0.03 #infoleak",
  "id" : 438760438117834753,
  "created_at" : "2014-02-26 19:40:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/55S4RoK3nM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y1aCVNKQ",
      "display_url" : "pastebin.com\/raw.php?i=Y1aC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438756576577339392",
  "text" : "http:\/\/t.co\/55S4RoK3nM Emails: 5624 Keywords: 0.22 #infoleak",
  "id" : 438756576577339392,
  "created_at" : "2014-02-26 19:24:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oPpLA0bT84",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m2V9E0fD",
      "display_url" : "pastebin.com\/raw.php?i=m2V9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438756294124511233",
  "text" : "http:\/\/t.co\/oPpLA0bT84 Found possible Google API key(s) #infoleak",
  "id" : 438756294124511233,
  "created_at" : "2014-02-26 19:23:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JdlxKQiUZc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9Mr3frKY",
      "display_url" : "pastebin.com\/raw.php?i=9Mr3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438744244451176448",
  "text" : "http:\/\/t.co\/JdlxKQiUZc Found possible Google API key(s) #infoleak",
  "id" : 438744244451176448,
  "created_at" : "2014-02-26 18:35:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n7ZeffSf0w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9drbVTpb",
      "display_url" : "pastebin.com\/raw.php?i=9drb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438743778598219777",
  "text" : "http:\/\/t.co\/n7ZeffSf0w Emails: 3 Hashes: 56 E\/H: 0.05 Keywords: 0.08 #infoleak",
  "id" : 438743778598219777,
  "created_at" : "2014-02-26 18:34:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ffrtaXe1hW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F2iXAdqy",
      "display_url" : "pastebin.com\/raw.php?i=F2iX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438735470436958208",
  "text" : "http:\/\/t.co\/ffrtaXe1hW Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 438735470436958208,
  "created_at" : "2014-02-26 18:01:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nutp4pHLEi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=36NZWTRc",
      "display_url" : "pastebin.com\/raw.php?i=36NZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438726097425809408",
  "text" : "http:\/\/t.co\/nutp4pHLEi Emails: 990 Keywords: 0.11 #infoleak",
  "id" : 438726097425809408,
  "created_at" : "2014-02-26 17:23:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZGb8XOhm9M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mcfydeUD",
      "display_url" : "pastebin.com\/raw.php?i=mcfy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438720631694049281",
  "text" : "http:\/\/t.co\/ZGb8XOhm9M Emails: 496 Keywords: 0.0 #infoleak",
  "id" : 438720631694049281,
  "created_at" : "2014-02-26 17:02:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3KkgyHAdLS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gEQfgAkU",
      "display_url" : "pastebin.com\/raw.php?i=gEQf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438716490112450561",
  "text" : "http:\/\/t.co\/3KkgyHAdLS Emails: 997 Keywords: 0.11 #infoleak",
  "id" : 438716490112450561,
  "created_at" : "2014-02-26 16:45:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2FInNCZIkn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JiFhA2bt",
      "display_url" : "pastebin.com\/raw.php?i=JiFh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438715696789217282",
  "text" : "http:\/\/t.co\/2FInNCZIkn Emails: 9996 Keywords: 0.11 #infoleak",
  "id" : 438715696789217282,
  "created_at" : "2014-02-26 16:42:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XgBiP8iUep",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cWgGr4v0",
      "display_url" : "pastebin.com\/raw.php?i=cWgG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438714798306361344",
  "text" : "http:\/\/t.co\/XgBiP8iUep Emails: 116 Keywords: 0.0 #infoleak",
  "id" : 438714798306361344,
  "created_at" : "2014-02-26 16:38:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sGDFRLe03A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vjyLnnCn",
      "display_url" : "pastebin.com\/raw.php?i=vjyL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438709775300169728",
  "text" : "http:\/\/t.co\/sGDFRLe03A Hashes: 30 Keywords: 0.33 #infoleak",
  "id" : 438709775300169728,
  "created_at" : "2014-02-26 16:18:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B3CzhuAasQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P00NLYmq",
      "display_url" : "pastebin.com\/raw.php?i=P00N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438705572129415168",
  "text" : "http:\/\/t.co\/B3CzhuAasQ Emails: 40 Hashes: 1 E\/H: 40.0 Keywords: 0.22 #infoleak",
  "id" : 438705572129415168,
  "created_at" : "2014-02-26 16:02:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vdMJNwUo8z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kqKmRANA",
      "display_url" : "pastebin.com\/raw.php?i=kqKm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438636778241540096",
  "text" : "http:\/\/t.co\/vdMJNwUo8z Hashes: 388 Keywords: 0.0 #infoleak",
  "id" : 438636778241540096,
  "created_at" : "2014-02-26 11:28:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uDJlAAfLWn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fZWst2sY",
      "display_url" : "pastebin.com\/raw.php?i=fZWs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438609699336753152",
  "text" : "http:\/\/t.co\/uDJlAAfLWn Emails: 132 Keywords: 0.08 #infoleak",
  "id" : 438609699336753152,
  "created_at" : "2014-02-26 09:41:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4n3QLYBWBA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cgc1nqmf",
      "display_url" : "pastebin.com\/raw.php?i=cgc1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438581578768207872",
  "text" : "http:\/\/t.co\/4n3QLYBWBA Keywords: 0.55 #infoleak",
  "id" : 438581578768207872,
  "created_at" : "2014-02-26 07:49:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/imsZG92BKO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b0K2UJ71",
      "display_url" : "pastebin.com\/raw.php?i=b0K2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438540473582383104",
  "text" : "http:\/\/t.co\/imsZG92BKO Hashes: 45 Keywords: 0.33 #infoleak",
  "id" : 438540473582383104,
  "created_at" : "2014-02-26 05:06:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2FluGsPULH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BVtyiE9p",
      "display_url" : "pastebin.com\/raw.php?i=BVty\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438536574817431552",
  "text" : "http:\/\/t.co\/2FluGsPULH Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.44 #infoleak",
  "id" : 438536574817431552,
  "created_at" : "2014-02-26 04:50:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fLiHLdo4Wh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Rkd87YwM",
      "display_url" : "pastebin.com\/raw.php?i=Rkd8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438536363130892288",
  "text" : "http:\/\/t.co\/fLiHLdo4Wh Hashes: 49 Keywords: 0.11 #infoleak",
  "id" : 438536363130892288,
  "created_at" : "2014-02-26 04:49:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MPr8fbII6z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=STbR6Ca3",
      "display_url" : "pastebin.com\/raw.php?i=STbR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438534499215740928",
  "text" : "http:\/\/t.co\/MPr8fbII6z Emails: 1 Hashes: 2 E\/H: 0.5 Keywords: 0.66 #infoleak",
  "id" : 438534499215740928,
  "created_at" : "2014-02-26 04:42:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FHpUHFxDcR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0TDFf0WJ",
      "display_url" : "pastebin.com\/raw.php?i=0TDF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438528701945245696",
  "text" : "http:\/\/t.co\/FHpUHFxDcR Keywords: 0.55 #infoleak",
  "id" : 438528701945245696,
  "created_at" : "2014-02-26 04:19:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EY2Fah1cu8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X4XssNi3",
      "display_url" : "pastebin.com\/raw.php?i=X4Xs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438519988425465857",
  "text" : "http:\/\/t.co\/EY2Fah1cu8 Emails: 8026 Keywords: 0.11 #infoleak",
  "id" : 438519988425465857,
  "created_at" : "2014-02-26 03:44:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hcnsVAu4BK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hs4aZUKc",
      "display_url" : "pastebin.com\/raw.php?i=Hs4a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438506955984756737",
  "text" : "http:\/\/t.co\/hcnsVAu4BK Hashes: 43 Keywords: 0.08 #infoleak",
  "id" : 438506955984756737,
  "created_at" : "2014-02-26 02:53:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/txDdVaEKPR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FafnwuFE",
      "display_url" : "pastebin.com\/raw.php?i=Fafn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438505051183521792",
  "text" : "http:\/\/t.co\/txDdVaEKPR Emails: 95 Keywords: 0.0 #infoleak",
  "id" : 438505051183521792,
  "created_at" : "2014-02-26 02:45:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ULOYQTBu48",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s0ZgMxje",
      "display_url" : "pastebin.com\/raw.php?i=s0Zg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438490315419185152",
  "text" : "http:\/\/t.co\/ULOYQTBu48 Emails: 85 Keywords: 0.33 #infoleak",
  "id" : 438490315419185152,
  "created_at" : "2014-02-26 01:46:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DHPIEfrO2L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mv5Zz4eF",
      "display_url" : "pastebin.com\/raw.php?i=Mv5Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438480101492019200",
  "text" : "http:\/\/t.co\/DHPIEfrO2L Emails: 100 Keywords: 0.19 #infoleak",
  "id" : 438480101492019200,
  "created_at" : "2014-02-26 01:06:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vHAJzPGI2S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mTFc8wqM",
      "display_url" : "pastebin.com\/raw.php?i=mTFc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438476310864601088",
  "text" : "http:\/\/t.co\/vHAJzPGI2S Hashes: 48 Keywords: 0.0 #infoleak",
  "id" : 438476310864601088,
  "created_at" : "2014-02-26 00:51:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OyZiIcl0pi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Chhh6E81",
      "display_url" : "pastebin.com\/raw.php?i=Chhh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438476023034699776",
  "text" : "http:\/\/t.co\/OyZiIcl0pi Hashes: 43 Keywords: 0.08 #infoleak",
  "id" : 438476023034699776,
  "created_at" : "2014-02-26 00:50:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YPVokMLv5Q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QY3xCWGS",
      "display_url" : "pastebin.com\/raw.php?i=QY3x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438467571155603456",
  "text" : "http:\/\/t.co\/YPVokMLv5Q Emails: 79 Keywords: 0.0 #infoleak",
  "id" : 438467571155603456,
  "created_at" : "2014-02-26 00:16:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KAAKDiExei",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ui9ySCNQ",
      "display_url" : "pastebin.com\/raw.php?i=Ui9y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438456817329270784",
  "text" : "http:\/\/t.co\/KAAKDiExei Emails: 47 Hashes: 45 E\/H: 1.04 Keywords: 0.44 #infoleak",
  "id" : 438456817329270784,
  "created_at" : "2014-02-25 23:33:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lfQaPpnv41",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ctb244ys",
      "display_url" : "pastebin.com\/raw.php?i=ctb2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438443076256665600",
  "text" : "http:\/\/t.co\/lfQaPpnv41 Found possible Google API key(s) #infoleak",
  "id" : 438443076256665600,
  "created_at" : "2014-02-25 22:39:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dqy3YM6Q19",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gf3WVzkw",
      "display_url" : "pastebin.com\/raw.php?i=Gf3W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438440258544209920",
  "text" : "http:\/\/t.co\/dqy3YM6Q19 Emails: 3591 Hashes: 3583 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 438440258544209920,
  "created_at" : "2014-02-25 22:27:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HuJC0Fz46k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=swyCrYg7",
      "display_url" : "pastebin.com\/raw.php?i=swyC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438437655559168000",
  "text" : "http:\/\/t.co\/HuJC0Fz46k Emails: 35 Keywords: -0.14 #infoleak",
  "id" : 438437655559168000,
  "created_at" : "2014-02-25 22:17:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OrBZSKmxDU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pkvxLPv3",
      "display_url" : "pastebin.com\/raw.php?i=pkvx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438437069593919489",
  "text" : "http:\/\/t.co\/OrBZSKmxDU Emails: 135 Keywords: 0.22 #infoleak",
  "id" : 438437069593919489,
  "created_at" : "2014-02-25 22:15:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kV82qCXSNF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jrrba8Tj",
      "display_url" : "pastebin.com\/raw.php?i=Jrrb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438431003502059520",
  "text" : "http:\/\/t.co\/kV82qCXSNF Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 438431003502059520,
  "created_at" : "2014-02-25 21:51:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dnrhYQh1BA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RT8drCzA",
      "display_url" : "pastebin.com\/raw.php?i=RT8d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438430505784987648",
  "text" : "http:\/\/t.co\/dnrhYQh1BA Emails: 535 Keywords: -0.03 #infoleak",
  "id" : 438430505784987648,
  "created_at" : "2014-02-25 21:49:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7tsgiG858n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8SjYTsHT",
      "display_url" : "pastebin.com\/raw.php?i=8SjY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438420915747962880",
  "text" : "http:\/\/t.co\/7tsgiG858n Emails: 299 Keywords: 0.11 #infoleak",
  "id" : 438420915747962880,
  "created_at" : "2014-02-25 21:11:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TG4FksmcFE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zyj0uGa3",
      "display_url" : "pastebin.com\/raw.php?i=Zyj0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438417999796506624",
  "text" : "http:\/\/t.co\/TG4FksmcFE Emails: 204 Keywords: 0.19 #infoleak",
  "id" : 438417999796506624,
  "created_at" : "2014-02-25 20:59:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hby57RDMds",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y5R8LxyD",
      "display_url" : "pastebin.com\/raw.php?i=Y5R8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438409808408883200",
  "text" : "http:\/\/t.co\/Hby57RDMds Emails: 876 Hashes: 946 E\/H: 0.93 Keywords: 0.66 #infoleak",
  "id" : 438409808408883200,
  "created_at" : "2014-02-25 20:26:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dZGixhAVUf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7aQh7n9g",
      "display_url" : "pastebin.com\/raw.php?i=7aQh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438407421371756544",
  "text" : "http:\/\/t.co\/dZGixhAVUf Emails: 247 Keywords: 0.55 #infoleak",
  "id" : 438407421371756544,
  "created_at" : "2014-02-25 20:17:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KxR0O23PwV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8A4CN2Aa",
      "display_url" : "pastebin.com\/raw.php?i=8A4C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438195355096592384",
  "text" : "http:\/\/t.co\/KxR0O23PwV Keywords: 0.55 #infoleak",
  "id" : 438195355096592384,
  "created_at" : "2014-02-25 06:14:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AdlZNQT8h0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=buNe5CnW",
      "display_url" : "pastebin.com\/raw.php?i=buNe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438172711609565184",
  "text" : "http:\/\/t.co\/AdlZNQT8h0 Emails: 6403 Keywords: 0.22 #infoleak",
  "id" : 438172711609565184,
  "created_at" : "2014-02-25 04:44:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/amvsTlkIah",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wZ4C4uu9",
      "display_url" : "pastebin.com\/raw.php?i=wZ4C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438164428215701504",
  "text" : "http:\/\/t.co\/amvsTlkIah Emails: 3 Hashes: 34 E\/H: 0.09 Keywords: 0.44 #infoleak",
  "id" : 438164428215701504,
  "created_at" : "2014-02-25 04:11:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6NlcgEIbSY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VSiyKjKe",
      "display_url" : "pastebin.com\/raw.php?i=VSiy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438150216093417472",
  "text" : "http:\/\/t.co\/6NlcgEIbSY Emails: 3 Hashes: 34 E\/H: 0.09 Keywords: 0.44 #infoleak",
  "id" : 438150216093417472,
  "created_at" : "2014-02-25 03:15:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kB4PCLBfr3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pMpLAC62",
      "display_url" : "pastebin.com\/raw.php?i=pMpL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438148673327751168",
  "text" : "http:\/\/t.co\/kB4PCLBfr3 Emails: 305 Keywords: 0.55 #infoleak",
  "id" : 438148673327751168,
  "created_at" : "2014-02-25 03:09:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kR2rsucTMD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ApLMC39x",
      "display_url" : "pastebin.com\/raw.php?i=ApLM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438142018204622849",
  "text" : "http:\/\/t.co\/kR2rsucTMD Found possible Google API key(s) #infoleak",
  "id" : 438142018204622849,
  "created_at" : "2014-02-25 02:42:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/riR4CiaXvN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7sktPWVZ",
      "display_url" : "pastebin.com\/raw.php?i=7skt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438119758697734144",
  "text" : "http:\/\/t.co\/riR4CiaXvN Possible cisco configuration #infoleak",
  "id" : 438119758697734144,
  "created_at" : "2014-02-25 01:14:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gF1CprE6WG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=84Addd2w",
      "display_url" : "pastebin.com\/raw.php?i=84Ad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438111727301836801",
  "text" : "http:\/\/t.co\/gF1CprE6WG Found possible Google API key(s) #infoleak",
  "id" : 438111727301836801,
  "created_at" : "2014-02-25 00:42:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KLHS3mWj5h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GnQrrSPi",
      "display_url" : "pastebin.com\/raw.php?i=GnQr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438096337741963266",
  "text" : "http:\/\/t.co\/KLHS3mWj5h Hashes: 2123 Keywords: 0.11 #infoleak",
  "id" : 438096337741963266,
  "created_at" : "2014-02-24 23:41:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C63z41zagg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BEUBBYKV",
      "display_url" : "pastebin.com\/raw.php?i=BEUB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438068182574579714",
  "text" : "http:\/\/t.co\/C63z41zagg Emails: 62 Hashes: 27 E\/H: 2.3 Keywords: 0.33 #infoleak",
  "id" : 438068182574579714,
  "created_at" : "2014-02-24 21:49:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3TNc9VRmCy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AzeLCGCp",
      "display_url" : "pastebin.com\/raw.php?i=AzeL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438067439234871296",
  "text" : "http:\/\/t.co\/3TNc9VRmCy Emails: 20 Hashes: 1 E\/H: 20.0 Keywords: 0.33 #infoleak",
  "id" : 438067439234871296,
  "created_at" : "2014-02-24 21:46:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3KaeOVgrbJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8LP3auMR",
      "display_url" : "pastebin.com\/raw.php?i=8LP3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438064431474294784",
  "text" : "http:\/\/t.co\/3KaeOVgrbJ Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 438064431474294784,
  "created_at" : "2014-02-24 21:34:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qJ4xBlkp2E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CbwWheAj",
      "display_url" : "pastebin.com\/raw.php?i=CbwW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438063342444228608",
  "text" : "http:\/\/t.co\/qJ4xBlkp2E Emails: 253 Hashes: 1 E\/H: 253.0 Keywords: 0.33 #infoleak",
  "id" : 438063342444228608,
  "created_at" : "2014-02-24 21:30:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ehywKExTZ2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LVRM7Gkn",
      "display_url" : "pastebin.com\/raw.php?i=LVRM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438041418464886784",
  "text" : "http:\/\/t.co\/ehywKExTZ2 Emails: 49 Keywords: 0.0 #infoleak",
  "id" : 438041418464886784,
  "created_at" : "2014-02-24 20:03:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c8IIGfZhUp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q5zQdz5q",
      "display_url" : "pastebin.com\/raw.php?i=q5zQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437880798738251776",
  "text" : "http:\/\/t.co\/c8IIGfZhUp Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 437880798738251776,
  "created_at" : "2014-02-24 09:24:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q77WprXpKT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KKwEWFNZ",
      "display_url" : "pastebin.com\/raw.php?i=KKwE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437876026555633665",
  "text" : "http:\/\/t.co\/q77WprXpKT Emails: 67 Keywords: 0.0 #infoleak",
  "id" : 437876026555633665,
  "created_at" : "2014-02-24 09:05:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QN4rC42LEc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=30bEnidp",
      "display_url" : "pastebin.com\/raw.php?i=30bE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437865043732869120",
  "text" : "http:\/\/t.co\/QN4rC42LEc Hashes: 8278 Keywords: 0.11 #infoleak",
  "id" : 437865043732869120,
  "created_at" : "2014-02-24 08:22:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iTXzgyHUfh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UQRCRC3f",
      "display_url" : "pastebin.com\/raw.php?i=UQRC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437863901942648832",
  "text" : "http:\/\/t.co\/iTXzgyHUfh Emails: 75 Keywords: 0.11 #infoleak",
  "id" : 437863901942648832,
  "created_at" : "2014-02-24 08:17:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/liwZo2BdT3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uLZHCQ7z",
      "display_url" : "pastebin.com\/raw.php?i=uLZH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437837410743771136",
  "text" : "http:\/\/t.co\/liwZo2BdT3 Emails: 154 Keywords: 0.33 #infoleak",
  "id" : 437837410743771136,
  "created_at" : "2014-02-24 06:32:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s6wktW7QGU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fZfpXjGL",
      "display_url" : "pastebin.com\/raw.php?i=fZfp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437836915597778944",
  "text" : "http:\/\/t.co\/s6wktW7QGU Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 437836915597778944,
  "created_at" : "2014-02-24 06:30:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XMzueXLZDt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7h7QKVmF",
      "display_url" : "pastebin.com\/raw.php?i=7h7Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437813215607545856",
  "text" : "http:\/\/t.co\/XMzueXLZDt Keywords: 0.55 #infoleak",
  "id" : 437813215607545856,
  "created_at" : "2014-02-24 04:56:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8qrr6btg3p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w2Rqj9aN",
      "display_url" : "pastebin.com\/raw.php?i=w2Rq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437804063925608449",
  "text" : "http:\/\/t.co\/8qrr6btg3p Emails: 238 Hashes: 26 E\/H: 9.15 Keywords: 0.11 #infoleak",
  "id" : 437804063925608449,
  "created_at" : "2014-02-24 04:19:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/caaszfBExt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=URtiWEBq",
      "display_url" : "pastebin.com\/raw.php?i=URti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437800606015553536",
  "text" : "http:\/\/t.co\/caaszfBExt Found possible Google API key(s) #infoleak",
  "id" : 437800606015553536,
  "created_at" : "2014-02-24 04:06:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UMbvTlsb7h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ccXQNGf2",
      "display_url" : "pastebin.com\/raw.php?i=ccXQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437792021663580163",
  "text" : "http:\/\/t.co\/UMbvTlsb7h Emails: 595 Hashes: 596 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 437792021663580163,
  "created_at" : "2014-02-24 03:32:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2PpvfzoVn4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BAxGJDuv",
      "display_url" : "pastebin.com\/raw.php?i=BAxG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437791270304358400",
  "text" : "http:\/\/t.co\/2PpvfzoVn4 Emails: 1183 Hashes: 1183 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 437791270304358400,
  "created_at" : "2014-02-24 03:29:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CZf8nZkBMh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RXjz1wHT",
      "display_url" : "pastebin.com\/raw.php?i=RXjz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437790800412307456",
  "text" : "http:\/\/t.co\/CZf8nZkBMh Emails: 347 Keywords: 0.19 #infoleak",
  "id" : 437790800412307456,
  "created_at" : "2014-02-24 03:27:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/70XwPgzgs2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BqqxG2yq",
      "display_url" : "pastebin.com\/raw.php?i=Bqqx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437775547393773569",
  "text" : "http:\/\/t.co\/70XwPgzgs2 Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 437775547393773569,
  "created_at" : "2014-02-24 02:26:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QASVSlNAO5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J1HgG4fq",
      "display_url" : "pastebin.com\/raw.php?i=J1Hg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437773539056173056",
  "text" : "http:\/\/t.co\/QASVSlNAO5 Found possible Google API key(s) #infoleak",
  "id" : 437773539056173056,
  "created_at" : "2014-02-24 02:18:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R8uLCyj8Gq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x4NVF4nt",
      "display_url" : "pastebin.com\/raw.php?i=x4NV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437766561747582976",
  "text" : "http:\/\/t.co\/R8uLCyj8Gq Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 437766561747582976,
  "created_at" : "2014-02-24 01:50:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9BZKMzYpQ7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ydg7MLEj",
      "display_url" : "pastebin.com\/raw.php?i=Ydg7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437762150581293056",
  "text" : "http:\/\/t.co\/9BZKMzYpQ7 Emails: 99 Keywords: 0.11 #infoleak",
  "id" : 437762150581293056,
  "created_at" : "2014-02-24 01:33:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dTV36WYJxs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hPPGR9zA",
      "display_url" : "pastebin.com\/raw.php?i=hPPG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437760868856500224",
  "text" : "http:\/\/t.co\/dTV36WYJxs Emails: 50 Keywords: 0.11 #infoleak",
  "id" : 437760868856500224,
  "created_at" : "2014-02-24 01:28:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kWzsG4pfno",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RyQhJKQy",
      "display_url" : "pastebin.com\/raw.php?i=RyQh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437757904054009856",
  "text" : "http:\/\/t.co\/kWzsG4pfno Found possible Google API key(s) #infoleak",
  "id" : 437757904054009856,
  "created_at" : "2014-02-24 01:16:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y3yRyC4JGN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z3Xs6wyh",
      "display_url" : "pastebin.com\/raw.php?i=Z3Xs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437756063169773568",
  "text" : "http:\/\/t.co\/y3yRyC4JGN Emails: 240 Keywords: 0.33 #infoleak",
  "id" : 437756063169773568,
  "created_at" : "2014-02-24 01:09:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OnmNmohpWz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A20NYatB",
      "display_url" : "pastebin.com\/raw.php?i=A20N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437751458520260608",
  "text" : "http:\/\/t.co\/OnmNmohpWz Hashes: 50 Keywords: -0.06 #infoleak",
  "id" : 437751458520260608,
  "created_at" : "2014-02-24 00:50:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oVR661fi7I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rLWbHbYT",
      "display_url" : "pastebin.com\/raw.php?i=rLWb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437750233825427456",
  "text" : "http:\/\/t.co\/oVR661fi7I Emails: 85 Keywords: 0.0 #infoleak",
  "id" : 437750233825427456,
  "created_at" : "2014-02-24 00:46:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WceHbSd6vD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cb0vSsKG",
      "display_url" : "pastebin.com\/raw.php?i=cb0v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437750170264944640",
  "text" : "http:\/\/t.co\/WceHbSd6vD Emails: 34 Keywords: 0.11 #infoleak",
  "id" : 437750170264944640,
  "created_at" : "2014-02-24 00:45:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/72naxUIadD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3PqqN0bZ",
      "display_url" : "pastebin.com\/raw.php?i=3Pqq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437749455928836096",
  "text" : "http:\/\/t.co\/72naxUIadD Emails: 519 Keywords: 0.0 #infoleak",
  "id" : 437749455928836096,
  "created_at" : "2014-02-24 00:42:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/butRn6FRT3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=su97YWgJ",
      "display_url" : "pastebin.com\/raw.php?i=su97\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437747944897257472",
  "text" : "http:\/\/t.co\/butRn6FRT3 Emails: 519 Keywords: 0.0 #infoleak",
  "id" : 437747944897257472,
  "created_at" : "2014-02-24 00:36:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YMuBrNOqIt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pwnVCdQD",
      "display_url" : "pastebin.com\/raw.php?i=pwnV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437745767663419392",
  "text" : "http:\/\/t.co\/YMuBrNOqIt Found possible Google API key(s) #infoleak",
  "id" : 437745767663419392,
  "created_at" : "2014-02-24 00:28:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AZh4tJB0Sq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SDergetD",
      "display_url" : "pastebin.com\/raw.php?i=SDer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437734220228616192",
  "text" : "http:\/\/t.co\/AZh4tJB0Sq Emails: 24 Keywords: 0.11 #infoleak",
  "id" : 437734220228616192,
  "created_at" : "2014-02-23 23:42:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JNEziVZ01u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZW6nemTN",
      "display_url" : "pastebin.com\/raw.php?i=ZW6n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437728234130513920",
  "text" : "http:\/\/t.co\/JNEziVZ01u Found possible Google API key(s) #infoleak",
  "id" : 437728234130513920,
  "created_at" : "2014-02-23 23:18:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WXjNIYz9PU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mm6PxR6E",
      "display_url" : "pastebin.com\/raw.php?i=mm6P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437721909547892736",
  "text" : "http:\/\/t.co\/WXjNIYz9PU Emails: 7 Hashes: 4 E\/H: 1.75 Keywords: 0.77 #infoleak",
  "id" : 437721909547892736,
  "created_at" : "2014-02-23 22:53:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HkVIMEtR3P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kE90y8dK",
      "display_url" : "pastebin.com\/raw.php?i=kE90\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437710686752227328",
  "text" : "http:\/\/t.co\/HkVIMEtR3P Emails: 49 Keywords: 0.44 #infoleak",
  "id" : 437710686752227328,
  "created_at" : "2014-02-23 22:08:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OzGswtyX9r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NFv9LM0L",
      "display_url" : "pastebin.com\/raw.php?i=NFv9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437709881949159425",
  "text" : "http:\/\/t.co\/OzGswtyX9r Emails: 49 Keywords: 0.33 #infoleak",
  "id" : 437709881949159425,
  "created_at" : "2014-02-23 22:05:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nT6O5z14Jn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qQQzsnaN",
      "display_url" : "pastebin.com\/raw.php?i=qQQz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437708963602116608",
  "text" : "http:\/\/t.co\/nT6O5z14Jn Emails: 49 Keywords: 0.33 #infoleak",
  "id" : 437708963602116608,
  "created_at" : "2014-02-23 22:02:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QKqtpi3eRS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jVLj6VKW",
      "display_url" : "pastebin.com\/raw.php?i=jVLj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437706480746106880",
  "text" : "http:\/\/t.co\/QKqtpi3eRS Emails: 7 Hashes: 125 E\/H: 0.06 Keywords: 0.19 #infoleak",
  "id" : 437706480746106880,
  "created_at" : "2014-02-23 21:52:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wXBaAVdSrc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UkH6aFeg",
      "display_url" : "pastebin.com\/raw.php?i=UkH6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437698828058099712",
  "text" : "http:\/\/t.co\/wXBaAVdSrc Emails: 35 Keywords: -0.03 #infoleak",
  "id" : 437698828058099712,
  "created_at" : "2014-02-23 21:21:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qqhcVRZY40",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xFzm4uub",
      "display_url" : "pastebin.com\/raw.php?i=xFzm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437693922878304256",
  "text" : "http:\/\/t.co\/qqhcVRZY40 Emails: 27 Keywords: 0.11 #infoleak",
  "id" : 437693922878304256,
  "created_at" : "2014-02-23 21:02:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8CTkHSQRO9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xNPW46jj",
      "display_url" : "pastebin.com\/raw.php?i=xNPW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437515744176132096",
  "text" : "http:\/\/t.co\/8CTkHSQRO9 Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.55 #infoleak",
  "id" : 437515744176132096,
  "created_at" : "2014-02-23 09:14:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/34W1qQExcZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P3uLRmyH",
      "display_url" : "pastebin.com\/raw.php?i=P3uL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437514950232141824",
  "text" : "http:\/\/t.co\/34W1qQExcZ Emails: 91 Keywords: 0.22 #infoleak",
  "id" : 437514950232141824,
  "created_at" : "2014-02-23 09:11:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xZ9Lj9SW1h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yeNB8z98",
      "display_url" : "pastebin.com\/raw.php?i=yeNB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437465325370474496",
  "text" : "http:\/\/t.co\/xZ9Lj9SW1h Found possible Google API key(s) #infoleak",
  "id" : 437465325370474496,
  "created_at" : "2014-02-23 05:53:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mtGi4YlKsi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Pp29F3fJ",
      "display_url" : "pastebin.com\/raw.php?i=Pp29\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437323024585347072",
  "text" : "http:\/\/t.co\/mtGi4YlKsi Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 437323024585347072,
  "created_at" : "2014-02-22 20:28:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ofqzlnAJrX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3XZP9j4Y",
      "display_url" : "pastebin.com\/raw.php?i=3XZP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437311959550005250",
  "text" : "http:\/\/t.co\/ofqzlnAJrX Hashes: 681 Keywords: 0.0 #infoleak",
  "id" : 437311959550005250,
  "created_at" : "2014-02-22 19:44:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GCWSo0ZmRK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4eGdMDXx",
      "display_url" : "pastebin.com\/raw.php?i=4eGd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437304885785018369",
  "text" : "http:\/\/t.co\/GCWSo0ZmRK Emails: 5 Hashes: 44 E\/H: 0.11 Keywords: 0.22 #infoleak",
  "id" : 437304885785018369,
  "created_at" : "2014-02-22 19:16:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j2vIBN5PeJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N5vzBqux",
      "display_url" : "pastebin.com\/raw.php?i=N5vz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437303398245744640",
  "text" : "http:\/\/t.co\/j2vIBN5PeJ Emails: 7858 Keywords: 0.22 #infoleak",
  "id" : 437303398245744640,
  "created_at" : "2014-02-22 19:10:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4534KwBhVc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7mX0qDWG",
      "display_url" : "pastebin.com\/raw.php?i=7mX0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437288435213017088",
  "text" : "http:\/\/t.co\/4534KwBhVc Emails: 2232 Hashes: 27 E\/H: 82.67 Keywords: 0.22 #infoleak",
  "id" : 437288435213017088,
  "created_at" : "2014-02-22 18:11:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ajt4gruNAs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BCi8VE2m",
      "display_url" : "pastebin.com\/raw.php?i=BCi8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437271511808737280",
  "text" : "http:\/\/t.co\/ajt4gruNAs Hashes: 135 Keywords: 0.11 #infoleak",
  "id" : 437271511808737280,
  "created_at" : "2014-02-22 17:03:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HrrUnSRPm2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ixXR2J2F",
      "display_url" : "pastebin.com\/raw.php?i=ixXR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437251252934565889",
  "text" : "http:\/\/t.co\/HrrUnSRPm2 Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 437251252934565889,
  "created_at" : "2014-02-22 15:43:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0e6293sbNm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kZy0auZx",
      "display_url" : "pastebin.com\/raw.php?i=kZy0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437243675320397824",
  "text" : "http:\/\/t.co\/0e6293sbNm Emails: 540 Hashes: 600 E\/H: 0.9 Keywords: -0.03 #infoleak",
  "id" : 437243675320397824,
  "created_at" : "2014-02-22 15:13:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/80IRPuJSNp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ysd7B5Hh",
      "display_url" : "pastebin.com\/raw.php?i=Ysd7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437242100887719936",
  "text" : "http:\/\/t.co\/80IRPuJSNp Emails: 480 Hashes: 489 E\/H: 0.98 Keywords: 0.08 #infoleak",
  "id" : 437242100887719936,
  "created_at" : "2014-02-22 15:06:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rZLnUwom6B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FEYP7abN",
      "display_url" : "pastebin.com\/raw.php?i=FEYP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437241507423072256",
  "text" : "http:\/\/t.co\/rZLnUwom6B Emails: 125 Hashes: 133 E\/H: 0.94 Keywords: 0.41 #infoleak",
  "id" : 437241507423072256,
  "created_at" : "2014-02-22 15:04:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0t7r5BWp3C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0Gjz38jS",
      "display_url" : "pastebin.com\/raw.php?i=0Gjz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437230949068070912",
  "text" : "http:\/\/t.co\/0t7r5BWp3C Found possible Google API key(s) #infoleak",
  "id" : 437230949068070912,
  "created_at" : "2014-02-22 14:22:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ia0IdDrmaW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uQW8tzr2",
      "display_url" : "pastebin.com\/raw.php?i=uQW8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437225218717650944",
  "text" : "http:\/\/t.co\/ia0IdDrmaW Hashes: 30 Keywords: 0.22 #infoleak",
  "id" : 437225218717650944,
  "created_at" : "2014-02-22 13:59:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TGdJCMxihy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5TLgn163",
      "display_url" : "pastebin.com\/raw.php?i=5TLg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437223996535209986",
  "text" : "http:\/\/t.co\/TGdJCMxihy Hashes: 2001 Keywords: 0.05 #infoleak",
  "id" : 437223996535209986,
  "created_at" : "2014-02-22 13:54:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e8lGKzNzPh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ExdPFzZz",
      "display_url" : "pastebin.com\/raw.php?i=ExdP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437220788433743872",
  "text" : "http:\/\/t.co\/e8lGKzNzPh Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 437220788433743872,
  "created_at" : "2014-02-22 13:42:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lxW1AjjLEr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2yrtCaWV",
      "display_url" : "pastebin.com\/raw.php?i=2yrt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437208351563194369",
  "text" : "http:\/\/t.co\/lxW1AjjLEr Emails: 290 Keywords: 0.0 #infoleak",
  "id" : 437208351563194369,
  "created_at" : "2014-02-22 12:52:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/odjV7yvINB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YcJnknfW",
      "display_url" : "pastebin.com\/raw.php?i=YcJn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437196456995196928",
  "text" : "http:\/\/t.co\/odjV7yvINB Emails: 74 Keywords: 0.11 #infoleak",
  "id" : 437196456995196928,
  "created_at" : "2014-02-22 12:05:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bf9KM8c2FG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HPTGmEpU",
      "display_url" : "pastebin.com\/raw.php?i=HPTG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437184564553740288",
  "text" : "http:\/\/t.co\/Bf9KM8c2FG Emails: 254 Keywords: 0.33 #infoleak",
  "id" : 437184564553740288,
  "created_at" : "2014-02-22 11:18:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1K6NP2YTfZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LZE2AZHD",
      "display_url" : "pastebin.com\/raw.php?i=LZE2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437182716266557440",
  "text" : "http:\/\/t.co\/1K6NP2YTfZ Emails: 3 Hashes: 1 E\/H: 3.0 Keywords: 0.55 #infoleak",
  "id" : 437182716266557440,
  "created_at" : "2014-02-22 11:10:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pY6iDoMOB9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GwkuXx9B",
      "display_url" : "pastebin.com\/raw.php?i=Gwku\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437181337850490880",
  "text" : "http:\/\/t.co\/pY6iDoMOB9 Found possible Google API key(s) #infoleak",
  "id" : 437181337850490880,
  "created_at" : "2014-02-22 11:05:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gn3mYTsbeZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LeN0nF1R",
      "display_url" : "pastebin.com\/raw.php?i=LeN0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437179377134997504",
  "text" : "http:\/\/t.co\/gn3mYTsbeZ Emails: 67 Keywords: -0.03 #infoleak",
  "id" : 437179377134997504,
  "created_at" : "2014-02-22 10:57:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9nSOJiLpCn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K4D8jY6z",
      "display_url" : "pastebin.com\/raw.php?i=K4D8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437169308720852993",
  "text" : "http:\/\/t.co\/9nSOJiLpCn Emails: 43 Keywords: -0.03 #infoleak",
  "id" : 437169308720852993,
  "created_at" : "2014-02-22 10:17:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eIOY6BGLP9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C1b4JLZG",
      "display_url" : "pastebin.com\/raw.php?i=C1b4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437168399060193280",
  "text" : "http:\/\/t.co\/eIOY6BGLP9 Possible cisco configuration #infoleak",
  "id" : 437168399060193280,
  "created_at" : "2014-02-22 10:14:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nV5ANoiNSJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pD4GvD5n",
      "display_url" : "pastebin.com\/raw.php?i=pD4G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437161628950224897",
  "text" : "http:\/\/t.co\/nV5ANoiNSJ Hashes: 53 Keywords: 0.11 #infoleak",
  "id" : 437161628950224897,
  "created_at" : "2014-02-22 09:47:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QXixcHPLtC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dJnaeW6M",
      "display_url" : "pastebin.com\/raw.php?i=dJna\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437142939551023104",
  "text" : "http:\/\/t.co\/QXixcHPLtC Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 437142939551023104,
  "created_at" : "2014-02-22 08:32:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SSX8lEXg7t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gW05vjx5",
      "display_url" : "pastebin.com\/raw.php?i=gW05\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437141933912113152",
  "text" : "http:\/\/t.co\/SSX8lEXg7t Emails: 238 Hashes: 6 E\/H: 39.67 Keywords: 0.0 #infoleak",
  "id" : 437141933912113152,
  "created_at" : "2014-02-22 08:28:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Sr0LoLPYcg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=anDwJCCz",
      "display_url" : "pastebin.com\/raw.php?i=anDw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437078210182799360",
  "text" : "http:\/\/t.co\/Sr0LoLPYcg Hashes: 41 Keywords: 0.0 #infoleak",
  "id" : 437078210182799360,
  "created_at" : "2014-02-22 04:15:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pwQbsYH6K3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MHEbMBR1",
      "display_url" : "pastebin.com\/raw.php?i=MHEb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437070825829588993",
  "text" : "http:\/\/t.co\/pwQbsYH6K3 Emails: 630 Hashes: 19 E\/H: 33.16 Keywords: 0.77 #infoleak",
  "id" : 437070825829588993,
  "created_at" : "2014-02-22 03:46:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oSr9mhuXcu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zvrXafxC",
      "display_url" : "pastebin.com\/raw.php?i=zvrX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437068005671833601",
  "text" : "http:\/\/t.co\/oSr9mhuXcu Emails: 495 Keywords: 0.0 #infoleak",
  "id" : 437068005671833601,
  "created_at" : "2014-02-22 03:35:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ntnjkclfkf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cXvMMj77",
      "display_url" : "pastebin.com\/raw.php?i=cXvM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437066949504163841",
  "text" : "http:\/\/t.co\/ntnjkclfkf Emails: 497 Keywords: 0.0 #infoleak",
  "id" : 437066949504163841,
  "created_at" : "2014-02-22 03:30:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YRIz5q13tI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8gv7SYUY",
      "display_url" : "pastebin.com\/raw.php?i=8gv7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437056658691198979",
  "text" : "http:\/\/t.co\/YRIz5q13tI Emails: 81 Keywords: 0.0 #infoleak",
  "id" : 437056658691198979,
  "created_at" : "2014-02-22 02:50:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WseN33NN0d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GabYMTJs",
      "display_url" : "pastebin.com\/raw.php?i=GabY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437048672186929153",
  "text" : "http:\/\/t.co\/WseN33NN0d Emails: 499 Keywords: 0.0 #infoleak",
  "id" : 437048672186929153,
  "created_at" : "2014-02-22 02:18:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jcFOu0YH7J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=67dATw5R",
      "display_url" : "pastebin.com\/raw.php?i=67dA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437048058677690369",
  "text" : "http:\/\/t.co\/jcFOu0YH7J Emails: 1183 Keywords: 0.44 #infoleak",
  "id" : 437048058677690369,
  "created_at" : "2014-02-22 02:15:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T1JyNlrI77",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Aa8RSVhi",
      "display_url" : "pastebin.com\/raw.php?i=Aa8R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437043924259975168",
  "text" : "http:\/\/t.co\/T1JyNlrI77 Emails: 396 Keywords: 0.44 #infoleak",
  "id" : 437043924259975168,
  "created_at" : "2014-02-22 01:59:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FCUYW93iaA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KREbEUTb",
      "display_url" : "pastebin.com\/raw.php?i=KREb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437042507088539648",
  "text" : "http:\/\/t.co\/FCUYW93iaA Emails: 160 Keywords: 0.44 #infoleak",
  "id" : 437042507088539648,
  "created_at" : "2014-02-22 01:53:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lN0MY7lBSn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QRT7hdss",
      "display_url" : "pastebin.com\/raw.php?i=QRT7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437030477862420480",
  "text" : "http:\/\/t.co\/lN0MY7lBSn Found possible Google API key(s) #infoleak",
  "id" : 437030477862420480,
  "created_at" : "2014-02-22 01:06:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mTHcmNGl9P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aqNHhDs4",
      "display_url" : "pastebin.com\/raw.php?i=aqNH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437013362551975936",
  "text" : "http:\/\/t.co\/mTHcmNGl9P Emails: 94 Keywords: 0.22 #infoleak",
  "id" : 437013362551975936,
  "created_at" : "2014-02-21 23:57:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xLJwKnpom1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PeHFdPiR",
      "display_url" : "pastebin.com\/raw.php?i=PeHF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437007917183545344",
  "text" : "http:\/\/t.co\/xLJwKnpom1 Hashes: 43 Keywords: 0.05 #infoleak",
  "id" : 437007917183545344,
  "created_at" : "2014-02-21 23:36:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BcEaIA2ANr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CGbfGQuN",
      "display_url" : "pastebin.com\/raw.php?i=CGbf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436995247898247168",
  "text" : "http:\/\/t.co\/BcEaIA2ANr Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 436995247898247168,
  "created_at" : "2014-02-21 22:46:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B8p5VJmUnZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3r5bWr8W",
      "display_url" : "pastebin.com\/raw.php?i=3r5b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436994826618155008",
  "text" : "http:\/\/t.co\/B8p5VJmUnZ Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 436994826618155008,
  "created_at" : "2014-02-21 22:44:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OROP402y8N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zUtEwt4t",
      "display_url" : "pastebin.com\/raw.php?i=zUtE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436994276832976896",
  "text" : "http:\/\/t.co\/OROP402y8N Emails: 3565 Keywords: 0.22 #infoleak",
  "id" : 436994276832976896,
  "created_at" : "2014-02-21 22:42:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hmiKSDrYiR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=68sQhGgv",
      "display_url" : "pastebin.com\/raw.php?i=68sQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436993927451652096",
  "text" : "http:\/\/t.co\/hmiKSDrYiR Emails: 46 Keywords: 0.0 #infoleak",
  "id" : 436993927451652096,
  "created_at" : "2014-02-21 22:40:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c3gBwY2mpD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i3vDSph7",
      "display_url" : "pastebin.com\/raw.php?i=i3vD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436992722780446720",
  "text" : "http:\/\/t.co\/c3gBwY2mpD Emails: 51 Keywords: 0.0 #infoleak",
  "id" : 436992722780446720,
  "created_at" : "2014-02-21 22:35:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4DbXxPBaec",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PztSyhX6",
      "display_url" : "pastebin.com\/raw.php?i=PztS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436989532844478464",
  "text" : "http:\/\/t.co\/4DbXxPBaec Emails: 45 Keywords: 0.0 #infoleak",
  "id" : 436989532844478464,
  "created_at" : "2014-02-21 22:23:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CaG56m4jvM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d7Kk2TRj",
      "display_url" : "pastebin.com\/raw.php?i=d7Kk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436985739696295937",
  "text" : "http:\/\/t.co\/CaG56m4jvM Emails: 41 Hashes: 1 E\/H: 41.0 Keywords: 0.44 #infoleak",
  "id" : 436985739696295937,
  "created_at" : "2014-02-21 22:08:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8s5cn5fpzh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UJgtZKdM",
      "display_url" : "pastebin.com\/raw.php?i=UJgt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436969925723176960",
  "text" : "http:\/\/t.co\/8s5cn5fpzh Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 436969925723176960,
  "created_at" : "2014-02-21 21:05:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ptc4FGlyFK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=L16dEuHH",
      "display_url" : "pastebin.com\/raw.php?i=L16d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436969712749010945",
  "text" : "http:\/\/t.co\/Ptc4FGlyFK Found possible Google API key(s) #infoleak",
  "id" : 436969712749010945,
  "created_at" : "2014-02-21 21:04:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3anfAniuHO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MvdXYa9E",
      "display_url" : "pastebin.com\/raw.php?i=MvdX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436969527264288768",
  "text" : "http:\/\/t.co\/3anfAniuHO Hashes: 66 Keywords: -0.03 #infoleak",
  "id" : 436969527264288768,
  "created_at" : "2014-02-21 21:03:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CxyPsMJUl2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SwhCAS6G",
      "display_url" : "pastebin.com\/raw.php?i=SwhC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436966537325342720",
  "text" : "http:\/\/t.co\/CxyPsMJUl2 Found possible Google API key(s) #infoleak",
  "id" : 436966537325342720,
  "created_at" : "2014-02-21 20:51:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/38DgKrBta6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PG3gyMe8",
      "display_url" : "pastebin.com\/raw.php?i=PG3g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436964587242418176",
  "text" : "http:\/\/t.co\/38DgKrBta6 Hashes: 40 Keywords: 0.22 #infoleak",
  "id" : 436964587242418176,
  "created_at" : "2014-02-21 20:44:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OxyYTLBHiN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nrdw2f56",
      "display_url" : "pastebin.com\/raw.php?i=nrdw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436963054262038528",
  "text" : "http:\/\/t.co\/OxyYTLBHiN Found possible Google API key(s) #infoleak",
  "id" : 436963054262038528,
  "created_at" : "2014-02-21 20:38:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AOogc0nnjA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=57e8H988",
      "display_url" : "pastebin.com\/raw.php?i=57e8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436954655742885888",
  "text" : "http:\/\/t.co\/AOogc0nnjA Hashes: 4 Keywords: 0.88 #infoleak",
  "id" : 436954655742885888,
  "created_at" : "2014-02-21 20:04:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oJOk1W8wGq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DbjJnp8u",
      "display_url" : "pastebin.com\/raw.php?i=DbjJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436951224894496768",
  "text" : "http:\/\/t.co\/oJOk1W8wGq Found possible Google API key(s) #infoleak",
  "id" : 436951224894496768,
  "created_at" : "2014-02-21 19:51:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hxDKthUjvm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E5dscz29",
      "display_url" : "pastebin.com\/raw.php?i=E5ds\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436943013349056512",
  "text" : "http:\/\/t.co\/hxDKthUjvm Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 436943013349056512,
  "created_at" : "2014-02-21 19:18:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FJ8t5zAPnd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7RgRXpRV",
      "display_url" : "pastebin.com\/raw.php?i=7RgR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436937236399935488",
  "text" : "http:\/\/t.co\/FJ8t5zAPnd Emails: 50 Keywords: 0.08 #infoleak",
  "id" : 436937236399935488,
  "created_at" : "2014-02-21 18:55:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gDkK8jnRF4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6yar1zyB",
      "display_url" : "pastebin.com\/raw.php?i=6yar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436935405762383872",
  "text" : "http:\/\/t.co\/gDkK8jnRF4 Emails: 50 Keywords: 0.11 #infoleak",
  "id" : 436935405762383872,
  "created_at" : "2014-02-21 18:48:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6O1lMFXLHJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q3wZygen",
      "display_url" : "pastebin.com\/raw.php?i=Q3wZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436934480423436288",
  "text" : "http:\/\/t.co\/6O1lMFXLHJ Hashes: 39 Keywords: 0.05 #infoleak",
  "id" : 436934480423436288,
  "created_at" : "2014-02-21 18:44:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LC5TXCl2lQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Rf39TRcQ",
      "display_url" : "pastebin.com\/raw.php?i=Rf39\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436933820151889920",
  "text" : "http:\/\/t.co\/LC5TXCl2lQ Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 436933820151889920,
  "created_at" : "2014-02-21 18:41:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UzqarCL8Mq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dUbaHsbP",
      "display_url" : "pastebin.com\/raw.php?i=dUba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436933632502927360",
  "text" : "http:\/\/t.co\/UzqarCL8Mq Emails: 22 Keywords: 0.33 #infoleak",
  "id" : 436933632502927360,
  "created_at" : "2014-02-21 18:41:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5BpaOH8iyC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BgUdu5rx",
      "display_url" : "pastebin.com\/raw.php?i=BgUd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436931553025732608",
  "text" : "http:\/\/t.co\/5BpaOH8iyC Emails: 74 Keywords: 0.0 #infoleak",
  "id" : 436931553025732608,
  "created_at" : "2014-02-21 18:32:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Pw9V9xO0Rl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KD7SjyCG",
      "display_url" : "pastebin.com\/raw.php?i=KD7S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436924449950932992",
  "text" : "http:\/\/t.co\/Pw9V9xO0Rl Hashes: 176 Keywords: 0.3 #infoleak",
  "id" : 436924449950932992,
  "created_at" : "2014-02-21 18:04:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xz4krH5frk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vd9Un55u",
      "display_url" : "pastebin.com\/raw.php?i=vd9U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436922135466872832",
  "text" : "http:\/\/t.co\/Xz4krH5frk Emails: 74 Keywords: 0.0 #infoleak",
  "id" : 436922135466872832,
  "created_at" : "2014-02-21 17:55:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hmdlDgqn8p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vxP38DUv",
      "display_url" : "pastebin.com\/raw.php?i=vxP3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436901769608589312",
  "text" : "http:\/\/t.co\/hmdlDgqn8p Hashes: 528 Keywords: 0.08 #infoleak",
  "id" : 436901769608589312,
  "created_at" : "2014-02-21 16:34:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HEhaHIlJfe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jt7GD8pv",
      "display_url" : "pastebin.com\/raw.php?i=Jt7G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436736654628225024",
  "text" : "http:\/\/t.co\/HEhaHIlJfe Emails: 95 Keywords: 0.55 #infoleak",
  "id" : 436736654628225024,
  "created_at" : "2014-02-21 05:38:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9MQ5SXodUd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9VTX47Gy",
      "display_url" : "pastebin.com\/raw.php?i=9VTX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436735271191597056",
  "text" : "http:\/\/t.co\/9MQ5SXodUd Found possible Google API key(s) #infoleak",
  "id" : 436735271191597056,
  "created_at" : "2014-02-21 05:32:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TuBtKoFQeq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VJe57MmW",
      "display_url" : "pastebin.com\/raw.php?i=VJe5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436734194882867200",
  "text" : "http:\/\/t.co\/TuBtKoFQeq Emails: 252 Hashes: 256 E\/H: 0.98 Keywords: 0.41 #infoleak",
  "id" : 436734194882867200,
  "created_at" : "2014-02-21 05:28:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qb3ubJIfxw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NngieW3N",
      "display_url" : "pastebin.com\/raw.php?i=Nngi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436731152892567554",
  "text" : "http:\/\/t.co\/Qb3ubJIfxw Emails: 3 Hashes: 75 E\/H: 0.04 Keywords: -0.12 #infoleak",
  "id" : 436731152892567554,
  "created_at" : "2014-02-21 05:16:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DmCfw2nPRk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y49Jn34R",
      "display_url" : "pastebin.com\/raw.php?i=Y49J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436730534782173184",
  "text" : "http:\/\/t.co\/DmCfw2nPRk Hashes: 60 Keywords: 0.0 #infoleak",
  "id" : 436730534782173184,
  "created_at" : "2014-02-21 05:14:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yaE0kF9xZX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1SV6xyPJ",
      "display_url" : "pastebin.com\/raw.php?i=1SV6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436716159090442240",
  "text" : "http:\/\/t.co\/yaE0kF9xZX Emails: 433 Hashes: 434 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 436716159090442240,
  "created_at" : "2014-02-21 04:17:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SnwxslJHqG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ai44BvCK",
      "display_url" : "pastebin.com\/raw.php?i=ai44\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436710806198034432",
  "text" : "http:\/\/t.co\/SnwxslJHqG Found possible Google API key(s) #infoleak",
  "id" : 436710806198034432,
  "created_at" : "2014-02-21 03:55:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WfsvrouGiK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XJvpTQVE",
      "display_url" : "pastebin.com\/raw.php?i=XJvp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436703472193269760",
  "text" : "http:\/\/t.co\/WfsvrouGiK Emails: 3292 Keywords: 0.08 #infoleak",
  "id" : 436703472193269760,
  "created_at" : "2014-02-21 03:26:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aELp1hUVTg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KWjpaq1g",
      "display_url" : "pastebin.com\/raw.php?i=KWjp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436700907418312707",
  "text" : "http:\/\/t.co\/aELp1hUVTg Emails: 25 Hashes: 25 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 436700907418312707,
  "created_at" : "2014-02-21 03:16:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1vw4ZEGRny",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QJQu4Yzm",
      "display_url" : "pastebin.com\/raw.php?i=QJQu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436699874700972032",
  "text" : "http:\/\/t.co\/1vw4ZEGRny Hashes: 378 Keywords: -0.03 #infoleak",
  "id" : 436699874700972032,
  "created_at" : "2014-02-21 03:12:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0hKi2T3Ko9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ikvCE01m",
      "display_url" : "pastebin.com\/raw.php?i=ikvC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436698588916097024",
  "text" : "http:\/\/t.co\/0hKi2T3Ko9 Emails: 86 Keywords: 0.22 #infoleak",
  "id" : 436698588916097024,
  "created_at" : "2014-02-21 03:07:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JVkoxlarLy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7bDsT7ZS",
      "display_url" : "pastebin.com\/raw.php?i=7bDs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436690814404534273",
  "text" : "http:\/\/t.co\/JVkoxlarLy Keywords: 0.55 #infoleak",
  "id" : 436690814404534273,
  "created_at" : "2014-02-21 02:36:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6CfaK4W27e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VWvqpq57",
      "display_url" : "pastebin.com\/raw.php?i=VWvq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436685858867924992",
  "text" : "http:\/\/t.co\/6CfaK4W27e Emails: 497 Keywords: 0.0 #infoleak",
  "id" : 436685858867924992,
  "created_at" : "2014-02-21 02:16:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PS5pgksmd1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2QJVk3vZ",
      "display_url" : "pastebin.com\/raw.php?i=2QJV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436683414582751233",
  "text" : "http:\/\/t.co\/PS5pgksmd1 Emails: 14 Hashes: 386 E\/H: 0.04 Keywords: 0.52 #infoleak",
  "id" : 436683414582751233,
  "created_at" : "2014-02-21 02:06:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4IjasxVfP6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YBJpZ0Ai",
      "display_url" : "pastebin.com\/raw.php?i=YBJp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436681865445904384",
  "text" : "http:\/\/t.co\/4IjasxVfP6 Emails: 1 Hashes: 68 E\/H: 0.01 Keywords: 0.3 #infoleak",
  "id" : 436681865445904384,
  "created_at" : "2014-02-21 02:00:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nuesAVhrkO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S7kanTW2",
      "display_url" : "pastebin.com\/raw.php?i=S7ka\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436681281452011520",
  "text" : "http:\/\/t.co\/nuesAVhrkO Emails: 68 Keywords: 0.0 #infoleak",
  "id" : 436681281452011520,
  "created_at" : "2014-02-21 01:58:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p0TEdOptH1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N5xemk0A",
      "display_url" : "pastebin.com\/raw.php?i=N5xe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436678398283231232",
  "text" : "http:\/\/t.co\/p0TEdOptH1 Emails: 24 Hashes: 1 E\/H: 24.0 Keywords: 0.33 #infoleak",
  "id" : 436678398283231232,
  "created_at" : "2014-02-21 01:46:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/52yZrHTFWl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=275iPW1M",
      "display_url" : "pastebin.com\/raw.php?i=275i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436673826881957889",
  "text" : "http:\/\/t.co\/52yZrHTFWl Emails: 17182 Keywords: -0.03 #infoleak",
  "id" : 436673826881957889,
  "created_at" : "2014-02-21 01:28:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VscK8Qjp5s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8K6kmJ0C",
      "display_url" : "pastebin.com\/raw.php?i=8K6k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436671007844073472",
  "text" : "http:\/\/t.co\/VscK8Qjp5s Hashes: 696 Keywords: 0.05 #infoleak",
  "id" : 436671007844073472,
  "created_at" : "2014-02-21 01:17:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7i6iH1BKsQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mE6Zmyuy",
      "display_url" : "pastebin.com\/raw.php?i=mE6Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436668389608546304",
  "text" : "http:\/\/t.co\/7i6iH1BKsQ Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 436668389608546304,
  "created_at" : "2014-02-21 01:07:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VdRBXJYbGL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zPm9P8qE",
      "display_url" : "pastebin.com\/raw.php?i=zPm9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436668171420848129",
  "text" : "http:\/\/t.co\/VdRBXJYbGL Found possible Google API key(s) #infoleak",
  "id" : 436668171420848129,
  "created_at" : "2014-02-21 01:06:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eZ3tYnT8w3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vnwjsihR",
      "display_url" : "pastebin.com\/raw.php?i=vnwj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436660510147108864",
  "text" : "http:\/\/t.co\/eZ3tYnT8w3 Found possible Google API key(s) #infoleak",
  "id" : 436660510147108864,
  "created_at" : "2014-02-21 00:35:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yJ4AVlmv5T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2H3virw1",
      "display_url" : "pastebin.com\/raw.php?i=2H3v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436656166257438720",
  "text" : "http:\/\/t.co\/yJ4AVlmv5T Hashes: 43 Keywords: -0.06 #infoleak",
  "id" : 436656166257438720,
  "created_at" : "2014-02-21 00:18:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FhS6WHQDqb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z72FRx3J",
      "display_url" : "pastebin.com\/raw.php?i=z72F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436645855123099649",
  "text" : "http:\/\/t.co\/FhS6WHQDqb Found possible Google API key(s) #infoleak",
  "id" : 436645855123099649,
  "created_at" : "2014-02-20 23:37:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nqSPprPTAr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7ge6XJ5j",
      "display_url" : "pastebin.com\/raw.php?i=7ge6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436645594308685824",
  "text" : "http:\/\/t.co\/nqSPprPTAr Emails: 146 Keywords: 0.0 #infoleak",
  "id" : 436645594308685824,
  "created_at" : "2014-02-20 23:36:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HP0R7x6v2M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m0zE8evW",
      "display_url" : "pastebin.com\/raw.php?i=m0zE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436643744545140736",
  "text" : "http:\/\/t.co\/HP0R7x6v2M Emails: 28 Keywords: 0.11 #infoleak",
  "id" : 436643744545140736,
  "created_at" : "2014-02-20 23:29:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qzsjvkPVlt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9udhTKuX",
      "display_url" : "pastebin.com\/raw.php?i=9udh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436639625071706112",
  "text" : "http:\/\/t.co\/qzsjvkPVlt Found possible Google API key(s) #infoleak",
  "id" : 436639625071706112,
  "created_at" : "2014-02-20 23:12:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5qkqGFZDJg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qbit0MPU",
      "display_url" : "pastebin.com\/raw.php?i=Qbit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436633678664318976",
  "text" : "http:\/\/t.co\/5qkqGFZDJg Found possible Google API key(s) #infoleak",
  "id" : 436633678664318976,
  "created_at" : "2014-02-20 22:49:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ph05F3wxm1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S3HCMQv2",
      "display_url" : "pastebin.com\/raw.php?i=S3HC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436607107652001792",
  "text" : "http:\/\/t.co\/ph05F3wxm1 Emails: 22 Keywords: 0.22 #infoleak",
  "id" : 436607107652001792,
  "created_at" : "2014-02-20 21:03:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xpKWoYGP9d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CbTqAtRD",
      "display_url" : "pastebin.com\/raw.php?i=CbTq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436605233964130304",
  "text" : "http:\/\/t.co\/xpKWoYGP9d Emails: 22 Keywords: 0.22 #infoleak",
  "id" : 436605233964130304,
  "created_at" : "2014-02-20 20:56:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jGzfYdKPTY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xG3UDL4Q",
      "display_url" : "pastebin.com\/raw.php?i=xG3U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436588249373343744",
  "text" : "http:\/\/t.co\/jGzfYdKPTY Emails: 1298 Keywords: -0.03 #infoleak",
  "id" : 436588249373343744,
  "created_at" : "2014-02-20 19:48:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jJd3otubmm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0MzFXgYe",
      "display_url" : "pastebin.com\/raw.php?i=0MzF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436552806535675904",
  "text" : "http:\/\/t.co\/jJd3otubmm Emails: 95 Hashes: 1 E\/H: 95.0 Keywords: 0.08 #infoleak",
  "id" : 436552806535675904,
  "created_at" : "2014-02-20 17:27:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SfIeAC1mYN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kMPYJ624",
      "display_url" : "pastebin.com\/raw.php?i=kMPY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436551971089022976",
  "text" : "http:\/\/t.co\/SfIeAC1mYN Emails: 118 Keywords: 0.0 #infoleak",
  "id" : 436551971089022976,
  "created_at" : "2014-02-20 17:24:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T4BYkdnEQo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nqGaU5Mw",
      "display_url" : "pastebin.com\/raw.php?i=nqGa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436549268573147137",
  "text" : "http:\/\/t.co\/T4BYkdnEQo Found possible Google API key(s) #infoleak",
  "id" : 436549268573147137,
  "created_at" : "2014-02-20 17:13:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DHUDg9Qy37",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dVh73DTb",
      "display_url" : "pastebin.com\/raw.php?i=dVh7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436545384270159872",
  "text" : "http:\/\/t.co\/DHUDg9Qy37 Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 436545384270159872,
  "created_at" : "2014-02-20 16:58:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yDavCSz6gb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AKYUCeL1",
      "display_url" : "pastebin.com\/raw.php?i=AKYU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436543895619371008",
  "text" : "http:\/\/t.co\/yDavCSz6gb Emails: 165 Keywords: 0.11 #infoleak",
  "id" : 436543895619371008,
  "created_at" : "2014-02-20 16:52:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/26heEI2zjZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F6zeMV6Q",
      "display_url" : "pastebin.com\/raw.php?i=F6ze\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436543081123307521",
  "text" : "http:\/\/t.co\/26heEI2zjZ Emails: 95 Keywords: 0.0 #infoleak",
  "id" : 436543081123307521,
  "created_at" : "2014-02-20 16:49:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HYoCrDlmQe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TRsZd9P9",
      "display_url" : "pastebin.com\/raw.php?i=TRsZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436537918392266753",
  "text" : "http:\/\/t.co\/HYoCrDlmQe Hashes: 44 Keywords: 0.22 #infoleak",
  "id" : 436537918392266753,
  "created_at" : "2014-02-20 16:28:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CpnzLOu1XR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qwLB3fy0",
      "display_url" : "pastebin.com\/raw.php?i=qwLB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436535322726264832",
  "text" : "http:\/\/t.co\/CpnzLOu1XR Emails: 171 Keywords: 0.0 #infoleak",
  "id" : 436535322726264832,
  "created_at" : "2014-02-20 16:18:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ufNpUjPcQp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3tyddTJr",
      "display_url" : "pastebin.com\/raw.php?i=3tyd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436534716838076416",
  "text" : "http:\/\/t.co\/ufNpUjPcQp Emails: 102 Keywords: 0.11 #infoleak",
  "id" : 436534716838076416,
  "created_at" : "2014-02-20 16:16:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zO5QtCH6tf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xiS4CYKL",
      "display_url" : "pastebin.com\/raw.php?i=xiS4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436435189909041152",
  "text" : "http:\/\/t.co\/zO5QtCH6tf Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 436435189909041152,
  "created_at" : "2014-02-20 09:40:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/It3HoylEWS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e5XMRCxN",
      "display_url" : "pastebin.com\/raw.php?i=e5XM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436434530992275456",
  "text" : "http:\/\/t.co\/It3HoylEWS Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 436434530992275456,
  "created_at" : "2014-02-20 09:37:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LhT6lJ9odd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=77nfpRck",
      "display_url" : "pastebin.com\/raw.php?i=77nf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436428752688381953",
  "text" : "http:\/\/t.co\/LhT6lJ9odd Emails: 24 Keywords: -0.14 #infoleak",
  "id" : 436428752688381953,
  "created_at" : "2014-02-20 09:14:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rh526IokhC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LFi4LY9k",
      "display_url" : "pastebin.com\/raw.php?i=LFi4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436422318290501632",
  "text" : "http:\/\/t.co\/rh526IokhC Emails: 82 Keywords: 0.33 #infoleak",
  "id" : 436422318290501632,
  "created_at" : "2014-02-20 08:49:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aK39sQMwHe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QCYevXJm",
      "display_url" : "pastebin.com\/raw.php?i=QCYe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436421363859853313",
  "text" : "http:\/\/t.co\/aK39sQMwHe Emails: 962 Keywords: 0.0 #infoleak",
  "id" : 436421363859853313,
  "created_at" : "2014-02-20 08:45:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hv91B7vnAG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8w1TVeTr",
      "display_url" : "pastebin.com\/raw.php?i=8w1T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436413044743077888",
  "text" : "http:\/\/t.co\/Hv91B7vnAG Hashes: 63 Keywords: 0.0 #infoleak",
  "id" : 436413044743077888,
  "created_at" : "2014-02-20 08:12:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b0depmmxyM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xJ0Ay8wt",
      "display_url" : "pastebin.com\/raw.php?i=xJ0A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436402937074429952",
  "text" : "http:\/\/t.co\/b0depmmxyM Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 436402937074429952,
  "created_at" : "2014-02-20 07:32:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XNyXFuXhMP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jiMsJbNe",
      "display_url" : "pastebin.com\/raw.php?i=jiMs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436392501398626304",
  "text" : "http:\/\/t.co\/XNyXFuXhMP Found possible Google API key(s) #infoleak",
  "id" : 436392501398626304,
  "created_at" : "2014-02-20 06:50:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PuOHyZGytX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DvYYnbEZ",
      "display_url" : "pastebin.com\/raw.php?i=DvYY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436387965036548096",
  "text" : "http:\/\/t.co\/PuOHyZGytX Emails: 265 Keywords: 0.0 #infoleak",
  "id" : 436387965036548096,
  "created_at" : "2014-02-20 06:32:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l4CYlrPAUJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ec1DAa5X",
      "display_url" : "pastebin.com\/raw.php?i=ec1D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436381344558379008",
  "text" : "http:\/\/t.co\/l4CYlrPAUJ Emails: 1828 Keywords: 0.22 #infoleak",
  "id" : 436381344558379008,
  "created_at" : "2014-02-20 06:06:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I3GEs81504",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i3bPxkZM",
      "display_url" : "pastebin.com\/raw.php?i=i3bP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436378673105477632",
  "text" : "http:\/\/t.co\/I3GEs81504 Emails: 111 Keywords: 0.19 #infoleak",
  "id" : 436378673105477632,
  "created_at" : "2014-02-20 05:55:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QyX0vY6eWu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NvyAkrj9",
      "display_url" : "pastebin.com\/raw.php?i=NvyA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436370486889435136",
  "text" : "http:\/\/t.co\/QyX0vY6eWu Emails: 43 Hashes: 43 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 436370486889435136,
  "created_at" : "2014-02-20 05:23:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F7YkwDWAu4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=57AD09Lq",
      "display_url" : "pastebin.com\/raw.php?i=57AD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436369979303157760",
  "text" : "http:\/\/t.co\/F7YkwDWAu4 Emails: 111 Keywords: 0.0 #infoleak",
  "id" : 436369979303157760,
  "created_at" : "2014-02-20 05:21:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iawAPp6QqR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FJ1G2z8V",
      "display_url" : "pastebin.com\/raw.php?i=FJ1G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436365786081280000",
  "text" : "http:\/\/t.co\/iawAPp6QqR Emails: 1 Hashes: 172 E\/H: 0.01 Keywords: 0.3 #infoleak",
  "id" : 436365786081280000,
  "created_at" : "2014-02-20 05:04:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wbXzaHW6gM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kf1ryy79",
      "display_url" : "pastebin.com\/raw.php?i=kf1r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436351701876867072",
  "text" : "http:\/\/t.co\/wbXzaHW6gM Emails: 38 Keywords: 0.41 #infoleak",
  "id" : 436351701876867072,
  "created_at" : "2014-02-20 04:08:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TNvYRHMeyo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LVkWPEec",
      "display_url" : "pastebin.com\/raw.php?i=LVkW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436341150425702400",
  "text" : "http:\/\/t.co\/TNvYRHMeyo Emails: 42 Keywords: 0.11 #infoleak",
  "id" : 436341150425702400,
  "created_at" : "2014-02-20 03:26:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UlANuY5Vlv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=grba1V8u",
      "display_url" : "pastebin.com\/raw.php?i=grba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436340907936210944",
  "text" : "http:\/\/t.co\/UlANuY5Vlv Emails: 496 Keywords: 0.0 #infoleak",
  "id" : 436340907936210944,
  "created_at" : "2014-02-20 03:25:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M8BSizXqGt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NAeXFnJ7",
      "display_url" : "pastebin.com\/raw.php?i=NAeX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436334720582823937",
  "text" : "http:\/\/t.co\/M8BSizXqGt Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 436334720582823937,
  "created_at" : "2014-02-20 03:01:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/04Jk7XJCDn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LmyyMTWG",
      "display_url" : "pastebin.com\/raw.php?i=Lmyy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436327888489426945",
  "text" : "http:\/\/t.co\/04Jk7XJCDn Emails: 75 Keywords: 0.0 #infoleak",
  "id" : 436327888489426945,
  "created_at" : "2014-02-20 02:34:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VLtcUb67hi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9dJw1zaV",
      "display_url" : "pastebin.com\/raw.php?i=9dJw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436326731285135360",
  "text" : "http:\/\/t.co\/VLtcUb67hi Emails: 496 Keywords: 0.0 #infoleak",
  "id" : 436326731285135360,
  "created_at" : "2014-02-20 02:29:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1HxEVM7e9j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YCDB7kQA",
      "display_url" : "pastebin.com\/raw.php?i=YCDB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436319945861758976",
  "text" : "http:\/\/t.co\/1HxEVM7e9j Emails: 172 Keywords: 0.33 #infoleak",
  "id" : 436319945861758976,
  "created_at" : "2014-02-20 02:02:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y4tg2RvwFr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jn72tGTL",
      "display_url" : "pastebin.com\/raw.php?i=Jn72\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436318971474616322",
  "text" : "http:\/\/t.co\/Y4tg2RvwFr Emails: 496 Keywords: 0.0 #infoleak",
  "id" : 436318971474616322,
  "created_at" : "2014-02-20 01:58:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DoXFw0ixcJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xjLLpyub",
      "display_url" : "pastebin.com\/raw.php?i=xjLL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436314301515567104",
  "text" : "http:\/\/t.co\/DoXFw0ixcJ Emails: 494 Keywords: 0.0 #infoleak",
  "id" : 436314301515567104,
  "created_at" : "2014-02-20 01:40:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X7nfXCU2ua",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XKqMKPAM",
      "display_url" : "pastebin.com\/raw.php?i=XKqM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436309274872922112",
  "text" : "http:\/\/t.co\/X7nfXCU2ua Emails: 429 Keywords: 0.22 #infoleak",
  "id" : 436309274872922112,
  "created_at" : "2014-02-20 01:20:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5KPdD1crVq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DLRaYQ9P",
      "display_url" : "pastebin.com\/raw.php?i=DLRa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436140170891362304",
  "text" : "http:\/\/t.co\/5KPdD1crVq Emails: 27 Keywords: 0.11 #infoleak",
  "id" : 436140170891362304,
  "created_at" : "2014-02-19 14:08:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k3bxgRfsaK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QwMSM4vf",
      "display_url" : "pastebin.com\/raw.php?i=QwMS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436116380283195392",
  "text" : "http:\/\/t.co\/k3bxgRfsaK Emails: 31 Keywords: 0.3 #infoleak",
  "id" : 436116380283195392,
  "created_at" : "2014-02-19 12:33:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KQJx1ZYY6Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YSAaDYj1",
      "display_url" : "pastebin.com\/raw.php?i=YSAa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436116029287067648",
  "text" : "http:\/\/t.co\/KQJx1ZYY6Z Emails: 23 Keywords: 0.22 #infoleak",
  "id" : 436116029287067648,
  "created_at" : "2014-02-19 12:32:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8Q9wJi96st",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8C8JgRX9",
      "display_url" : "pastebin.com\/raw.php?i=8C8J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436114516321923072",
  "text" : "http:\/\/t.co\/8Q9wJi96st Emails: 125 Keywords: 0.22 #infoleak",
  "id" : 436114516321923072,
  "created_at" : "2014-02-19 12:26:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t7xNBgzrfX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XC5i3qaB",
      "display_url" : "pastebin.com\/raw.php?i=XC5i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436106045564264448",
  "text" : "http:\/\/t.co\/t7xNBgzrfX Hashes: 319 Keywords: 0.11 #infoleak",
  "id" : 436106045564264448,
  "created_at" : "2014-02-19 11:52:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2JFz8uboKQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qAFQUPfj",
      "display_url" : "pastebin.com\/raw.php?i=qAFQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436101090241568768",
  "text" : "http:\/\/t.co\/2JFz8uboKQ Emails: 495 Keywords: 0.11 #infoleak",
  "id" : 436101090241568768,
  "created_at" : "2014-02-19 11:32:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0ejlmp1lQu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uHKgcdgB",
      "display_url" : "pastebin.com\/raw.php?i=uHKg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436096217689239552",
  "text" : "http:\/\/t.co\/0ejlmp1lQu Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 436096217689239552,
  "created_at" : "2014-02-19 11:13:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/znQqD1K7kx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9TyDsSR3",
      "display_url" : "pastebin.com\/raw.php?i=9TyD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436094671366782978",
  "text" : "http:\/\/t.co\/znQqD1K7kx Emails: 1469 Hashes: 1471 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 436094671366782978,
  "created_at" : "2014-02-19 11:07:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rFyTXUJWWP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=65D2imke",
      "display_url" : "pastebin.com\/raw.php?i=65D2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436091213452570624",
  "text" : "http:\/\/t.co\/rFyTXUJWWP Emails: 320 Keywords: 0.19 #infoleak",
  "id" : 436091213452570624,
  "created_at" : "2014-02-19 10:53:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iYIBChSDEy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B1yEzpAM",
      "display_url" : "pastebin.com\/raw.php?i=B1yE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436088608097697793",
  "text" : "http:\/\/t.co\/iYIBChSDEy Found possible Google API key(s) #infoleak",
  "id" : 436088608097697793,
  "created_at" : "2014-02-19 10:43:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q0KxSjxQz3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uL2pJ5YW",
      "display_url" : "pastebin.com\/raw.php?i=uL2p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436030571840405504",
  "text" : "http:\/\/t.co\/Q0KxSjxQz3 Emails: 1612 Keywords: 0.11 #infoleak",
  "id" : 436030571840405504,
  "created_at" : "2014-02-19 06:52:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tg2IWyTzJQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SEQ3F18t",
      "display_url" : "pastebin.com\/raw.php?i=SEQ3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436022013904158720",
  "text" : "http:\/\/t.co\/Tg2IWyTzJQ Emails: 243 Keywords: -0.03 #infoleak",
  "id" : 436022013904158720,
  "created_at" : "2014-02-19 06:18:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JcmC1hmNT2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tv9ada5g",
      "display_url" : "pastebin.com\/raw.php?i=tv9a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436021448570707969",
  "text" : "http:\/\/t.co\/JcmC1hmNT2 Emails: 1765 Keywords: 0.08 #infoleak",
  "id" : 436021448570707969,
  "created_at" : "2014-02-19 06:16:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HMwIGGFI6w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ufdYP71F",
      "display_url" : "pastebin.com\/raw.php?i=ufdY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436004081069330432",
  "text" : "http:\/\/t.co\/HMwIGGFI6w Emails: 32 Keywords: 0.22 #infoleak",
  "id" : 436004081069330432,
  "created_at" : "2014-02-19 05:07:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dACH4BExy9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8zB6vHer",
      "display_url" : "pastebin.com\/raw.php?i=8zB6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435993995164909568",
  "text" : "http:\/\/t.co\/dACH4BExy9 Emails: 29 Keywords: 0.11 #infoleak",
  "id" : 435993995164909568,
  "created_at" : "2014-02-19 04:27:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ryZ4i0KMiT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9WYeGpUY",
      "display_url" : "pastebin.com\/raw.php?i=9WYe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435993717602656256",
  "text" : "http:\/\/t.co\/ryZ4i0KMiT Emails: 999 Keywords: 0.22 #infoleak",
  "id" : 435993717602656256,
  "created_at" : "2014-02-19 04:26:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ce6Z0TM1gU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Udx7HT7B",
      "display_url" : "pastebin.com\/raw.php?i=Udx7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435984064718204930",
  "text" : "http:\/\/t.co\/Ce6Z0TM1gU Emails: 544 Keywords: 0.22 #infoleak",
  "id" : 435984064718204930,
  "created_at" : "2014-02-19 03:47:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TMN1BRfJqI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m89TyGKf",
      "display_url" : "pastebin.com\/raw.php?i=m89T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435974919554224129",
  "text" : "http:\/\/t.co\/TMN1BRfJqI Found possible Google API key(s) #infoleak",
  "id" : 435974919554224129,
  "created_at" : "2014-02-19 03:11:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YG9sgvly79",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pD7Na4MJ",
      "display_url" : "pastebin.com\/raw.php?i=pD7N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435972715107729408",
  "text" : "http:\/\/t.co\/YG9sgvly79 Emails: 494 Hashes: 11 E\/H: 44.91 Keywords: 0.08 #infoleak",
  "id" : 435972715107729408,
  "created_at" : "2014-02-19 03:02:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/djpGJJmQTg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fUyRBKA1",
      "display_url" : "pastebin.com\/raw.php?i=fUyR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435965523151433729",
  "text" : "http:\/\/t.co\/djpGJJmQTg Emails: 2 Hashes: 18 E\/H: 0.11 Keywords: 0.63 #infoleak",
  "id" : 435965523151433729,
  "created_at" : "2014-02-19 02:34:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kzu9KmjHZQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=akyybcKU",
      "display_url" : "pastebin.com\/raw.php?i=akyy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435960200231522304",
  "text" : "http:\/\/t.co\/Kzu9KmjHZQ Emails: 243 Keywords: 0.22 #infoleak",
  "id" : 435960200231522304,
  "created_at" : "2014-02-19 02:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0y7WpA5CFA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xBjnzuVn",
      "display_url" : "pastebin.com\/raw.php?i=xBjn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435950756873531393",
  "text" : "http:\/\/t.co\/0y7WpA5CFA Emails: 4960 Keywords: 0.19 #infoleak",
  "id" : 435950756873531393,
  "created_at" : "2014-02-19 01:35:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AsUvve3n1C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6f7giBzN",
      "display_url" : "pastebin.com\/raw.php?i=6f7g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435921133171257344",
  "text" : "http:\/\/t.co\/AsUvve3n1C Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 435921133171257344,
  "created_at" : "2014-02-18 23:37:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qx6Vh0ithj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EFSHqS57",
      "display_url" : "pastebin.com\/raw.php?i=EFSH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435916788421779456",
  "text" : "http:\/\/t.co\/Qx6Vh0ithj Emails: 80 Keywords: 0.0 #infoleak",
  "id" : 435916788421779456,
  "created_at" : "2014-02-18 23:20:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qh8RLTTbI4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6QafsHCQ",
      "display_url" : "pastebin.com\/raw.php?i=6Qaf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435911712777068544",
  "text" : "http:\/\/t.co\/qh8RLTTbI4 Emails: 497 Keywords: 0.0 #infoleak",
  "id" : 435911712777068544,
  "created_at" : "2014-02-18 23:00:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CkvtCIKSCb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KFt8DmbB",
      "display_url" : "pastebin.com\/raw.php?i=KFt8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435911658053984256",
  "text" : "http:\/\/t.co\/CkvtCIKSCb Hashes: 48 Keywords: -0.06 #infoleak",
  "id" : 435911658053984256,
  "created_at" : "2014-02-18 23:00:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YJHOGobhdW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZxPRGika",
      "display_url" : "pastebin.com\/raw.php?i=ZxPR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435907969851486208",
  "text" : "http:\/\/t.co\/YJHOGobhdW Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 435907969851486208,
  "created_at" : "2014-02-18 22:45:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6rAmxp0zzM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UDzzxEDB",
      "display_url" : "pastebin.com\/raw.php?i=UDzz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435904280168382464",
  "text" : "http:\/\/t.co\/6rAmxp0zzM Emails: 182 Keywords: 0.11 #infoleak",
  "id" : 435904280168382464,
  "created_at" : "2014-02-18 22:30:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b0C1LCSWd9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RfbQgYJj",
      "display_url" : "pastebin.com\/raw.php?i=RfbQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435898454414336000",
  "text" : "http:\/\/t.co\/b0C1LCSWd9 Emails: 8 Hashes: 59 E\/H: 0.14 Keywords: 0.66 #infoleak",
  "id" : 435898454414336000,
  "created_at" : "2014-02-18 22:07:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WG8V6grIXT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=81q2vy3z",
      "display_url" : "pastebin.com\/raw.php?i=81q2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435896157940633600",
  "text" : "http:\/\/t.co\/WG8V6grIXT Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 435896157940633600,
  "created_at" : "2014-02-18 21:58:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PMydbqsdRa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Za30Kaud",
      "display_url" : "pastebin.com\/raw.php?i=Za30\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435882735253454848",
  "text" : "http:\/\/t.co\/PMydbqsdRa Found possible Google API key(s) #infoleak",
  "id" : 435882735253454848,
  "created_at" : "2014-02-18 21:05:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/236QMpMPJ9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xP4yycXi",
      "display_url" : "pastebin.com\/raw.php?i=xP4y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435878545068277760",
  "text" : "http:\/\/t.co\/236QMpMPJ9 Emails: 2085 Keywords: 0.33 #infoleak",
  "id" : 435878545068277760,
  "created_at" : "2014-02-18 20:48:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435867785118633984",
  "geo" : { },
  "id_str" : "435878377577132032",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl Been storing the data in a mongo database since the beginning. :) I've been contemplating the best\/most responsible way of sharing.",
  "id" : 435878377577132032,
  "in_reply_to_status_id" : 435867785118633984,
  "created_at" : "2014-02-18 20:47:58 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435865571528568832",
  "geo" : { },
  "id_str" : "435867236633305088",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I've been meaning to compile all the data that I have - but their numbers sound about right.",
  "id" : 435867236633305088,
  "in_reply_to_status_id" : 435865571528568832,
  "created_at" : "2014-02-18 20:03:41 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435865571528568832",
  "geo" : { },
  "id_str" : "435867146900365312",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl Very interesting - Thanks for the heads up!",
  "id" : 435867146900365312,
  "in_reply_to_status_id" : 435865571528568832,
  "created_at" : "2014-02-18 20:03:20 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cTC2dpiZzF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y9trwGyU",
      "display_url" : "pastebin.com\/raw.php?i=Y9tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435863035555495936",
  "text" : "http:\/\/t.co\/cTC2dpiZzF Possible cisco configuration #infoleak",
  "id" : 435863035555495936,
  "created_at" : "2014-02-18 19:47:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fBW4EWrkiq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MSHbgGKN",
      "display_url" : "pastebin.com\/raw.php?i=MSHb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435862015123259392",
  "text" : "http:\/\/t.co\/fBW4EWrkiq Emails: 3169 Keywords: 0.19 #infoleak",
  "id" : 435862015123259392,
  "created_at" : "2014-02-18 19:42:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i7aJup6n6C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9fT3tx3u",
      "display_url" : "pastebin.com\/raw.php?i=9fT3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435861644791394304",
  "text" : "http:\/\/t.co\/i7aJup6n6C Possible cisco configuration #infoleak",
  "id" : 435861644791394304,
  "created_at" : "2014-02-18 19:41:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qAT8Vo7lSw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bKfXn67F",
      "display_url" : "pastebin.com\/raw.php?i=bKfX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435860287552372736",
  "text" : "http:\/\/t.co\/qAT8Vo7lSw Found possible Google API key(s) #infoleak",
  "id" : 435860287552372736,
  "created_at" : "2014-02-18 19:36:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9lL5I8fLOa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BX9QHRyC",
      "display_url" : "pastebin.com\/raw.php?i=BX9Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435858088659132417",
  "text" : "http:\/\/t.co\/9lL5I8fLOa Found possible Google API key(s) #infoleak",
  "id" : 435858088659132417,
  "created_at" : "2014-02-18 19:27:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IQd8oDEMQj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qBXR7D87",
      "display_url" : "pastebin.com\/raw.php?i=qBXR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435849624222310400",
  "text" : "http:\/\/t.co\/IQd8oDEMQj Hashes: 56 Keywords: 0.22 #infoleak",
  "id" : 435849624222310400,
  "created_at" : "2014-02-18 18:53:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mdH53pgiij",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6iunZLJT",
      "display_url" : "pastebin.com\/raw.php?i=6iun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435846337318629376",
  "text" : "http:\/\/t.co\/mdH53pgiij Emails: 26 Keywords: 0.11 #infoleak",
  "id" : 435846337318629376,
  "created_at" : "2014-02-18 18:40:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0LjmtwII1J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qCH5SGFe",
      "display_url" : "pastebin.com\/raw.php?i=qCH5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435844184306900993",
  "text" : "http:\/\/t.co\/0LjmtwII1J Hashes: 37 Keywords: -0.14 #infoleak",
  "id" : 435844184306900993,
  "created_at" : "2014-02-18 18:32:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xZwsCig8gO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iFXjWUvU",
      "display_url" : "pastebin.com\/raw.php?i=iFXj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435837547948675072",
  "text" : "http:\/\/t.co\/xZwsCig8gO Hashes: 221 Keywords: 0.11 #infoleak",
  "id" : 435837547948675072,
  "created_at" : "2014-02-18 18:05:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fd6vusY4tZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WburNycx",
      "display_url" : "pastebin.com\/raw.php?i=Wbur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435832886965440513",
  "text" : "http:\/\/t.co\/Fd6vusY4tZ Found possible Google API key(s) #infoleak",
  "id" : 435832886965440513,
  "created_at" : "2014-02-18 17:47:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/azCLbX4owI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=enDsEZTX",
      "display_url" : "pastebin.com\/raw.php?i=enDs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435828898828271616",
  "text" : "http:\/\/t.co\/azCLbX4owI Emails: 1302 Hashes: 1303 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 435828898828271616,
  "created_at" : "2014-02-18 17:31:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9EZAr3g2jQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=psQhwgRM",
      "display_url" : "pastebin.com\/raw.php?i=psQh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435807946023251969",
  "text" : "http:\/\/t.co\/9EZAr3g2jQ Emails: 265 Keywords: 0.22 #infoleak",
  "id" : 435807946023251969,
  "created_at" : "2014-02-18 16:08:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q98O0b8V4Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kvX423kL",
      "display_url" : "pastebin.com\/raw.php?i=kvX4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435806249922211840",
  "text" : "http:\/\/t.co\/Q98O0b8V4Z Hashes: 114 Keywords: 0.08 #infoleak",
  "id" : 435806249922211840,
  "created_at" : "2014-02-18 16:01:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WYGtgpgxd4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tVgE3BGt",
      "display_url" : "pastebin.com\/raw.php?i=tVgE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435806180959469568",
  "text" : "http:\/\/t.co\/WYGtgpgxd4 Emails: 3 Hashes: 34 E\/H: 0.09 Keywords: 0.05 #infoleak",
  "id" : 435806180959469568,
  "created_at" : "2014-02-18 16:01:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TuC3jhjqKp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VDeQggaP",
      "display_url" : "pastebin.com\/raw.php?i=VDeQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435784634178097152",
  "text" : "http:\/\/t.co\/TuC3jhjqKp Hashes: 35 Keywords: 0.0 #infoleak",
  "id" : 435784634178097152,
  "created_at" : "2014-02-18 14:35:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bHCT43Hwhu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qx1BgdgK",
      "display_url" : "pastebin.com\/raw.php?i=qx1B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434900343915151360",
  "text" : "http:\/\/t.co\/bHCT43Hwhu Emails: 340 Hashes: 2 E\/H: 170.0 Keywords: 0.0 #infoleak",
  "id" : 434900343915151360,
  "created_at" : "2014-02-16 04:01:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/REoUI6LCIH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KdaTATWc",
      "display_url" : "pastebin.com\/raw.php?i=KdaT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434885836325154817",
  "text" : "http:\/\/t.co\/REoUI6LCIH Emails: 175 Keywords: 0.33 #infoleak",
  "id" : 434885836325154817,
  "created_at" : "2014-02-16 03:03:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9yOWVgmFYl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sHwNTidj",
      "display_url" : "pastebin.com\/raw.php?i=sHwN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434881519736213504",
  "text" : "http:\/\/t.co\/9yOWVgmFYl Emails: 48 Keywords: 0.0 #infoleak",
  "id" : 434881519736213504,
  "created_at" : "2014-02-16 02:46:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bEQjokVmQE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z1Ansnzj",
      "display_url" : "pastebin.com\/raw.php?i=Z1An\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434879759525236736",
  "text" : "http:\/\/t.co\/bEQjokVmQE Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 434879759525236736,
  "created_at" : "2014-02-16 02:39:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nTOtlNSTnw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WYxWSASs",
      "display_url" : "pastebin.com\/raw.php?i=WYxW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434868817051676672",
  "text" : "http:\/\/t.co\/nTOtlNSTnw Emails: 100 Keywords: -0.14 #infoleak",
  "id" : 434868817051676672,
  "created_at" : "2014-02-16 01:56:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kpHxyqAR9o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GYEEVkfF",
      "display_url" : "pastebin.com\/raw.php?i=GYEE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434868204389679105",
  "text" : "http:\/\/t.co\/kpHxyqAR9o Emails: 497 Keywords: 0.0 #infoleak",
  "id" : 434868204389679105,
  "created_at" : "2014-02-16 01:53:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HOnNMyEf7x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bg8iG5xj",
      "display_url" : "pastebin.com\/raw.php?i=Bg8i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434867930782642177",
  "text" : "http:\/\/t.co\/HOnNMyEf7x Emails: 492 Keywords: 0.0 #infoleak",
  "id" : 434867930782642177,
  "created_at" : "2014-02-16 01:52:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S5CBjNCZ8f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xh3wCHeU",
      "display_url" : "pastebin.com\/raw.php?i=xh3w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434861393100025856",
  "text" : "http:\/\/t.co\/S5CBjNCZ8f Found possible Google API key(s) #infoleak",
  "id" : 434861393100025856,
  "created_at" : "2014-02-16 01:26:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9Oe4ksnLMq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LPVb5NPy",
      "display_url" : "pastebin.com\/raw.php?i=LPVb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434858262098227200",
  "text" : "http:\/\/t.co\/9Oe4ksnLMq Found possible Google API key(s) #infoleak",
  "id" : 434858262098227200,
  "created_at" : "2014-02-16 01:14:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JkhCho4iaQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9DSg8pff",
      "display_url" : "pastebin.com\/raw.php?i=9DSg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434805216496459776",
  "text" : "http:\/\/t.co\/JkhCho4iaQ Emails: 32 Hashes: 35 E\/H: 0.91 Keywords: 0.22 #infoleak",
  "id" : 434805216496459776,
  "created_at" : "2014-02-15 21:43:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Scd9kiB0dt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AeHF42rz",
      "display_url" : "pastebin.com\/raw.php?i=AeHF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434779488321163264",
  "text" : "http:\/\/t.co\/Scd9kiB0dt Emails: 15 Keywords: 0.66 #infoleak",
  "id" : 434779488321163264,
  "created_at" : "2014-02-15 20:01:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZGJiaAReRx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hJb3y3cg",
      "display_url" : "pastebin.com\/raw.php?i=hJb3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434777313830383616",
  "text" : "http:\/\/t.co\/ZGJiaAReRx Emails: 825 Keywords: 0.22 #infoleak",
  "id" : 434777313830383616,
  "created_at" : "2014-02-15 19:52:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DsFRVv7xFu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NgYYPKb3",
      "display_url" : "pastebin.com\/raw.php?i=NgYY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434766387311935488",
  "text" : "http:\/\/t.co\/DsFRVv7xFu Emails: 500 Keywords: 0.33 #infoleak",
  "id" : 434766387311935488,
  "created_at" : "2014-02-15 19:09:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/20d67ze1qe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NizJBv53",
      "display_url" : "pastebin.com\/raw.php?i=NizJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434761072692572160",
  "text" : "http:\/\/t.co\/20d67ze1qe Emails: 178 Keywords: 0.0 #infoleak",
  "id" : 434761072692572160,
  "created_at" : "2014-02-15 18:48:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vIlSJTPX9u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wyBcAqPu",
      "display_url" : "pastebin.com\/raw.php?i=wyBc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434758291353120768",
  "text" : "http:\/\/t.co\/vIlSJTPX9u Possible cisco configuration #infoleak",
  "id" : 434758291353120768,
  "created_at" : "2014-02-15 18:37:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UjJKdpoLpp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F7zZkLDe",
      "display_url" : "pastebin.com\/raw.php?i=F7zZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434754967283310592",
  "text" : "http:\/\/t.co\/UjJKdpoLpp Emails: 160 Keywords: 0.11 #infoleak",
  "id" : 434754967283310592,
  "created_at" : "2014-02-15 18:23:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/psvOwAERai",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N5tnJXFp",
      "display_url" : "pastebin.com\/raw.php?i=N5tn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434056629021995008",
  "text" : "http:\/\/t.co\/psvOwAERai Hashes: 49 Keywords: -0.09 #infoleak",
  "id" : 434056629021995008,
  "created_at" : "2014-02-13 20:08:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HDwMrK257Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CBgVZesd",
      "display_url" : "pastebin.com\/raw.php?i=CBgV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434053719953383424",
  "text" : "http:\/\/t.co\/HDwMrK257Z Emails: 50 Keywords: 0.11 #infoleak",
  "id" : 434053719953383424,
  "created_at" : "2014-02-13 19:57:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6GUSR49PmV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1gPXGfwe",
      "display_url" : "pastebin.com\/raw.php?i=1gPX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434051197360562176",
  "text" : "http:\/\/t.co\/6GUSR49PmV Emails: 23 Keywords: -0.14 #infoleak",
  "id" : 434051197360562176,
  "created_at" : "2014-02-13 19:47:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SGbNlvujmt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b72CgwPp",
      "display_url" : "pastebin.com\/raw.php?i=b72C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434047728339795968",
  "text" : "http:\/\/t.co\/SGbNlvujmt Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 434047728339795968,
  "created_at" : "2014-02-13 19:33:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tdpO5IRtDi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cZqr2MdN",
      "display_url" : "pastebin.com\/raw.php?i=cZqr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434043712100790272",
  "text" : "http:\/\/t.co\/tdpO5IRtDi Hashes: 96 Keywords: 0.11 #infoleak",
  "id" : 434043712100790272,
  "created_at" : "2014-02-13 19:17:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    }, {
      "name" : "Tesco",
      "screen_name" : "Tesco",
      "indices" : [ 20, 26 ],
      "id_str" : "271986064",
      "id" : 271986064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433719604603392000",
  "geo" : { },
  "id_str" : "433993695356936192",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon Looks like @Tesco may want to look into this.",
  "id" : 433993695356936192,
  "in_reply_to_status_id" : 433719604603392000,
  "created_at" : "2014-02-13 15:58:54 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Afdvx1eD0z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1NC9rQt3",
      "display_url" : "pastebin.com\/raw.php?i=1NC9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433984530156761088",
  "text" : "http:\/\/t.co\/Afdvx1eD0z Emails: 223 Keywords: 0.22 #infoleak",
  "id" : 433984530156761088,
  "created_at" : "2014-02-13 15:22:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LlK8SpmPWZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CsWwRvks",
      "display_url" : "pastebin.com\/raw.php?i=CsWw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433983301146001408",
  "text" : "http:\/\/t.co\/LlK8SpmPWZ Emails: 21 Keywords: 0.08 #infoleak",
  "id" : 433983301146001408,
  "created_at" : "2014-02-13 15:17:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v4MHNrgdyD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V3anaGss",
      "display_url" : "pastebin.com\/raw.php?i=V3an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433982107073789952",
  "text" : "http:\/\/t.co\/v4MHNrgdyD Emails: 1000 Keywords: 0.11 #infoleak",
  "id" : 433982107073789952,
  "created_at" : "2014-02-13 15:12:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WNZGBXkLFh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F3RNQDnu",
      "display_url" : "pastebin.com\/raw.php?i=F3RN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433979593616146433",
  "text" : "http:\/\/t.co\/WNZGBXkLFh Emails: 1404 Keywords: 0.11 #infoleak",
  "id" : 433979593616146433,
  "created_at" : "2014-02-13 15:02:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BTpuOuNREb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HLtQAuuL",
      "display_url" : "pastebin.com\/raw.php?i=HLtQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433944000987291649",
  "text" : "http:\/\/t.co\/BTpuOuNREb Found possible Google API key(s) #infoleak",
  "id" : 433944000987291649,
  "created_at" : "2014-02-13 12:41:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JMDfAuoEsi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z0VQkLcn",
      "display_url" : "pastebin.com\/raw.php?i=Z0VQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433919559817388034",
  "text" : "http:\/\/t.co\/JMDfAuoEsi Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 433919559817388034,
  "created_at" : "2014-02-13 11:04:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JlkYGqVc8o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xbXphZCM",
      "display_url" : "pastebin.com\/raw.php?i=xbXp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433903100965842944",
  "text" : "http:\/\/t.co\/JlkYGqVc8o Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 433903100965842944,
  "created_at" : "2014-02-13 09:58:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rvT3gqpAUf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EXiftTmH",
      "display_url" : "pastebin.com\/raw.php?i=EXif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433890086380249089",
  "text" : "http:\/\/t.co\/rvT3gqpAUf Emails: 5 Hashes: 64 E\/H: 0.08 Keywords: 0.22 #infoleak",
  "id" : 433890086380249089,
  "created_at" : "2014-02-13 09:07:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7Zu6WjNLSS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WxMUK3fp",
      "display_url" : "pastebin.com\/raw.php?i=WxMU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433888626011680768",
  "text" : "http:\/\/t.co\/7Zu6WjNLSS Keywords: 0.55 #infoleak",
  "id" : 433888626011680768,
  "created_at" : "2014-02-13 09:01:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h2RknJuk0K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2L8NKiUw",
      "display_url" : "pastebin.com\/raw.php?i=2L8N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433888340190830593",
  "text" : "http:\/\/t.co\/h2RknJuk0K Emails: 25 Hashes: 25 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 433888340190830593,
  "created_at" : "2014-02-13 09:00:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ux283hf26S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WjrPNhst",
      "display_url" : "pastebin.com\/raw.php?i=WjrP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433888094014537731",
  "text" : "http:\/\/t.co\/Ux283hf26S Emails: 327 Keywords: 0.0 #infoleak",
  "id" : 433888094014537731,
  "created_at" : "2014-02-13 08:59:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mWqgtXPQSE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YevN19xK",
      "display_url" : "pastebin.com\/raw.php?i=YevN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433887868176453632",
  "text" : "http:\/\/t.co\/mWqgtXPQSE Found possible Google API key(s) #infoleak",
  "id" : 433887868176453632,
  "created_at" : "2014-02-13 08:58:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LvSOtUVXoQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5uhy0mMJ",
      "display_url" : "pastebin.com\/raw.php?i=5uhy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433872977570979840",
  "text" : "http:\/\/t.co\/LvSOtUVXoQ Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 433872977570979840,
  "created_at" : "2014-02-13 07:59:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1BBTPijlIM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j4e5tnLe",
      "display_url" : "pastebin.com\/raw.php?i=j4e5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433865106477178880",
  "text" : "http:\/\/t.co\/1BBTPijlIM Found possible Google API key(s) #infoleak",
  "id" : 433865106477178880,
  "created_at" : "2014-02-13 07:27:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PQFGXrxKiD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YnYSe4B5",
      "display_url" : "pastebin.com\/raw.php?i=YnYS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433864590439358464",
  "text" : "http:\/\/t.co\/PQFGXrxKiD Emails: 2524 Keywords: 0.44 #infoleak",
  "id" : 433864590439358464,
  "created_at" : "2014-02-13 07:25:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D8FVf5QD62",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pe0URupa",
      "display_url" : "pastebin.com\/raw.php?i=pe0U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433860062893711360",
  "text" : "http:\/\/t.co\/D8FVf5QD62 Hashes: 47 Keywords: 0.22 #infoleak",
  "id" : 433860062893711360,
  "created_at" : "2014-02-13 07:07:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DbmXjj4Ytb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TzZR5TjE",
      "display_url" : "pastebin.com\/raw.php?i=TzZR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433848522207543298",
  "text" : "http:\/\/t.co\/DbmXjj4Ytb Emails: 32 Keywords: 0.11 #infoleak",
  "id" : 433848522207543298,
  "created_at" : "2014-02-13 06:22:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/31vkiTe00f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q9TMDJXZ",
      "display_url" : "pastebin.com\/raw.php?i=Q9TM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433719604603392000",
  "text" : "http:\/\/t.co\/31vkiTe00f Emails: 2239 Keywords: 0.44 #infoleak",
  "id" : 433719604603392000,
  "created_at" : "2014-02-12 21:49:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KvBLJjoaGk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WdxhHAnW",
      "display_url" : "pastebin.com\/raw.php?i=Wdxh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433709386167369728",
  "text" : "http:\/\/t.co\/KvBLJjoaGk Emails: 733 Keywords: 0.0 #infoleak",
  "id" : 433709386167369728,
  "created_at" : "2014-02-12 21:09:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B7TPCoSJMU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P7aeDLsY",
      "display_url" : "pastebin.com\/raw.php?i=P7ae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433709158911602689",
  "text" : "http:\/\/t.co\/B7TPCoSJMU Hashes: 41 Keywords: 0.11 #infoleak",
  "id" : 433709158911602689,
  "created_at" : "2014-02-12 21:08:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/97G4keK7aK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VXcxN8rB",
      "display_url" : "pastebin.com\/raw.php?i=VXcx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433698690188861441",
  "text" : "http:\/\/t.co\/97G4keK7aK Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 433698690188861441,
  "created_at" : "2014-02-12 20:26:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6Tsf3pwgYd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=igjQiV3Y",
      "display_url" : "pastebin.com\/raw.php?i=igjQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433695246531047424",
  "text" : "http:\/\/t.co\/6Tsf3pwgYd Emails: 9593 Keywords: 0.33 #infoleak",
  "id" : 433695246531047424,
  "created_at" : "2014-02-12 20:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UosMfvHQMl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=neFb4yAT",
      "display_url" : "pastebin.com\/raw.php?i=neFb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433692776236994560",
  "text" : "http:\/\/t.co\/UosMfvHQMl Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 433692776236994560,
  "created_at" : "2014-02-12 20:03:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HWshjY0PQe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qPcJC8j9",
      "display_url" : "pastebin.com\/raw.php?i=qPcJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433674618839109632",
  "text" : "http:\/\/t.co\/HWshjY0PQe Hashes: 41 Keywords: 0.0 #infoleak",
  "id" : 433674618839109632,
  "created_at" : "2014-02-12 18:51:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X45OFNCPGK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xfu5Hxwj",
      "display_url" : "pastebin.com\/raw.php?i=Xfu5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433662368959041536",
  "text" : "http:\/\/t.co\/X45OFNCPGK Emails: 346 Keywords: 0.33 #infoleak",
  "id" : 433662368959041536,
  "created_at" : "2014-02-12 18:02:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SdjbLluPDR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ERR7t9pY",
      "display_url" : "pastebin.com\/raw.php?i=ERR7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433655314609475585",
  "text" : "http:\/\/t.co\/SdjbLluPDR Emails: 703 Keywords: 0.11 #infoleak",
  "id" : 433655314609475585,
  "created_at" : "2014-02-12 17:34:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6ZVEfaYpAB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f5CznM61",
      "display_url" : "pastebin.com\/raw.php?i=f5Cz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433651456298606592",
  "text" : "http:\/\/t.co\/6ZVEfaYpAB Keywords: 0.55 #infoleak",
  "id" : 433651456298606592,
  "created_at" : "2014-02-12 17:18:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z1rSVREAgJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hh2a6CD0",
      "display_url" : "pastebin.com\/raw.php?i=hh2a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433651372097937408",
  "text" : "http:\/\/t.co\/z1rSVREAgJ Emails: 136 Keywords: 0.66 #infoleak",
  "id" : 433651372097937408,
  "created_at" : "2014-02-12 17:18:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KrShiEChJA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G6EM7UnY",
      "display_url" : "pastebin.com\/raw.php?i=G6EM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433650846417424384",
  "text" : "http:\/\/t.co\/KrShiEChJA Keywords: 0.66 #infoleak",
  "id" : 433650846417424384,
  "created_at" : "2014-02-12 17:16:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KXXGFruMMQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=66F4WHs8",
      "display_url" : "pastebin.com\/raw.php?i=66F4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433650539570552832",
  "text" : "http:\/\/t.co\/KXXGFruMMQ Keywords: 0.55 #infoleak",
  "id" : 433650539570552832,
  "created_at" : "2014-02-12 17:15:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4gr22aTVRp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FEMAbm9k",
      "display_url" : "pastebin.com\/raw.php?i=FEMA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433649046087933952",
  "text" : "http:\/\/t.co\/4gr22aTVRp Hashes: 19 Keywords: 0.77 #infoleak",
  "id" : 433649046087933952,
  "created_at" : "2014-02-12 17:09:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D8PfaZdIAE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T3MdteD2",
      "display_url" : "pastebin.com\/raw.php?i=T3Md\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433647776283377664",
  "text" : "http:\/\/t.co\/D8PfaZdIAE Emails: 3542 Keywords: 0.11 #infoleak",
  "id" : 433647776283377664,
  "created_at" : "2014-02-12 17:04:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2WX1ck6Jh3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1uKmxKRA",
      "display_url" : "pastebin.com\/raw.php?i=1uKm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433645734915608577",
  "text" : "http:\/\/t.co\/2WX1ck6Jh3 Emails: 705 Keywords: 0.11 #infoleak",
  "id" : 433645734915608577,
  "created_at" : "2014-02-12 16:56:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G7xra4ejhu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QB5wqzeh",
      "display_url" : "pastebin.com\/raw.php?i=QB5w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433640582993297408",
  "text" : "http:\/\/t.co\/G7xra4ejhu Keywords: 0.55 #infoleak",
  "id" : 433640582993297408,
  "created_at" : "2014-02-12 16:35:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FO0ugMwu76",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cTjJscVr",
      "display_url" : "pastebin.com\/raw.php?i=cTjJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433637998895198208",
  "text" : "http:\/\/t.co\/FO0ugMwu76 Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 433637998895198208,
  "created_at" : "2014-02-12 16:25:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sjkuTXMNaz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zwrp192C",
      "display_url" : "pastebin.com\/raw.php?i=zwrp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433628060877746177",
  "text" : "http:\/\/t.co\/sjkuTXMNaz Emails: 624 Keywords: 0.11 #infoleak",
  "id" : 433628060877746177,
  "created_at" : "2014-02-12 15:46:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/drbxpUCjR0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=79mJY9qY",
      "display_url" : "pastebin.com\/raw.php?i=79mJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433627536010928129",
  "text" : "http:\/\/t.co\/drbxpUCjR0 Emails: 70 Keywords: 0.0 #infoleak",
  "id" : 433627536010928129,
  "created_at" : "2014-02-12 15:43:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mTKganDIJ2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J1hqQxRY",
      "display_url" : "pastebin.com\/raw.php?i=J1hq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433626250716798976",
  "text" : "http:\/\/t.co\/mTKganDIJ2 Emails: 43 Keywords: 0.22 #infoleak",
  "id" : 433626250716798976,
  "created_at" : "2014-02-12 15:38:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uHHSKGFI20",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fwJHBhgr",
      "display_url" : "pastebin.com\/raw.php?i=fwJH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433610625323786242",
  "text" : "http:\/\/t.co\/uHHSKGFI20 Hashes: 78 Keywords: 0.22 #infoleak",
  "id" : 433610625323786242,
  "created_at" : "2014-02-12 14:36:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Axewt1t1IP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uLssU6Ui",
      "display_url" : "pastebin.com\/raw.php?i=uLss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433568347205017601",
  "text" : "http:\/\/t.co\/Axewt1t1IP Found possible Google API key(s) #infoleak",
  "id" : 433568347205017601,
  "created_at" : "2014-02-12 11:48:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zuYceKl9yb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m4RuGUyU",
      "display_url" : "pastebin.com\/raw.php?i=m4Ru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433544803364507648",
  "text" : "http:\/\/t.co\/zuYceKl9yb Emails: 346 Keywords: 0.33 #infoleak",
  "id" : 433544803364507648,
  "created_at" : "2014-02-12 10:15:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ACRAdQe5OR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a213iA9q",
      "display_url" : "pastebin.com\/raw.php?i=a213\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433459946005331968",
  "text" : "http:\/\/t.co\/ACRAdQe5OR Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 433459946005331968,
  "created_at" : "2014-02-12 04:37:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YzVS43gSUQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=76iNBEbj",
      "display_url" : "pastebin.com\/raw.php?i=76iN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433448096618401792",
  "text" : "http:\/\/t.co\/YzVS43gSUQ Hashes: 2109 Keywords: 0.11 #infoleak",
  "id" : 433448096618401792,
  "created_at" : "2014-02-12 03:50:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L4JAeBdYpR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rRR3fA0S",
      "display_url" : "pastebin.com\/raw.php?i=rRR3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433445887440715777",
  "text" : "http:\/\/t.co\/L4JAeBdYpR Hashes: 32 Keywords: 0.22 #infoleak",
  "id" : 433445887440715777,
  "created_at" : "2014-02-12 03:42:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YbNeipZ3OV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3UfMJDNW",
      "display_url" : "pastebin.com\/raw.php?i=3UfM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433428221527212033",
  "text" : "http:\/\/t.co\/YbNeipZ3OV Emails: 860 Keywords: 0.22 #infoleak",
  "id" : 433428221527212033,
  "created_at" : "2014-02-12 02:31:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aWBHUwCNxW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RJ7ApV3t",
      "display_url" : "pastebin.com\/raw.php?i=RJ7A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433426613816934401",
  "text" : "http:\/\/t.co\/aWBHUwCNxW Emails: 674 Keywords: 0.22 #infoleak",
  "id" : 433426613816934401,
  "created_at" : "2014-02-12 02:25:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l4sDm3SOzH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8QchZxEa",
      "display_url" : "pastebin.com\/raw.php?i=8Qch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433426498586808321",
  "text" : "http:\/\/t.co\/l4sDm3SOzH Emails: 193 Keywords: 0.0 #infoleak",
  "id" : 433426498586808321,
  "created_at" : "2014-02-12 02:25:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HckOiMcdKr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uiEjbwxD",
      "display_url" : "pastebin.com\/raw.php?i=uiEj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433422790104866816",
  "text" : "http:\/\/t.co\/HckOiMcdKr Hashes: 36 Keywords: 0.11 #infoleak",
  "id" : 433422790104866816,
  "created_at" : "2014-02-12 02:10:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YHREzTHIyl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JmbYx2Dm",
      "display_url" : "pastebin.com\/raw.php?i=JmbY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433416145274560512",
  "text" : "http:\/\/t.co\/YHREzTHIyl Found possible Google API key(s) #infoleak",
  "id" : 433416145274560512,
  "created_at" : "2014-02-12 01:43:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ENG61r3NYQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PrvMzTA6",
      "display_url" : "pastebin.com\/raw.php?i=PrvM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433416095613992960",
  "text" : "http:\/\/t.co\/ENG61r3NYQ Emails: 4008 Keywords: 0.33 #infoleak",
  "id" : 433416095613992960,
  "created_at" : "2014-02-12 01:43:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0VOBACv1xQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xSfpiU1X",
      "display_url" : "pastebin.com\/raw.php?i=xSfp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433415764721164288",
  "text" : "http:\/\/t.co\/0VOBACv1xQ Emails: 200 Keywords: 0.11 #infoleak",
  "id" : 433415764721164288,
  "created_at" : "2014-02-12 01:42:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ht8YS1OiB8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4LZYbJ61",
      "display_url" : "pastebin.com\/raw.php?i=4LZY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433413178320371712",
  "text" : "http:\/\/t.co\/ht8YS1OiB8 Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 433413178320371712,
  "created_at" : "2014-02-12 01:32:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9G575bsc3J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7eqMNtGa",
      "display_url" : "pastebin.com\/raw.php?i=7eqM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433394364673310720",
  "text" : "http:\/\/t.co\/9G575bsc3J Emails: 225 Keywords: 0.11 #infoleak",
  "id" : 433394364673310720,
  "created_at" : "2014-02-12 00:17:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zMLQvCJznO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jq961AS4",
      "display_url" : "pastebin.com\/raw.php?i=Jq96\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433385926874509312",
  "text" : "http:\/\/t.co\/zMLQvCJznO Found possible Google API key(s) #infoleak",
  "id" : 433385926874509312,
  "created_at" : "2014-02-11 23:43:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CFGOlXWVQM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sQ0rw54u",
      "display_url" : "pastebin.com\/raw.php?i=sQ0r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433379682549915648",
  "text" : "http:\/\/t.co\/CFGOlXWVQM Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 433379682549915648,
  "created_at" : "2014-02-11 23:19:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g7vWhrCDvm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=34Wg0tYB",
      "display_url" : "pastebin.com\/raw.php?i=34Wg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433378728953933825",
  "text" : "http:\/\/t.co\/g7vWhrCDvm Emails: 40 Keywords: -0.03 #infoleak",
  "id" : 433378728953933825,
  "created_at" : "2014-02-11 23:15:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XnVbplVH8U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x1VhJQzB",
      "display_url" : "pastebin.com\/raw.php?i=x1Vh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433371572741488640",
  "text" : "http:\/\/t.co\/XnVbplVH8U Keywords: 0.55 #infoleak",
  "id" : 433371572741488640,
  "created_at" : "2014-02-11 22:46:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dSOrJZMftO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NfAa2c9i",
      "display_url" : "pastebin.com\/raw.php?i=NfAa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433370150994071552",
  "text" : "http:\/\/t.co\/dSOrJZMftO Emails: 21 Hashes: 2 E\/H: 10.5 Keywords: 0.11 #infoleak",
  "id" : 433370150994071552,
  "created_at" : "2014-02-11 22:41:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9BaRoNcD88",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f8KGZPJP",
      "display_url" : "pastebin.com\/raw.php?i=f8KG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433366685072912385",
  "text" : "http:\/\/t.co\/9BaRoNcD88 Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 433366685072912385,
  "created_at" : "2014-02-11 22:27:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/olCVh7pnSX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tYvtRiPm",
      "display_url" : "pastebin.com\/raw.php?i=tYvt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433365598957891584",
  "text" : "http:\/\/t.co\/olCVh7pnSX Emails: 44 Keywords: 0.0 #infoleak",
  "id" : 433365598957891584,
  "created_at" : "2014-02-11 22:23:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ogpogRsTeb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yA756mBR",
      "display_url" : "pastebin.com\/raw.php?i=yA75\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433365049042685952",
  "text" : "http:\/\/t.co\/ogpogRsTeb Emails: 261 Keywords: 0.33 #infoleak",
  "id" : 433365049042685952,
  "created_at" : "2014-02-11 22:20:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xobezibucM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YANP8Ryf",
      "display_url" : "pastebin.com\/raw.php?i=YANP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433357676064411650",
  "text" : "http:\/\/t.co\/xobezibucM Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 433357676064411650,
  "created_at" : "2014-02-11 21:51:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SsTp9pJOtQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WceXFxW4",
      "display_url" : "pastebin.com\/raw.php?i=WceX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433354854547738626",
  "text" : "http:\/\/t.co\/SsTp9pJOtQ Hashes: 108 Keywords: 0.0 #infoleak",
  "id" : 433354854547738626,
  "created_at" : "2014-02-11 21:40:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oVBHD06KW1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NEhCvmY9",
      "display_url" : "pastebin.com\/raw.php?i=NEhC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433352598955896833",
  "text" : "http:\/\/t.co\/oVBHD06KW1 Emails: 24 Keywords: 0.44 #infoleak",
  "id" : 433352598955896833,
  "created_at" : "2014-02-11 21:31:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/htwKtwz7Bs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9CWaM7Qu",
      "display_url" : "pastebin.com\/raw.php?i=9CWa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433349846620045312",
  "text" : "http:\/\/t.co\/htwKtwz7Bs Emails: 38 Keywords: 0.22 #infoleak",
  "id" : 433349846620045312,
  "created_at" : "2014-02-11 21:20:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I52H8Ffyxi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wwZusTTA",
      "display_url" : "pastebin.com\/raw.php?i=wwZu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433347818141401088",
  "text" : "http:\/\/t.co\/I52H8Ffyxi Emails: 49 Keywords: -0.14 #infoleak",
  "id" : 433347818141401088,
  "created_at" : "2014-02-11 21:12:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MGvghdLWXC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mseZXv7w",
      "display_url" : "pastebin.com\/raw.php?i=mseZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433347342159208448",
  "text" : "http:\/\/t.co\/MGvghdLWXC Emails: 48 Keywords: -0.14 #infoleak",
  "id" : 433347342159208448,
  "created_at" : "2014-02-11 21:10:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8moRGu7yhS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=09rWguaU",
      "display_url" : "pastebin.com\/raw.php?i=09rW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433346250964881408",
  "text" : "http:\/\/t.co\/8moRGu7yhS Emails: 28 Keywords: 0.08 #infoleak",
  "id" : 433346250964881408,
  "created_at" : "2014-02-11 21:06:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8nheZJEjoJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hxgBpCVg",
      "display_url" : "pastebin.com\/raw.php?i=hxgB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433334241632346112",
  "text" : "http:\/\/t.co\/8nheZJEjoJ Keywords: 0.55 #infoleak",
  "id" : 433334241632346112,
  "created_at" : "2014-02-11 20:18:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z13y097faB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gZXPJCpW",
      "display_url" : "pastebin.com\/raw.php?i=gZXP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433330820263075840",
  "text" : "http:\/\/t.co\/z13y097faB Hashes: 140 Keywords: 0.02 #infoleak",
  "id" : 433330820263075840,
  "created_at" : "2014-02-11 20:04:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fp2i5bpWKP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WuzWgM42",
      "display_url" : "pastebin.com\/raw.php?i=WuzW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433329324423262208",
  "text" : "http:\/\/t.co\/Fp2i5bpWKP Keywords: 0.55 #infoleak",
  "id" : 433329324423262208,
  "created_at" : "2014-02-11 19:58:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DwP1ulCeFP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=53FrP8SZ",
      "display_url" : "pastebin.com\/raw.php?i=53Fr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433325063954124801",
  "text" : "http:\/\/t.co\/DwP1ulCeFP Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 433325063954124801,
  "created_at" : "2014-02-11 19:42:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cqc07BLVTb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M5QxLzzw",
      "display_url" : "pastebin.com\/raw.php?i=M5Qx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433314053557997568",
  "text" : "http:\/\/t.co\/cqc07BLVTb Emails: 188 Hashes: 188 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 433314053557997568,
  "created_at" : "2014-02-11 18:58:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/16PdlrTJgn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nPm0Pc9X",
      "display_url" : "pastebin.com\/raw.php?i=nPm0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433313813572501505",
  "text" : "http:\/\/t.co\/16PdlrTJgn Emails: 188 Hashes: 188 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 433313813572501505,
  "created_at" : "2014-02-11 18:57:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VajnecA4DY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UMDc5Ds1",
      "display_url" : "pastebin.com\/raw.php?i=UMDc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433309991202586625",
  "text" : "http:\/\/t.co\/VajnecA4DY Possible cisco configuration #infoleak",
  "id" : 433309991202586625,
  "created_at" : "2014-02-11 18:42:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u9ANGY9BWM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zC0R40Gq",
      "display_url" : "pastebin.com\/raw.php?i=zC0R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433300460192010240",
  "text" : "http:\/\/t.co\/u9ANGY9BWM Emails: 9 Hashes: 305 E\/H: 0.03 Keywords: 0.11 #infoleak",
  "id" : 433300460192010240,
  "created_at" : "2014-02-11 18:04:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jpGOTHQy0L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ALjCu3WX",
      "display_url" : "pastebin.com\/raw.php?i=ALjC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433296542464618496",
  "text" : "http:\/\/t.co\/jpGOTHQy0L Emails: 78 Hashes: 103 E\/H: 0.76 Keywords: 0.0 #infoleak",
  "id" : 433296542464618496,
  "created_at" : "2014-02-11 17:48:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hOjc8Q31sb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bvMzGTRA",
      "display_url" : "pastebin.com\/raw.php?i=bvMz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433208538542792704",
  "text" : "http:\/\/t.co\/hOjc8Q31sb Emails: 725 Hashes: 735 E\/H: 0.99 Keywords: 0.22 #infoleak",
  "id" : 433208538542792704,
  "created_at" : "2014-02-11 11:58:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pNIYuc201X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eHtuL53k",
      "display_url" : "pastebin.com\/raw.php?i=eHtu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433095765863325696",
  "text" : "http:\/\/t.co\/pNIYuc201X Found possible Google API key(s) #infoleak",
  "id" : 433095765863325696,
  "created_at" : "2014-02-11 04:30:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EizPyffSCf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w2sDi2u8",
      "display_url" : "pastebin.com\/raw.php?i=w2sD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433095211284054016",
  "text" : "http:\/\/t.co\/EizPyffSCf Emails: 265 Keywords: 0.41 #infoleak",
  "id" : 433095211284054016,
  "created_at" : "2014-02-11 04:28:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/44Hj1ThRFZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KTYfJwVm",
      "display_url" : "pastebin.com\/raw.php?i=KTYf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433091309935419393",
  "text" : "http:\/\/t.co\/44Hj1ThRFZ Emails: 918 Keywords: 0.33 #infoleak",
  "id" : 433091309935419393,
  "created_at" : "2014-02-11 04:13:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ql0dHb20V5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P5DhJKFx",
      "display_url" : "pastebin.com\/raw.php?i=P5Dh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433089374813556736",
  "text" : "http:\/\/t.co\/Ql0dHb20V5 Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 433089374813556736,
  "created_at" : "2014-02-11 04:05:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cXpSaWkIRs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sF7Sz2gz",
      "display_url" : "pastebin.com\/raw.php?i=sF7S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433047414220402688",
  "text" : "http:\/\/t.co\/cXpSaWkIRs Emails: 4645 Keywords: 0.3 #infoleak",
  "id" : 433047414220402688,
  "created_at" : "2014-02-11 01:18:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7DnjnbpdAO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0aiRjRmU",
      "display_url" : "pastebin.com\/raw.php?i=0aiR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433041137763241984",
  "text" : "http:\/\/t.co\/7DnjnbpdAO Hashes: 68 Keywords: -0.06 #infoleak",
  "id" : 433041137763241984,
  "created_at" : "2014-02-11 00:53:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NthQ8jM9Ta",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5UxFRm6Q",
      "display_url" : "pastebin.com\/raw.php?i=5UxF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433033295295561728",
  "text" : "http:\/\/t.co\/NthQ8jM9Ta Keywords: 0.55 #infoleak",
  "id" : 433033295295561728,
  "created_at" : "2014-02-11 00:22:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kIHMz1ipQO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LcCGwkaq",
      "display_url" : "pastebin.com\/raw.php?i=LcCG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433031687425904642",
  "text" : "http:\/\/t.co\/kIHMz1ipQO Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 433031687425904642,
  "created_at" : "2014-02-11 00:16:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lXfZZCKeA0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d3euiA0m",
      "display_url" : "pastebin.com\/raw.php?i=d3eu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433030778687995904",
  "text" : "http:\/\/t.co\/lXfZZCKeA0 Hashes: 37 Keywords: -0.17 #infoleak",
  "id" : 433030778687995904,
  "created_at" : "2014-02-11 00:12:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8e86R3qC7D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KQy8J2ve",
      "display_url" : "pastebin.com\/raw.php?i=KQy8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433027050018836480",
  "text" : "http:\/\/t.co\/8e86R3qC7D Hashes: 45 Keywords: 0.33 #infoleak",
  "id" : 433027050018836480,
  "created_at" : "2014-02-10 23:57:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MCu64gMK6C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2kX8EDt6",
      "display_url" : "pastebin.com\/raw.php?i=2kX8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433026216606437376",
  "text" : "http:\/\/t.co\/MCu64gMK6C Emails: 29 Keywords: 0.11 #infoleak",
  "id" : 433026216606437376,
  "created_at" : "2014-02-10 23:54:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3Xd2GUlO5P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fF1aHYJ4",
      "display_url" : "pastebin.com\/raw.php?i=fF1a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432954641265856513",
  "text" : "http:\/\/t.co\/3Xd2GUlO5P Emails: 151 Keywords: 0.11 #infoleak",
  "id" : 432954641265856513,
  "created_at" : "2014-02-10 19:10:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d5JceakBka",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gERvrTgL",
      "display_url" : "pastebin.com\/raw.php?i=gERv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432952736338821120",
  "text" : "http:\/\/t.co\/d5JceakBka Emails: 1398 Keywords: 0.11 #infoleak",
  "id" : 432952736338821120,
  "created_at" : "2014-02-10 19:02:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j1yq0kMQkK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P9NsNqfe",
      "display_url" : "pastebin.com\/raw.php?i=P9Ns\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432889027507671040",
  "text" : "http:\/\/t.co\/j1yq0kMQkK Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 432889027507671040,
  "created_at" : "2014-02-10 14:49:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NR9RsbeN1J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MXkhxTXp",
      "display_url" : "pastebin.com\/raw.php?i=MXkh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432884170855964672",
  "text" : "http:\/\/t.co\/NR9RsbeN1J Emails: 749 Keywords: 0.11 #infoleak",
  "id" : 432884170855964672,
  "created_at" : "2014-02-10 14:30:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WNUO5eGkvL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yBdEgEVt",
      "display_url" : "pastebin.com\/raw.php?i=yBdE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432882153437663233",
  "text" : "http:\/\/t.co\/WNUO5eGkvL Emails: 144 Keywords: 0.11 #infoleak",
  "id" : 432882153437663233,
  "created_at" : "2014-02-10 14:22:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zj52Kq2spi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tk7ERmfK",
      "display_url" : "pastebin.com\/raw.php?i=Tk7E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432704519298744320",
  "text" : "http:\/\/t.co\/Zj52Kq2spi Emails: 22 Hashes: 1 E\/H: 22.0 Keywords: 0.0 #infoleak",
  "id" : 432704519298744320,
  "created_at" : "2014-02-10 02:36:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IuT9amwkFM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vX9NfwwN",
      "display_url" : "pastebin.com\/raw.php?i=vX9N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432698896792293376",
  "text" : "http:\/\/t.co\/IuT9amwkFM Hashes: 45 Keywords: 0.33 #infoleak",
  "id" : 432698896792293376,
  "created_at" : "2014-02-10 02:13:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hb82pWuJBu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cQDqT2aK",
      "display_url" : "pastebin.com\/raw.php?i=cQDq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432691300358311937",
  "text" : "http:\/\/t.co\/Hb82pWuJBu Keywords: 0.55 #infoleak",
  "id" : 432691300358311937,
  "created_at" : "2014-02-10 01:43:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EJYwINKd8W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CGs3P2CH",
      "display_url" : "pastebin.com\/raw.php?i=CGs3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432690120827731969",
  "text" : "http:\/\/t.co\/EJYwINKd8W Hashes: 41 Keywords: 0.19 #infoleak",
  "id" : 432690120827731969,
  "created_at" : "2014-02-10 01:38:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ugicFKi8Sf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Sk9EUPJN",
      "display_url" : "pastebin.com\/raw.php?i=Sk9E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432656973603946496",
  "text" : "http:\/\/t.co\/ugicFKi8Sf Emails: 680 Keywords: 0.33 #infoleak",
  "id" : 432656973603946496,
  "created_at" : "2014-02-09 23:27:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ukyNgmRzUP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m1xgYpuW",
      "display_url" : "pastebin.com\/raw.php?i=m1xg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432628612357816320",
  "text" : "http:\/\/t.co\/ukyNgmRzUP Emails: 1594 Keywords: -0.03 #infoleak",
  "id" : 432628612357816320,
  "created_at" : "2014-02-09 21:34:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7P5R0zRyWm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BmPn5MZV",
      "display_url" : "pastebin.com\/raw.php?i=BmPn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432624157306540032",
  "text" : "http:\/\/t.co\/7P5R0zRyWm Emails: 67 Keywords: 0.11 #infoleak",
  "id" : 432624157306540032,
  "created_at" : "2014-02-09 21:16:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zX54WqFZwD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gd78rAQb",
      "display_url" : "pastebin.com\/raw.php?i=Gd78\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432618389207404544",
  "text" : "http:\/\/t.co\/zX54WqFZwD Found possible Google API key(s) #infoleak",
  "id" : 432618389207404544,
  "created_at" : "2014-02-09 20:53:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0Bkngdz6FE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mZPeAsqw",
      "display_url" : "pastebin.com\/raw.php?i=mZPe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432615817927073792",
  "text" : "http:\/\/t.co\/0Bkngdz6FE Hashes: 65 Keywords: 0.0 #infoleak",
  "id" : 432615817927073792,
  "created_at" : "2014-02-09 20:43:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MRuEryQA8D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bRPGbnep",
      "display_url" : "pastebin.com\/raw.php?i=bRPG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432597148287242240",
  "text" : "http:\/\/t.co\/MRuEryQA8D Emails: 92 Hashes: 532 E\/H: 0.17 Keywords: 0.33 #infoleak",
  "id" : 432597148287242240,
  "created_at" : "2014-02-09 19:29:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KNxsUxD0zW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tHWquSqh",
      "display_url" : "pastebin.com\/raw.php?i=tHWq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432579618910904321",
  "text" : "http:\/\/t.co\/KNxsUxD0zW Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 432579618910904321,
  "created_at" : "2014-02-09 18:19:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/feP7b1AH0T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QJhvbwGT",
      "display_url" : "pastebin.com\/raw.php?i=QJhv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432545290973741058",
  "text" : "http:\/\/t.co\/feP7b1AH0T Emails: 70 Keywords: 0.0 #infoleak",
  "id" : 432545290973741058,
  "created_at" : "2014-02-09 16:03:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YA5Vc1Zb8G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iUCvA13P",
      "display_url" : "pastebin.com\/raw.php?i=iUCv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432526187911319552",
  "text" : "http:\/\/t.co\/YA5Vc1Zb8G Emails: 340 Hashes: 2 E\/H: 170.0 Keywords: 0.0 #infoleak",
  "id" : 432526187911319552,
  "created_at" : "2014-02-09 14:47:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zVlDBZh8IX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g3ktEjSz",
      "display_url" : "pastebin.com\/raw.php?i=g3kt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432521095099326464",
  "text" : "http:\/\/t.co\/zVlDBZh8IX Emails: 345 Hashes: 2 E\/H: 172.5 Keywords: 0.11 #infoleak",
  "id" : 432521095099326464,
  "created_at" : "2014-02-09 14:27:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4NLJ78ALor",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kj5Urvu4",
      "display_url" : "pastebin.com\/raw.php?i=kj5U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432512734341521408",
  "text" : "http:\/\/t.co\/4NLJ78ALor Emails: 67 Keywords: 0.22 #infoleak",
  "id" : 432512734341521408,
  "created_at" : "2014-02-09 13:54:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mp5HFPe1Y3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2MJPPyMh",
      "display_url" : "pastebin.com\/raw.php?i=2MJP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432510864436891648",
  "text" : "http:\/\/t.co\/Mp5HFPe1Y3 Hashes: 42 Keywords: 0.05 #infoleak",
  "id" : 432510864436891648,
  "created_at" : "2014-02-09 13:46:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wEUoJCtbiM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ak09mBd0",
      "display_url" : "pastebin.com\/raw.php?i=ak09\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432496098192547841",
  "text" : "http:\/\/t.co\/wEUoJCtbiM Hashes: 73 Keywords: 0.22 #infoleak",
  "id" : 432496098192547841,
  "created_at" : "2014-02-09 12:47:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8oRA3XNzZF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ydkR7wj8",
      "display_url" : "pastebin.com\/raw.php?i=ydkR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432487704484257792",
  "text" : "http:\/\/t.co\/8oRA3XNzZF Emails: 115 Keywords: 0.0 #infoleak",
  "id" : 432487704484257792,
  "created_at" : "2014-02-09 12:14:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/icSEqZHt1v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mKDsxBeh",
      "display_url" : "pastebin.com\/raw.php?i=mKDs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432444300022927360",
  "text" : "http:\/\/t.co\/icSEqZHt1v Hashes: 111 Keywords: 0.11 #infoleak",
  "id" : 432444300022927360,
  "created_at" : "2014-02-09 09:22:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BCZkpurVlY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5BdAJKUf",
      "display_url" : "pastebin.com\/raw.php?i=5BdA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432443973357944833",
  "text" : "http:\/\/t.co\/BCZkpurVlY Hashes: 160 Keywords: 0.11 #infoleak",
  "id" : 432443973357944833,
  "created_at" : "2014-02-09 09:20:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5aYhZtnZt4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Lu2aCiAw",
      "display_url" : "pastebin.com\/raw.php?i=Lu2a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432443466455339010",
  "text" : "http:\/\/t.co\/5aYhZtnZt4 Hashes: 160 Keywords: 0.11 #infoleak",
  "id" : 432443466455339010,
  "created_at" : "2014-02-09 09:18:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y3DPLJvnef",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WnEN61uB",
      "display_url" : "pastebin.com\/raw.php?i=WnEN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432443307172450304",
  "text" : "http:\/\/t.co\/y3DPLJvnef Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 432443307172450304,
  "created_at" : "2014-02-09 09:18:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dFuKH21SIp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZDtP8pWx",
      "display_url" : "pastebin.com\/raw.php?i=ZDtP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432436889920864256",
  "text" : "http:\/\/t.co\/dFuKH21SIp Emails: 9871 Keywords: 0.22 #infoleak",
  "id" : 432436889920864256,
  "created_at" : "2014-02-09 08:52:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/D0sHYjiquO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k8LkHMbd",
      "display_url" : "pastebin.com\/raw.php?i=k8Lk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432435304390074368",
  "text" : "http:\/\/t.co\/D0sHYjiquO Emails: 9871 Keywords: 0.22 #infoleak",
  "id" : 432435304390074368,
  "created_at" : "2014-02-09 08:46:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/75ZddteM4R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xZFybt4t",
      "display_url" : "pastebin.com\/raw.php?i=xZFy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432432594974547968",
  "text" : "http:\/\/t.co\/75ZddteM4R Found possible Google API key(s) #infoleak",
  "id" : 432432594974547968,
  "created_at" : "2014-02-09 08:35:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dcJSAcvgDu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ENFe0VgV",
      "display_url" : "pastebin.com\/raw.php?i=ENFe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432426093912395776",
  "text" : "http:\/\/t.co\/dcJSAcvgDu Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 432426093912395776,
  "created_at" : "2014-02-09 08:09:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vKxkYx1SrX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=L0miVqSB",
      "display_url" : "pastebin.com\/raw.php?i=L0mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432365901388578816",
  "text" : "http:\/\/t.co\/vKxkYx1SrX Emails: 204 Keywords: 0.19 #infoleak",
  "id" : 432365901388578816,
  "created_at" : "2014-02-09 04:10:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j2rV8Ks2aF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hKx1DFDJ",
      "display_url" : "pastebin.com\/raw.php?i=hKx1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432354892506595328",
  "text" : "http:\/\/t.co\/j2rV8Ks2aF Emails: 174 Keywords: 0.0 #infoleak",
  "id" : 432354892506595328,
  "created_at" : "2014-02-09 03:26:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Enaee4u34p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jiBJrsMu",
      "display_url" : "pastebin.com\/raw.php?i=jiBJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432330424094699520",
  "text" : "http:\/\/t.co\/Enaee4u34p Hashes: 1114 Keywords: 0.44 #infoleak",
  "id" : 432330424094699520,
  "created_at" : "2014-02-09 01:49:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ipAdg73FXJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PvVP8K3b",
      "display_url" : "pastebin.com\/raw.php?i=PvVP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432327087018348544",
  "text" : "http:\/\/t.co\/ipAdg73FXJ Emails: 47 Keywords: 0.05 #infoleak",
  "id" : 432327087018348544,
  "created_at" : "2014-02-09 01:36:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3l9ylIK8Kz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CfMzBzZA",
      "display_url" : "pastebin.com\/raw.php?i=CfMz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432283387508690944",
  "text" : "http:\/\/t.co\/3l9ylIK8Kz Emails: 186 Keywords: 0.0 #infoleak",
  "id" : 432283387508690944,
  "created_at" : "2014-02-08 22:42:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f8ZEuN6WS2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qs5t2Xsm",
      "display_url" : "pastebin.com\/raw.php?i=qs5t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432282491877998592",
  "text" : "http:\/\/t.co\/f8ZEuN6WS2 Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 432282491877998592,
  "created_at" : "2014-02-08 22:39:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4sLx91aPxk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zxTE9gxU",
      "display_url" : "pastebin.com\/raw.php?i=zxTE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432280245870145536",
  "text" : "http:\/\/t.co\/4sLx91aPxk Hashes: 33 Keywords: 0.22 #infoleak",
  "id" : 432280245870145536,
  "created_at" : "2014-02-08 22:30:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TlLnEtAwTn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R8PQ2cvm",
      "display_url" : "pastebin.com\/raw.php?i=R8PQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432270638128975872",
  "text" : "http:\/\/t.co\/TlLnEtAwTn Emails: 51 Keywords: 0.22 #infoleak",
  "id" : 432270638128975872,
  "created_at" : "2014-02-08 21:52:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NQy8bItrua",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z7JwWhEQ",
      "display_url" : "pastebin.com\/raw.php?i=z7Jw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432155098618159104",
  "text" : "http:\/\/t.co\/NQy8bItrua Emails: 31 Keywords: 0.11 #infoleak",
  "id" : 432155098618159104,
  "created_at" : "2014-02-08 14:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ot98tzdQKb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8qCHGMXc",
      "display_url" : "pastebin.com\/raw.php?i=8qCH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432138436749713408",
  "text" : "http:\/\/t.co\/ot98tzdQKb Emails: 997 Keywords: 0.22 #infoleak",
  "id" : 432138436749713408,
  "created_at" : "2014-02-08 13:06:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8oEz985bpB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6M4muJm7",
      "display_url" : "pastebin.com\/raw.php?i=6M4m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432137963472830464",
  "text" : "http:\/\/t.co\/8oEz985bpB Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 432137963472830464,
  "created_at" : "2014-02-08 13:04:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DVyoJtWQGO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M2xMPSV0",
      "display_url" : "pastebin.com\/raw.php?i=M2xM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432135968938680321",
  "text" : "http:\/\/t.co\/DVyoJtWQGO Hashes: 248 Keywords: 0.08 #infoleak",
  "id" : 432135968938680321,
  "created_at" : "2014-02-08 12:56:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zLp9qWozv0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CXeWTaWR",
      "display_url" : "pastebin.com\/raw.php?i=CXeW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432134520553230337",
  "text" : "http:\/\/t.co\/zLp9qWozv0 Emails: 239 Hashes: 3 E\/H: 79.67 Keywords: 0.11 #infoleak",
  "id" : 432134520553230337,
  "created_at" : "2014-02-08 12:51:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9ZjhoVk5rc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Vtp6zhwp",
      "display_url" : "pastebin.com\/raw.php?i=Vtp6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432123121345105920",
  "text" : "http:\/\/t.co\/9ZjhoVk5rc Hashes: 160 Keywords: 0.11 #infoleak",
  "id" : 432123121345105920,
  "created_at" : "2014-02-08 12:05:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N1e2LUa2rs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=paE8NdfU",
      "display_url" : "pastebin.com\/raw.php?i=paE8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432122393965133824",
  "text" : "http:\/\/t.co\/N1e2LUa2rs Hashes: 160 Keywords: 0.11 #infoleak",
  "id" : 432122393965133824,
  "created_at" : "2014-02-08 12:03:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wkFknCKD6c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q4DZue13",
      "display_url" : "pastebin.com\/raw.php?i=Q4DZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432121363956903936",
  "text" : "http:\/\/t.co\/wkFknCKD6c Hashes: 160 Keywords: 0.11 #infoleak",
  "id" : 432121363956903936,
  "created_at" : "2014-02-08 11:58:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9cGRdwPc4b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M9SbEw7t",
      "display_url" : "pastebin.com\/raw.php?i=M9Sb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432120615722442752",
  "text" : "http:\/\/t.co\/9cGRdwPc4b Emails: 344 Keywords: 0.0 #infoleak",
  "id" : 432120615722442752,
  "created_at" : "2014-02-08 11:55:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dc9Z4X2Uks",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a6MCpk2j",
      "display_url" : "pastebin.com\/raw.php?i=a6MC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432098802422390784",
  "text" : "http:\/\/t.co\/dc9Z4X2Uks Hashes: 248 Keywords: 0.08 #infoleak",
  "id" : 432098802422390784,
  "created_at" : "2014-02-08 10:29:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ErFSWYZmgu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1ys2J6Mw",
      "display_url" : "pastebin.com\/raw.php?i=1ys2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432087960133963776",
  "text" : "http:\/\/t.co\/ErFSWYZmgu Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.44 #infoleak",
  "id" : 432087960133963776,
  "created_at" : "2014-02-08 09:46:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aBFWIE2A1K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PAYCUNe1",
      "display_url" : "pastebin.com\/raw.php?i=PAYC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432074379422228480",
  "text" : "http:\/\/t.co\/aBFWIE2A1K Emails: 78 Keywords: 0.22 #infoleak",
  "id" : 432074379422228480,
  "created_at" : "2014-02-08 08:52:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iAXrP3kG7w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hwEUkCHX",
      "display_url" : "pastebin.com\/raw.php?i=hwEU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432050884587970560",
  "text" : "http:\/\/t.co\/iAXrP3kG7w Emails: 1090 Keywords: 0.33 #infoleak",
  "id" : 432050884587970560,
  "created_at" : "2014-02-08 07:18:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2SwAvU1dYY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hwBX0CwM",
      "display_url" : "pastebin.com\/raw.php?i=hwBX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432036692489293824",
  "text" : "http:\/\/t.co\/2SwAvU1dYY Emails: 71 Hashes: 5 E\/H: 14.2 Keywords: 0.22 #infoleak",
  "id" : 432036692489293824,
  "created_at" : "2014-02-08 06:22:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2sXorvRXg7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8q851jH3",
      "display_url" : "pastebin.com\/raw.php?i=8q85\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432032459115360256",
  "text" : "http:\/\/t.co\/2sXorvRXg7 Emails: 98 Keywords: 0.11 #infoleak",
  "id" : 432032459115360256,
  "created_at" : "2014-02-08 06:05:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Rk47kWpGri",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1E0DWVkj",
      "display_url" : "pastebin.com\/raw.php?i=1E0D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432032107980812289",
  "text" : "http:\/\/t.co\/Rk47kWpGri Hashes: 113 Keywords: -0.17 #infoleak",
  "id" : 432032107980812289,
  "created_at" : "2014-02-08 06:04:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/33gz94t7dH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=varEUw4B",
      "display_url" : "pastebin.com\/raw.php?i=varE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432031399999066112",
  "text" : "http:\/\/t.co\/33gz94t7dH Emails: 139 Keywords: 0.11 #infoleak",
  "id" : 432031399999066112,
  "created_at" : "2014-02-08 06:01:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5DfdaeFJov",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bBYQut6s",
      "display_url" : "pastebin.com\/raw.php?i=bBYQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432021502947381248",
  "text" : "http:\/\/t.co\/5DfdaeFJov Hashes: 74 Keywords: -0.17 #infoleak",
  "id" : 432021502947381248,
  "created_at" : "2014-02-08 05:22:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vLCxQN5uuw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hJ2wyUvf",
      "display_url" : "pastebin.com\/raw.php?i=hJ2w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432020498101186561",
  "text" : "http:\/\/t.co\/vLCxQN5uuw Keywords: 0.55 #infoleak",
  "id" : 432020498101186561,
  "created_at" : "2014-02-08 05:18:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8DGrutI7Ao",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DLV8jSrM",
      "display_url" : "pastebin.com\/raw.php?i=DLV8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432015733233422336",
  "text" : "http:\/\/t.co\/8DGrutI7Ao Emails: 135 Hashes: 1 E\/H: 135.0 Keywords: 0.11 #infoleak",
  "id" : 432015733233422336,
  "created_at" : "2014-02-08 04:59:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7bxWDeGVcR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wbD6pDfs",
      "display_url" : "pastebin.com\/raw.php?i=wbD6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432011248914280448",
  "text" : "http:\/\/t.co\/7bxWDeGVcR Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 432011248914280448,
  "created_at" : "2014-02-08 04:41:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QZZxFWHV79",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wXsJX1s9",
      "display_url" : "pastebin.com\/raw.php?i=wXsJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431996835461218304",
  "text" : "http:\/\/t.co\/QZZxFWHV79 Hashes: 52 Keywords: 0.11 #infoleak",
  "id" : 431996835461218304,
  "created_at" : "2014-02-08 03:44:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yLoX6UTtK8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gs0Pt51g",
      "display_url" : "pastebin.com\/raw.php?i=Gs0P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431978372487331840",
  "text" : "http:\/\/t.co\/yLoX6UTtK8 Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 431978372487331840,
  "created_at" : "2014-02-08 02:30:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tt07ORnW7T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UYzhpsTb",
      "display_url" : "pastebin.com\/raw.php?i=UYzh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431961925350457344",
  "text" : "http:\/\/t.co\/Tt07ORnW7T Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 431961925350457344,
  "created_at" : "2014-02-08 01:25:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YPhBJipUj8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SMxHMaUj",
      "display_url" : "pastebin.com\/raw.php?i=SMxH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431958615348363264",
  "text" : "http:\/\/t.co\/YPhBJipUj8 Keywords: 0.55 #infoleak",
  "id" : 431958615348363264,
  "created_at" : "2014-02-08 01:12:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WpUMmRFijW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y3aEav3a",
      "display_url" : "pastebin.com\/raw.php?i=Y3aE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431914218560839680",
  "text" : "http:\/\/t.co\/WpUMmRFijW Emails: 256 Keywords: 0.0 #infoleak",
  "id" : 431914218560839680,
  "created_at" : "2014-02-07 22:15:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DG6WVFYPKU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3whkQezW",
      "display_url" : "pastebin.com\/raw.php?i=3whk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431912688646504448",
  "text" : "http:\/\/t.co\/DG6WVFYPKU Possible cisco configuration #infoleak",
  "id" : 431912688646504448,
  "created_at" : "2014-02-07 22:09:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7140lKgubE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J2DDxki4",
      "display_url" : "pastebin.com\/raw.php?i=J2DD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431911426743996416",
  "text" : "http:\/\/t.co\/7140lKgubE Keywords: 0.55 #infoleak",
  "id" : 431911426743996416,
  "created_at" : "2014-02-07 22:04:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7CZHuu6H3j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gpg85XYh",
      "display_url" : "pastebin.com\/raw.php?i=gpg8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431907919018221568",
  "text" : "http:\/\/t.co\/7CZHuu6H3j Emails: 39 Keywords: 0.3 #infoleak",
  "id" : 431907919018221568,
  "created_at" : "2014-02-07 21:50:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RXItaeon3n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YR7QUvCU",
      "display_url" : "pastebin.com\/raw.php?i=YR7Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431889384745353216",
  "text" : "http:\/\/t.co\/RXItaeon3n Found possible Google API key(s) #infoleak",
  "id" : 431889384745353216,
  "created_at" : "2014-02-07 20:37:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vPDAPDlHOb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FWWanjMR",
      "display_url" : "pastebin.com\/raw.php?i=FWWa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431833811538542592",
  "text" : "http:\/\/t.co\/vPDAPDlHOb Emails: 330 Keywords: 0.3 #infoleak",
  "id" : 431833811538542592,
  "created_at" : "2014-02-07 16:56:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431450246766690304",
  "geo" : { },
  "id_str" : "431825461404913666",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl Back up and running now! Even bots need PTO.",
  "id" : 431825461404913666,
  "in_reply_to_status_id" : 431450246766690304,
  "created_at" : "2014-02-07 16:23:07 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431825363434340352",
  "text" : "Back up and running!",
  "id" : 431825363434340352,
  "created_at" : "2014-02-07 16:22:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yvw4wZMMyd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zixdjqBq",
      "display_url" : "pastebin.com\/raw.php?i=zixd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430567236479111168",
  "text" : "http:\/\/t.co\/yvw4wZMMyd Emails: 320 Keywords: 0.33 #infoleak",
  "id" : 430567236479111168,
  "created_at" : "2014-02-04 05:03:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wh6VA2WwWA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mN9PPpgm",
      "display_url" : "pastebin.com\/raw.php?i=mN9P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430553693809696769",
  "text" : "http:\/\/t.co\/wh6VA2WwWA Emails: 87 Keywords: 0.0 #infoleak",
  "id" : 430553693809696769,
  "created_at" : "2014-02-04 04:09:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xkhWmNTzEC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dciwepFi",
      "display_url" : "pastebin.com\/raw.php?i=dciw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430551305648488448",
  "text" : "http:\/\/t.co\/xkhWmNTzEC Emails: 70 Keywords: 0.0 #infoleak",
  "id" : 430551305648488448,
  "created_at" : "2014-02-04 04:00:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KNNdHh3F96",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r7T4PNdG",
      "display_url" : "pastebin.com\/raw.php?i=r7T4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430530177097953281",
  "text" : "http:\/\/t.co\/KNNdHh3F96 Keywords: 0.55 #infoleak",
  "id" : 430530177097953281,
  "created_at" : "2014-02-04 02:36:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iC4J2XhXgS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=86dBwaDH",
      "display_url" : "pastebin.com\/raw.php?i=86dB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430527939688411136",
  "text" : "http:\/\/t.co\/iC4J2XhXgS Emails: 20 Keywords: 0.11 #infoleak",
  "id" : 430527939688411136,
  "created_at" : "2014-02-04 02:27:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4blFQnTBqX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yyTTyBJZ",
      "display_url" : "pastebin.com\/raw.php?i=yyTT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430444807496814592",
  "text" : "http:\/\/t.co\/4blFQnTBqX Emails: 1444 Hashes: 1152 E\/H: 1.25 Keywords: 0.22 #infoleak",
  "id" : 430444807496814592,
  "created_at" : "2014-02-03 20:56:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NMllxoSN3w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y0RqGwAk",
      "display_url" : "pastebin.com\/raw.php?i=y0Rq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430430897569935360",
  "text" : "http:\/\/t.co\/NMllxoSN3w Emails: 1399 Keywords: 0.0 #infoleak",
  "id" : 430430897569935360,
  "created_at" : "2014-02-03 20:01:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0JelKlhBVj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Yz6mftHh",
      "display_url" : "pastebin.com\/raw.php?i=Yz6m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430294256318554112",
  "text" : "http:\/\/t.co\/0JelKlhBVj Hashes: 52 Keywords: 0.22 #infoleak",
  "id" : 430294256318554112,
  "created_at" : "2014-02-03 10:58:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/InvOplAyc6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pPyPR8a3",
      "display_url" : "pastebin.com\/raw.php?i=pPyP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430273326527688705",
  "text" : "http:\/\/t.co\/InvOplAyc6 Emails: 30 Hashes: 1 E\/H: 30.0 Keywords: 0.08 #infoleak",
  "id" : 430273326527688705,
  "created_at" : "2014-02-03 09:35:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fvEssGfLBQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8YNLERBc",
      "display_url" : "pastebin.com\/raw.php?i=8YNL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430273303253512192",
  "text" : "http:\/\/t.co\/fvEssGfLBQ Hashes: 3567 Keywords: 0.08 #infoleak",
  "id" : 430273303253512192,
  "created_at" : "2014-02-03 09:35:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uqXsFguC30",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hD4PmQdd",
      "display_url" : "pastebin.com\/raw.php?i=hD4P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430257827290959872",
  "text" : "http:\/\/t.co\/uqXsFguC30 Emails: 57 Keywords: -0.03 #infoleak",
  "id" : 430257827290959872,
  "created_at" : "2014-02-03 08:33:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/alCFHCKUCe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8DiU6qjg",
      "display_url" : "pastebin.com\/raw.php?i=8DiU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430240938259001344",
  "text" : "http:\/\/t.co\/alCFHCKUCe Emails: 1 Hashes: 32 E\/H: 0.03 Keywords: 0.08 #infoleak",
  "id" : 430240938259001344,
  "created_at" : "2014-02-03 07:26:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aGJs6k6C0C",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ckPUgHY2",
      "display_url" : "pastebin.com\/raw.php?i=ckPU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430235795824185345",
  "text" : "http:\/\/t.co\/aGJs6k6C0C Found possible Google API key(s) #infoleak",
  "id" : 430235795824185345,
  "created_at" : "2014-02-03 07:06:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hrQbfwyQLJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hAcQujVe",
      "display_url" : "pastebin.com\/raw.php?i=hAcQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430233341476864000",
  "text" : "http:\/\/t.co\/hrQbfwyQLJ Hashes: 132 Keywords: -0.03 #infoleak",
  "id" : 430233341476864000,
  "created_at" : "2014-02-03 06:56:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gaVwtOVVwZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0XUL3CSU",
      "display_url" : "pastebin.com\/raw.php?i=0XUL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430228490080620545",
  "text" : "http:\/\/t.co\/gaVwtOVVwZ Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 430228490080620545,
  "created_at" : "2014-02-03 06:37:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VxFhh37TN7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CjVDgdx3",
      "display_url" : "pastebin.com\/raw.php?i=CjVD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430218133731672064",
  "text" : "http:\/\/t.co\/VxFhh37TN7 Emails: 20 Keywords: 0.22 #infoleak",
  "id" : 430218133731672064,
  "created_at" : "2014-02-03 05:56:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XTUB4e6Wdj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i9RzLWBB",
      "display_url" : "pastebin.com\/raw.php?i=i9Rz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430214069434318848",
  "text" : "http:\/\/t.co\/XTUB4e6Wdj Keywords: 0.55 #infoleak",
  "id" : 430214069434318848,
  "created_at" : "2014-02-03 05:40:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wDc4qBwe0E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qcnW5519",
      "display_url" : "pastebin.com\/raw.php?i=qcnW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430209734310780928",
  "text" : "http:\/\/t.co\/wDc4qBwe0E Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 430209734310780928,
  "created_at" : "2014-02-03 05:22:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w5Im4APrAH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uuSt61h8",
      "display_url" : "pastebin.com\/raw.php?i=uuSt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430209598700527616",
  "text" : "http:\/\/t.co\/w5Im4APrAH Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 430209598700527616,
  "created_at" : "2014-02-03 05:22:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9U7P7cEOIb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TyimsmbB",
      "display_url" : "pastebin.com\/raw.php?i=Tyim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430203676804669440",
  "text" : "http:\/\/t.co\/9U7P7cEOIb Found possible Google API key(s) #infoleak",
  "id" : 430203676804669440,
  "created_at" : "2014-02-03 04:58:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZcHKae0C5N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NaPG64Ly",
      "display_url" : "pastebin.com\/raw.php?i=NaPG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430179172434993152",
  "text" : "http:\/\/t.co\/ZcHKae0C5N Emails: 142 Keywords: 0.0 #infoleak",
  "id" : 430179172434993152,
  "created_at" : "2014-02-03 03:21:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O8USfWAsCC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CdzYFX35",
      "display_url" : "pastebin.com\/raw.php?i=CdzY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430173722108895232",
  "text" : "http:\/\/t.co\/O8USfWAsCC Found possible Google API key(s) #infoleak",
  "id" : 430173722108895232,
  "created_at" : "2014-02-03 02:59:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fdW8VsMjRl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=STs3J0cX",
      "display_url" : "pastebin.com\/raw.php?i=STs3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430171957271605248",
  "text" : "http:\/\/t.co\/fdW8VsMjRl Emails: 240 Keywords: -0.28 #infoleak",
  "id" : 430171957271605248,
  "created_at" : "2014-02-03 02:52:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hox8unmJNw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xKtWytYd",
      "display_url" : "pastebin.com\/raw.php?i=xKtW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430148554217115649",
  "text" : "http:\/\/t.co\/Hox8unmJNw Hashes: 35 Keywords: -0.31 #infoleak",
  "id" : 430148554217115649,
  "created_at" : "2014-02-03 01:19:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xP4fqR0PH0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FjczgFL7",
      "display_url" : "pastebin.com\/raw.php?i=Fjcz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430124525104005122",
  "text" : "http:\/\/t.co\/xP4fqR0PH0 Emails: 64 Keywords: 0.0 #infoleak",
  "id" : 430124525104005122,
  "created_at" : "2014-02-02 23:44:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XI6IhEIA71",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zr9xUqgs",
      "display_url" : "pastebin.com\/raw.php?i=zr9x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430117683963502592",
  "text" : "http:\/\/t.co\/XI6IhEIA71 Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 430117683963502592,
  "created_at" : "2014-02-02 23:17:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qQCwGsJtws",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mhEC48Ek",
      "display_url" : "pastebin.com\/raw.php?i=mhEC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430108466569416704",
  "text" : "http:\/\/t.co\/qQCwGsJtws Emails: 59 Keywords: 0.0 #infoleak",
  "id" : 430108466569416704,
  "created_at" : "2014-02-02 22:40:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lgj9q8KJHE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m2YzmNTm",
      "display_url" : "pastebin.com\/raw.php?i=m2Yz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430106058380431360",
  "text" : "http:\/\/t.co\/lgj9q8KJHE Hashes: 39 Keywords: 0.0 #infoleak",
  "id" : 430106058380431360,
  "created_at" : "2014-02-02 22:30:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fHm9RMWzTE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UZ0tNWiQ",
      "display_url" : "pastebin.com\/raw.php?i=UZ0t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430102199889166336",
  "text" : "http:\/\/t.co\/fHm9RMWzTE Hashes: 238 Keywords: -0.03 #infoleak",
  "id" : 430102199889166336,
  "created_at" : "2014-02-02 22:15:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5NzfOiE7XD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2hGSJKYC",
      "display_url" : "pastebin.com\/raw.php?i=2hGS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430095996727463936",
  "text" : "http:\/\/t.co\/5NzfOiE7XD Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 430095996727463936,
  "created_at" : "2014-02-02 21:50:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UbcMMyaRfj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NgS6M6Xp",
      "display_url" : "pastebin.com\/raw.php?i=NgS6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430072877115641856",
  "text" : "http:\/\/t.co\/UbcMMyaRfj Found possible Google API key(s) #infoleak",
  "id" : 430072877115641856,
  "created_at" : "2014-02-02 20:18:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1sm32hmms1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zJpYPCZ1",
      "display_url" : "pastebin.com\/raw.php?i=zJpY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430071735228964864",
  "text" : "http:\/\/t.co\/1sm32hmms1 Found possible Google API key(s) #infoleak",
  "id" : 430071735228964864,
  "created_at" : "2014-02-02 20:14:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pqkpfPdPUM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eZhrnSMt",
      "display_url" : "pastebin.com\/raw.php?i=eZhr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430050952356171777",
  "text" : "http:\/\/t.co\/pqkpfPdPUM Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 430050952356171777,
  "created_at" : "2014-02-02 18:51:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6iydvCHxKD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vTDT85V5",
      "display_url" : "pastebin.com\/raw.php?i=vTDT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430043409416736768",
  "text" : "http:\/\/t.co\/6iydvCHxKD Emails: 55 Keywords: 0.0 #infoleak",
  "id" : 430043409416736768,
  "created_at" : "2014-02-02 18:21:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BKmdJzjvtH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CdyUcHMY",
      "display_url" : "pastebin.com\/raw.php?i=CdyU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430039912889741312",
  "text" : "http:\/\/t.co\/BKmdJzjvtH Found possible Google API key(s) #infoleak",
  "id" : 430039912889741312,
  "created_at" : "2014-02-02 18:07:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oMcTmKSHSa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E3LHDspV",
      "display_url" : "pastebin.com\/raw.php?i=E3LH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430029117690372096",
  "text" : "http:\/\/t.co\/oMcTmKSHSa Emails: 237 Keywords: 0.0 #infoleak",
  "id" : 430029117690372096,
  "created_at" : "2014-02-02 17:25:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ink8dAUo57",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AcrihYRa",
      "display_url" : "pastebin.com\/raw.php?i=Acri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429923288278515712",
  "text" : "http:\/\/t.co\/Ink8dAUo57 Hashes: 501 Keywords: 0.11 #infoleak",
  "id" : 429923288278515712,
  "created_at" : "2014-02-02 10:24:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1KnuFw7ohR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ePP6Tkv6",
      "display_url" : "pastebin.com\/raw.php?i=ePP6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429914103289618433",
  "text" : "http:\/\/t.co\/1KnuFw7ohR Hashes: 99 Keywords: 0.0 #infoleak",
  "id" : 429914103289618433,
  "created_at" : "2014-02-02 09:48:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hlCI6UoQD7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2jKQGTmB",
      "display_url" : "pastebin.com\/raw.php?i=2jKQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429913262834991105",
  "text" : "http:\/\/t.co\/hlCI6UoQD7 Hashes: 3958 Keywords: 0.11 #infoleak",
  "id" : 429913262834991105,
  "created_at" : "2014-02-02 09:44:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ScjRglBf2Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7N4XjMRU",
      "display_url" : "pastebin.com\/raw.php?i=7N4X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429912524947865601",
  "text" : "http:\/\/t.co\/ScjRglBf2Z Emails: 1707 Keywords: -0.03 #infoleak",
  "id" : 429912524947865601,
  "created_at" : "2014-02-02 09:41:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CmJ5mMlTns",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8JaKHBqG",
      "display_url" : "pastebin.com\/raw.php?i=8JaK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429911613366214656",
  "text" : "http:\/\/t.co\/CmJ5mMlTns Hashes: 512 Keywords: -0.14 #infoleak",
  "id" : 429911613366214656,
  "created_at" : "2014-02-02 09:38:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uYuhhQOmGu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W4m9sYuj",
      "display_url" : "pastebin.com\/raw.php?i=W4m9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429898592216563713",
  "text" : "http:\/\/t.co\/uYuhhQOmGu Found possible Google API key(s) #infoleak",
  "id" : 429898592216563713,
  "created_at" : "2014-02-02 08:46:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uRGNozEVgv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ggTwjBxP",
      "display_url" : "pastebin.com\/raw.php?i=ggTw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429859817700610048",
  "text" : "http:\/\/t.co\/uRGNozEVgv Hashes: 126 Keywords: 0.33 #infoleak",
  "id" : 429859817700610048,
  "created_at" : "2014-02-02 06:12:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9tu3Xb9qxF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4GSjifHS",
      "display_url" : "pastebin.com\/raw.php?i=4GSj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429855188677976064",
  "text" : "http:\/\/t.co\/9tu3Xb9qxF Possible cisco configuration #infoleak",
  "id" : 429855188677976064,
  "created_at" : "2014-02-02 05:53:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SFjS3HNZpV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0ReWKquJ",
      "display_url" : "pastebin.com\/raw.php?i=0ReW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429854080320544768",
  "text" : "http:\/\/t.co\/SFjS3HNZpV Emails: 107 Keywords: 0.3 #infoleak",
  "id" : 429854080320544768,
  "created_at" : "2014-02-02 05:49:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vfQBjNm6GN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m6mSgx4P",
      "display_url" : "pastebin.com\/raw.php?i=m6mS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429848242705006592",
  "text" : "http:\/\/t.co\/vfQBjNm6GN Hashes: 2 Keywords: 0.77 #infoleak",
  "id" : 429848242705006592,
  "created_at" : "2014-02-02 05:26:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vvJOQfyr3s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XMAG6mg9",
      "display_url" : "pastebin.com\/raw.php?i=XMAG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429835848562253825",
  "text" : "http:\/\/t.co\/vvJOQfyr3s Emails: 51 Keywords: 0.44 #infoleak",
  "id" : 429835848562253825,
  "created_at" : "2014-02-02 04:37:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SJhIkTYDnF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hVNnc6HL",
      "display_url" : "pastebin.com\/raw.php?i=hVNn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429795276845776897",
  "text" : "http:\/\/t.co\/SJhIkTYDnF Emails: 172 Hashes: 931 E\/H: 0.18 Keywords: 0.66 #infoleak",
  "id" : 429795276845776897,
  "created_at" : "2014-02-02 01:55:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jQM9X4Cou2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bGn0BeSx",
      "display_url" : "pastebin.com\/raw.php?i=bGn0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429786337961857024",
  "text" : "http:\/\/t.co\/jQM9X4Cou2 Emails: 56 Keywords: -0.14 #infoleak",
  "id" : 429786337961857024,
  "created_at" : "2014-02-02 01:20:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6O1OI5UPIo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4wpTMjx9",
      "display_url" : "pastebin.com\/raw.php?i=4wpT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429776806011355138",
  "text" : "http:\/\/t.co\/6O1OI5UPIo Emails: 106 Hashes: 200 E\/H: 0.53 Keywords: 0.11 #infoleak",
  "id" : 429776806011355138,
  "created_at" : "2014-02-02 00:42:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P7qLB3ssMx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HUekce5g",
      "display_url" : "pastebin.com\/raw.php?i=HUek\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429770907712647168",
  "text" : "http:\/\/t.co\/P7qLB3ssMx Emails: 58 Keywords: -0.03 #infoleak",
  "id" : 429770907712647168,
  "created_at" : "2014-02-02 00:19:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E70dxwhEJ6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K2JG6ndB",
      "display_url" : "pastebin.com\/raw.php?i=K2JG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429770685687148544",
  "text" : "http:\/\/t.co\/E70dxwhEJ6 Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 429770685687148544,
  "created_at" : "2014-02-02 00:18:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IUPgp3p1oK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HZsAjffB",
      "display_url" : "pastebin.com\/raw.php?i=HZsA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429765510742290432",
  "text" : "http:\/\/t.co\/IUPgp3p1oK Emails: 58 Keywords: -0.14 #infoleak",
  "id" : 429765510742290432,
  "created_at" : "2014-02-01 23:57:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CCgonU5ZJd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eAA0uuhF",
      "display_url" : "pastebin.com\/raw.php?i=eAA0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429760397789233152",
  "text" : "http:\/\/t.co\/CCgonU5ZJd Possible cisco configuration #infoleak",
  "id" : 429760397789233152,
  "created_at" : "2014-02-01 23:37:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WwSX7M6M9X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wgyjQnf3",
      "display_url" : "pastebin.com\/raw.php?i=wgyj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429753506656829441",
  "text" : "http:\/\/t.co\/WwSX7M6M9X Emails: 231 Hashes: 201 E\/H: 1.15 Keywords: 0.33 #infoleak",
  "id" : 429753506656829441,
  "created_at" : "2014-02-01 23:09:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5uVt0dXgee",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pVLcQ75T",
      "display_url" : "pastebin.com\/raw.php?i=pVLc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429750688382320642",
  "text" : "http:\/\/t.co\/5uVt0dXgee Keywords: 0.55 #infoleak",
  "id" : 429750688382320642,
  "created_at" : "2014-02-01 22:58:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qk6NrW9yuJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jenHERw5",
      "display_url" : "pastebin.com\/raw.php?i=jenH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429749697268285441",
  "text" : "http:\/\/t.co\/Qk6NrW9yuJ Possible cisco configuration #infoleak",
  "id" : 429749697268285441,
  "created_at" : "2014-02-01 22:54:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2PaTsJ7sJK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tvSWJS6U",
      "display_url" : "pastebin.com\/raw.php?i=tvSW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429747562698924033",
  "text" : "http:\/\/t.co\/2PaTsJ7sJK Emails: 1320 Keywords: 0.44 #infoleak",
  "id" : 429747562698924033,
  "created_at" : "2014-02-01 22:46:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1qkmd6PTJt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kSUr4PTW",
      "display_url" : "pastebin.com\/raw.php?i=kSUr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429729231824633856",
  "text" : "http:\/\/t.co\/1qkmd6PTJt Emails: 1142 Hashes: 1143 E\/H: 1.0 Keywords: 0.88 #infoleak",
  "id" : 429729231824633856,
  "created_at" : "2014-02-01 21:33:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z8EGTD8FNA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KQfuyJVE",
      "display_url" : "pastebin.com\/raw.php?i=KQfu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429724369418321920",
  "text" : "http:\/\/t.co\/z8EGTD8FNA Emails: 729 Hashes: 1 E\/H: 729.0 Keywords: -0.14 #infoleak",
  "id" : 429724369418321920,
  "created_at" : "2014-02-01 21:14:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2HsaWEE20G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CuV8TeMj",
      "display_url" : "pastebin.com\/raw.php?i=CuV8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429717382966153218",
  "text" : "http:\/\/t.co\/2HsaWEE20G Emails: 65 Keywords: 0.44 #infoleak",
  "id" : 429717382966153218,
  "created_at" : "2014-02-01 20:46:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z5gGt7wtTp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GpPBYQ9d",
      "display_url" : "pastebin.com\/raw.php?i=GpPB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429710420664778753",
  "text" : "http:\/\/t.co\/z5gGt7wtTp Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 429710420664778753,
  "created_at" : "2014-02-01 20:18:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wJNav8mOgH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Luw2XsP2",
      "display_url" : "pastebin.com\/raw.php?i=Luw2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429703653507600384",
  "text" : "http:\/\/t.co\/wJNav8mOgH Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 429703653507600384,
  "created_at" : "2014-02-01 19:51:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0WjTRAnlpX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XpcPBLzL",
      "display_url" : "pastebin.com\/raw.php?i=XpcP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429702581636431872",
  "text" : "http:\/\/t.co\/0WjTRAnlpX Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 429702581636431872,
  "created_at" : "2014-02-01 19:47:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GsEuXaaWp2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y88nKB4x",
      "display_url" : "pastebin.com\/raw.php?i=y88n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429668700237492224",
  "text" : "http:\/\/t.co\/GsEuXaaWp2 Found possible Google API key(s) #infoleak",
  "id" : 429668700237492224,
  "created_at" : "2014-02-01 17:32:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/802W7614fn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=27w1EUfj",
      "display_url" : "pastebin.com\/raw.php?i=27w1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429647441336336384",
  "text" : "http:\/\/t.co\/802W7614fn Emails: 194 Hashes: 66 E\/H: 2.94 Keywords: 0.22 #infoleak",
  "id" : 429647441336336384,
  "created_at" : "2014-02-01 16:08:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nlNE14nrgV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PzhpGnEy",
      "display_url" : "pastebin.com\/raw.php?i=Pzhp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429633305940475904",
  "text" : "http:\/\/t.co\/nlNE14nrgV Found possible Google API key(s) #infoleak",
  "id" : 429633305940475904,
  "created_at" : "2014-02-01 15:12:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wPdR06vgk1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9wAMivRA",
      "display_url" : "pastebin.com\/raw.php?i=9wAM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429613959910416385",
  "text" : "http:\/\/t.co\/wPdR06vgk1 Emails: 11159 Keywords: 0.08 #infoleak",
  "id" : 429613959910416385,
  "created_at" : "2014-02-01 13:55:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MQxNqzbKyA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iLTzFn3e",
      "display_url" : "pastebin.com\/raw.php?i=iLTz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429612904883576832",
  "text" : "http:\/\/t.co\/MQxNqzbKyA Keywords: 0.66 #infoleak",
  "id" : 429612904883576832,
  "created_at" : "2014-02-01 13:51:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gocf5zr4JT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yrUy2PNP",
      "display_url" : "pastebin.com\/raw.php?i=yrUy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429612716366368768",
  "text" : "http:\/\/t.co\/gocf5zr4JT Emails: 6599 Keywords: 0.22 #infoleak",
  "id" : 429612716366368768,
  "created_at" : "2014-02-01 13:50:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JQhlXfxR1g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DFucD8Yz",
      "display_url" : "pastebin.com\/raw.php?i=DFuc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429611277938221056",
  "text" : "http:\/\/t.co\/JQhlXfxR1g Emails: 1836 Keywords: 0.08 #infoleak",
  "id" : 429611277938221056,
  "created_at" : "2014-02-01 13:44:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C4kFy4iYNw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rtLiv1kP",
      "display_url" : "pastebin.com\/raw.php?i=rtLi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429582626035228673",
  "text" : "http:\/\/t.co\/C4kFy4iYNw Hashes: 38 Keywords: 0.0 #infoleak",
  "id" : 429582626035228673,
  "created_at" : "2014-02-01 11:50:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
} ]
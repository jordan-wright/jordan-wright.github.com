Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468175327861026816",
  "text" : "Brief outage - moving to a new location. Be back soon!",
  "id" : 468175327861026816,
  "created_at" : "2014-05-18 23:44:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ChUsMyNRIV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JavM17Ci",
      "display_url" : "pastebin.com\/raw.php?i=JavM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466617239387783168",
  "text" : "http:\/\/t.co\/ChUsMyNRIV Emails: 39 Keywords: 0.22 #infoleak",
  "id" : 466617239387783168,
  "created_at" : "2014-05-14 16:33:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cETBKkZ8WF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uaVVDCqX",
      "display_url" : "pastebin.com\/raw.php?i=uaVV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466616250186334209",
  "text" : "http:\/\/t.co\/cETBKkZ8WF Keywords: 0.55 #infoleak",
  "id" : 466616250186334209,
  "created_at" : "2014-05-14 16:29:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YVmrGMZnei",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fw9xHWC4",
      "display_url" : "pastebin.com\/raw.php?i=fw9x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466604278808076288",
  "text" : "http:\/\/t.co\/YVmrGMZnei Found possible Google API key(s) #infoleak",
  "id" : 466604278808076288,
  "created_at" : "2014-05-14 15:41:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/weWC1TJiqC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hKsBRfX0",
      "display_url" : "pastebin.com\/raw.php?i=hKsB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466597112638357504",
  "text" : "http:\/\/t.co\/weWC1TJiqC Emails: 153 Keywords: 0.0 #infoleak",
  "id" : 466597112638357504,
  "created_at" : "2014-05-14 15:13:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2R0w3cnyib",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9dGyk7qm",
      "display_url" : "pastebin.com\/raw.php?i=9dGy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466594419295399936",
  "text" : "http:\/\/t.co\/2R0w3cnyib Emails: 36 Hashes: 37 E\/H: 0.97 Keywords: 0.0 #infoleak",
  "id" : 466594419295399936,
  "created_at" : "2014-05-14 15:02:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TAhQTdxQNL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZD6R6nf7",
      "display_url" : "pastebin.com\/raw.php?i=ZD6R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466593426671013888",
  "text" : "http:\/\/t.co\/TAhQTdxQNL Found possible Google API key(s) #infoleak",
  "id" : 466593426671013888,
  "created_at" : "2014-05-14 14:58:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NPTeGiGzLD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tvi1vr7D",
      "display_url" : "pastebin.com\/raw.php?i=tvi1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466589741979152384",
  "text" : "http:\/\/t.co\/NPTeGiGzLD Possible cisco configuration #infoleak",
  "id" : 466589741979152384,
  "created_at" : "2014-05-14 14:43:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XaaWDHh0dH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hegdjc4f",
      "display_url" : "pastebin.com\/raw.php?i=Hegd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466581454072598528",
  "text" : "http:\/\/t.co\/XaaWDHh0dH Emails: 114 Keywords: 0.0 #infoleak",
  "id" : 466581454072598528,
  "created_at" : "2014-05-14 14:11:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yfyt6NXivM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iff23dp8",
      "display_url" : "pastebin.com\/raw.php?i=iff2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466578131051376640",
  "text" : "http:\/\/t.co\/Yfyt6NXivM Emails: 808 Hashes: 808 E\/H: 1.0 Keywords: 0.44 #infoleak",
  "id" : 466578131051376640,
  "created_at" : "2014-05-14 13:57:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sIDtjP3EtE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dQ8rik79",
      "display_url" : "pastebin.com\/raw.php?i=dQ8r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466576052140408832",
  "text" : "http:\/\/t.co\/sIDtjP3EtE Emails: 108 Hashes: 180 E\/H: 0.6 Keywords: 0.22 #infoleak",
  "id" : 466576052140408832,
  "created_at" : "2014-05-14 13:49:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JDt15ZllLs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vq76jvXC",
      "display_url" : "pastebin.com\/raw.php?i=vq76\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466568322205499393",
  "text" : "http:\/\/t.co\/JDt15ZllLs Found possible Google API key(s) #infoleak",
  "id" : 466568322205499393,
  "created_at" : "2014-05-14 13:18:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IYyDePfDyy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SbPdXAcP",
      "display_url" : "pastebin.com\/raw.php?i=SbPd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466566926022754305",
  "text" : "http:\/\/t.co\/IYyDePfDyy Emails: 106 Keywords: 0.0 #infoleak",
  "id" : 466566926022754305,
  "created_at" : "2014-05-14 13:13:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wXP6Z2ueFN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nhP8x1bZ",
      "display_url" : "pastebin.com\/raw.php?i=nhP8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466566819709747200",
  "text" : "http:\/\/t.co\/wXP6Z2ueFN Hashes: 31 Keywords: 0.16 #infoleak",
  "id" : 466566819709747200,
  "created_at" : "2014-05-14 13:12:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/390BzI3gb3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ey0HEvas",
      "display_url" : "pastebin.com\/raw.php?i=Ey0H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466565135088099328",
  "text" : "http:\/\/t.co\/390BzI3gb3 Emails: 499 Keywords: 0.0 #infoleak",
  "id" : 466565135088099328,
  "created_at" : "2014-05-14 13:06:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3C80OXmp7J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H4Qtd4Jf",
      "display_url" : "pastebin.com\/raw.php?i=H4Qt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466556228555264000",
  "text" : "http:\/\/t.co\/3C80OXmp7J Hashes: 67 Keywords: 0.33 #infoleak",
  "id" : 466556228555264000,
  "created_at" : "2014-05-14 12:30:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5civSkw81A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NNYXWyrB",
      "display_url" : "pastebin.com\/raw.php?i=NNYX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466544025218994177",
  "text" : "http:\/\/t.co\/5civSkw81A Emails: 2 Hashes: 119 E\/H: 0.02 Keywords: 0.41 #infoleak",
  "id" : 466544025218994177,
  "created_at" : "2014-05-14 11:42:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tIpx8DntXC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LgwaD5tX",
      "display_url" : "pastebin.com\/raw.php?i=Lgwa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466540313444900864",
  "text" : "http:\/\/t.co\/tIpx8DntXC Emails: 1 Hashes: 55 E\/H: 0.02 Keywords: 0.08 #infoleak",
  "id" : 466540313444900864,
  "created_at" : "2014-05-14 11:27:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VdmUiTI1RL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SegqzvLr",
      "display_url" : "pastebin.com\/raw.php?i=Segq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466539391461363712",
  "text" : "http:\/\/t.co\/VdmUiTI1RL Hashes: 144 Keywords: 0.0 #infoleak",
  "id" : 466539391461363712,
  "created_at" : "2014-05-14 11:23:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T1Up2UFWJe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v3VZxiUm",
      "display_url" : "pastebin.com\/raw.php?i=v3VZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466538973771599873",
  "text" : "http:\/\/t.co\/T1Up2UFWJe Emails: 314 Hashes: 315 E\/H: 1.0 Keywords: 0.74 #infoleak",
  "id" : 466538973771599873,
  "created_at" : "2014-05-14 11:22:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fGwllrSdTN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zmbCJsUN",
      "display_url" : "pastebin.com\/raw.php?i=zmbC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466536703222886400",
  "text" : "http:\/\/t.co\/fGwllrSdTN Emails: 163 Keywords: 0.0 #infoleak",
  "id" : 466536703222886400,
  "created_at" : "2014-05-14 11:13:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3xaGLT1kIP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EHYe3XaG",
      "display_url" : "pastebin.com\/raw.php?i=EHYe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466531801402728448",
  "text" : "http:\/\/t.co\/3xaGLT1kIP Emails: 398 Keywords: 0.0 #infoleak",
  "id" : 466531801402728448,
  "created_at" : "2014-05-14 10:53:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A5IZ116kkx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p2EdfyEF",
      "display_url" : "pastebin.com\/raw.php?i=p2Ed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466515016259497984",
  "text" : "http:\/\/t.co\/A5IZ116kkx Emails: 23 Keywords: 0.08 #infoleak",
  "id" : 466515016259497984,
  "created_at" : "2014-05-14 09:47:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/85z4RSINPH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xb84A314",
      "display_url" : "pastebin.com\/raw.php?i=xb84\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466509983434428416",
  "text" : "http:\/\/t.co\/85z4RSINPH Possible cisco configuration #infoleak",
  "id" : 466509983434428416,
  "created_at" : "2014-05-14 09:27:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S8iCp3rSLN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0s6hR7bX",
      "display_url" : "pastebin.com\/raw.php?i=0s6h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466506660476112896",
  "text" : "http:\/\/t.co\/S8iCp3rSLN Emails: 342 Keywords: 0.0 #infoleak",
  "id" : 466506660476112896,
  "created_at" : "2014-05-14 09:13:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/usogJQnhyY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hFXHs3Bf",
      "display_url" : "pastebin.com\/raw.php?i=hFXH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466496771448131584",
  "text" : "http:\/\/t.co\/usogJQnhyY Emails: 93 Keywords: 0.0 #infoleak",
  "id" : 466496771448131584,
  "created_at" : "2014-05-14 08:34:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VB2WAQw5ht",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gD4QkGu5",
      "display_url" : "pastebin.com\/raw.php?i=gD4Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466496468535488512",
  "text" : "http:\/\/t.co\/VB2WAQw5ht Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 466496468535488512,
  "created_at" : "2014-05-14 08:33:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KVUefN3ON5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MLQvKGvB",
      "display_url" : "pastebin.com\/raw.php?i=MLQv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466490282847248384",
  "text" : "http:\/\/t.co\/KVUefN3ON5 Possible cisco configuration #infoleak",
  "id" : 466490282847248384,
  "created_at" : "2014-05-14 08:08:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ytWsYXV1Xo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NNnxFSu9",
      "display_url" : "pastebin.com\/raw.php?i=NNnx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466489492019634176",
  "text" : "http:\/\/t.co\/ytWsYXV1Xo Hashes: 48 Keywords: 0.33 #infoleak",
  "id" : 466489492019634176,
  "created_at" : "2014-05-14 08:05:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fkO3B4Ca4U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9ZRyzW17",
      "display_url" : "pastebin.com\/raw.php?i=9ZRy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466476307506028544",
  "text" : "http:\/\/t.co\/fkO3B4Ca4U Emails: 176 Keywords: 0.0 #infoleak",
  "id" : 466476307506028544,
  "created_at" : "2014-05-14 07:13:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NDXIWNBQhP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZHHd6Wxx",
      "display_url" : "pastebin.com\/raw.php?i=ZHHd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466468272855339008",
  "text" : "http:\/\/t.co\/NDXIWNBQhP Emails: 318 Keywords: 0.44 #infoleak",
  "id" : 466468272855339008,
  "created_at" : "2014-05-14 06:41:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SMgeHOpx95",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g2MjAftJ",
      "display_url" : "pastebin.com\/raw.php?i=g2Mj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466449074691276800",
  "text" : "http:\/\/t.co\/SMgeHOpx95 Emails: 217 Hashes: 219 E\/H: 0.99 Keywords: 0.44 #infoleak",
  "id" : 466449074691276800,
  "created_at" : "2014-05-14 05:25:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CxG6gOzajO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fmWkU7fR",
      "display_url" : "pastebin.com\/raw.php?i=fmWk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466446092939575296",
  "text" : "http:\/\/t.co\/CxG6gOzajO Emails: 175 Keywords: 0.0 #infoleak",
  "id" : 466446092939575296,
  "created_at" : "2014-05-14 05:13:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MZBpMc3Uyg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e5a2xMai",
      "display_url" : "pastebin.com\/raw.php?i=e5a2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466425884665458688",
  "text" : "http:\/\/t.co\/MZBpMc3Uyg Found possible Google API key(s) #infoleak",
  "id" : 466425884665458688,
  "created_at" : "2014-05-14 03:52:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bzw4Q9KS3e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AMPmfevT",
      "display_url" : "pastebin.com\/raw.php?i=AMPm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466424968184877056",
  "text" : "http:\/\/t.co\/bzw4Q9KS3e Found possible Google API key(s) #infoleak",
  "id" : 466424968184877056,
  "created_at" : "2014-05-14 03:49:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gcK0fAbYU7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dxgUPC4A",
      "display_url" : "pastebin.com\/raw.php?i=dxgU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466415898493214720",
  "text" : "http:\/\/t.co\/gcK0fAbYU7 Emails: 230 Keywords: 0.0 #infoleak",
  "id" : 466415898493214720,
  "created_at" : "2014-05-14 03:13:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gxzOx7dIQv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qcuREQq8",
      "display_url" : "pastebin.com\/raw.php?i=qcuR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466399416099037184",
  "text" : "http:\/\/t.co\/gxzOx7dIQv Keywords: 0.66 #infoleak",
  "id" : 466399416099037184,
  "created_at" : "2014-05-14 02:07:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8QIqJZlRNF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HRzXgjNa",
      "display_url" : "pastebin.com\/raw.php?i=HRzX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466399153409773569",
  "text" : "http:\/\/t.co\/8QIqJZlRNF Emails: 385 Keywords: 0.11 #infoleak",
  "id" : 466399153409773569,
  "created_at" : "2014-05-14 02:06:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vU9qS1mETw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rixQERC2",
      "display_url" : "pastebin.com\/raw.php?i=rixQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466385723533582336",
  "text" : "http:\/\/t.co\/vU9qS1mETw Emails: 166 Keywords: 0.0 #infoleak",
  "id" : 466385723533582336,
  "created_at" : "2014-05-14 01:13:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LwyVbbBeIC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tuVgpnHd",
      "display_url" : "pastebin.com\/raw.php?i=tuVg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466384236963188736",
  "text" : "http:\/\/t.co\/LwyVbbBeIC Emails: 3461 Keywords: 0.44 #infoleak",
  "id" : 466384236963188736,
  "created_at" : "2014-05-14 01:07:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YzCZRiCJa7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pq44vf0c",
      "display_url" : "pastebin.com\/raw.php?i=pq44\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466382450286133252",
  "text" : "http:\/\/t.co\/YzCZRiCJa7 Emails: 2958 Keywords: 0.08 #infoleak",
  "id" : 466382450286133252,
  "created_at" : "2014-05-14 01:00:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mNDobXFwlz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NmAMTVGj",
      "display_url" : "pastebin.com\/raw.php?i=NmAM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466381129805987841",
  "text" : "http:\/\/t.co\/mNDobXFwlz Emails: 1067 Keywords: 0.22 #infoleak",
  "id" : 466381129805987841,
  "created_at" : "2014-05-14 00:55:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/az9i7EvuFj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SwYcgDGr",
      "display_url" : "pastebin.com\/raw.php?i=SwYc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466377613976817667",
  "text" : "http:\/\/t.co\/az9i7EvuFj Emails: 753 Keywords: 0.22 #infoleak",
  "id" : 466377613976817667,
  "created_at" : "2014-05-14 00:41:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r1MXKrfbny",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qxea9D0C",
      "display_url" : "pastebin.com\/raw.php?i=qxea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466355691977179136",
  "text" : "http:\/\/t.co\/r1MXKrfbny Emails: 379 Keywords: 0.0 #infoleak",
  "id" : 466355691977179136,
  "created_at" : "2014-05-13 23:13:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gdho9yC3ev",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E4f8XCCq",
      "display_url" : "pastebin.com\/raw.php?i=E4f8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466349420075053056",
  "text" : "http:\/\/t.co\/Gdho9yC3ev Hashes: 234 Keywords: 0.11 #infoleak",
  "id" : 466349420075053056,
  "created_at" : "2014-05-13 22:49:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lNil0NafwH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RYGFMpeL",
      "display_url" : "pastebin.com\/raw.php?i=RYGF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466341173150646272",
  "text" : "http:\/\/t.co\/lNil0NafwH Emails: 498 Keywords: 0.0 #infoleak",
  "id" : 466341173150646272,
  "created_at" : "2014-05-13 22:16:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zOcA7peGBk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ahuqmsmi",
      "display_url" : "pastebin.com\/raw.php?i=ahuq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466340543845638144",
  "text" : "http:\/\/t.co\/zOcA7peGBk Emails: 494 Keywords: 0.0 #infoleak",
  "id" : 466340543845638144,
  "created_at" : "2014-05-13 22:13:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ebFxcSBC3b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ujgYGXT7",
      "display_url" : "pastebin.com\/raw.php?i=ujgY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466337091493068801",
  "text" : "http:\/\/t.co\/ebFxcSBC3b Emails: 89 Keywords: 0.0 #infoleak",
  "id" : 466337091493068801,
  "created_at" : "2014-05-13 22:00:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xst3UWd46M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8F4hFYdU",
      "display_url" : "pastebin.com\/raw.php?i=8F4h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466335111559249921",
  "text" : "http:\/\/t.co\/xst3UWd46M Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 466335111559249921,
  "created_at" : "2014-05-13 21:52:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xwZtLxXPEG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sZX7uJN0",
      "display_url" : "pastebin.com\/raw.php?i=sZX7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466325304194375680",
  "text" : "http:\/\/t.co\/xwZtLxXPEG Emails: 381 Keywords: 0.0 #infoleak",
  "id" : 466325304194375680,
  "created_at" : "2014-05-13 21:13:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5yPYY7eAWS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KThgZ0aL",
      "display_url" : "pastebin.com\/raw.php?i=KThg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466307305487626241",
  "text" : "http:\/\/t.co\/5yPYY7eAWS Emails: 4 Hashes: 109 E\/H: 0.04 Keywords: 0.08 #infoleak",
  "id" : 466307305487626241,
  "created_at" : "2014-05-13 20:01:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w83MfWLywj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8epXc5CC",
      "display_url" : "pastebin.com\/raw.php?i=8epX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466306691529601024",
  "text" : "http:\/\/t.co\/w83MfWLywj Hashes: 31 Keywords: 0.22 #infoleak",
  "id" : 466306691529601024,
  "created_at" : "2014-05-13 19:59:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h2EyyWbXy1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1i2yBWYh",
      "display_url" : "pastebin.com\/raw.php?i=1i2y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466305666609471489",
  "text" : "http:\/\/t.co\/h2EyyWbXy1 Hashes: 55 Keywords: 0.08 #infoleak",
  "id" : 466305666609471489,
  "created_at" : "2014-05-13 19:55:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iUn2PXT7e7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9CkDKVnd",
      "display_url" : "pastebin.com\/raw.php?i=9CkD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466304647842377729",
  "text" : "http:\/\/t.co\/iUn2PXT7e7 Hashes: 38 Keywords: -0.06 #infoleak",
  "id" : 466304647842377729,
  "created_at" : "2014-05-13 19:51:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o7n90hi0WO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vG4tenDf",
      "display_url" : "pastebin.com\/raw.php?i=vG4t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466232834550558721",
  "text" : "http:\/\/t.co\/o7n90hi0WO Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 466232834550558721,
  "created_at" : "2014-05-13 15:05:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/irxCd1y3qR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g7TR4ekw",
      "display_url" : "pastebin.com\/raw.php?i=g7TR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466023489430753281",
  "text" : "http:\/\/t.co\/irxCd1y3qR Emails: 162 Keywords: 0.0 #infoleak",
  "id" : 466023489430753281,
  "created_at" : "2014-05-13 01:13:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MW18oLRYUF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rdRaqGQb",
      "display_url" : "pastebin.com\/raw.php?i=rdRa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466018484246175745",
  "text" : "http:\/\/t.co\/MW18oLRYUF Emails: 39 Keywords: 0.0 #infoleak",
  "id" : 466018484246175745,
  "created_at" : "2014-05-13 00:53:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bTRQWrUVpY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s1dcW9HE",
      "display_url" : "pastebin.com\/raw.php?i=s1dc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466018156125761537",
  "text" : "http:\/\/t.co\/bTRQWrUVpY Emails: 49 Keywords: 0.0 #infoleak",
  "id" : 466018156125761537,
  "created_at" : "2014-05-13 00:52:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SRpVGhOkJu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7YzPHpUe",
      "display_url" : "pastebin.com\/raw.php?i=7YzP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466015019159662592",
  "text" : "http:\/\/t.co\/SRpVGhOkJu Emails: 419 Hashes: 416 E\/H: 1.01 Keywords: -0.03 #infoleak",
  "id" : 466015019159662592,
  "created_at" : "2014-05-13 00:40:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gPt22GwdEm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yJidKNgs",
      "display_url" : "pastebin.com\/raw.php?i=yJid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466003657125675008",
  "text" : "http:\/\/t.co\/gPt22GwdEm Emails: 49 Keywords: 0.0 #infoleak",
  "id" : 466003657125675008,
  "created_at" : "2014-05-12 23:55:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1MXHr60QCb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zd3TUHa2",
      "display_url" : "pastebin.com\/raw.php?i=zd3T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465993140315246594",
  "text" : "http:\/\/t.co\/1MXHr60QCb Emails: 154 Keywords: 0.0 #infoleak",
  "id" : 465993140315246594,
  "created_at" : "2014-05-12 23:13:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Rr00soqKM6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XAtR8fsj",
      "display_url" : "pastebin.com\/raw.php?i=XAtR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465990360976461825",
  "text" : "http:\/\/t.co\/Rr00soqKM6 Found possible Google API key(s) #infoleak",
  "id" : 465990360976461825,
  "created_at" : "2014-05-12 23:02:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JiG9xFIHFS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a0v1P8jA",
      "display_url" : "pastebin.com\/raw.php?i=a0v1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465990324947406848",
  "text" : "http:\/\/t.co\/JiG9xFIHFS Hashes: 51 Keywords: 0.05 #infoleak",
  "id" : 465990324947406848,
  "created_at" : "2014-05-12 23:02:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TtNvxI4l8L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SvZR2M9L",
      "display_url" : "pastebin.com\/raw.php?i=SvZR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465988858052497408",
  "text" : "http:\/\/t.co\/TtNvxI4l8L Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 465988858052497408,
  "created_at" : "2014-05-12 22:56:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tiLrVNFbk7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wqYFXJLN",
      "display_url" : "pastebin.com\/raw.php?i=wqYF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465981218186481664",
  "text" : "http:\/\/t.co\/tiLrVNFbk7 Hashes: 62 Keywords: -0.09 #infoleak",
  "id" : 465981218186481664,
  "created_at" : "2014-05-12 22:25:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IJAw2MmA0L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0ixyarHQ",
      "display_url" : "pastebin.com\/raw.php?i=0ixy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465979279570780160",
  "text" : "http:\/\/t.co\/IJAw2MmA0L Hashes: 50 Keywords: 0.11 #infoleak",
  "id" : 465979279570780160,
  "created_at" : "2014-05-12 22:18:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AltGndpgok",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5bhzu66D",
      "display_url" : "pastebin.com\/raw.php?i=5bhz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465976502744403970",
  "text" : "http:\/\/t.co\/AltGndpgok Possible cisco configuration #infoleak",
  "id" : 465976502744403970,
  "created_at" : "2014-05-12 22:07:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2LLeUiLryV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xjxMFKzU",
      "display_url" : "pastebin.com\/raw.php?i=xjxM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465970497675489280",
  "text" : "http:\/\/t.co\/2LLeUiLryV Found possible Google API key(s) #infoleak",
  "id" : 465970497675489280,
  "created_at" : "2014-05-12 21:43:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZyZ3XakkgJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8rsBxgKB",
      "display_url" : "pastebin.com\/raw.php?i=8rsB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465965009932021760",
  "text" : "http:\/\/t.co\/ZyZ3XakkgJ Keywords: 0.55 #infoleak",
  "id" : 465965009932021760,
  "created_at" : "2014-05-12 21:21:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VhJhPOx3Ww",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nKRe8J6F",
      "display_url" : "pastebin.com\/raw.php?i=nKRe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465963108058419200",
  "text" : "http:\/\/t.co\/VhJhPOx3Ww Emails: 395 Keywords: 0.11 #infoleak",
  "id" : 465963108058419200,
  "created_at" : "2014-05-12 21:13:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OlukjZapFt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aZbvUMfz",
      "display_url" : "pastebin.com\/raw.php?i=aZbv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465962378106904576",
  "text" : "http:\/\/t.co\/OlukjZapFt Found possible Google API key(s) #infoleak",
  "id" : 465962378106904576,
  "created_at" : "2014-05-12 21:11:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1acREsPuok",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mc7CZg0t",
      "display_url" : "pastebin.com\/raw.php?i=Mc7C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465957609229398016",
  "text" : "http:\/\/t.co\/1acREsPuok Possible cisco configuration #infoleak",
  "id" : 465957609229398016,
  "created_at" : "2014-05-12 20:52:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3qjIZC5npX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7g5yvUtd",
      "display_url" : "pastebin.com\/raw.php?i=7g5y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465954241446547456",
  "text" : "http:\/\/t.co\/3qjIZC5npX Keywords: 0.55 #infoleak",
  "id" : 465954241446547456,
  "created_at" : "2014-05-12 20:38:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yl2dC7vWig",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Qnn5hcg",
      "display_url" : "pastebin.com\/raw.php?i=7Qnn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465945144382853120",
  "text" : "http:\/\/t.co\/Yl2dC7vWig Found possible Google API key(s) #infoleak",
  "id" : 465945144382853120,
  "created_at" : "2014-05-12 20:02:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hosn6Zn2wo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SqKu2abv",
      "display_url" : "pastebin.com\/raw.php?i=SqKu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465940865433628672",
  "text" : "http:\/\/t.co\/hosn6Zn2wo Emails: 73 Keywords: 0.0 #infoleak",
  "id" : 465940865433628672,
  "created_at" : "2014-05-12 19:45:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m9WifoqvLd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ENNyEKut",
      "display_url" : "pastebin.com\/raw.php?i=ENNy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465932721768759296",
  "text" : "http:\/\/t.co\/m9WifoqvLd Emails: 146 Keywords: 0.0 #infoleak",
  "id" : 465932721768759296,
  "created_at" : "2014-05-12 19:13:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X0BLkuHo0B",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f0tg7VbZ",
      "display_url" : "pastebin.com\/raw.php?i=f0tg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465923502273339392",
  "text" : "http:\/\/t.co\/X0BLkuHo0B Found possible Google API key(s) #infoleak",
  "id" : 465923502273339392,
  "created_at" : "2014-05-12 18:36:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mqbxD3bIVK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bEKBLf6p",
      "display_url" : "pastebin.com\/raw.php?i=bEKB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465916522079059968",
  "text" : "http:\/\/t.co\/mqbxD3bIVK Emails: 327 Keywords: 0.33 #infoleak",
  "id" : 465916522079059968,
  "created_at" : "2014-05-12 18:08:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n89syyRGST",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QtXqrVqe",
      "display_url" : "pastebin.com\/raw.php?i=QtXq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465915907001171968",
  "text" : "http:\/\/t.co\/n89syyRGST Hashes: 184 Keywords: 0.0 #infoleak",
  "id" : 465915907001171968,
  "created_at" : "2014-05-12 18:06:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fNzfVVaCvu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zYpHyGiN",
      "display_url" : "pastebin.com\/raw.php?i=zYpH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465901364963733504",
  "text" : "http:\/\/t.co\/fNzfVVaCvu Found possible Google API key(s) #infoleak",
  "id" : 465901364963733504,
  "created_at" : "2014-05-12 17:08:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XKvzvs9jtS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m0QJ1EkL",
      "display_url" : "pastebin.com\/raw.php?i=m0QJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465899768485404672",
  "text" : "http:\/\/t.co\/XKvzvs9jtS Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 465899768485404672,
  "created_at" : "2014-05-12 17:02:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oFGquHZ8Nv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HgpxJwfc",
      "display_url" : "pastebin.com\/raw.php?i=Hgpx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465896819419930624",
  "text" : "http:\/\/t.co\/oFGquHZ8Nv Emails: 26 Keywords: -0.14 #infoleak",
  "id" : 465896819419930624,
  "created_at" : "2014-05-12 16:50:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CzgpNMhZVy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uNsK5T4E",
      "display_url" : "pastebin.com\/raw.php?i=uNsK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465890969603174400",
  "text" : "http:\/\/t.co\/CzgpNMhZVy Found possible Google API key(s) #infoleak",
  "id" : 465890969603174400,
  "created_at" : "2014-05-12 16:27:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dOn1a7GLBe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=522NHFdp",
      "display_url" : "pastebin.com\/raw.php?i=522N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465890439304712192",
  "text" : "http:\/\/t.co\/dOn1a7GLBe Hashes: 91 Keywords: 0.3 #infoleak",
  "id" : 465890439304712192,
  "created_at" : "2014-05-12 16:25:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Un7GlZRm1W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AXU7Xayj",
      "display_url" : "pastebin.com\/raw.php?i=AXU7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465888678812717057",
  "text" : "http:\/\/t.co\/Un7GlZRm1W Possible cisco configuration #infoleak",
  "id" : 465888678812717057,
  "created_at" : "2014-05-12 16:18:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zC36Yw1I1w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qywcQ8pE",
      "display_url" : "pastebin.com\/raw.php?i=qywc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465888135818133505",
  "text" : "http:\/\/t.co\/zC36Yw1I1w Hashes: 7 Keywords: 0.63 #infoleak",
  "id" : 465888135818133505,
  "created_at" : "2014-05-12 16:16:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h0MVEZ2W8J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3jQEZtNW",
      "display_url" : "pastebin.com\/raw.php?i=3jQE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465887027754328065",
  "text" : "http:\/\/t.co\/h0MVEZ2W8J Emails: 400 Keywords: 0.0 #infoleak",
  "id" : 465887027754328065,
  "created_at" : "2014-05-12 16:11:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0bcP9m6UGn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hJm1E7Zm",
      "display_url" : "pastebin.com\/raw.php?i=hJm1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465880881572220928",
  "text" : "http:\/\/t.co\/0bcP9m6UGn Emails: 9 Hashes: 42 E\/H: 0.21 Keywords: 0.11 #infoleak",
  "id" : 465880881572220928,
  "created_at" : "2014-05-12 15:47:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OTEo0u6Ikx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qwzUUXub",
      "display_url" : "pastebin.com\/raw.php?i=qwzU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465879457056563200",
  "text" : "http:\/\/t.co\/OTEo0u6Ikx Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 465879457056563200,
  "created_at" : "2014-05-12 15:41:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DblEuipbCZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pkYeiQfH",
      "display_url" : "pastebin.com\/raw.php?i=pkYe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465878031601389568",
  "text" : "http:\/\/t.co\/DblEuipbCZ Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 465878031601389568,
  "created_at" : "2014-05-12 15:35:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hOTYUnNUa0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5Anga8W1",
      "display_url" : "pastebin.com\/raw.php?i=5Ang\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465872321924694016",
  "text" : "http:\/\/t.co\/hOTYUnNUa0 Emails: 273 Keywords: 0.11 #infoleak",
  "id" : 465872321924694016,
  "created_at" : "2014-05-12 15:13:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JdmEsjQpAA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fN77kmrA",
      "display_url" : "pastebin.com\/raw.php?i=fN77\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465871755177771009",
  "text" : "http:\/\/t.co\/JdmEsjQpAA Hashes: 85 Keywords: 0.0 #infoleak",
  "id" : 465871755177771009,
  "created_at" : "2014-05-12 15:10:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PpIbsN93eO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3P6eFrbV",
      "display_url" : "pastebin.com\/raw.php?i=3P6e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465870152458702851",
  "text" : "http:\/\/t.co\/PpIbsN93eO Emails: 498 Keywords: 0.0 #infoleak",
  "id" : 465870152458702851,
  "created_at" : "2014-05-12 15:04:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/28hOQk2OLu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MH6DrHnk",
      "display_url" : "pastebin.com\/raw.php?i=MH6D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465864341351170048",
  "text" : "http:\/\/t.co\/28hOQk2OLu Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 465864341351170048,
  "created_at" : "2014-05-12 14:41:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A2drDo7Omv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6UBkpq38",
      "display_url" : "pastebin.com\/raw.php?i=6UBk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465862137575796736",
  "text" : "http:\/\/t.co\/A2drDo7Omv Found possible Google API key(s) #infoleak",
  "id" : 465862137575796736,
  "created_at" : "2014-05-12 14:32:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b7Gj26KSpc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mxdCpQ8E",
      "display_url" : "pastebin.com\/raw.php?i=mxdC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465856969090142209",
  "text" : "http:\/\/t.co\/b7Gj26KSpc Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 465856969090142209,
  "created_at" : "2014-05-12 14:12:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FQUXGuUPWv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=veYMZrav",
      "display_url" : "pastebin.com\/raw.php?i=veYM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465842142598803456",
  "text" : "http:\/\/t.co\/FQUXGuUPWv Emails: 308 Keywords: 0.0 #infoleak",
  "id" : 465842142598803456,
  "created_at" : "2014-05-12 13:13:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LzMglLdeh1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EfpNSx58",
      "display_url" : "pastebin.com\/raw.php?i=EfpN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465841147818950657",
  "text" : "http:\/\/t.co\/LzMglLdeh1 Emails: 384 Keywords: 0.11 #infoleak",
  "id" : 465841147818950657,
  "created_at" : "2014-05-12 13:09:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0IU9fqocA0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bceUwKWR",
      "display_url" : "pastebin.com\/raw.php?i=bceU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465840359646318592",
  "text" : "http:\/\/t.co\/0IU9fqocA0 Emails: 1247 Keywords: 0.0 #infoleak",
  "id" : 465840359646318592,
  "created_at" : "2014-05-12 13:06:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kDCucHjzw1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bJi2NRww",
      "display_url" : "pastebin.com\/raw.php?i=bJi2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465836416266555394",
  "text" : "http:\/\/t.co\/kDCucHjzw1 Emails: 6344 Keywords: 0.3 #infoleak",
  "id" : 465836416266555394,
  "created_at" : "2014-05-12 12:50:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3UDUQWxml1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6cgwk1qv",
      "display_url" : "pastebin.com\/raw.php?i=6cgw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465834023491629057",
  "text" : "http:\/\/t.co\/3UDUQWxml1 Hashes: 60 Keywords: 0.22 #infoleak",
  "id" : 465834023491629057,
  "created_at" : "2014-05-12 12:41:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HdEKPPJ36Q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=encW69WG",
      "display_url" : "pastebin.com\/raw.php?i=encW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465813555577491456",
  "text" : "http:\/\/t.co\/HdEKPPJ36Q Emails: 340 Hashes: 359 E\/H: 0.95 Keywords: 0.11 #infoleak",
  "id" : 465813555577491456,
  "created_at" : "2014-05-12 11:19:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZBHUrioVYA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QWpvi8q8",
      "display_url" : "pastebin.com\/raw.php?i=QWpv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465811925788393472",
  "text" : "http:\/\/t.co\/ZBHUrioVYA Emails: 222 Keywords: 0.0 #infoleak",
  "id" : 465811925788393472,
  "created_at" : "2014-05-12 11:13:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i6kI2hvZq3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NiSxXK6Q",
      "display_url" : "pastebin.com\/raw.php?i=NiSx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465811237033345024",
  "text" : "http:\/\/t.co\/i6kI2hvZq3 Hashes: 292 Keywords: 0.11 #infoleak",
  "id" : 465811237033345024,
  "created_at" : "2014-05-12 11:10:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LQunwiKPF7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=48WQUkMM",
      "display_url" : "pastebin.com\/raw.php?i=48WQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465798007795884033",
  "text" : "http:\/\/t.co\/LQunwiKPF7 Found possible Google API key(s) #infoleak",
  "id" : 465798007795884033,
  "created_at" : "2014-05-12 10:17:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6OrM0FntN5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fh5jSHdf",
      "display_url" : "pastebin.com\/raw.php?i=Fh5j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465751507069976576",
  "text" : "http:\/\/t.co\/6OrM0FntN5 Emails: 323 Keywords: 0.0 #infoleak",
  "id" : 465751507069976576,
  "created_at" : "2014-05-12 07:13:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NmRWX3FRxK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vurgEPXM",
      "display_url" : "pastebin.com\/raw.php?i=vurg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465664192247132160",
  "text" : "http:\/\/t.co\/NmRWX3FRxK Hashes: 50 Keywords: 0.11 #infoleak",
  "id" : 465664192247132160,
  "created_at" : "2014-05-12 01:26:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RiVH19t3nx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hwu2yceb",
      "display_url" : "pastebin.com\/raw.php?i=Hwu2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465660929103761409",
  "text" : "http:\/\/t.co\/RiVH19t3nx Emails: 273 Keywords: 0.0 #infoleak",
  "id" : 465660929103761409,
  "created_at" : "2014-05-12 01:13:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/exP0hFriQI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HdyDKc50",
      "display_url" : "pastebin.com\/raw.php?i=HdyD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465657925935964161",
  "text" : "http:\/\/t.co\/exP0hFriQI Hashes: 161 Keywords: -0.2 #infoleak",
  "id" : 465657925935964161,
  "created_at" : "2014-05-12 01:01:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fYv2of3ea8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hCjWZ39g",
      "display_url" : "pastebin.com\/raw.php?i=hCjW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465644593115955200",
  "text" : "http:\/\/t.co\/fYv2of3ea8 Found possible Google API key(s) #infoleak",
  "id" : 465644593115955200,
  "created_at" : "2014-05-12 00:08:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HRPUtTixrf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LFt0ccDt",
      "display_url" : "pastebin.com\/raw.php?i=LFt0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465637144552161280",
  "text" : "http:\/\/t.co\/HRPUtTixrf Emails: 1672 Keywords: 0.22 #infoleak",
  "id" : 465637144552161280,
  "created_at" : "2014-05-11 23:38:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8yxhlKbDVz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ckq23fcy",
      "display_url" : "pastebin.com\/raw.php?i=ckq2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465635963612307456",
  "text" : "http:\/\/t.co\/8yxhlKbDVz Emails: 110 Keywords: 0.0 #infoleak",
  "id" : 465635963612307456,
  "created_at" : "2014-05-11 23:33:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6qoaqswMvl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k3h4YpJv",
      "display_url" : "pastebin.com\/raw.php?i=k3h4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465630771378540544",
  "text" : "http:\/\/t.co\/6qoaqswMvl Emails: 284 Keywords: 0.0 #infoleak",
  "id" : 465630771378540544,
  "created_at" : "2014-05-11 23:13:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eSuct0BEo0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aeVbMT8q",
      "display_url" : "pastebin.com\/raw.php?i=aeVb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465629716225851392",
  "text" : "http:\/\/t.co\/eSuct0BEo0 Keywords: 0.66 #infoleak",
  "id" : 465629716225851392,
  "created_at" : "2014-05-11 23:09:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ql82cg9ME7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8rvM1PKm",
      "display_url" : "pastebin.com\/raw.php?i=8rvM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465626873683116032",
  "text" : "http:\/\/t.co\/ql82cg9ME7 Keywords: 0.66 #infoleak",
  "id" : 465626873683116032,
  "created_at" : "2014-05-11 22:57:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yq6eZjTMgt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=biBnJBKS",
      "display_url" : "pastebin.com\/raw.php?i=biBn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465622387808305152",
  "text" : "http:\/\/t.co\/yq6eZjTMgt Keywords: 0.63 #infoleak",
  "id" : 465622387808305152,
  "created_at" : "2014-05-11 22:40:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Jc7i1SSLs6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VmXm9BBN",
      "display_url" : "pastebin.com\/raw.php?i=VmXm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465616686985383936",
  "text" : "http:\/\/t.co\/Jc7i1SSLs6 Emails: 1 Keywords: 0.77 #infoleak",
  "id" : 465616686985383936,
  "created_at" : "2014-05-11 22:17:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cdlNVR0EeD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vpjh4U2D",
      "display_url" : "pastebin.com\/raw.php?i=vpjh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465607195896184832",
  "text" : "http:\/\/t.co\/cdlNVR0EeD Emails: 20 Keywords: 0.11 #infoleak",
  "id" : 465607195896184832,
  "created_at" : "2014-05-11 21:39:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zmvYk000UL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HSPDka6x",
      "display_url" : "pastebin.com\/raw.php?i=HSPD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465605649301114880",
  "text" : "http:\/\/t.co\/zmvYk000UL Emails: 88 Keywords: 0.22 #infoleak",
  "id" : 465605649301114880,
  "created_at" : "2014-05-11 21:33:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ns8hSP5tBP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=14TqeBzt",
      "display_url" : "pastebin.com\/raw.php?i=14Tq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465600570871386113",
  "text" : "http:\/\/t.co\/Ns8hSP5tBP Emails: 190 Keywords: 0.0 #infoleak",
  "id" : 465600570871386113,
  "created_at" : "2014-05-11 21:13:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ONlfttVN2O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dSsAEgJj",
      "display_url" : "pastebin.com\/raw.php?i=dSsA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465597134671060992",
  "text" : "http:\/\/t.co\/ONlfttVN2O Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 465597134671060992,
  "created_at" : "2014-05-11 20:59:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jJzrh73s0e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cfnJ7YBR",
      "display_url" : "pastebin.com\/raw.php?i=cfnJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465574281007493120",
  "text" : "http:\/\/t.co\/jJzrh73s0e Emails: 119 Keywords: 0.22 #infoleak",
  "id" : 465574281007493120,
  "created_at" : "2014-05-11 19:28:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hJlvAonqMq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tAZ5r8Vr",
      "display_url" : "pastebin.com\/raw.php?i=tAZ5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465570308716384257",
  "text" : "http:\/\/t.co\/hJlvAonqMq Emails: 174 Keywords: 0.0 #infoleak",
  "id" : 465570308716384257,
  "created_at" : "2014-05-11 19:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jc7FKTQ2xn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SapJPFLr",
      "display_url" : "pastebin.com\/raw.php?i=SapJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465568587529216000",
  "text" : "http:\/\/t.co\/jc7FKTQ2xn Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 465568587529216000,
  "created_at" : "2014-05-11 19:06:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/riXhgYYfIh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RfHkwNBV",
      "display_url" : "pastebin.com\/raw.php?i=RfHk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465565975425712128",
  "text" : "http:\/\/t.co\/riXhgYYfIh Keywords: 0.66 #infoleak",
  "id" : 465565975425712128,
  "created_at" : "2014-05-11 18:55:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vmCpotPwEX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=93FUgfYT",
      "display_url" : "pastebin.com\/raw.php?i=93FU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465563565345079297",
  "text" : "http:\/\/t.co\/vmCpotPwEX Found possible Google API key(s) #infoleak",
  "id" : 465563565345079297,
  "created_at" : "2014-05-11 18:46:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mnSjWgpycH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SALFt6eK",
      "display_url" : "pastebin.com\/raw.php?i=SALF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465558314558844928",
  "text" : "http:\/\/t.co\/mnSjWgpycH Keywords: 0.66 #infoleak",
  "id" : 465558314558844928,
  "created_at" : "2014-05-11 18:25:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MDncxrSHli",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bZEUwwQU",
      "display_url" : "pastebin.com\/raw.php?i=bZEU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465553495773286400",
  "text" : "http:\/\/t.co\/MDncxrSHli Found possible Google API key(s) #infoleak",
  "id" : 465553495773286400,
  "created_at" : "2014-05-11 18:06:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DQQRA3PHyS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=syj4JdUx",
      "display_url" : "pastebin.com\/raw.php?i=syj4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465547255533957120",
  "text" : "http:\/\/t.co\/DQQRA3PHyS Emails: 60 Keywords: 0.0 #infoleak",
  "id" : 465547255533957120,
  "created_at" : "2014-05-11 17:41:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eFTHBPkXdY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r5djBbqG",
      "display_url" : "pastebin.com\/raw.php?i=r5dj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465543637586030592",
  "text" : "http:\/\/t.co\/eFTHBPkXdY Hashes: 183 Keywords: 0.11 #infoleak",
  "id" : 465543637586030592,
  "created_at" : "2014-05-11 17:27:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A3Na5HHHIr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CSZ8KwcE",
      "display_url" : "pastebin.com\/raw.php?i=CSZ8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465482642436026368",
  "text" : "http:\/\/t.co\/A3Na5HHHIr Emails: 676 Keywords: 0.0 #infoleak",
  "id" : 465482642436026368,
  "created_at" : "2014-05-11 13:24:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WOe6JLYwW9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z0Vn1HPc",
      "display_url" : "pastebin.com\/raw.php?i=z0Vn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465481077616672768",
  "text" : "http:\/\/t.co\/WOe6JLYwW9 Emails: 93 Keywords: 0.0 #infoleak",
  "id" : 465481077616672768,
  "created_at" : "2014-05-11 13:18:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lJjmhaOKDM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EaxUXDpD",
      "display_url" : "pastebin.com\/raw.php?i=EaxU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465479721635950592",
  "text" : "http:\/\/t.co\/lJjmhaOKDM Emails: 350 Keywords: 0.0 #infoleak",
  "id" : 465479721635950592,
  "created_at" : "2014-05-11 13:13:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JYCEaMirVV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=18N7GdNW",
      "display_url" : "pastebin.com\/raw.php?i=18N7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465471364376166400",
  "text" : "http:\/\/t.co\/JYCEaMirVV Hashes: 1935 Keywords: 0.22 #infoleak",
  "id" : 465471364376166400,
  "created_at" : "2014-05-11 12:39:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5vBQZSnNvo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WV2hAkHE",
      "display_url" : "pastebin.com\/raw.php?i=WV2h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465463783280738304",
  "text" : "http:\/\/t.co\/5vBQZSnNvo Found possible Google API key(s) #infoleak",
  "id" : 465463783280738304,
  "created_at" : "2014-05-11 12:09:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WBwu1lzryF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ctfvSwcN",
      "display_url" : "pastebin.com\/raw.php?i=ctfv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465462971355762688",
  "text" : "http:\/\/t.co\/WBwu1lzryF Emails: 22 Hashes: 115 E\/H: 0.19 Keywords: 0.0 #infoleak",
  "id" : 465462971355762688,
  "created_at" : "2014-05-11 12:06:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z80B51A6tm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0v9MnVYw",
      "display_url" : "pastebin.com\/raw.php?i=0v9M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465459641371987969",
  "text" : "http:\/\/t.co\/z80B51A6tm Found possible Google API key(s) #infoleak",
  "id" : 465459641371987969,
  "created_at" : "2014-05-11 11:53:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4mm9sbBUaI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=97J1wW1K",
      "display_url" : "pastebin.com\/raw.php?i=97J1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465451840750891008",
  "text" : "http:\/\/t.co\/4mm9sbBUaI Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 465451840750891008,
  "created_at" : "2014-05-11 11:22:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R9IPompaYi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HdpxqVCs",
      "display_url" : "pastebin.com\/raw.php?i=Hdpx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465449514447273985",
  "text" : "http:\/\/t.co\/R9IPompaYi Emails: 283 Keywords: 0.0 #infoleak",
  "id" : 465449514447273985,
  "created_at" : "2014-05-11 11:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n8aDK84k6F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LRLHYv9C",
      "display_url" : "pastebin.com\/raw.php?i=LRLH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465433273162670080",
  "text" : "http:\/\/t.co\/n8aDK84k6F Emails: 2427 Keywords: 0.22 #infoleak",
  "id" : 465433273162670080,
  "created_at" : "2014-05-11 10:08:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VwTPfIxyq4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7N2TZ2gW",
      "display_url" : "pastebin.com\/raw.php?i=7N2T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465432745171099649",
  "text" : "http:\/\/t.co\/VwTPfIxyq4 Emails: 34 Keywords: 0.0 #infoleak",
  "id" : 465432745171099649,
  "created_at" : "2014-05-11 10:06:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GF2fqfYw8v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RJb49cVc",
      "display_url" : "pastebin.com\/raw.php?i=RJb4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465419423545704449",
  "text" : "http:\/\/t.co\/GF2fqfYw8v Emails: 300 Keywords: 0.0 #infoleak",
  "id" : 465419423545704449,
  "created_at" : "2014-05-11 09:13:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6ShlJ5m1jY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2Urjk41P",
      "display_url" : "pastebin.com\/raw.php?i=2Urj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465407198751772672",
  "text" : "http:\/\/t.co\/6ShlJ5m1jY Hashes: 56 Keywords: 0.08 #infoleak",
  "id" : 465407198751772672,
  "created_at" : "2014-05-11 08:24:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BxxTthJUY7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yPay5M2y",
      "display_url" : "pastebin.com\/raw.php?i=yPay\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465401815589072896",
  "text" : "http:\/\/t.co\/BxxTthJUY7 Emails: 34 Keywords: 0.22 #infoleak",
  "id" : 465401815589072896,
  "created_at" : "2014-05-11 08:03:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RAzOTlotkT",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9165040\/text",
      "display_url" : "pastie.org\/pastes\/9165040\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465395132565446656",
  "text" : "http:\/\/t.co\/RAzOTlotkT Found possible Google API key(s) #infoleak",
  "id" : 465395132565446656,
  "created_at" : "2014-05-11 07:37:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/almtmc9Yvx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kiPnmhqe",
      "display_url" : "pastebin.com\/raw.php?i=kiPn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465389578795241473",
  "text" : "http:\/\/t.co\/almtmc9Yvx Emails: 364 Keywords: 0.0 #infoleak",
  "id" : 465389578795241473,
  "created_at" : "2014-05-11 07:14:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1G0ouAXDob",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iQygBJLt",
      "display_url" : "pastebin.com\/raw.php?i=iQyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465389487254540288",
  "text" : "http:\/\/t.co\/1G0ouAXDob Emails: 117 Hashes: 116 E\/H: 1.01 Keywords: 0.22 #infoleak",
  "id" : 465389487254540288,
  "created_at" : "2014-05-11 07:14:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RwgunXJNIf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SG2N5VER",
      "display_url" : "pastebin.com\/raw.php?i=SG2N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465389122857615360",
  "text" : "http:\/\/t.co\/RwgunXJNIf Emails: 6429 Keywords: 0.41 #infoleak",
  "id" : 465389122857615360,
  "created_at" : "2014-05-11 07:13:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g1vVAhOv1O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EiU3ZKtd",
      "display_url" : "pastebin.com\/raw.php?i=EiU3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465363217821073409",
  "text" : "http:\/\/t.co\/g1vVAhOv1O Found possible Google API key(s) #infoleak",
  "id" : 465363217821073409,
  "created_at" : "2014-05-11 05:30:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S5AWZewRR3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wNULhddA",
      "display_url" : "pastebin.com\/raw.php?i=wNUL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465359043536502787",
  "text" : "http:\/\/t.co\/S5AWZewRR3 Emails: 157 Keywords: 0.0 #infoleak",
  "id" : 465359043536502787,
  "created_at" : "2014-05-11 05:13:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XuFI2wjCZc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mVJjR84p",
      "display_url" : "pastebin.com\/raw.php?i=mVJj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465356543295115264",
  "text" : "http:\/\/t.co\/XuFI2wjCZc Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 465356543295115264,
  "created_at" : "2014-05-11 05:03:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DJjpyxialb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X8dHZWTK",
      "display_url" : "pastebin.com\/raw.php?i=X8dH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465352600351567873",
  "text" : "http:\/\/t.co\/DJjpyxialb Emails: 379 Keywords: 0.11 #infoleak",
  "id" : 465352600351567873,
  "created_at" : "2014-05-11 04:48:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/va4oehbzoY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h9Mq5VmM",
      "display_url" : "pastebin.com\/raw.php?i=h9Mq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465349978378862592",
  "text" : "http:\/\/t.co\/va4oehbzoY Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 465349978378862592,
  "created_at" : "2014-05-11 04:37:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3BsVhmA9VH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pViSpdWy",
      "display_url" : "pastebin.com\/raw.php?i=pViS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465341638127009792",
  "text" : "http:\/\/t.co\/3BsVhmA9VH Emails: 283 Keywords: 0.0 #infoleak",
  "id" : 465341638127009792,
  "created_at" : "2014-05-11 04:04:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tx0ZcgRnn3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EFki5ETV",
      "display_url" : "pastebin.com\/raw.php?i=EFki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465329839885406209",
  "text" : "http:\/\/t.co\/tx0ZcgRnn3 Emails: 230 Keywords: 0.0 #infoleak",
  "id" : 465329839885406209,
  "created_at" : "2014-05-11 03:17:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hhH8D8FnSO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jPrz82J0",
      "display_url" : "pastebin.com\/raw.php?i=jPrz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465152777337847808",
  "text" : "http:\/\/t.co\/hhH8D8FnSO Hashes: 227 Keywords: -0.03 #infoleak",
  "id" : 465152777337847808,
  "created_at" : "2014-05-10 15:33:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dk8ouDDKIc",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9162514\/text",
      "display_url" : "pastie.org\/pastes\/9162514\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465150312492171265",
  "text" : "http:\/\/t.co\/dk8ouDDKIc Keywords: 0.55 #infoleak",
  "id" : 465150312492171265,
  "created_at" : "2014-05-10 15:24:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/krfAIYuBhM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f0dUwfV5",
      "display_url" : "pastebin.com\/raw.php?i=f0dU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465147532369084416",
  "text" : "http:\/\/t.co\/krfAIYuBhM Emails: 129 Keywords: 0.0 #infoleak",
  "id" : 465147532369084416,
  "created_at" : "2014-05-10 15:13:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O2f9f0ogBx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FTbza3iU",
      "display_url" : "pastebin.com\/raw.php?i=FTbz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465146758746492928",
  "text" : "http:\/\/t.co\/O2f9f0ogBx Hashes: 31 Keywords: 0.0 #infoleak",
  "id" : 465146758746492928,
  "created_at" : "2014-05-10 15:10:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oO3r03X0kk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a97UgBJr",
      "display_url" : "pastebin.com\/raw.php?i=a97U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465129150919884801",
  "text" : "http:\/\/t.co\/oO3r03X0kk Hashes: 66 Keywords: -0.17 #infoleak",
  "id" : 465129150919884801,
  "created_at" : "2014-05-10 14:00:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/st0JPcrnI2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aFR6Bx5R",
      "display_url" : "pastebin.com\/raw.php?i=aFR6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465117371787522049",
  "text" : "http:\/\/t.co\/st0JPcrnI2 Emails: 124 Keywords: 0.11 #infoleak",
  "id" : 465117371787522049,
  "created_at" : "2014-05-10 13:13:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mcFbL4aTrL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AmWL04ti",
      "display_url" : "pastebin.com\/raw.php?i=AmWL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465113341950570496",
  "text" : "http:\/\/t.co\/mcFbL4aTrL Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 465113341950570496,
  "created_at" : "2014-05-10 12:57:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W2Xcb89G9g",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2Jh6A8W0D",
      "display_url" : "slexy.org\/raw\/s2Jh6A8W0D"
    } ]
  },
  "geo" : { },
  "id_str" : "465097569366855680",
  "text" : "http:\/\/t.co\/W2Xcb89G9g Emails: 3 Hashes: 42 E\/H: 0.07 Keywords: 0.27 #infoleak",
  "id" : 465097569366855680,
  "created_at" : "2014-05-10 11:54:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jYEetmeJpr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q9cfQA8T",
      "display_url" : "pastebin.com\/raw.php?i=q9cf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465075607806545921",
  "text" : "http:\/\/t.co\/jYEetmeJpr Emails: 25 Hashes: 1 E\/H: 25.0 Keywords: 0.22 #infoleak",
  "id" : 465075607806545921,
  "created_at" : "2014-05-10 10:27:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EVxH2hzuTi",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2pdIbjVfb",
      "display_url" : "slexy.org\/raw\/s2pdIbjVfb"
    } ]
  },
  "geo" : { },
  "id_str" : "465072482462887936",
  "text" : "http:\/\/t.co\/EVxH2hzuTi Emails: 5 Hashes: 66 E\/H: 0.08 Keywords: 0.27 #infoleak",
  "id" : 465072482462887936,
  "created_at" : "2014-05-10 10:14:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IRfx5dF1yr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UyKmUapU",
      "display_url" : "pastebin.com\/raw.php?i=UyKm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465071239652843521",
  "text" : "http:\/\/t.co\/IRfx5dF1yr Emails: 93 Keywords: 0.0 #infoleak",
  "id" : 465071239652843521,
  "created_at" : "2014-05-10 10:09:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BQT5JhxZUX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dGmd1EGd",
      "display_url" : "pastebin.com\/raw.php?i=dGmd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465056973092691968",
  "text" : "http:\/\/t.co\/BQT5JhxZUX Emails: 260 Keywords: 0.0 #infoleak",
  "id" : 465056973092691968,
  "created_at" : "2014-05-10 09:13:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0x3tk6Lf2V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k3an0VvY",
      "display_url" : "pastebin.com\/raw.php?i=k3an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464851493342822400",
  "text" : "http:\/\/t.co\/0x3tk6Lf2V Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 464851493342822400,
  "created_at" : "2014-05-09 19:36:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q7wCf2xTLO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DF1TEVvb",
      "display_url" : "pastebin.com\/raw.php?i=DF1T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464849228276039680",
  "text" : "http:\/\/t.co\/Q7wCf2xTLO Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 464849228276039680,
  "created_at" : "2014-05-09 19:27:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GmoKASfBbH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v8u3WWuP",
      "display_url" : "pastebin.com\/raw.php?i=v8u3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464847547895267328",
  "text" : "http:\/\/t.co\/GmoKASfBbH Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 464847547895267328,
  "created_at" : "2014-05-09 19:21:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QGeLb8QCeo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CusBb5Km",
      "display_url" : "pastebin.com\/raw.php?i=CusB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464845529671684097",
  "text" : "http:\/\/t.co\/QGeLb8QCeo Emails: 287 Keywords: 0.0 #infoleak",
  "id" : 464845529671684097,
  "created_at" : "2014-05-09 19:13:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/faYbgGJLHS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AEVhfhX6",
      "display_url" : "pastebin.com\/raw.php?i=AEVh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464845090381234176",
  "text" : "http:\/\/t.co\/faYbgGJLHS Emails: 57 Keywords: 0.0 #infoleak",
  "id" : 464845090381234176,
  "created_at" : "2014-05-09 19:11:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/26VTCaN8Hh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m1HWZb1f",
      "display_url" : "pastebin.com\/raw.php?i=m1HW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464844363495776256",
  "text" : "http:\/\/t.co\/26VTCaN8Hh Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 464844363495776256,
  "created_at" : "2014-05-09 19:08:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rUcCKtsZLs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yqP6NUDC",
      "display_url" : "pastebin.com\/raw.php?i=yqP6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464827815410819072",
  "text" : "http:\/\/t.co\/rUcCKtsZLs Hashes: 132 Keywords: 0.0 #infoleak",
  "id" : 464827815410819072,
  "created_at" : "2014-05-09 18:02:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SCd3TbYVBw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=43jEJPPY",
      "display_url" : "pastebin.com\/raw.php?i=43jE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464827249431437312",
  "text" : "http:\/\/t.co\/SCd3TbYVBw Emails: 22 Keywords: -0.14 #infoleak",
  "id" : 464827249431437312,
  "created_at" : "2014-05-09 18:00:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yZ2BGw9mtG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=URJ0hmzj",
      "display_url" : "pastebin.com\/raw.php?i=URJ0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464820171664670720",
  "text" : "http:\/\/t.co\/yZ2BGw9mtG Hashes: 37 Keywords: 0.0 #infoleak",
  "id" : 464820171664670720,
  "created_at" : "2014-05-09 17:32:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rzmyNHFfwU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=crqQQHJD",
      "display_url" : "pastebin.com\/raw.php?i=crqQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464818969963421698",
  "text" : "http:\/\/t.co\/rzmyNHFfwU Hashes: 198 Keywords: 0.0 #infoleak",
  "id" : 464818969963421698,
  "created_at" : "2014-05-09 17:27:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qZgqYVhJ7r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f9yB0TzP",
      "display_url" : "pastebin.com\/raw.php?i=f9yB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464815333690195968",
  "text" : "http:\/\/t.co\/qZgqYVhJ7r Emails: 137 Keywords: 0.0 #infoleak",
  "id" : 464815333690195968,
  "created_at" : "2014-05-09 17:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oCFQCWhdbD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mtCgPhg2",
      "display_url" : "pastebin.com\/raw.php?i=mtCg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464813330226741248",
  "text" : "http:\/\/t.co\/oCFQCWhdbD Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 464813330226741248,
  "created_at" : "2014-05-09 17:05:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hk3qSrDaDG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dqUdt0B7",
      "display_url" : "pastebin.com\/raw.php?i=dqUd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464806661929324544",
  "text" : "http:\/\/t.co\/hk3qSrDaDG Emails: 4 Keywords: 0.66 #infoleak",
  "id" : 464806661929324544,
  "created_at" : "2014-05-09 16:38:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OZJReEOk9w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=70XEinxE",
      "display_url" : "pastebin.com\/raw.php?i=70XE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464803041841913856",
  "text" : "http:\/\/t.co\/OZJReEOk9w Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 464803041841913856,
  "created_at" : "2014-05-09 16:24:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PGhMno1Zgf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uK6XKtV2",
      "display_url" : "pastebin.com\/raw.php?i=uK6X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464799708251430912",
  "text" : "http:\/\/t.co\/PGhMno1Zgf Emails: 374 Keywords: 0.0 #infoleak",
  "id" : 464799708251430912,
  "created_at" : "2014-05-09 16:11:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v7MmWX5Bnb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Df9m73wd",
      "display_url" : "pastebin.com\/raw.php?i=Df9m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464789341500239872",
  "text" : "http:\/\/t.co\/v7MmWX5Bnb Emails: 37 Keywords: -0.14 #infoleak",
  "id" : 464789341500239872,
  "created_at" : "2014-05-09 15:29:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0boHIwuGk6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M276JySq",
      "display_url" : "pastebin.com\/raw.php?i=M276\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464786964663656448",
  "text" : "http:\/\/t.co\/0boHIwuGk6 Emails: 628 Keywords: 0.0 #infoleak",
  "id" : 464786964663656448,
  "created_at" : "2014-05-09 15:20:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lF6kAl4kUc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aEQ6x5vc",
      "display_url" : "pastebin.com\/raw.php?i=aEQ6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464785115692822529",
  "text" : "http:\/\/t.co\/lF6kAl4kUc Emails: 241 Keywords: 0.0 #infoleak",
  "id" : 464785115692822529,
  "created_at" : "2014-05-09 15:13:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zpef2aOWgw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Rkrpzn8P",
      "display_url" : "pastebin.com\/raw.php?i=Rkrp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464782660275937282",
  "text" : "http:\/\/t.co\/Zpef2aOWgw Emails: 69 Keywords: 0.22 #infoleak",
  "id" : 464782660275937282,
  "created_at" : "2014-05-09 15:03:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LaibiOQApf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eE8WSyAR",
      "display_url" : "pastebin.com\/raw.php?i=eE8W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464768528789164033",
  "text" : "http:\/\/t.co\/LaibiOQApf Emails: 498 Keywords: 0.0 #infoleak",
  "id" : 464768528789164033,
  "created_at" : "2014-05-09 14:07:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A7xJ7du0Rq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tbbt8qs2",
      "display_url" : "pastebin.com\/raw.php?i=Tbbt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464766249369473025",
  "text" : "http:\/\/t.co\/A7xJ7du0Rq Emails: 204 Keywords: 0.22 #infoleak",
  "id" : 464766249369473025,
  "created_at" : "2014-05-09 13:58:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lnJ9FU2StP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ezw1LQuQ",
      "display_url" : "pastebin.com\/raw.php?i=Ezw1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464760904383361024",
  "text" : "http:\/\/t.co\/lnJ9FU2StP Emails: 1887 Keywords: 0.33 #infoleak",
  "id" : 464760904383361024,
  "created_at" : "2014-05-09 13:36:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0b9vvsCvCk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bmJ8jm5L",
      "display_url" : "pastebin.com\/raw.php?i=bmJ8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464754919782621185",
  "text" : "http:\/\/t.co\/0b9vvsCvCk Emails: 213 Keywords: 0.0 #infoleak",
  "id" : 464754919782621185,
  "created_at" : "2014-05-09 13:13:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0WdMKPLvy8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MNJL0gJ0",
      "display_url" : "pastebin.com\/raw.php?i=MNJL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464753200449323008",
  "text" : "http:\/\/t.co\/0WdMKPLvy8 Emails: 495 Keywords: 0.0 #infoleak",
  "id" : 464753200449323008,
  "created_at" : "2014-05-09 13:06:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QkHkZsLglW",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9159213\/text",
      "display_url" : "pastie.org\/pastes\/9159213\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464746236071800833",
  "text" : "http:\/\/t.co\/QkHkZsLglW Hashes: 31 Keywords: -0.03 #infoleak",
  "id" : 464746236071800833,
  "created_at" : "2014-05-09 12:38:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rIoNia8Lo2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JMyZKUyy",
      "display_url" : "pastebin.com\/raw.php?i=JMyZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464737328204750848",
  "text" : "http:\/\/t.co\/rIoNia8Lo2 Emails: 1887 Keywords: 0.33 #infoleak",
  "id" : 464737328204750848,
  "created_at" : "2014-05-09 12:03:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6hvxadEyzf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2rXxmscq",
      "display_url" : "pastebin.com\/raw.php?i=2rXx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464736287581147138",
  "text" : "http:\/\/t.co\/6hvxadEyzf Emails: 433 Keywords: 0.11 #infoleak",
  "id" : 464736287581147138,
  "created_at" : "2014-05-09 11:59:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/STnsvSaHnQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ggyhrpch",
      "display_url" : "pastebin.com\/raw.php?i=ggyh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464724695460216832",
  "text" : "http:\/\/t.co\/STnsvSaHnQ Emails: 388 Keywords: 0.0 #infoleak",
  "id" : 464724695460216832,
  "created_at" : "2014-05-09 11:12:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rT3MDguwqP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c3cWk7xr",
      "display_url" : "pastebin.com\/raw.php?i=c3cW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464707811645988864",
  "text" : "http:\/\/t.co\/rT3MDguwqP Keywords: 0.55 #infoleak",
  "id" : 464707811645988864,
  "created_at" : "2014-05-09 10:05:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RqCt5rXxcX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NK2X2J9F",
      "display_url" : "pastebin.com\/raw.php?i=NK2X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464692788768935936",
  "text" : "http:\/\/t.co\/RqCt5rXxcX Emails: 82 Keywords: 0.0 #infoleak",
  "id" : 464692788768935936,
  "created_at" : "2014-05-09 09:06:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lefn73h9Np",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gma7w0XM",
      "display_url" : "pastebin.com\/raw.php?i=gma7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464690366361251840",
  "text" : "http:\/\/t.co\/lefn73h9Np Emails: 133 Hashes: 266 E\/H: 0.5 Keywords: 0.11 #infoleak",
  "id" : 464690366361251840,
  "created_at" : "2014-05-09 08:56:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tOHdxVuRkb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DsZzZe8j",
      "display_url" : "pastebin.com\/raw.php?i=DsZz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464679644143165440",
  "text" : "http:\/\/t.co\/tOHdxVuRkb Hashes: 44 Keywords: 0.08 #infoleak",
  "id" : 464679644143165440,
  "created_at" : "2014-05-09 08:13:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dLZgd6fWEJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XP8msMgN",
      "display_url" : "pastebin.com\/raw.php?i=XP8m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464678971641040896",
  "text" : "http:\/\/t.co\/dLZgd6fWEJ Emails: 406 Keywords: 0.11 #infoleak",
  "id" : 464678971641040896,
  "created_at" : "2014-05-09 08:11:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GLSHxIhQoQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=41re331x",
      "display_url" : "pastebin.com\/raw.php?i=41re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464668454016909312",
  "text" : "http:\/\/t.co\/GLSHxIhQoQ Emails: 942 Keywords: 0.0 #infoleak",
  "id" : 464668454016909312,
  "created_at" : "2014-05-09 07:29:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tdTsbVed9z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pmVKfmEC",
      "display_url" : "pastebin.com\/raw.php?i=pmVK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464664313936887808",
  "text" : "http:\/\/t.co\/tdTsbVed9z Emails: 106 Keywords: 0.0 #infoleak",
  "id" : 464664313936887808,
  "created_at" : "2014-05-09 07:13:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A2EYAToPEZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FR4kAnn3",
      "display_url" : "pastebin.com\/raw.php?i=FR4k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464657359223001089",
  "text" : "http:\/\/t.co\/A2EYAToPEZ Emails: 165 Keywords: 0.22 #infoleak",
  "id" : 464657359223001089,
  "created_at" : "2014-05-09 06:45:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0DbmSfZDeG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=usnPMf9T",
      "display_url" : "pastebin.com\/raw.php?i=usnP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464657159490260992",
  "text" : "http:\/\/t.co\/0DbmSfZDeG Keywords: 0.55 #infoleak",
  "id" : 464657159490260992,
  "created_at" : "2014-05-09 06:44:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l7t9CedtX8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5rFxv1s8",
      "display_url" : "pastebin.com\/raw.php?i=5rFx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464638196161454080",
  "text" : "http:\/\/t.co\/l7t9CedtX8 Hashes: 80 Keywords: 0.22 #infoleak",
  "id" : 464638196161454080,
  "created_at" : "2014-05-09 05:29:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b5hrtA7w1X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r8u8m2JD",
      "display_url" : "pastebin.com\/raw.php?i=r8u8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464634789258338304",
  "text" : "http:\/\/t.co\/b5hrtA7w1X Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 464634789258338304,
  "created_at" : "2014-05-09 05:15:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mBqtM5Sz8z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KRFhNJL4",
      "display_url" : "pastebin.com\/raw.php?i=KRFh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464634202047401985",
  "text" : "http:\/\/t.co\/mBqtM5Sz8z Emails: 307 Keywords: 0.0 #infoleak",
  "id" : 464634202047401985,
  "created_at" : "2014-05-09 05:13:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IxZ3QZnJgs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MteWpugY",
      "display_url" : "pastebin.com\/raw.php?i=MteW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464620050398601216",
  "text" : "http:\/\/t.co\/IxZ3QZnJgs Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 464620050398601216,
  "created_at" : "2014-05-09 04:17:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iso8uOqkp2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HjqbfPei",
      "display_url" : "pastebin.com\/raw.php?i=Hjqb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464616742271348736",
  "text" : "http:\/\/t.co\/iso8uOqkp2 Emails: 4268 Keywords: 0.11 #infoleak",
  "id" : 464616742271348736,
  "created_at" : "2014-05-09 04:03:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4VxpQlylLs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gVNwncQQ",
      "display_url" : "pastebin.com\/raw.php?i=gVNw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464613054966411264",
  "text" : "http:\/\/t.co\/4VxpQlylLs Emails: 32 Keywords: -0.14 #infoleak",
  "id" : 464613054966411264,
  "created_at" : "2014-05-09 03:49:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2NWr5VVMok",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HuVXbx0X",
      "display_url" : "pastebin.com\/raw.php?i=HuVX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464609753646497792",
  "text" : "http:\/\/t.co\/2NWr5VVMok Emails: 76 Keywords: 0.0 #infoleak",
  "id" : 464609753646497792,
  "created_at" : "2014-05-09 03:36:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n7mLozmImo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QzetzCQ7",
      "display_url" : "pastebin.com\/raw.php?i=Qzet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464603919680036869",
  "text" : "http:\/\/t.co\/n7mLozmImo Emails: 137 Keywords: 0.0 #infoleak",
  "id" : 464603919680036869,
  "created_at" : "2014-05-09 03:13:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3yoxE1i1TI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FsHD6waA",
      "display_url" : "pastebin.com\/raw.php?i=FsHD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464598867657629697",
  "text" : "http:\/\/t.co\/3yoxE1i1TI Hashes: 43 Keywords: 0.08 #infoleak",
  "id" : 464598867657629697,
  "created_at" : "2014-05-09 02:52:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1JxRLe79dj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mfS1Xesr",
      "display_url" : "pastebin.com\/raw.php?i=mfS1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464576651696017408",
  "text" : "http:\/\/t.co\/1JxRLe79dj Hashes: 74 Keywords: 0.33 #infoleak",
  "id" : 464576651696017408,
  "created_at" : "2014-05-09 01:24:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ulYgVz2ODn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JaKE3HY4",
      "display_url" : "pastebin.com\/raw.php?i=JaKE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464576426042482688",
  "text" : "http:\/\/t.co\/ulYgVz2ODn Emails: 51 Keywords: 0.0 #infoleak",
  "id" : 464576426042482688,
  "created_at" : "2014-05-09 01:23:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ae2qxr4Fk0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eRXURa5L",
      "display_url" : "pastebin.com\/raw.php?i=eRXU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464573742170267648",
  "text" : "http:\/\/t.co\/Ae2qxr4Fk0 Emails: 399 Keywords: 0.0 #infoleak",
  "id" : 464573742170267648,
  "created_at" : "2014-05-09 01:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PmQs9Aw2WX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nnHaCNge",
      "display_url" : "pastebin.com\/raw.php?i=nnHa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464567303150239745",
  "text" : "http:\/\/t.co\/PmQs9Aw2WX Hashes: 85 Keywords: 0.33 #infoleak",
  "id" : 464567303150239745,
  "created_at" : "2014-05-09 00:47:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fVYA0y5wRv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cNKD21fF",
      "display_url" : "pastebin.com\/raw.php?i=cNKD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464554938337869825",
  "text" : "http:\/\/t.co\/fVYA0y5wRv Emails: 3 Hashes: 34 E\/H: 0.09 Keywords: 0.33 #infoleak",
  "id" : 464554938337869825,
  "created_at" : "2014-05-08 23:58:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/76Bf9KfHLe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QDax4vCg",
      "display_url" : "pastebin.com\/raw.php?i=QDax\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464549351852101632",
  "text" : "http:\/\/t.co\/76Bf9KfHLe Emails: 497 Hashes: 495 E\/H: 1.0 Keywords: 0.19 #infoleak",
  "id" : 464549351852101632,
  "created_at" : "2014-05-08 23:36:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N0LnhsxZv4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NNkNQWxA",
      "display_url" : "pastebin.com\/raw.php?i=NNkN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464543540966854657",
  "text" : "http:\/\/t.co\/N0LnhsxZv4 Emails: 193 Keywords: 0.0 #infoleak",
  "id" : 464543540966854657,
  "created_at" : "2014-05-08 23:13:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mZrxx13kLP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RZaZfHhw",
      "display_url" : "pastebin.com\/raw.php?i=RZaZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464538563481460736",
  "text" : "http:\/\/t.co\/mZrxx13kLP Found possible Google API key(s) #infoleak",
  "id" : 464538563481460736,
  "created_at" : "2014-05-08 22:53:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KLlqcsizJi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hXkcKD6z",
      "display_url" : "pastebin.com\/raw.php?i=hXkc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464536255657963520",
  "text" : "http:\/\/t.co\/KLlqcsizJi Emails: 274 Keywords: 0.11 #infoleak",
  "id" : 464536255657963520,
  "created_at" : "2014-05-08 22:44:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LAB2NQF7P6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kedDB2aH",
      "display_url" : "pastebin.com\/raw.php?i=kedD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464533472640770048",
  "text" : "http:\/\/t.co\/LAB2NQF7P6 Hashes: 41 Keywords: 0.11 #infoleak",
  "id" : 464533472640770048,
  "created_at" : "2014-05-08 22:33:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iiw5Sh2t7V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EHCGnhVk",
      "display_url" : "pastebin.com\/raw.php?i=EHCG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464528692946145281",
  "text" : "http:\/\/t.co\/iiw5Sh2t7V Emails: 250 Keywords: 0.0 #infoleak",
  "id" : 464528692946145281,
  "created_at" : "2014-05-08 22:14:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2lT0OLqSL7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wMn6kDir",
      "display_url" : "pastebin.com\/raw.php?i=wMn6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464527813463535616",
  "text" : "http:\/\/t.co\/2lT0OLqSL7 Emails: 44 Keywords: 0.22 #infoleak",
  "id" : 464527813463535616,
  "created_at" : "2014-05-08 22:10:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d3wuveO0sL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mywhpVBt",
      "display_url" : "pastebin.com\/raw.php?i=mywh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464525903268413440",
  "text" : "http:\/\/t.co\/d3wuveO0sL Hashes: 232 Keywords: 0.08 #infoleak",
  "id" : 464525903268413440,
  "created_at" : "2014-05-08 22:03:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9LyTIfGjhn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5vyPzP5g",
      "display_url" : "pastebin.com\/raw.php?i=5vyP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464518953423749120",
  "text" : "http:\/\/t.co\/9LyTIfGjhn Emails: 158 Keywords: 0.11 #infoleak",
  "id" : 464518953423749120,
  "created_at" : "2014-05-08 21:35:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7pweWOf3W1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cvLcD7aE",
      "display_url" : "pastebin.com\/raw.php?i=cvLc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464515185181339648",
  "text" : "http:\/\/t.co\/7pweWOf3W1 Hashes: 66 Keywords: 0.33 #infoleak",
  "id" : 464515185181339648,
  "created_at" : "2014-05-08 21:20:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rJlwGXgSV4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XadQXzv0",
      "display_url" : "pastebin.com\/raw.php?i=XadQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464513351788150784",
  "text" : "http:\/\/t.co\/rJlwGXgSV4 Emails: 371 Keywords: 0.0 #infoleak",
  "id" : 464513351788150784,
  "created_at" : "2014-05-08 21:13:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i575oPJRHo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X9vbs7N1",
      "display_url" : "pastebin.com\/raw.php?i=X9vb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464513292119977984",
  "text" : "http:\/\/t.co\/i575oPJRHo Emails: 416 Keywords: 0.11 #infoleak",
  "id" : 464513292119977984,
  "created_at" : "2014-05-08 21:12:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ONzQt7AfXz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bpQJG3GK",
      "display_url" : "pastebin.com\/raw.php?i=bpQJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464511732547723265",
  "text" : "http:\/\/t.co\/ONzQt7AfXz Emails: 153 Keywords: 0.0 #infoleak",
  "id" : 464511732547723265,
  "created_at" : "2014-05-08 21:06:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B4YqEHXSAk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QcWC3aT5",
      "display_url" : "pastebin.com\/raw.php?i=QcWC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464511668299395073",
  "text" : "http:\/\/t.co\/B4YqEHXSAk Emails: 59 Hashes: 60 E\/H: 0.98 Keywords: 0.22 #infoleak",
  "id" : 464511668299395073,
  "created_at" : "2014-05-08 21:06:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uhk6BCeEJS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n7FZCCEL",
      "display_url" : "pastebin.com\/raw.php?i=n7FZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464503667886796800",
  "text" : "http:\/\/t.co\/uhk6BCeEJS Found possible Google API key(s) #infoleak",
  "id" : 464503667886796800,
  "created_at" : "2014-05-08 20:34:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QQhXQQudGA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Uhgp76en",
      "display_url" : "pastebin.com\/raw.php?i=Uhgp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464500341636333569",
  "text" : "http:\/\/t.co\/QQhXQQudGA Hashes: 654 Keywords: 0.0 #infoleak",
  "id" : 464500341636333569,
  "created_at" : "2014-05-08 20:21:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R0iiXWQo5V",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Wf7dxaUZ",
      "display_url" : "pastebin.com\/raw.php?i=Wf7d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464498949907578880",
  "text" : "http:\/\/t.co\/R0iiXWQo5V Hashes: 56 Keywords: 0.22 #infoleak",
  "id" : 464498949907578880,
  "created_at" : "2014-05-08 20:15:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2Lw2zKugMq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sLmaHBQJ",
      "display_url" : "pastebin.com\/raw.php?i=sLma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464494416166547456",
  "text" : "http:\/\/t.co\/2Lw2zKugMq Emails: 4486 Hashes: 3349 E\/H: 1.34 Keywords: 0.19 #infoleak",
  "id" : 464494416166547456,
  "created_at" : "2014-05-08 19:57:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vBRslKWMYd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4vtkfRnc",
      "display_url" : "pastebin.com\/raw.php?i=4vtk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464487614892875776",
  "text" : "http:\/\/t.co\/vBRslKWMYd Possible cisco configuration #infoleak",
  "id" : 464487614892875776,
  "created_at" : "2014-05-08 19:30:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MrlvCMiH6n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rV883z9g",
      "display_url" : "pastebin.com\/raw.php?i=rV88\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464484634990882816",
  "text" : "http:\/\/t.co\/MrlvCMiH6n Emails: 37 Keywords: 0.11 #infoleak",
  "id" : 464484634990882816,
  "created_at" : "2014-05-08 19:19:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M4tYC1Vtou",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZWuwzzU4",
      "display_url" : "pastebin.com\/raw.php?i=ZWuw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464483126492680192",
  "text" : "http:\/\/t.co\/M4tYC1Vtou Emails: 150 Keywords: 0.0 #infoleak",
  "id" : 464483126492680192,
  "created_at" : "2014-05-08 19:13:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4DV1VSDyUA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4A2Whi1a",
      "display_url" : "pastebin.com\/raw.php?i=4A2W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464475309987729409",
  "text" : "http:\/\/t.co\/4DV1VSDyUA Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 464475309987729409,
  "created_at" : "2014-05-08 18:41:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dqaPhDrZIR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y5V2FqhQ",
      "display_url" : "pastebin.com\/raw.php?i=y5V2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464399401356513280",
  "text" : "http:\/\/t.co\/dqaPhDrZIR Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 464399401356513280,
  "created_at" : "2014-05-08 13:40:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0qMWHRANnR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Tx6qvgpM",
      "display_url" : "pastebin.com\/raw.php?i=Tx6q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464396294744584193",
  "text" : "http:\/\/t.co\/0qMWHRANnR Found possible Google API key(s) #infoleak",
  "id" : 464396294744584193,
  "created_at" : "2014-05-08 13:27:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V10jXULRuN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nJRAVVVZ",
      "display_url" : "pastebin.com\/raw.php?i=nJRA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464392518109372416",
  "text" : "http:\/\/t.co\/V10jXULRuN Emails: 295 Keywords: 0.0 #infoleak",
  "id" : 464392518109372416,
  "created_at" : "2014-05-08 13:12:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5oxULHfQmn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2NKE6BBt",
      "display_url" : "pastebin.com\/raw.php?i=2NKE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464386926489763840",
  "text" : "http:\/\/t.co\/5oxULHfQmn Keywords: 0.55 #infoleak",
  "id" : 464386926489763840,
  "created_at" : "2014-05-08 12:50:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lLU16Hbnnj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2DJwQWTh",
      "display_url" : "pastebin.com\/raw.php?i=2DJw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464379793291481090",
  "text" : "http:\/\/t.co\/lLU16Hbnnj Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 464379793291481090,
  "created_at" : "2014-05-08 12:22:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ILt3xm3SPu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NQ7zZPRm",
      "display_url" : "pastebin.com\/raw.php?i=NQ7z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464377714468597762",
  "text" : "http:\/\/t.co\/ILt3xm3SPu Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 464377714468597762,
  "created_at" : "2014-05-08 12:14:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xqFbM3J3xm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=im6xUr5m",
      "display_url" : "pastebin.com\/raw.php?i=im6x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464368984742060032",
  "text" : "http:\/\/t.co\/xqFbM3J3xm Hashes: 330 Keywords: 0.0 #infoleak",
  "id" : 464368984742060032,
  "created_at" : "2014-05-08 11:39:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LmYNrJTrwX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E3LNwSsQ",
      "display_url" : "pastebin.com\/raw.php?i=E3LN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464328683616878592",
  "text" : "http:\/\/t.co\/LmYNrJTrwX Found possible Google API key(s) #infoleak",
  "id" : 464328683616878592,
  "created_at" : "2014-05-08 08:59:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AIqQKpi6Kk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UDZikET3",
      "display_url" : "pastebin.com\/raw.php?i=UDZi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464326297192132610",
  "text" : "http:\/\/t.co\/AIqQKpi6Kk Emails: 1 Hashes: 2382 E\/H: 0.0 Keywords: 0.11 #infoleak",
  "id" : 464326297192132610,
  "created_at" : "2014-05-08 08:49:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tDoar1Lv5M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fq5YDU6b",
      "display_url" : "pastebin.com\/raw.php?i=fq5Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464320995147264000",
  "text" : "http:\/\/t.co\/tDoar1Lv5M Hashes: 32 Keywords: 0.33 #infoleak",
  "id" : 464320995147264000,
  "created_at" : "2014-05-08 08:28:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HR3e2BOAWA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c9ZHWQNc",
      "display_url" : "pastebin.com\/raw.php?i=c9ZH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464301955938930688",
  "text" : "http:\/\/t.co\/HR3e2BOAWA Emails: 385 Keywords: 0.0 #infoleak",
  "id" : 464301955938930688,
  "created_at" : "2014-05-08 07:13:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PIw7Vx0Hrs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dQb7XDUF",
      "display_url" : "pastebin.com\/raw.php?i=dQb7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464295862433087488",
  "text" : "http:\/\/t.co\/PIw7Vx0Hrs Emails: 47 Keywords: 0.0 #infoleak",
  "id" : 464295862433087488,
  "created_at" : "2014-05-08 06:48:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lPgc7V4ofC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gmupn4Ew",
      "display_url" : "pastebin.com\/raw.php?i=Gmup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464292666457350144",
  "text" : "http:\/\/t.co\/lPgc7V4ofC Emails: 307 Keywords: 0.0 #infoleak",
  "id" : 464292666457350144,
  "created_at" : "2014-05-08 06:36:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZgmLp5JZzH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TyMXLWGS",
      "display_url" : "pastebin.com\/raw.php?i=TyMX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464277561581633538",
  "text" : "http:\/\/t.co\/ZgmLp5JZzH Keywords: 0.77 #infoleak",
  "id" : 464277561581633538,
  "created_at" : "2014-05-08 05:36:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/je7n9XUrpf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YNqdsFyR",
      "display_url" : "pastebin.com\/raw.php?i=YNqd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464271735290736640",
  "text" : "http:\/\/t.co\/je7n9XUrpf Emails: 300 Keywords: 0.0 #infoleak",
  "id" : 464271735290736640,
  "created_at" : "2014-05-08 05:13:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mAQaA8b2xi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2wgBBNvL",
      "display_url" : "pastebin.com\/raw.php?i=2wgB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464255561127583745",
  "text" : "http:\/\/t.co\/mAQaA8b2xi Found possible Google API key(s) #infoleak",
  "id" : 464255561127583745,
  "created_at" : "2014-05-08 04:08:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Pab0qGNU9P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=caGkdg84",
      "display_url" : "pastebin.com\/raw.php?i=caGk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464252365193768960",
  "text" : "http:\/\/t.co\/Pab0qGNU9P Possible cisco configuration #infoleak",
  "id" : 464252365193768960,
  "created_at" : "2014-05-08 03:56:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GhIcMWUWlO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3AyF0Ajv",
      "display_url" : "pastebin.com\/raw.php?i=3AyF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464251906513051652",
  "text" : "http:\/\/t.co\/GhIcMWUWlO Possible cisco configuration #infoleak",
  "id" : 464251906513051652,
  "created_at" : "2014-05-08 03:54:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BAHXT485ws",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m9WfRBUi",
      "display_url" : "pastebin.com\/raw.php?i=m9Wf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464248932512440320",
  "text" : "http:\/\/t.co\/BAHXT485ws Emails: 342 Hashes: 169 E\/H: 2.02 Keywords: 0.33 #infoleak",
  "id" : 464248932512440320,
  "created_at" : "2014-05-08 03:42:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hPQ4uV2ytC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5CUVaTxM",
      "display_url" : "pastebin.com\/raw.php?i=5CUV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464241513698844672",
  "text" : "http:\/\/t.co\/hPQ4uV2ytC Emails: 368 Keywords: 0.0 #infoleak",
  "id" : 464241513698844672,
  "created_at" : "2014-05-08 03:12:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RdzmJSebev",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TxU5F9X3",
      "display_url" : "pastebin.com\/raw.php?i=TxU5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464241118528278529",
  "text" : "http:\/\/t.co\/RdzmJSebev Possible cisco configuration #infoleak",
  "id" : 464241118528278529,
  "created_at" : "2014-05-08 03:11:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZYcLnjBTFl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B7pcZctN",
      "display_url" : "pastebin.com\/raw.php?i=B7pc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464238985322065920",
  "text" : "http:\/\/t.co\/ZYcLnjBTFl Possible cisco configuration #infoleak",
  "id" : 464238985322065920,
  "created_at" : "2014-05-08 03:02:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PwFCe1yiHk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YppBREy0",
      "display_url" : "pastebin.com\/raw.php?i=YppB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464235958460624896",
  "text" : "http:\/\/t.co\/PwFCe1yiHk Keywords: 0.55 #infoleak",
  "id" : 464235958460624896,
  "created_at" : "2014-05-08 02:50:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/do7LIQodgi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QqyKdjYC",
      "display_url" : "pastebin.com\/raw.php?i=QqyK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464234239953625088",
  "text" : "http:\/\/t.co\/do7LIQodgi Possible cisco configuration #infoleak",
  "id" : 464234239953625088,
  "created_at" : "2014-05-08 02:44:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z6IXTywoPZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=At5kDpy3",
      "display_url" : "pastebin.com\/raw.php?i=At5k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464233449205686272",
  "text" : "http:\/\/t.co\/z6IXTywoPZ Possible cisco configuration #infoleak",
  "id" : 464233449205686272,
  "created_at" : "2014-05-08 02:40:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9tu9APbPrs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gLZtnL9U",
      "display_url" : "pastebin.com\/raw.php?i=gLZt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464226667477467136",
  "text" : "http:\/\/t.co\/9tu9APbPrs Possible cisco configuration #infoleak",
  "id" : 464226667477467136,
  "created_at" : "2014-05-08 02:13:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XDDsSnvKnN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JNGRaEUa",
      "display_url" : "pastebin.com\/raw.php?i=JNGR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464224432580333569",
  "text" : "http:\/\/t.co\/XDDsSnvKnN Possible cisco configuration #infoleak",
  "id" : 464224432580333569,
  "created_at" : "2014-05-08 02:05:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FwPUdnHzwC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FAtTWJv8",
      "display_url" : "pastebin.com\/raw.php?i=FAtT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464211326093385728",
  "text" : "http:\/\/t.co\/FwPUdnHzwC Emails: 396 Keywords: 0.0 #infoleak",
  "id" : 464211326093385728,
  "created_at" : "2014-05-08 01:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XjMlkcxuWd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G2Yp4wSR",
      "display_url" : "pastebin.com\/raw.php?i=G2Yp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464199028100440064",
  "text" : "http:\/\/t.co\/XjMlkcxuWd Emails: 26 Hashes: 13 E\/H: 2.0 Keywords: 0.3 #infoleak",
  "id" : 464199028100440064,
  "created_at" : "2014-05-08 00:24:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fezBtW59No",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h69wz8HW",
      "display_url" : "pastebin.com\/raw.php?i=h69w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464197617615114240",
  "text" : "http:\/\/t.co\/fezBtW59No Emails: 338 Keywords: 0.33 #infoleak",
  "id" : 464197617615114240,
  "created_at" : "2014-05-08 00:18:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jUk7PvevY9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZebigGYK",
      "display_url" : "pastebin.com\/raw.php?i=Zebi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464192397006499840",
  "text" : "http:\/\/t.co\/jUk7PvevY9 Emails: 38 Keywords: -0.14 #infoleak",
  "id" : 464192397006499840,
  "created_at" : "2014-05-07 23:57:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cXsMGFsZlt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hnV1MsN2",
      "display_url" : "pastebin.com\/raw.php?i=hnV1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464184999768379392",
  "text" : "http:\/\/t.co\/cXsMGFsZlt Emails: 338 Keywords: 0.33 #infoleak",
  "id" : 464184999768379392,
  "created_at" : "2014-05-07 23:28:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5VsTIwoPLE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pNyYeHWQ",
      "display_url" : "pastebin.com\/raw.php?i=pNyY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464181119458365442",
  "text" : "http:\/\/t.co\/5VsTIwoPLE Emails: 335 Keywords: 0.0 #infoleak",
  "id" : 464181119458365442,
  "created_at" : "2014-05-07 23:12:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F0SSRKze2p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cqNv1Ksp",
      "display_url" : "pastebin.com\/raw.php?i=cqNv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464168319059116032",
  "text" : "http:\/\/t.co\/F0SSRKze2p Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 464168319059116032,
  "created_at" : "2014-05-07 22:22:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XAm85AmywA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8QYF3y76",
      "display_url" : "pastebin.com\/raw.php?i=8QYF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464161510298624000",
  "text" : "http:\/\/t.co\/XAm85AmywA Keywords: 0.55 #infoleak",
  "id" : 464161510298624000,
  "created_at" : "2014-05-07 21:55:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vltYR3rfgZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Wi4yVYvy",
      "display_url" : "pastebin.com\/raw.php?i=Wi4y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464157949376462848",
  "text" : "http:\/\/t.co\/vltYR3rfgZ Hashes: 143 Keywords: 0.33 #infoleak",
  "id" : 464157949376462848,
  "created_at" : "2014-05-07 21:40:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oTCpjXn2yN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9AiaCUwg",
      "display_url" : "pastebin.com\/raw.php?i=9Aia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464132823142514688",
  "text" : "http:\/\/t.co\/oTCpjXn2yN Hashes: 44 Keywords: -0.03 #infoleak",
  "id" : 464132823142514688,
  "created_at" : "2014-05-07 20:01:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Cg2z6d6Fk2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JaJyANvQ",
      "display_url" : "pastebin.com\/raw.php?i=JaJy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464130344745058304",
  "text" : "http:\/\/t.co\/Cg2z6d6Fk2 Hashes: 30 Keywords: -0.06 #infoleak",
  "id" : 464130344745058304,
  "created_at" : "2014-05-07 19:51:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Tmq4T4EqSi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ax5jyVx1",
      "display_url" : "pastebin.com\/raw.php?i=ax5j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464113692229922816",
  "text" : "http:\/\/t.co\/Tmq4T4EqSi Emails: 21 Keywords: 0.44 #infoleak",
  "id" : 464113692229922816,
  "created_at" : "2014-05-07 18:45:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cem9IlqpRs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Eym8QxYW",
      "display_url" : "pastebin.com\/raw.php?i=Eym8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464103500645801984",
  "text" : "http:\/\/t.co\/cem9IlqpRs Emails: 3 Hashes: 332 E\/H: 0.01 Keywords: 0.22 #infoleak",
  "id" : 464103500645801984,
  "created_at" : "2014-05-07 18:04:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KrBAZ4G7K2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6a1JP9VV",
      "display_url" : "pastebin.com\/raw.php?i=6a1J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464097655736373248",
  "text" : "http:\/\/t.co\/KrBAZ4G7K2 Possible cisco configuration #infoleak",
  "id" : 464097655736373248,
  "created_at" : "2014-05-07 17:41:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xA3UdthNXc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xLBsdYUV",
      "display_url" : "pastebin.com\/raw.php?i=xLBs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464095618592305152",
  "text" : "http:\/\/t.co\/xA3UdthNXc Keywords: 0.66 #infoleak",
  "id" : 464095618592305152,
  "created_at" : "2014-05-07 17:33:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i9fm5YzoAi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DKfPiB56",
      "display_url" : "pastebin.com\/raw.php?i=DKfP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464092743736651778",
  "text" : "http:\/\/t.co\/i9fm5YzoAi Hashes: 31 Keywords: 0.0 #infoleak",
  "id" : 464092743736651778,
  "created_at" : "2014-05-07 17:21:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/B6xKUr9PBF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vRHL6ymR",
      "display_url" : "pastebin.com\/raw.php?i=vRHL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464090524907876352",
  "text" : "http:\/\/t.co\/B6xKUr9PBF Emails: 346 Keywords: 0.0 #infoleak",
  "id" : 464090524907876352,
  "created_at" : "2014-05-07 17:12:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7vQfCFAbb0",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9150493\/text",
      "display_url" : "pastie.org\/pastes\/9150493\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464086568492208129",
  "text" : "http:\/\/t.co\/7vQfCFAbb0 Keywords: 0.55 #infoleak",
  "id" : 464086568492208129,
  "created_at" : "2014-05-07 16:57:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ICPkUcsjrX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KYiXcwhX",
      "display_url" : "pastebin.com\/raw.php?i=KYiX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464081624343121921",
  "text" : "http:\/\/t.co\/ICPkUcsjrX Possible cisco configuration #infoleak",
  "id" : 464081624343121921,
  "created_at" : "2014-05-07 16:37:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9QjtHWbiaw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jQuLbvxk",
      "display_url" : "pastebin.com\/raw.php?i=jQuL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464081566151360514",
  "text" : "http:\/\/t.co\/9QjtHWbiaw Hashes: 67 Keywords: 0.0 #infoleak",
  "id" : 464081566151360514,
  "created_at" : "2014-05-07 16:37:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xpnv5sE6H7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zR6c5dYm",
      "display_url" : "pastebin.com\/raw.php?i=zR6c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464078406896717824",
  "text" : "http:\/\/t.co\/xpnv5sE6H7 Hashes: 148 Keywords: 0.16 #infoleak",
  "id" : 464078406896717824,
  "created_at" : "2014-05-07 16:24:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aBaK9hBZjR",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9150413\/text",
      "display_url" : "pastie.org\/pastes\/9150413\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464076738218057731",
  "text" : "http:\/\/t.co\/aBaK9hBZjR Hashes: 58 Keywords: 0.08 #infoleak",
  "id" : 464076738218057731,
  "created_at" : "2014-05-07 16:18:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LDHVqSAi0x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V5LeP15d",
      "display_url" : "pastebin.com\/raw.php?i=V5Le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464074260047093760",
  "text" : "http:\/\/t.co\/LDHVqSAi0x Hashes: 30 Keywords: 0.19 #infoleak",
  "id" : 464074260047093760,
  "created_at" : "2014-05-07 16:08:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/30X6Gbns7z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0Zg6RfyE",
      "display_url" : "pastebin.com\/raw.php?i=0Zg6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464062103154749440",
  "text" : "http:\/\/t.co\/30X6Gbns7z Emails: 101 Keywords: 0.0 #infoleak",
  "id" : 464062103154749440,
  "created_at" : "2014-05-07 15:20:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tmE09Av84k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Px2nWWrM",
      "display_url" : "pastebin.com\/raw.php?i=Px2n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464061981918367744",
  "text" : "http:\/\/t.co\/tmE09Av84k Emails: 31 Keywords: 0.44 #infoleak",
  "id" : 464061981918367744,
  "created_at" : "2014-05-07 15:19:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fsih1vM0Ei",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nL4y1U2V",
      "display_url" : "pastebin.com\/raw.php?i=nL4y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464061688149311488",
  "text" : "http:\/\/t.co\/Fsih1vM0Ei Keywords: 0.55 #infoleak",
  "id" : 464061688149311488,
  "created_at" : "2014-05-07 15:18:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W4oOPOsgo3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DYDfWhUT",
      "display_url" : "pastebin.com\/raw.php?i=DYDf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464061527876583424",
  "text" : "http:\/\/t.co\/W4oOPOsgo3 Emails: 1 Hashes: 254 E\/H: 0.0 Keywords: 0.11 #infoleak",
  "id" : 464061527876583424,
  "created_at" : "2014-05-07 15:17:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tUaaiUxORX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zduTvgNx",
      "display_url" : "pastebin.com\/raw.php?i=zduT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464061051122622464",
  "text" : "http:\/\/t.co\/tUaaiUxORX Keywords: 0.55 #infoleak",
  "id" : 464061051122622464,
  "created_at" : "2014-05-07 15:15:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lBIQjAwKMK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qaPmjPbt",
      "display_url" : "pastebin.com\/raw.php?i=qaPm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464060329190625280",
  "text" : "http:\/\/t.co\/lBIQjAwKMK Emails: 360 Keywords: 0.0 #infoleak",
  "id" : 464060329190625280,
  "created_at" : "2014-05-07 15:12:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JuXOgvMCrc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S43jVJyW",
      "display_url" : "pastebin.com\/raw.php?i=S43j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464059973719166976",
  "text" : "http:\/\/t.co\/JuXOgvMCrc Hashes: 56 Keywords: -0.31 #infoleak",
  "id" : 464059973719166976,
  "created_at" : "2014-05-07 15:11:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fhwSadeXJV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1UvQgVua",
      "display_url" : "pastebin.com\/raw.php?i=1UvQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464058901080440832",
  "text" : "http:\/\/t.co\/fhwSadeXJV Hashes: 95 Keywords: 0.0 #infoleak",
  "id" : 464058901080440832,
  "created_at" : "2014-05-07 15:07:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lzDd9dvWda",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=54myhVgH",
      "display_url" : "pastebin.com\/raw.php?i=54my\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464050871068663813",
  "text" : "http:\/\/t.co\/lzDd9dvWda Emails: 337 Keywords: 0.27 #infoleak",
  "id" : 464050871068663813,
  "created_at" : "2014-05-07 14:35:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/61PmzQ37Tm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=atMecJYn",
      "display_url" : "pastebin.com\/raw.php?i=atMe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464045003191246848",
  "text" : "http:\/\/t.co\/61PmzQ37Tm Emails: 61 Keywords: 0.0 #infoleak",
  "id" : 464045003191246848,
  "created_at" : "2014-05-07 14:12:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zG88dKvZdi",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9150026\/text",
      "display_url" : "pastie.org\/pastes\/9150026\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464044773490167808",
  "text" : "http:\/\/t.co\/zG88dKvZdi Hashes: 31 Keywords: 0.0 #infoleak",
  "id" : 464044773490167808,
  "created_at" : "2014-05-07 14:11:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cAYmy8NlZQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KLLGHznT",
      "display_url" : "pastebin.com\/raw.php?i=KLLG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464035883075649537",
  "text" : "http:\/\/t.co\/cAYmy8NlZQ Possible cisco configuration #infoleak",
  "id" : 464035883075649537,
  "created_at" : "2014-05-07 13:35:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UGq9f2FWxd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dh55rwih",
      "display_url" : "pastebin.com\/raw.php?i=Dh55\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464032685107580928",
  "text" : "http:\/\/t.co\/UGq9f2FWxd Emails: 1100 Hashes: 1100 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 464032685107580928,
  "created_at" : "2014-05-07 13:23:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pRx4q5kToo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yMmrbeMb",
      "display_url" : "pastebin.com\/raw.php?i=yMmr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464030175798108160",
  "text" : "http:\/\/t.co\/pRx4q5kToo Emails: 290 Keywords: 0.0 #infoleak",
  "id" : 464030175798108160,
  "created_at" : "2014-05-07 13:13:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/olXIc9ogDw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K2YTkR2f",
      "display_url" : "pastebin.com\/raw.php?i=K2YT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464029524171051008",
  "text" : "http:\/\/t.co\/olXIc9ogDw Emails: 24 Keywords: -0.06 #infoleak",
  "id" : 464029524171051008,
  "created_at" : "2014-05-07 13:10:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ItnWhnq72E",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9149891\/text",
      "display_url" : "pastie.org\/pastes\/9149891\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464028823177003008",
  "text" : "http:\/\/t.co\/ItnWhnq72E Keywords: 0.55 #infoleak",
  "id" : 464028823177003008,
  "created_at" : "2014-05-07 13:07:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/suRePcWWKi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RhRg7qBk",
      "display_url" : "pastebin.com\/raw.php?i=RhRg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464009373446987776",
  "text" : "http:\/\/t.co\/suRePcWWKi Found possible Google API key(s) #infoleak",
  "id" : 464009373446987776,
  "created_at" : "2014-05-07 11:50:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kBk88BNxLR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pD5rVJYR",
      "display_url" : "pastebin.com\/raw.php?i=pD5r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464006064694779905",
  "text" : "http:\/\/t.co\/kBk88BNxLR Emails: 99 Keywords: 0.22 #infoleak",
  "id" : 464006064694779905,
  "created_at" : "2014-05-07 11:37:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2FPtc765PJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mwruqWz1",
      "display_url" : "pastebin.com\/raw.php?i=mwru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463999928948105216",
  "text" : "http:\/\/t.co\/2FPtc765PJ Emails: 306 Keywords: 0.0 #infoleak",
  "id" : 463999928948105216,
  "created_at" : "2014-05-07 11:12:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KLb5KNRW78",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KGXcfBm3",
      "display_url" : "pastebin.com\/raw.php?i=KGXc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463998350845440000",
  "text" : "http:\/\/t.co\/KLb5KNRW78 Hashes: 546 Keywords: 0.11 #infoleak",
  "id" : 463998350845440000,
  "created_at" : "2014-05-07 11:06:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IHdGsVHNhD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kTNmPM4k",
      "display_url" : "pastebin.com\/raw.php?i=kTNm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463997979716644865",
  "text" : "http:\/\/t.co\/IHdGsVHNhD Found possible Google API key(s) #infoleak",
  "id" : 463997979716644865,
  "created_at" : "2014-05-07 11:05:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tjCAVtONNZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xqXmqVwz",
      "display_url" : "pastebin.com\/raw.php?i=xqXm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463994535241342976",
  "text" : "http:\/\/t.co\/tjCAVtONNZ Hashes: 90 Keywords: -0.03 #infoleak",
  "id" : 463994535241342976,
  "created_at" : "2014-05-07 10:51:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Au5zldQ0cT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9ypwcbxm",
      "display_url" : "pastebin.com\/raw.php?i=9ypw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463990803342188544",
  "text" : "http:\/\/t.co\/Au5zldQ0cT Emails: 26 Keywords: -0.17 #infoleak",
  "id" : 463990803342188544,
  "created_at" : "2014-05-07 10:36:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hewKFZfeJt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A4nHSKYx",
      "display_url" : "pastebin.com\/raw.php?i=A4nH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463989504659828737",
  "text" : "http:\/\/t.co\/hewKFZfeJt Emails: 224 Keywords: 0.11 #infoleak",
  "id" : 463989504659828737,
  "created_at" : "2014-05-07 10:31:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bZS3ruPvLx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3J11VedV",
      "display_url" : "pastebin.com\/raw.php?i=3J11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463988686565015552",
  "text" : "http:\/\/t.co\/bZS3ruPvLx Hashes: 82 Keywords: -0.03 #infoleak",
  "id" : 463988686565015552,
  "created_at" : "2014-05-07 10:28:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IGBG5ND5dc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M1vUXJNL",
      "display_url" : "pastebin.com\/raw.php?i=M1vU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463987433906774016",
  "text" : "http:\/\/t.co\/IGBG5ND5dc Hashes: 119 Keywords: -0.03 #infoleak",
  "id" : 463987433906774016,
  "created_at" : "2014-05-07 10:23:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9CZtGbPKzn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iCphH4j6",
      "display_url" : "pastebin.com\/raw.php?i=iCph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463984385855737856",
  "text" : "http:\/\/t.co\/9CZtGbPKzn Emails: 24 Keywords: 0.05 #infoleak",
  "id" : 463984385855737856,
  "created_at" : "2014-05-07 10:11:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mDqUIYK6qT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KTEey8Dc",
      "display_url" : "pastebin.com\/raw.php?i=KTEe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463977618660810752",
  "text" : "http:\/\/t.co\/mDqUIYK6qT Emails: 433 Hashes: 434 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 463977618660810752,
  "created_at" : "2014-05-07 09:44:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k34IRcJOkb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E7YaXiwC",
      "display_url" : "pastebin.com\/raw.php?i=E7Ya\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463973794642550784",
  "text" : "http:\/\/t.co\/k34IRcJOkb Keywords: 0.66 #infoleak",
  "id" : 463973794642550784,
  "created_at" : "2014-05-07 09:29:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/igjWHJt5Ye",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TQsY78qm",
      "display_url" : "pastebin.com\/raw.php?i=TQsY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463972430248042496",
  "text" : "http:\/\/t.co\/igjWHJt5Ye Emails: 1 Hashes: 50 E\/H: 0.02 Keywords: 0.33 #infoleak",
  "id" : 463972430248042496,
  "created_at" : "2014-05-07 09:23:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GlbiygFNiv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vBDBZzSy",
      "display_url" : "pastebin.com\/raw.php?i=vBDB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463967422458761216",
  "text" : "http:\/\/t.co\/GlbiygFNiv Emails: 131 Keywords: 0.22 #infoleak",
  "id" : 463967422458761216,
  "created_at" : "2014-05-07 09:03:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m4fp4Sg87y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vfcMfrRZ",
      "display_url" : "pastebin.com\/raw.php?i=vfcM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463966428719087616",
  "text" : "http:\/\/t.co\/m4fp4Sg87y Emails: 86 Keywords: 0.0 #infoleak",
  "id" : 463966428719087616,
  "created_at" : "2014-05-07 08:59:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4EwgFJlvRi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z5NPxTS4",
      "display_url" : "pastebin.com\/raw.php?i=z5NP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463962582278094848",
  "text" : "http:\/\/t.co\/4EwgFJlvRi Emails: 116 Keywords: 0.3 #infoleak",
  "id" : 463962582278094848,
  "created_at" : "2014-05-07 08:44:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gI5vqUYH7v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4HQfML45",
      "display_url" : "pastebin.com\/raw.php?i=4HQf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463956155937464320",
  "text" : "http:\/\/t.co\/gI5vqUYH7v Emails: 24 Keywords: 0.08 #infoleak",
  "id" : 463956155937464320,
  "created_at" : "2014-05-07 08:19:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MQOJWRRoeu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XDFNJx9G",
      "display_url" : "pastebin.com\/raw.php?i=XDFN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463939548754374657",
  "text" : "http:\/\/t.co\/MQOJWRRoeu Emails: 300 Keywords: 0.0 #infoleak",
  "id" : 463939548754374657,
  "created_at" : "2014-05-07 07:13:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g4XnCvqimT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1n2RaRnu",
      "display_url" : "pastebin.com\/raw.php?i=1n2R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463934832838336512",
  "text" : "http:\/\/t.co\/g4XnCvqimT Hashes: 36 Keywords: 0.22 #infoleak",
  "id" : 463934832838336512,
  "created_at" : "2014-05-07 06:54:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f8Xvx5gMWi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=umHF3L0q",
      "display_url" : "pastebin.com\/raw.php?i=umHF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463927017952399360",
  "text" : "http:\/\/t.co\/f8Xvx5gMWi Hashes: 290 Keywords: 0.33 #infoleak",
  "id" : 463927017952399360,
  "created_at" : "2014-05-07 06:23:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6MiXhmZ7zu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f8enHhHX",
      "display_url" : "pastebin.com\/raw.php?i=f8en\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463921785927241728",
  "text" : "http:\/\/t.co\/6MiXhmZ7zu Emails: 168 Keywords: 0.0 #infoleak",
  "id" : 463921785927241728,
  "created_at" : "2014-05-07 06:02:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q8E3bAwYEl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SvnpNWLj",
      "display_url" : "pastebin.com\/raw.php?i=Svnp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463914086506328064",
  "text" : "http:\/\/t.co\/q8E3bAwYEl Hashes: 97 Keywords: -0.03 #infoleak",
  "id" : 463914086506328064,
  "created_at" : "2014-05-07 05:31:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iBPZJOaOrl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=etHZfzdG",
      "display_url" : "pastebin.com\/raw.php?i=etHZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463909321860870144",
  "text" : "http:\/\/t.co\/iBPZJOaOrl Emails: 185 Keywords: 0.0 #infoleak",
  "id" : 463909321860870144,
  "created_at" : "2014-05-07 05:12:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oS42avEqCw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y8Q0e4ei",
      "display_url" : "pastebin.com\/raw.php?i=y8Q0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463906060068069376",
  "text" : "http:\/\/t.co\/oS42avEqCw Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 463906060068069376,
  "created_at" : "2014-05-07 04:59:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ya8HnF6Qcw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tERkuGGr",
      "display_url" : "pastebin.com\/raw.php?i=tERk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463902121515941889",
  "text" : "http:\/\/t.co\/ya8HnF6Qcw Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 463902121515941889,
  "created_at" : "2014-05-07 04:44:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/55dxFPVWRM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wPJJMVu8",
      "display_url" : "pastebin.com\/raw.php?i=wPJJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463902090163535872",
  "text" : "http:\/\/t.co\/55dxFPVWRM Emails: 173 Keywords: 0.0 #infoleak",
  "id" : 463902090163535872,
  "created_at" : "2014-05-07 04:44:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DCPsROnAeP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0D31sdZu",
      "display_url" : "pastebin.com\/raw.php?i=0D31\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463889400850423808",
  "text" : "http:\/\/t.co\/DCPsROnAeP Emails: 59 Keywords: 0.08 #infoleak",
  "id" : 463889400850423808,
  "created_at" : "2014-05-07 03:53:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YwOa94dgyg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sKTWSwbK",
      "display_url" : "pastebin.com\/raw.php?i=sKTW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463879128198807552",
  "text" : "http:\/\/t.co\/YwOa94dgyg Emails: 286 Keywords: 0.0 #infoleak",
  "id" : 463879128198807552,
  "created_at" : "2014-05-07 03:12:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CazMwXFgBF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xwGUXvjA",
      "display_url" : "pastebin.com\/raw.php?i=xwGU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463870065142534144",
  "text" : "http:\/\/t.co\/CazMwXFgBF Emails: 97 Keywords: 0.0 #infoleak",
  "id" : 463870065142534144,
  "created_at" : "2014-05-07 02:36:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rVM5HNqgwC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7daer0qv",
      "display_url" : "pastebin.com\/raw.php?i=7dae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463858768573263873",
  "text" : "http:\/\/t.co\/rVM5HNqgwC Emails: 1672 Keywords: 0.22 #infoleak",
  "id" : 463858768573263873,
  "created_at" : "2014-05-07 01:52:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XXpNZaDqXY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ecLTjz8R",
      "display_url" : "pastebin.com\/raw.php?i=ecLT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463856646825840640",
  "text" : "http:\/\/t.co\/XXpNZaDqXY Emails: 50 Keywords: 0.11 #infoleak",
  "id" : 463856646825840640,
  "created_at" : "2014-05-07 01:43:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cUGzRTQiWf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZVx6p8UR",
      "display_url" : "pastebin.com\/raw.php?i=ZVx6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463853691749933059",
  "text" : "http:\/\/t.co\/cUGzRTQiWf Emails: 25 Hashes: 12 E\/H: 2.08 Keywords: 0.3 #infoleak",
  "id" : 463853691749933059,
  "created_at" : "2014-05-07 01:31:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9XhJsuhoXY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MzPsBM99",
      "display_url" : "pastebin.com\/raw.php?i=MzPs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463852176167546882",
  "text" : "http:\/\/t.co\/9XhJsuhoXY Emails: 24 Hashes: 12 E\/H: 2.0 Keywords: 0.3 #infoleak",
  "id" : 463852176167546882,
  "created_at" : "2014-05-07 01:25:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hel0FFJDOW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=86e4VmiT",
      "display_url" : "pastebin.com\/raw.php?i=86e4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463848922566238209",
  "text" : "http:\/\/t.co\/Hel0FFJDOW Emails: 284 Keywords: 0.0 #infoleak",
  "id" : 463848922566238209,
  "created_at" : "2014-05-07 01:12:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/avGvYsV7C9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R56jP9yN",
      "display_url" : "pastebin.com\/raw.php?i=R56j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463841717620178946",
  "text" : "http:\/\/t.co\/avGvYsV7C9 Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 463841717620178946,
  "created_at" : "2014-05-07 00:44:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eBBQ4MfBVf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sULm31Yq",
      "display_url" : "pastebin.com\/raw.php?i=sULm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463834483611799554",
  "text" : "http:\/\/t.co\/eBBQ4MfBVf Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 463834483611799554,
  "created_at" : "2014-05-07 00:15:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5QC59vDtVo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ehuzjgiJ",
      "display_url" : "pastebin.com\/raw.php?i=ehuz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463834081466126336",
  "text" : "http:\/\/t.co\/5QC59vDtVo Hashes: 243 Keywords: 0.22 #infoleak",
  "id" : 463834081466126336,
  "created_at" : "2014-05-07 00:13:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3nmqqQXelY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w5qp5DGM",
      "display_url" : "pastebin.com\/raw.php?i=w5qp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463830132944146432",
  "text" : "http:\/\/t.co\/3nmqqQXelY Hashes: 32 Keywords: 0.19 #infoleak",
  "id" : 463830132944146432,
  "created_at" : "2014-05-06 23:58:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MG4rWruTXe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q7QR70W9",
      "display_url" : "pastebin.com\/raw.php?i=Q7QR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463828377833439233",
  "text" : "http:\/\/t.co\/MG4rWruTXe Emails: 24 Keywords: 0.11 #infoleak",
  "id" : 463828377833439233,
  "created_at" : "2014-05-06 23:51:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZtkbcU7Gb8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1CVRR7bz",
      "display_url" : "pastebin.com\/raw.php?i=1CVR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463821780512038914",
  "text" : "http:\/\/t.co\/ZtkbcU7Gb8 Found possible Google API key(s) #infoleak",
  "id" : 463821780512038914,
  "created_at" : "2014-05-06 23:25:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/36RzVNGxzn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RwQvd7Xq",
      "display_url" : "pastebin.com\/raw.php?i=RwQv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463818749133344768",
  "text" : "http:\/\/t.co\/36RzVNGxzn Emails: 187 Keywords: 0.0 #infoleak",
  "id" : 463818749133344768,
  "created_at" : "2014-05-06 23:13:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pC8f7AUdxf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CDMLBrF4",
      "display_url" : "pastebin.com\/raw.php?i=CDML\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463801983388753922",
  "text" : "http:\/\/t.co\/pC8f7AUdxf Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 463801983388753922,
  "created_at" : "2014-05-06 22:06:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pJdSyGu3lS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UjcELqS9",
      "display_url" : "pastebin.com\/raw.php?i=UjcE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463795355562147840",
  "text" : "http:\/\/t.co\/pJdSyGu3lS Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 463795355562147840,
  "created_at" : "2014-05-06 21:40:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AousnqNKf8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GrVujcpT",
      "display_url" : "pastebin.com\/raw.php?i=GrVu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463778828452511744",
  "text" : "http:\/\/t.co\/AousnqNKf8 Hashes: 86 Keywords: 0.0 #infoleak",
  "id" : 463778828452511744,
  "created_at" : "2014-05-06 20:34:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dty18ldyMl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=px2MpXE8",
      "display_url" : "pastebin.com\/raw.php?i=px2M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463775444722917377",
  "text" : "http:\/\/t.co\/dty18ldyMl Hashes: 30 Keywords: 0.22 #infoleak",
  "id" : 463775444722917377,
  "created_at" : "2014-05-06 20:20:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dJIUHBOfGg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8hWuEqpP",
      "display_url" : "pastebin.com\/raw.php?i=8hWu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463758352959279104",
  "text" : "http:\/\/t.co\/dJIUHBOfGg Emails: 197 Keywords: 0.0 #infoleak",
  "id" : 463758352959279104,
  "created_at" : "2014-05-06 19:13:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZIfS4vpa6T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gmbFPCJU",
      "display_url" : "pastebin.com\/raw.php?i=gmbF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463757348121481216",
  "text" : "http:\/\/t.co\/ZIfS4vpa6T Emails: 40 Keywords: 0.0 #infoleak",
  "id" : 463757348121481216,
  "created_at" : "2014-05-06 19:09:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AG0HLdaFBd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K2LDteSe",
      "display_url" : "pastebin.com\/raw.php?i=K2LD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463740779492433920",
  "text" : "http:\/\/t.co\/AG0HLdaFBd Hashes: 50 Keywords: 0.11 #infoleak",
  "id" : 463740779492433920,
  "created_at" : "2014-05-06 18:03:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2s22SmXApg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=94Da1zZ4",
      "display_url" : "pastebin.com\/raw.php?i=94Da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463738901719298048",
  "text" : "http:\/\/t.co\/2s22SmXApg Emails: 9 Hashes: 227 E\/H: 0.04 Keywords: 0.22 #infoleak",
  "id" : 463738901719298048,
  "created_at" : "2014-05-06 17:55:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WsMEtBe0ia",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j7XkcNke",
      "display_url" : "pastebin.com\/raw.php?i=j7Xk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463738272603074560",
  "text" : "http:\/\/t.co\/WsMEtBe0ia Emails: 1111 Keywords: 0.11 #infoleak",
  "id" : 463738272603074560,
  "created_at" : "2014-05-06 17:53:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dw9AqKvvpV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VRaY3pQJ",
      "display_url" : "pastebin.com\/raw.php?i=VRaY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463736816974442496",
  "text" : "http:\/\/t.co\/dw9AqKvvpV Hashes: 116 Keywords: 0.11 #infoleak",
  "id" : 463736816974442496,
  "created_at" : "2014-05-06 17:47:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6faphM0IP9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V1ahTEYN",
      "display_url" : "pastebin.com\/raw.php?i=V1ah\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463734007574708224",
  "text" : "http:\/\/t.co\/6faphM0IP9 Keywords: 0.66 #infoleak",
  "id" : 463734007574708224,
  "created_at" : "2014-05-06 17:36:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xGfArwvqlU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f1fxDrPJ",
      "display_url" : "pastebin.com\/raw.php?i=f1fx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463731465839058946",
  "text" : "http:\/\/t.co\/xGfArwvqlU Hashes: 1 Keywords: 0.66 #infoleak",
  "id" : 463731465839058946,
  "created_at" : "2014-05-06 17:26:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zDZmlov40y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vLX8XPVr",
      "display_url" : "pastebin.com\/raw.php?i=vLX8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463730115289964545",
  "text" : "http:\/\/t.co\/zDZmlov40y Hashes: 1 Keywords: 0.66 #infoleak",
  "id" : 463730115289964545,
  "created_at" : "2014-05-06 17:20:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I77TBO6whI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eMP9Xb1g",
      "display_url" : "pastebin.com\/raw.php?i=eMP9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463729981063827457",
  "text" : "http:\/\/t.co\/I77TBO6whI Emails: 1 Hashes: 1 E\/H: 1.0 Keywords: 0.55 #infoleak",
  "id" : 463729981063827457,
  "created_at" : "2014-05-06 17:20:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DXNFhQFnKu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=83H2ckx4",
      "display_url" : "pastebin.com\/raw.php?i=83H2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463720261959696384",
  "text" : "http:\/\/t.co\/DXNFhQFnKu Hashes: 1239 Keywords: -0.03 #infoleak",
  "id" : 463720261959696384,
  "created_at" : "2014-05-06 16:41:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SVyzCLSz8U",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k8b9jwVS",
      "display_url" : "pastebin.com\/raw.php?i=k8b9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463719943750443008",
  "text" : "http:\/\/t.co\/SVyzCLSz8U Hashes: 113 Keywords: 0.08 #infoleak",
  "id" : 463719943750443008,
  "created_at" : "2014-05-06 16:40:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XgiCAzKsYP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qf0Pmcqq",
      "display_url" : "pastebin.com\/raw.php?i=Qf0P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463719031485132800",
  "text" : "http:\/\/t.co\/XgiCAzKsYP Emails: 385 Keywords: 0.11 #infoleak",
  "id" : 463719031485132800,
  "created_at" : "2014-05-06 16:36:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iABIAerOuh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aUiYccK1",
      "display_url" : "pastebin.com\/raw.php?i=aUiY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463715851992969216",
  "text" : "http:\/\/t.co\/iABIAerOuh Emails: 145 Keywords: 0.22 #infoleak",
  "id" : 463715851992969216,
  "created_at" : "2014-05-06 16:24:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/83W90IXwxV",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s21uaZXGb6",
      "display_url" : "slexy.org\/raw\/s21uaZXGb6"
    } ]
  },
  "geo" : { },
  "id_str" : "463712093959503872",
  "text" : "http:\/\/t.co\/83W90IXwxV Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 463712093959503872,
  "created_at" : "2014-05-06 16:09:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VxnirPINO4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uzK86mC8",
      "display_url" : "pastebin.com\/raw.php?i=uzK8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463708601299632128",
  "text" : "http:\/\/t.co\/VxnirPINO4 Emails: 40 Keywords: 0.33 #infoleak",
  "id" : 463708601299632128,
  "created_at" : "2014-05-06 15:55:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I8V8L9MsgV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Pxz0VaRz",
      "display_url" : "pastebin.com\/raw.php?i=Pxz0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463706355098861568",
  "text" : "http:\/\/t.co\/I8V8L9MsgV Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 463706355098861568,
  "created_at" : "2014-05-06 15:46:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HL13GH83vL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jTfqPEPw",
      "display_url" : "pastebin.com\/raw.php?i=jTfq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463706162538364928",
  "text" : "http:\/\/t.co\/HL13GH83vL Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 463706162538364928,
  "created_at" : "2014-05-06 15:45:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qwAEayQwfy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m4Xd1cTf",
      "display_url" : "pastebin.com\/raw.php?i=m4Xd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463702559639625728",
  "text" : "http:\/\/t.co\/qwAEayQwfy Emails: 211 Keywords: 0.11 #infoleak",
  "id" : 463702559639625728,
  "created_at" : "2014-05-06 15:31:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Sib82c1Cc7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aqQ9ky0P",
      "display_url" : "pastebin.com\/raw.php?i=aqQ9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463695311525793792",
  "text" : "http:\/\/t.co\/Sib82c1Cc7 Emails: 18 Keywords: 0.99 #infoleak",
  "id" : 463695311525793792,
  "created_at" : "2014-05-06 15:02:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0BlHnyStY2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BGY7SvHi",
      "display_url" : "pastebin.com\/raw.php?i=BGY7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463694307489116161",
  "text" : "http:\/\/t.co\/0BlHnyStY2 Emails: 1 Hashes: 31 E\/H: 0.03 Keywords: 0.19 #infoleak",
  "id" : 463694307489116161,
  "created_at" : "2014-05-06 14:58:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8XOIQlHyke",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CNg2ELvG",
      "display_url" : "pastebin.com\/raw.php?i=CNg2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463689292561121280",
  "text" : "http:\/\/t.co\/8XOIQlHyke Emails: 18 Keywords: 0.99 #infoleak",
  "id" : 463689292561121280,
  "created_at" : "2014-05-06 14:38:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s5JHr9SjHe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p4gZ1ZEy",
      "display_url" : "pastebin.com\/raw.php?i=p4gZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463684476954886144",
  "text" : "http:\/\/t.co\/s5JHr9SjHe Hashes: 702 Keywords: 0.08 #infoleak",
  "id" : 463684476954886144,
  "created_at" : "2014-05-06 14:19:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zMwcmPF2Yz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q0aZjNkU",
      "display_url" : "pastebin.com\/raw.php?i=Q0aZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463683109855047682",
  "text" : "http:\/\/t.co\/zMwcmPF2Yz Emails: 2096 Keywords: 0.22 #infoleak",
  "id" : 463683109855047682,
  "created_at" : "2014-05-06 14:14:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vMOk86v4o9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j21AnpdW",
      "display_url" : "pastebin.com\/raw.php?i=j21A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463677849732259840",
  "text" : "http:\/\/t.co\/vMOk86v4o9 Emails: 18 Hashes: 62 E\/H: 0.29 Keywords: 0.11 #infoleak",
  "id" : 463677849732259840,
  "created_at" : "2014-05-06 13:53:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jyk92wlFvI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7TKGcqHW",
      "display_url" : "pastebin.com\/raw.php?i=7TKG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463676812883546112",
  "text" : "http:\/\/t.co\/jyk92wlFvI Hashes: 77 Keywords: 0.22 #infoleak",
  "id" : 463676812883546112,
  "created_at" : "2014-05-06 13:49:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LF31Gqy4Qf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EWtZER9c",
      "display_url" : "pastebin.com\/raw.php?i=EWtZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463675354654052352",
  "text" : "http:\/\/t.co\/LF31Gqy4Qf Keywords: 0.55 #infoleak",
  "id" : 463675354654052352,
  "created_at" : "2014-05-06 13:43:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YWyCAnYmr7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FjQLdAzQ",
      "display_url" : "pastebin.com\/raw.php?i=FjQL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463673024361684992",
  "text" : "http:\/\/t.co\/YWyCAnYmr7 Hashes: 46 Keywords: 0.19 #infoleak",
  "id" : 463673024361684992,
  "created_at" : "2014-05-06 13:33:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qKxnA9nhj5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qPMwfBBz",
      "display_url" : "pastebin.com\/raw.php?i=qPMw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463672834028343296",
  "text" : "http:\/\/t.co\/qKxnA9nhj5 Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 463672834028343296,
  "created_at" : "2014-05-06 13:33:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1rZaMahy7F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7LE6DS0p",
      "display_url" : "pastebin.com\/raw.php?i=7LE6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463667775483826177",
  "text" : "http:\/\/t.co\/1rZaMahy7F Emails: 383 Keywords: 0.0 #infoleak",
  "id" : 463667775483826177,
  "created_at" : "2014-05-06 13:13:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FI5ClEGT25",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J5pnu28A",
      "display_url" : "pastebin.com\/raw.php?i=J5pn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463654661782650880",
  "text" : "http:\/\/t.co\/FI5ClEGT25 Hashes: 122 Keywords: 0.33 #infoleak",
  "id" : 463654661782650880,
  "created_at" : "2014-05-06 12:21:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zl25EXd9sr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H5i0vwTG",
      "display_url" : "pastebin.com\/raw.php?i=H5i0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463649822893830144",
  "text" : "http:\/\/t.co\/zl25EXd9sr Emails: 167 Hashes: 167 E\/H: 1.0 Keywords: 0.77 #infoleak",
  "id" : 463649822893830144,
  "created_at" : "2014-05-06 12:01:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9H4hHCqjfb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UMizY5b9",
      "display_url" : "pastebin.com\/raw.php?i=UMiz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463644257966780418",
  "text" : "http:\/\/t.co\/9H4hHCqjfb Emails: 86 Keywords: 0.33 #infoleak",
  "id" : 463644257966780418,
  "created_at" : "2014-05-06 11:39:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QS8F0zpL5k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eTJZpS0e",
      "display_url" : "pastebin.com\/raw.php?i=eTJZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463623642752888834",
  "text" : "http:\/\/t.co\/QS8F0zpL5k Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 463623642752888834,
  "created_at" : "2014-05-06 10:17:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GBbu7t4Rc3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0J2pBY1H",
      "display_url" : "pastebin.com\/raw.php?i=0J2p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463622496478961664",
  "text" : "http:\/\/t.co\/GBbu7t4Rc3 Hashes: 314 Keywords: 0.41 #infoleak",
  "id" : 463622496478961664,
  "created_at" : "2014-05-06 10:13:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/puxpoghMyh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r23zKumH",
      "display_url" : "pastebin.com\/raw.php?i=r23z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463622437943255040",
  "text" : "http:\/\/t.co\/puxpoghMyh Hashes: 184 Keywords: 0.0 #infoleak",
  "id" : 463622437943255040,
  "created_at" : "2014-05-06 10:12:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YKq5TFDarp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X1GZrgYS",
      "display_url" : "pastebin.com\/raw.php?i=X1GZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463605168341127168",
  "text" : "http:\/\/t.co\/YKq5TFDarp Emails: 1244 Hashes: 10 E\/H: 124.4 Keywords: 0.22 #infoleak",
  "id" : 463605168341127168,
  "created_at" : "2014-05-06 09:04:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M0H316dK6J",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=X7hNNaV4",
      "display_url" : "pastebin.com\/raw.php?i=X7hN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463602573136502784",
  "text" : "http:\/\/t.co\/M0H316dK6J Emails: 228 Keywords: 0.11 #infoleak",
  "id" : 463602573136502784,
  "created_at" : "2014-05-06 08:54:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/itUeKLI5rA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QE08VD8W",
      "display_url" : "pastebin.com\/raw.php?i=QE08\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463601829050191872",
  "text" : "http:\/\/t.co\/itUeKLI5rA Found possible Google API key(s) #infoleak",
  "id" : 463601829050191872,
  "created_at" : "2014-05-06 08:51:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oIxgGhce8T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U1DBsnV0",
      "display_url" : "pastebin.com\/raw.php?i=U1DB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463597938782904320",
  "text" : "http:\/\/t.co\/oIxgGhce8T Emails: 1 Hashes: 66 E\/H: 0.02 Keywords: 0.44 #infoleak",
  "id" : 463597938782904320,
  "created_at" : "2014-05-06 08:35:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j773H2JKQG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wHUfVZ1x",
      "display_url" : "pastebin.com\/raw.php?i=wHUf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463594904942149632",
  "text" : "http:\/\/t.co\/j773H2JKQG Hashes: 37 Keywords: 0.0 #infoleak",
  "id" : 463594904942149632,
  "created_at" : "2014-05-06 08:23:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2O8ctFZMTs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qz1FQBhZ",
      "display_url" : "pastebin.com\/raw.php?i=qz1F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463588326067286016",
  "text" : "http:\/\/t.co\/2O8ctFZMTs Emails: 217 Hashes: 219 E\/H: 0.99 Keywords: 0.11 #infoleak",
  "id" : 463588326067286016,
  "created_at" : "2014-05-06 07:57:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fap8NERP6l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HLgRx6cN",
      "display_url" : "pastebin.com\/raw.php?i=HLgR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463585843869782016",
  "text" : "http:\/\/t.co\/Fap8NERP6l Emails: 186 Hashes: 194 E\/H: 0.96 Keywords: 0.19 #infoleak",
  "id" : 463585843869782016,
  "created_at" : "2014-05-06 07:47:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hgqbm5gIzi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UEADGYaa",
      "display_url" : "pastebin.com\/raw.php?i=UEAD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463579478212358145",
  "text" : "http:\/\/t.co\/Hgqbm5gIzi Emails: 1780 Hashes: 1196 E\/H: 1.49 Keywords: 0.11 #infoleak",
  "id" : 463579478212358145,
  "created_at" : "2014-05-06 07:22:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v1Ivm9f1jf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x1hQL0c7",
      "display_url" : "pastebin.com\/raw.php?i=x1hQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463579099877765120",
  "text" : "http:\/\/t.co\/v1Ivm9f1jf Emails: 3970 Hashes: 3974 E\/H: 1.0 Keywords: 0.08 #infoleak",
  "id" : 463579099877765120,
  "created_at" : "2014-05-06 07:20:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tAFxPwzmNG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=skLGXSKG",
      "display_url" : "pastebin.com\/raw.php?i=skLG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463578601397309440",
  "text" : "http:\/\/t.co\/tAFxPwzmNG Emails: 4486 Hashes: 3349 E\/H: 1.34 Keywords: 0.3 #infoleak",
  "id" : 463578601397309440,
  "created_at" : "2014-05-06 07:18:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NbZaoYDXOJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4jRMyYHD",
      "display_url" : "pastebin.com\/raw.php?i=4jRM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463578185083269120",
  "text" : "http:\/\/t.co\/NbZaoYDXOJ Emails: 2054 Hashes: 2059 E\/H: 1.0 Keywords: 0.33 #infoleak",
  "id" : 463578185083269120,
  "created_at" : "2014-05-06 07:17:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bEEyOx9xn5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HfTbnZkh",
      "display_url" : "pastebin.com\/raw.php?i=HfTb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463577288978608128",
  "text" : "http:\/\/t.co\/bEEyOx9xn5 Emails: 1786 Hashes: 1961 E\/H: 0.91 Keywords: 0.22 #infoleak",
  "id" : 463577288978608128,
  "created_at" : "2014-05-06 07:13:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W308Ihpxgh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ne2QHn8Q",
      "display_url" : "pastebin.com\/raw.php?i=ne2Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463577214882025472",
  "text" : "http:\/\/t.co\/W308Ihpxgh Emails: 205 Keywords: 0.0 #infoleak",
  "id" : 463577214882025472,
  "created_at" : "2014-05-06 07:13:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aD8yDQlVIq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8miCU4yY",
      "display_url" : "pastebin.com\/raw.php?i=8miC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463576349609701376",
  "text" : "http:\/\/t.co\/aD8yDQlVIq Emails: 127 Keywords: 0.11 #infoleak",
  "id" : 463576349609701376,
  "created_at" : "2014-05-06 07:09:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PELX1qZ0vr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vW9DydyJ",
      "display_url" : "pastebin.com\/raw.php?i=vW9D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463573312728084480",
  "text" : "http:\/\/t.co\/PELX1qZ0vr Emails: 4 Hashes: 32 E\/H: 0.13 Keywords: 0.05 #infoleak",
  "id" : 463573312728084480,
  "created_at" : "2014-05-06 06:57:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n6Rw43rJ8m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eG074tmE",
      "display_url" : "pastebin.com\/raw.php?i=eG07\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463571747736809472",
  "text" : "http:\/\/t.co\/n6Rw43rJ8m Emails: 4 Hashes: 32 E\/H: 0.13 Keywords: 0.05 #infoleak",
  "id" : 463571747736809472,
  "created_at" : "2014-05-06 06:51:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3tyhnOoNWT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Dy2623J9",
      "display_url" : "pastebin.com\/raw.php?i=Dy26\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463563687228235776",
  "text" : "http:\/\/t.co\/3tyhnOoNWT Emails: 413 Keywords: 0.11 #infoleak",
  "id" : 463563687228235776,
  "created_at" : "2014-05-06 06:19:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rMlPydEsZA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YAcnNwjj",
      "display_url" : "pastebin.com\/raw.php?i=YAcn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463563246583021568",
  "text" : "http:\/\/t.co\/rMlPydEsZA Hashes: 1 Keywords: 0.66 #infoleak",
  "id" : 463563246583021568,
  "created_at" : "2014-05-06 06:17:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AOAccEg2Fb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Sxkxib8",
      "display_url" : "pastebin.com\/raw.php?i=7Sxk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463558234851135488",
  "text" : "http:\/\/t.co\/AOAccEg2Fb Hashes: 44 Keywords: 0.22 #infoleak",
  "id" : 463558234851135488,
  "created_at" : "2014-05-06 05:57:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dUfSwo6beo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XNaz6CTS",
      "display_url" : "pastebin.com\/raw.php?i=XNaz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463548107553112064",
  "text" : "http:\/\/t.co\/dUfSwo6beo Emails: 2 Hashes: 61 E\/H: 0.03 Keywords: 0.22 #infoleak",
  "id" : 463548107553112064,
  "created_at" : "2014-05-06 05:17:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MI8qPQYGdz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jwHBV8jq",
      "display_url" : "pastebin.com\/raw.php?i=jwHB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463546969512628224",
  "text" : "http:\/\/t.co\/MI8qPQYGdz Emails: 344 Keywords: 0.0 #infoleak",
  "id" : 463546969512628224,
  "created_at" : "2014-05-06 05:13:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Pm3LfBZ0sI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8hV7DMrF",
      "display_url" : "pastebin.com\/raw.php?i=8hV7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463545960249819136",
  "text" : "http:\/\/t.co\/Pm3LfBZ0sI Found possible Google API key(s) #infoleak",
  "id" : 463545960249819136,
  "created_at" : "2014-05-06 05:09:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yeFotBj9Qp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ef3Dy4KN",
      "display_url" : "pastebin.com\/raw.php?i=Ef3D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463542122059010048",
  "text" : "http:\/\/t.co\/yeFotBj9Qp Emails: 46 Keywords: 0.0 #infoleak",
  "id" : 463542122059010048,
  "created_at" : "2014-05-06 04:53:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eKflEQvoA2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=myD5PmwJ",
      "display_url" : "pastebin.com\/raw.php?i=myD5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463537325490724865",
  "text" : "http:\/\/t.co\/eKflEQvoA2 Emails: 2 Hashes: 2 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 463537325490724865,
  "created_at" : "2014-05-06 04:34:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TCuOkgr38G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=da5M9Twb",
      "display_url" : "pastebin.com\/raw.php?i=da5M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463535880683003904",
  "text" : "http:\/\/t.co\/TCuOkgr38G Emails: 2 Hashes: 2 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 463535880683003904,
  "created_at" : "2014-05-06 04:29:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/82OrsfKhmQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SWw4V2vP",
      "display_url" : "pastebin.com\/raw.php?i=SWw4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463534973572505600",
  "text" : "http:\/\/t.co\/82OrsfKhmQ Emails: 2 Hashes: 2 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 463534973572505600,
  "created_at" : "2014-05-06 04:25:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9imypAR5DX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NbYQFZBm",
      "display_url" : "pastebin.com\/raw.php?i=NbYQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463531195121143808",
  "text" : "http:\/\/t.co\/9imypAR5DX Emails: 285 Keywords: 0.0 #infoleak",
  "id" : 463531195121143808,
  "created_at" : "2014-05-06 04:10:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dEws2vLvtd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z6V6T5FL",
      "display_url" : "pastebin.com\/raw.php?i=Z6V6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463530086407208960",
  "text" : "http:\/\/t.co\/dEws2vLvtd Keywords: 0.77 #infoleak",
  "id" : 463530086407208960,
  "created_at" : "2014-05-06 04:05:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N1l64yFCYk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ifqXSYvv",
      "display_url" : "pastebin.com\/raw.php?i=ifqX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463527840525217792",
  "text" : "http:\/\/t.co\/N1l64yFCYk Emails: 27 Keywords: 0.11 #infoleak",
  "id" : 463527840525217792,
  "created_at" : "2014-05-06 03:57:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K8xil7Jm6k",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JjWtaPFz",
      "display_url" : "pastebin.com\/raw.php?i=JjWt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463521157769986048",
  "text" : "http:\/\/t.co\/K8xil7Jm6k Hashes: 1 Keywords: 0.55 #infoleak",
  "id" : 463521157769986048,
  "created_at" : "2014-05-06 03:30:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uxBxYTiDiF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xVPjFA1K",
      "display_url" : "pastebin.com\/raw.php?i=xVPj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463517589381996544",
  "text" : "http:\/\/t.co\/uxBxYTiDiF Keywords: 0.55 #infoleak",
  "id" : 463517589381996544,
  "created_at" : "2014-05-06 03:16:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mphuKlRPv2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Va1Cq1vE",
      "display_url" : "pastebin.com\/raw.php?i=Va1C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463516773459820544",
  "text" : "http:\/\/t.co\/mphuKlRPv2 Emails: 263 Keywords: 0.0 #infoleak",
  "id" : 463516773459820544,
  "created_at" : "2014-05-06 03:13:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mr6MWIScWd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RpGUxpbH",
      "display_url" : "pastebin.com\/raw.php?i=RpGU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463486617567518720",
  "text" : "http:\/\/t.co\/Mr6MWIScWd Emails: 388 Keywords: 0.0 #infoleak",
  "id" : 463486617567518720,
  "created_at" : "2014-05-06 01:13:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zfAPXVxDdH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LH4VWjB7",
      "display_url" : "pastebin.com\/raw.php?i=LH4V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463486178973331456",
  "text" : "http:\/\/t.co\/zfAPXVxDdH Emails: 25 Keywords: 0.08 #infoleak",
  "id" : 463486178973331456,
  "created_at" : "2014-05-06 01:11:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jLnpDvA3nk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ufjRWckv",
      "display_url" : "pastebin.com\/raw.php?i=ufjR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463484596256899073",
  "text" : "http:\/\/t.co\/jLnpDvA3nk Possible cisco configuration #infoleak",
  "id" : 463484596256899073,
  "created_at" : "2014-05-06 01:05:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m0omZZEBJR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k26dUtbF",
      "display_url" : "pastebin.com\/raw.php?i=k26d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463456349611761664",
  "text" : "http:\/\/t.co\/m0omZZEBJR Emails: 212 Keywords: 0.0 #infoleak",
  "id" : 463456349611761664,
  "created_at" : "2014-05-05 23:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d2G0oCgbMe",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9143856\/text",
      "display_url" : "pastie.org\/pastes\/9143856\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463428478327468032",
  "text" : "http:\/\/t.co\/d2G0oCgbMe Hashes: 37 Keywords: -0.17 #infoleak",
  "id" : 463428478327468032,
  "created_at" : "2014-05-05 21:22:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wnGTRlYaeZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wygYi0nY",
      "display_url" : "pastebin.com\/raw.php?i=wygY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463426152002899969",
  "text" : "http:\/\/t.co\/wnGTRlYaeZ Emails: 288 Keywords: 0.0 #infoleak",
  "id" : 463426152002899969,
  "created_at" : "2014-05-05 21:12:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BQPraZ6elF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GyBLFubX",
      "display_url" : "pastebin.com\/raw.php?i=GyBL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463424416232112129",
  "text" : "http:\/\/t.co\/BQPraZ6elF Emails: 1044 Keywords: -0.03 #infoleak",
  "id" : 463424416232112129,
  "created_at" : "2014-05-05 21:06:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/onvei64DOL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=12DtRmjC",
      "display_url" : "pastebin.com\/raw.php?i=12Dt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463424032553959424",
  "text" : "http:\/\/t.co\/onvei64DOL Hashes: 176 Keywords: -0.14 #infoleak",
  "id" : 463424032553959424,
  "created_at" : "2014-05-05 21:04:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ocYeerx4bw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V1mDbmKZ",
      "display_url" : "pastebin.com\/raw.php?i=V1mD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463422996212760576",
  "text" : "http:\/\/t.co\/ocYeerx4bw Emails: 90 Keywords: 0.0 #infoleak",
  "id" : 463422996212760576,
  "created_at" : "2014-05-05 21:00:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OkFV3PWW0R",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9143786\/text",
      "display_url" : "pastie.org\/pastes\/9143786\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463422478593712128",
  "text" : "http:\/\/t.co\/OkFV3PWW0R Found possible Google API key(s) #infoleak",
  "id" : 463422478593712128,
  "created_at" : "2014-05-05 20:58:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nkl1kVghtx",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9143758\/text",
      "display_url" : "pastie.org\/pastes\/9143758\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463419400796643328",
  "text" : "http:\/\/t.co\/nkl1kVghtx Found possible Google API key(s) #infoleak",
  "id" : 463419400796643328,
  "created_at" : "2014-05-05 20:46:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/04GI8WvyeM",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9143757\/text",
      "display_url" : "pastie.org\/pastes\/9143757\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463419392827461632",
  "text" : "http:\/\/t.co\/04GI8WvyeM Found possible Google API key(s) #infoleak",
  "id" : 463419392827461632,
  "created_at" : "2014-05-05 20:46:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3tw4WG5qIj",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/9143751\/text",
      "display_url" : "pastie.org\/pastes\/9143751\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463419070813966336",
  "text" : "http:\/\/t.co\/3tw4WG5qIj Found possible Google API key(s) #infoleak",
  "id" : 463419070813966336,
  "created_at" : "2014-05-05 20:44:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ebcc00r9rS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MTr10Tgf",
      "display_url" : "pastebin.com\/raw.php?i=MTr1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463416895098462208",
  "text" : "http:\/\/t.co\/ebcc00r9rS Emails: 1792 Keywords: -0.14 #infoleak",
  "id" : 463416895098462208,
  "created_at" : "2014-05-05 20:36:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5mZmLAdDqR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0cGQpLnY",
      "display_url" : "pastebin.com\/raw.php?i=0cGQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463416572166410240",
  "text" : "http:\/\/t.co\/5mZmLAdDqR Emails: 1577 Keywords: -0.14 #infoleak",
  "id" : 463416572166410240,
  "created_at" : "2014-05-05 20:34:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gdjHPVlS8N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GKqAPiQP",
      "display_url" : "pastebin.com\/raw.php?i=GKqA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463407259553251328",
  "text" : "http:\/\/t.co\/gdjHPVlS8N Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 463407259553251328,
  "created_at" : "2014-05-05 19:57:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/THthMM93II",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=trShEk2F",
      "display_url" : "pastebin.com\/raw.php?i=trSh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463402624218181632",
  "text" : "http:\/\/t.co\/THthMM93II Emails: 110 Hashes: 2 E\/H: 55.0 Keywords: 0.0 #infoleak",
  "id" : 463402624218181632,
  "created_at" : "2014-05-05 19:39:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/evVAdEIKFm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kaTzQ9Fj",
      "display_url" : "pastebin.com\/raw.php?i=kaTz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463400825818071041",
  "text" : "http:\/\/t.co\/evVAdEIKFm Hashes: 39 Keywords: 0.11 #infoleak",
  "id" : 463400825818071041,
  "created_at" : "2014-05-05 19:32:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p7EorHWPZ8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1vD5FqG1",
      "display_url" : "pastebin.com\/raw.php?i=1vD5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463399942094987264",
  "text" : "http:\/\/t.co\/p7EorHWPZ8 Hashes: 1 Keywords: 0.55 #infoleak",
  "id" : 463399942094987264,
  "created_at" : "2014-05-05 19:28:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zJWBqIB1hk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dXXzz3sb",
      "display_url" : "pastebin.com\/raw.php?i=dXXz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463396024073990144",
  "text" : "http:\/\/t.co\/zJWBqIB1hk Emails: 291 Keywords: 0.0 #infoleak",
  "id" : 463396024073990144,
  "created_at" : "2014-05-05 19:13:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8ViWQLwjK1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SDYbimJY",
      "display_url" : "pastebin.com\/raw.php?i=SDYb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463393911889596416",
  "text" : "http:\/\/t.co\/8ViWQLwjK1 Hashes: 156 Keywords: 0.08 #infoleak",
  "id" : 463393911889596416,
  "created_at" : "2014-05-05 19:04:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u28gczfAIK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CybB9pYD",
      "display_url" : "pastebin.com\/raw.php?i=CybB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463391245297909760",
  "text" : "http:\/\/t.co\/u28gczfAIK Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 463391245297909760,
  "created_at" : "2014-05-05 18:54:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b3HKm5vSdw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gvMkD6p6",
      "display_url" : "pastebin.com\/raw.php?i=gvMk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463365743518564352",
  "text" : "http:\/\/t.co\/b3HKm5vSdw Emails: 178 Keywords: 0.0 #infoleak",
  "id" : 463365743518564352,
  "created_at" : "2014-05-05 17:12:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uhnywDonCb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xycHKuCB",
      "display_url" : "pastebin.com\/raw.php?i=xycH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463365276218572800",
  "text" : "http:\/\/t.co\/uhnywDonCb Emails: 125 Keywords: 0.0 #infoleak",
  "id" : 463365276218572800,
  "created_at" : "2014-05-05 17:11:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WDaSsVZRsa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j5TCL62z",
      "display_url" : "pastebin.com\/raw.php?i=j5TC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463362587099283456",
  "text" : "http:\/\/t.co\/WDaSsVZRsa Emails: 59 Hashes: 58 E\/H: 1.02 Keywords: 0.0 #infoleak",
  "id" : 463362587099283456,
  "created_at" : "2014-05-05 17:00:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8Ie0UGOxqU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3Nmb8Ubk",
      "display_url" : "pastebin.com\/raw.php?i=3Nmb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463355430077358080",
  "text" : "http:\/\/t.co\/8Ie0UGOxqU Found possible Google API key(s) #infoleak",
  "id" : 463355430077358080,
  "created_at" : "2014-05-05 16:31:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ggPowvnVS0",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s207CwDH2O",
      "display_url" : "slexy.org\/raw\/s207CwDH2O"
    } ]
  },
  "geo" : { },
  "id_str" : "463355355477450752",
  "text" : "http:\/\/t.co\/ggPowvnVS0 Emails: 100 Keywords: -0.14 #infoleak",
  "id" : 463355355477450752,
  "created_at" : "2014-05-05 16:31:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4BygOAYu6u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TxaApT3x",
      "display_url" : "pastebin.com\/raw.php?i=TxaA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463354074318897152",
  "text" : "http:\/\/t.co\/4BygOAYu6u Keywords: 0.66 #infoleak",
  "id" : 463354074318897152,
  "created_at" : "2014-05-05 16:26:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/09GpE9r1qr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HueE9XwE",
      "display_url" : "pastebin.com\/raw.php?i=HueE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463350882453553152",
  "text" : "http:\/\/t.co\/09GpE9r1qr Hashes: 300 Keywords: 0.11 #infoleak",
  "id" : 463350882453553152,
  "created_at" : "2014-05-05 16:13:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g7VLXEkw9X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WBdrqf9G",
      "display_url" : "pastebin.com\/raw.php?i=WBdr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463179472674361344",
  "text" : "http:\/\/t.co\/g7VLXEkw9X Found possible Google API key(s) #infoleak",
  "id" : 463179472674361344,
  "created_at" : "2014-05-05 04:52:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KZhlEdGgk6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qWMY79pV",
      "display_url" : "pastebin.com\/raw.php?i=qWMY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463154350919917570",
  "text" : "http:\/\/t.co\/KZhlEdGgk6 Emails: 142 Keywords: 0.0 #infoleak",
  "id" : 463154350919917570,
  "created_at" : "2014-05-05 03:12:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U2o8RVSE0L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gehbTv1N",
      "display_url" : "pastebin.com\/raw.php?i=gehb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463135968023695360",
  "text" : "http:\/\/t.co\/U2o8RVSE0L Hashes: 92 Keywords: 0.0 #infoleak",
  "id" : 463135968023695360,
  "created_at" : "2014-05-05 01:59:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PO0YpNDBRZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KdWr7FHJ",
      "display_url" : "pastebin.com\/raw.php?i=KdWr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463126362153185280",
  "text" : "http:\/\/t.co\/PO0YpNDBRZ Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 463126362153185280,
  "created_at" : "2014-05-05 01:21:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p3Z4Md1ZXJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tCWVDuSE",
      "display_url" : "pastebin.com\/raw.php?i=tCWV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463124145652252672",
  "text" : "http:\/\/t.co\/p3Z4Md1ZXJ Emails: 285 Keywords: 0.0 #infoleak",
  "id" : 463124145652252672,
  "created_at" : "2014-05-05 01:12:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iUsKwkaZ8A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sHLAxVK1",
      "display_url" : "pastebin.com\/raw.php?i=sHLA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463119763669921793",
  "text" : "http:\/\/t.co\/iUsKwkaZ8A Hashes: 70 Keywords: 0.33 #infoleak",
  "id" : 463119763669921793,
  "created_at" : "2014-05-05 00:55:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hGt8q9OxTW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mmB45V7J",
      "display_url" : "pastebin.com\/raw.php?i=mmB4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463114188785610752",
  "text" : "http:\/\/t.co\/hGt8q9OxTW Emails: 42 Keywords: 0.44 #infoleak",
  "id" : 463114188785610752,
  "created_at" : "2014-05-05 00:33:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5Yst0o0GtB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZvzCQr5X",
      "display_url" : "pastebin.com\/raw.php?i=ZvzC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463110710507999232",
  "text" : "http:\/\/t.co\/5Yst0o0GtB Emails: 145 Keywords: 0.0 #infoleak",
  "id" : 463110710507999232,
  "created_at" : "2014-05-05 00:19:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RFPSDBjhWj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D0VsXsGg",
      "display_url" : "pastebin.com\/raw.php?i=D0Vs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463108235130449920",
  "text" : "http:\/\/t.co\/RFPSDBjhWj Hashes: 71 Keywords: 0.11 #infoleak",
  "id" : 463108235130449920,
  "created_at" : "2014-05-05 00:09:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5FOU4gVkAV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8rHFXjqv",
      "display_url" : "pastebin.com\/raw.php?i=8rHF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463093954766852096",
  "text" : "http:\/\/t.co\/5FOU4gVkAV Emails: 272 Keywords: 0.0 #infoleak",
  "id" : 463093954766852096,
  "created_at" : "2014-05-04 23:12:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RweEfr228I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wB0yp1um",
      "display_url" : "pastebin.com\/raw.php?i=wB0y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463090815217061888",
  "text" : "http:\/\/t.co\/RweEfr228I Emails: 199 Hashes: 211 E\/H: 0.94 Keywords: 0.08 #infoleak",
  "id" : 463090815217061888,
  "created_at" : "2014-05-04 23:00:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/obZcRK0EGn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yhmWbs1x",
      "display_url" : "pastebin.com\/raw.php?i=yhmW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463089732583321600",
  "text" : "http:\/\/t.co\/obZcRK0EGn Emails: 463 Hashes: 487 E\/H: 0.95 Keywords: 0.08 #infoleak",
  "id" : 463089732583321600,
  "created_at" : "2014-05-04 22:56:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vgDzNWGPvx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a2pZhXtr",
      "display_url" : "pastebin.com\/raw.php?i=a2pZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463088764504403968",
  "text" : "http:\/\/t.co\/vgDzNWGPvx Emails: 650 Hashes: 690 E\/H: 0.94 Keywords: 0.08 #infoleak",
  "id" : 463088764504403968,
  "created_at" : "2014-05-04 22:52:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8pXuKnRsbH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VXz43gzM",
      "display_url" : "pastebin.com\/raw.php?i=VXz4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463087301690548224",
  "text" : "http:\/\/t.co\/8pXuKnRsbH Emails: 408 Hashes: 434 E\/H: 0.94 Keywords: 0.08 #infoleak",
  "id" : 463087301690548224,
  "created_at" : "2014-05-04 22:46:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ur8NMwOuPo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W6E2FVdX",
      "display_url" : "pastebin.com\/raw.php?i=W6E2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463086648717090816",
  "text" : "http:\/\/t.co\/Ur8NMwOuPo Emails: 383 Hashes: 408 E\/H: 0.94 Keywords: 0.08 #infoleak",
  "id" : 463086648717090816,
  "created_at" : "2014-05-04 22:43:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/De1smGqZik",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=83LCaTpy",
      "display_url" : "pastebin.com\/raw.php?i=83LC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463071030190145536",
  "text" : "http:\/\/t.co\/De1smGqZik Emails: 1163 Keywords: 0.08 #infoleak",
  "id" : 463071030190145536,
  "created_at" : "2014-05-04 21:41:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/66aO69SrKn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7bPMcd2U",
      "display_url" : "pastebin.com\/raw.php?i=7bPM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463063729815306240",
  "text" : "http:\/\/t.co\/66aO69SrKn Emails: 154 Keywords: 0.0 #infoleak",
  "id" : 463063729815306240,
  "created_at" : "2014-05-04 21:12:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XVt1J4eyZG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a71VJEhB",
      "display_url" : "pastebin.com\/raw.php?i=a71V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463055311171899392",
  "text" : "http:\/\/t.co\/XVt1J4eyZG Hashes: 58 Keywords: 0.0 #infoleak",
  "id" : 463055311171899392,
  "created_at" : "2014-05-04 20:39:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rn05eCV7YY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=20JUUHk3",
      "display_url" : "pastebin.com\/raw.php?i=20JU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463051738451169281",
  "text" : "http:\/\/t.co\/rn05eCV7YY Found possible Google API key(s) #infoleak",
  "id" : 463051738451169281,
  "created_at" : "2014-05-04 20:25:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Acz6BdxGqi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m4F2TzLF",
      "display_url" : "pastebin.com\/raw.php?i=m4F2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463043874584150016",
  "text" : "http:\/\/t.co\/Acz6BdxGqi Emails: 3 Hashes: 4 E\/H: 0.75 Keywords: 0.66 #infoleak",
  "id" : 463043874584150016,
  "created_at" : "2014-05-04 19:53:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RzX44Y6jjS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6GzBR1bK",
      "display_url" : "pastebin.com\/raw.php?i=6GzB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463038778928402432",
  "text" : "http:\/\/t.co\/RzX44Y6jjS Emails: 3660 Hashes: 3608 E\/H: 1.01 Keywords: 0.22 #infoleak",
  "id" : 463038778928402432,
  "created_at" : "2014-05-04 19:33:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rrWCh3l16Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RWr6ufxn",
      "display_url" : "pastebin.com\/raw.php?i=RWr6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463038426963398656",
  "text" : "http:\/\/t.co\/rrWCh3l16Z Emails: 806 Hashes: 851 E\/H: 0.95 Keywords: 0.08 #infoleak",
  "id" : 463038426963398656,
  "created_at" : "2014-05-04 19:32:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6Ci9AGXPkr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TX2uSmPe",
      "display_url" : "pastebin.com\/raw.php?i=TX2u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463028308251144192",
  "text" : "http:\/\/t.co\/6Ci9AGXPkr Emails: 36 Keywords: 0.44 #infoleak",
  "id" : 463028308251144192,
  "created_at" : "2014-05-04 18:52:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gEzAXOl6M4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LFdV09KE",
      "display_url" : "pastebin.com\/raw.php?i=LFdV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463027360879497216",
  "text" : "http:\/\/t.co\/gEzAXOl6M4 Hashes: 53 Keywords: -0.06 #infoleak",
  "id" : 463027360879497216,
  "created_at" : "2014-05-04 18:48:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WhcnSUKSWv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zmn9KKbF",
      "display_url" : "pastebin.com\/raw.php?i=zmn9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463024942422843392",
  "text" : "http:\/\/t.co\/WhcnSUKSWv Keywords: 0.55 #infoleak",
  "id" : 463024942422843392,
  "created_at" : "2014-05-04 18:38:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fp1edQll8t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KRvuyv9q",
      "display_url" : "pastebin.com\/raw.php?i=KRvu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463017921573163009",
  "text" : "http:\/\/t.co\/Fp1edQll8t Hashes: 1 Keywords: 0.66 #infoleak",
  "id" : 463017921573163009,
  "created_at" : "2014-05-04 18:10:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VMBpY123k5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5nRpVDF2",
      "display_url" : "pastebin.com\/raw.php?i=5nRp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463015117127294976",
  "text" : "http:\/\/t.co\/VMBpY123k5 Emails: 89 Keywords: 0.0 #infoleak",
  "id" : 463015117127294976,
  "created_at" : "2014-05-04 17:59:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nSloEehg73",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fRgUY8MX",
      "display_url" : "pastebin.com\/raw.php?i=fRgU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463014542360842240",
  "text" : "http:\/\/t.co\/nSloEehg73 Found possible Google API key(s) #infoleak",
  "id" : 463014542360842240,
  "created_at" : "2014-05-04 17:57:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z4yBtlKyfF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zW1cCAPs",
      "display_url" : "pastebin.com\/raw.php?i=zW1c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463014391068102656",
  "text" : "http:\/\/t.co\/z4yBtlKyfF Emails: 34 Keywords: 0.22 #infoleak",
  "id" : 463014391068102656,
  "created_at" : "2014-05-04 17:56:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NCAeN7Y7Pv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pZ8AQTEW",
      "display_url" : "pastebin.com\/raw.php?i=pZ8A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463012957392093185",
  "text" : "http:\/\/t.co\/NCAeN7Y7Pv Hashes: 44 Keywords: -0.06 #infoleak",
  "id" : 463012957392093185,
  "created_at" : "2014-05-04 17:51:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7JCcQjdrUU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wPHF3cC0",
      "display_url" : "pastebin.com\/raw.php?i=wPHF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463011375556476929",
  "text" : "http:\/\/t.co\/7JCcQjdrUU Emails: 2 Hashes: 34 E\/H: 0.06 Keywords: 0.3 #infoleak",
  "id" : 463011375556476929,
  "created_at" : "2014-05-04 17:44:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kj795UUbqk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XRWkgTh1",
      "display_url" : "pastebin.com\/raw.php?i=XRWk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463005656014794752",
  "text" : "http:\/\/t.co\/kj795UUbqk Hashes: 267 Keywords: -0.09 #infoleak",
  "id" : 463005656014794752,
  "created_at" : "2014-05-04 17:22:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xSfO2unPoV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6ue2MDE4",
      "display_url" : "pastebin.com\/raw.php?i=6ue2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462990797109882880",
  "text" : "http:\/\/t.co\/xSfO2unPoV Emails: 87 Keywords: 0.0 #infoleak",
  "id" : 462990797109882880,
  "created_at" : "2014-05-04 16:23:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/huqzAI4NEK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rfwupen0",
      "display_url" : "pastebin.com\/raw.php?i=rfwu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462974688302342144",
  "text" : "http:\/\/t.co\/huqzAI4NEK Found possible Google API key(s) #infoleak",
  "id" : 462974688302342144,
  "created_at" : "2014-05-04 15:19:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jKhAYRcgG8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B6fuuvtC",
      "display_url" : "pastebin.com\/raw.php?i=B6fu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462973372784058368",
  "text" : "http:\/\/t.co\/jKhAYRcgG8 Emails: 320 Keywords: 0.0 #infoleak",
  "id" : 462973372784058368,
  "created_at" : "2014-05-04 15:13:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Edf3O4Uhp0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tDL36Tmh",
      "display_url" : "pastebin.com\/raw.php?i=tDL3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462972916884176897",
  "text" : "http:\/\/t.co\/Edf3O4Uhp0 Hashes: 499 Keywords: 0.11 #infoleak",
  "id" : 462972916884176897,
  "created_at" : "2014-05-04 15:11:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ulnPVW4nG5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FLeN91rA",
      "display_url" : "pastebin.com\/raw.php?i=FLeN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462962084775354368",
  "text" : "http:\/\/t.co\/ulnPVW4nG5 Hashes: 155 Keywords: 0.11 #infoleak",
  "id" : 462962084775354368,
  "created_at" : "2014-05-04 14:28:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l4AhYlCIwV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HUDB0MYQ",
      "display_url" : "pastebin.com\/raw.php?i=HUDB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462961405327470592",
  "text" : "http:\/\/t.co\/l4AhYlCIwV Emails: 1 Hashes: 155 E\/H: 0.01 Keywords: 0.11 #infoleak",
  "id" : 462961405327470592,
  "created_at" : "2014-05-04 14:26:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3GFiq62MO4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Vxvzq18A",
      "display_url" : "pastebin.com\/raw.php?i=Vxvz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462961132571860992",
  "text" : "http:\/\/t.co\/3GFiq62MO4 Emails: 1 Hashes: 2430 E\/H: 0.0 Keywords: 0.11 #infoleak",
  "id" : 462961132571860992,
  "created_at" : "2014-05-04 14:25:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nSSBqvjIC4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MMGEJxjT",
      "display_url" : "pastebin.com\/raw.php?i=MMGE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462960105357443074",
  "text" : "http:\/\/t.co\/nSSBqvjIC4 Emails: 1 Hashes: 2586 E\/H: 0.0 Keywords: 0.11 #infoleak",
  "id" : 462960105357443074,
  "created_at" : "2014-05-04 14:21:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NzUi1DJ8km",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y8FRHNdS",
      "display_url" : "pastebin.com\/raw.php?i=Y8FR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462947885164666881",
  "text" : "http:\/\/t.co\/NzUi1DJ8km Hashes: 86 Keywords: 0.11 #infoleak",
  "id" : 462947885164666881,
  "created_at" : "2014-05-04 13:32:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0m9Mzwa5cX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GPTciLRi",
      "display_url" : "pastebin.com\/raw.php?i=GPTc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462943706069229568",
  "text" : "http:\/\/t.co\/0m9Mzwa5cX Emails: 52 Keywords: 0.11 #infoleak",
  "id" : 462943706069229568,
  "created_at" : "2014-05-04 13:15:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OTjFpTxowX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AiZyzH3a",
      "display_url" : "pastebin.com\/raw.php?i=AiZy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462943328254697472",
  "text" : "http:\/\/t.co\/OTjFpTxowX Keywords: 0.55 #infoleak",
  "id" : 462943328254697472,
  "created_at" : "2014-05-04 13:14:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KbUCMBa3qX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SGVNmNbh",
      "display_url" : "pastebin.com\/raw.php?i=SGVN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462942959306956800",
  "text" : "http:\/\/t.co\/KbUCMBa3qX Emails: 185 Keywords: 0.0 #infoleak",
  "id" : 462942959306956800,
  "created_at" : "2014-05-04 13:12:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5vv2q9FLfv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZLWzaQUz",
      "display_url" : "pastebin.com\/raw.php?i=ZLWz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462936841117655040",
  "text" : "http:\/\/t.co\/5vv2q9FLfv Hashes: 38 Keywords: -0.06 #infoleak",
  "id" : 462936841117655040,
  "created_at" : "2014-05-04 12:48:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nPQCpxUIAU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3Rw0wF9S",
      "display_url" : "pastebin.com\/raw.php?i=3Rw0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462927710457577472",
  "text" : "http:\/\/t.co\/nPQCpxUIAU Emails: 30 Keywords: 0.11 #infoleak",
  "id" : 462927710457577472,
  "created_at" : "2014-05-04 12:12:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4WyEA2TAOa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9xK6bw81",
      "display_url" : "pastebin.com\/raw.php?i=9xK6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462920731571933184",
  "text" : "http:\/\/t.co\/4WyEA2TAOa Emails: 25 Keywords: 0.77 #infoleak",
  "id" : 462920731571933184,
  "created_at" : "2014-05-04 11:44:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sha4FXlULl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5EAjJcFv",
      "display_url" : "pastebin.com\/raw.php?i=5EAj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462912820237967360",
  "text" : "http:\/\/t.co\/sha4FXlULl Emails: 254 Keywords: 0.0 #infoleak",
  "id" : 462912820237967360,
  "created_at" : "2014-05-04 11:13:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7ScEj1SKFw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TYEnchpZ",
      "display_url" : "pastebin.com\/raw.php?i=TYEn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462912737845075968",
  "text" : "http:\/\/t.co\/7ScEj1SKFw Emails: 143 Keywords: 0.0 #infoleak",
  "id" : 462912737845075968,
  "created_at" : "2014-05-04 11:12:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LSHRRlIN6g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7TCfwJms",
      "display_url" : "pastebin.com\/raw.php?i=7TCf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462912321040306176",
  "text" : "http:\/\/t.co\/LSHRRlIN6g Found possible Google API key(s) #infoleak",
  "id" : 462912321040306176,
  "created_at" : "2014-05-04 11:11:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Eg8QqR1j8f",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YnB90g3U",
      "display_url" : "pastebin.com\/raw.php?i=YnB9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462903850710474753",
  "text" : "http:\/\/t.co\/Eg8QqR1j8f Emails: 101 Keywords: 0.08 #infoleak",
  "id" : 462903850710474753,
  "created_at" : "2014-05-04 10:37:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d3e1UAUJJw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FFfS6xqF",
      "display_url" : "pastebin.com\/raw.php?i=FFfS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462902594394800128",
  "text" : "http:\/\/t.co\/d3e1UAUJJw Emails: 58 Keywords: -0.03 #infoleak",
  "id" : 462902594394800128,
  "created_at" : "2014-05-04 10:32:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YBjjIC9gcL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wgWPraW3",
      "display_url" : "pastebin.com\/raw.php?i=wgWP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462899966533312513",
  "text" : "http:\/\/t.co\/YBjjIC9gcL Emails: 2 Keywords: 0.66 #infoleak",
  "id" : 462899966533312513,
  "created_at" : "2014-05-04 10:22:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RPKGqoTaBp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Aiz9W0py",
      "display_url" : "pastebin.com\/raw.php?i=Aiz9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462898017889443840",
  "text" : "http:\/\/t.co\/RPKGqoTaBp Emails: 4 Keywords: 0.55 #infoleak",
  "id" : 462898017889443840,
  "created_at" : "2014-05-04 10:14:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qd8ErV5aaf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bthyH39w",
      "display_url" : "pastebin.com\/raw.php?i=bthy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462895905411067904",
  "text" : "http:\/\/t.co\/qd8ErV5aaf Emails: 1156 Keywords: 0.11 #infoleak",
  "id" : 462895905411067904,
  "created_at" : "2014-05-04 10:05:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t68J5uTsEO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CCj8KUAT",
      "display_url" : "pastebin.com\/raw.php?i=CCj8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462888673969598464",
  "text" : "http:\/\/t.co\/t68J5uTsEO Emails: 348 Hashes: 2 E\/H: 174.0 Keywords: 0.0 #infoleak",
  "id" : 462888673969598464,
  "created_at" : "2014-05-04 09:37:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kn13dQtWyd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tQ5DWQ0w",
      "display_url" : "pastebin.com\/raw.php?i=tQ5D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462792989677342720",
  "text" : "http:\/\/t.co\/kn13dQtWyd Emails: 65 Keywords: 0.0 #infoleak",
  "id" : 462792989677342720,
  "created_at" : "2014-05-04 03:17:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5IzqVahgP8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R1F2wW7e",
      "display_url" : "pastebin.com\/raw.php?i=R1F2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462791953176743936",
  "text" : "http:\/\/t.co\/5IzqVahgP8 Emails: 309 Keywords: 0.0 #infoleak",
  "id" : 462791953176743936,
  "created_at" : "2014-05-04 03:12:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dP9NIJA0cl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iX8tYZkf",
      "display_url" : "pastebin.com\/raw.php?i=iX8t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462791134343737345",
  "text" : "http:\/\/t.co\/dP9NIJA0cl Emails: 77 Keywords: 0.33 #infoleak",
  "id" : 462791134343737345,
  "created_at" : "2014-05-04 03:09:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CwG0QZ1pSH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TbWNQJzH",
      "display_url" : "pastebin.com\/raw.php?i=TbWN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462774387788111872",
  "text" : "http:\/\/t.co\/CwG0QZ1pSH Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 462774387788111872,
  "created_at" : "2014-05-04 02:03:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DD9f37pXsJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8fTYeEZY",
      "display_url" : "pastebin.com\/raw.php?i=8fTY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462773970819756032",
  "text" : "http:\/\/t.co\/DD9f37pXsJ Emails: 26 Keywords: 0.19 #infoleak",
  "id" : 462773970819756032,
  "created_at" : "2014-05-04 02:01:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J7aNyBWaUo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tXpwAjS5",
      "display_url" : "pastebin.com\/raw.php?i=tXpw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462761779840307201",
  "text" : "http:\/\/t.co\/J7aNyBWaUo Emails: 356 Keywords: 0.0 #infoleak",
  "id" : 462761779840307201,
  "created_at" : "2014-05-04 01:13:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/S3pwn0RtYI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kJRtj8sJ",
      "display_url" : "pastebin.com\/raw.php?i=kJRt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462760847589134338",
  "text" : "http:\/\/t.co\/S3pwn0RtYI Emails: 1672 Keywords: 0.22 #infoleak",
  "id" : 462760847589134338,
  "created_at" : "2014-05-04 01:09:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KdgT9VlTVG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HUYVdGYc",
      "display_url" : "pastebin.com\/raw.php?i=HUYV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462747723150553088",
  "text" : "http:\/\/t.co\/KdgT9VlTVG Emails: 62 Keywords: 0.0 #infoleak",
  "id" : 462747723150553088,
  "created_at" : "2014-05-04 00:17:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8kRcHPAQny",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dQpAcLsY",
      "display_url" : "pastebin.com\/raw.php?i=dQpA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462734902274711552",
  "text" : "http:\/\/t.co\/8kRcHPAQny Found possible Google API key(s) #infoleak",
  "id" : 462734902274711552,
  "created_at" : "2014-05-03 23:26:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zOIhDxRsol",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FLe1NJMw",
      "display_url" : "pastebin.com\/raw.php?i=FLe1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462731546483367936",
  "text" : "http:\/\/t.co\/zOIhDxRsol Emails: 375 Keywords: 0.0 #infoleak",
  "id" : 462731546483367936,
  "created_at" : "2014-05-03 23:12:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DchgpyJx9w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2ZtZnBQe",
      "display_url" : "pastebin.com\/raw.php?i=2ZtZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462723071011328001",
  "text" : "http:\/\/t.co\/DchgpyJx9w Hashes: 94 Keywords: -0.28 #infoleak",
  "id" : 462723071011328001,
  "created_at" : "2014-05-03 22:39:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4jur1TZsu7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yBjzYsbc",
      "display_url" : "pastebin.com\/raw.php?i=yBjz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462722706874441728",
  "text" : "http:\/\/t.co\/4jur1TZsu7 Hashes: 45 Keywords: 0.33 #infoleak",
  "id" : 462722706874441728,
  "created_at" : "2014-05-03 22:37:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K1Y1yI55bW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WfkT0D1p",
      "display_url" : "pastebin.com\/raw.php?i=WfkT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462719047985930240",
  "text" : "http:\/\/t.co\/K1Y1yI55bW Emails: 667 Keywords: 0.08 #infoleak",
  "id" : 462719047985930240,
  "created_at" : "2014-05-03 22:23:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AA0Isx6jVI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3Eeduj75",
      "display_url" : "pastebin.com\/raw.php?i=3Eed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462689505770631168",
  "text" : "http:\/\/t.co\/AA0Isx6jVI Emails: 107 Keywords: 0.22 #infoleak",
  "id" : 462689505770631168,
  "created_at" : "2014-05-03 20:25:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X22tUeXGEO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t7cQssuW",
      "display_url" : "pastebin.com\/raw.php?i=t7cQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462687290494435329",
  "text" : "http:\/\/t.co\/X22tUeXGEO Keywords: 0.55 #infoleak",
  "id" : 462687290494435329,
  "created_at" : "2014-05-03 20:17:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WUjC0dOzdr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qANZLEx3",
      "display_url" : "pastebin.com\/raw.php?i=qANZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462686801593769984",
  "text" : "http:\/\/t.co\/WUjC0dOzdr Emails: 47 Keywords: 0.0 #infoleak",
  "id" : 462686801593769984,
  "created_at" : "2014-05-03 20:15:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LjLoh4PKfG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nUVZzAT1",
      "display_url" : "pastebin.com\/raw.php?i=nUVZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462672268837920768",
  "text" : "http:\/\/t.co\/LjLoh4PKfG Emails: 110 Keywords: 0.19 #infoleak",
  "id" : 462672268837920768,
  "created_at" : "2014-05-03 19:17:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Jk2scTdmwV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vW5uARLs",
      "display_url" : "pastebin.com\/raw.php?i=vW5u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462671174346874880",
  "text" : "http:\/\/t.co\/Jk2scTdmwV Emails: 372 Keywords: 0.0 #infoleak",
  "id" : 462671174346874880,
  "created_at" : "2014-05-03 19:12:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PI36Oevdbk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vfkPaWtE",
      "display_url" : "pastebin.com\/raw.php?i=vfkP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462669849974415360",
  "text" : "http:\/\/t.co\/PI36Oevdbk Keywords: 0.77 #infoleak",
  "id" : 462669849974415360,
  "created_at" : "2014-05-03 19:07:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q88zRcM6uw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wtAdnjHd",
      "display_url" : "pastebin.com\/raw.php?i=wtAd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462665457099501568",
  "text" : "http:\/\/t.co\/Q88zRcM6uw Emails: 4998 Keywords: 0.11 #infoleak",
  "id" : 462665457099501568,
  "created_at" : "2014-05-03 18:50:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jC6RMtjGSq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uVVwRzpq",
      "display_url" : "pastebin.com\/raw.php?i=uVVw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462657629936824321",
  "text" : "http:\/\/t.co\/jC6RMtjGSq Emails: 338 Keywords: 0.44 #infoleak",
  "id" : 462657629936824321,
  "created_at" : "2014-05-03 18:19:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e5jWBZ9AaI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fthspeHm",
      "display_url" : "pastebin.com\/raw.php?i=fths\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462656621718409216",
  "text" : "http:\/\/t.co\/e5jWBZ9AaI Emails: 27 Keywords: 0.11 #infoleak",
  "id" : 462656621718409216,
  "created_at" : "2014-05-03 18:15:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oCoduAwy5G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q5Bu3j5a",
      "display_url" : "pastebin.com\/raw.php?i=Q5Bu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462651949418938368",
  "text" : "http:\/\/t.co\/oCoduAwy5G Found possible Google API key(s) #infoleak",
  "id" : 462651949418938368,
  "created_at" : "2014-05-03 17:56:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jsoQGGU12i",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d9AmWeeZ",
      "display_url" : "pastebin.com\/raw.php?i=d9Am\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462641183403945984",
  "text" : "http:\/\/t.co\/jsoQGGU12i Emails: 194 Keywords: 0.0 #infoleak",
  "id" : 462641183403945984,
  "created_at" : "2014-05-03 17:13:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wse0NMCF6n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Bg0ff3j",
      "display_url" : "pastebin.com\/raw.php?i=7Bg0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462633093430407168",
  "text" : "http:\/\/t.co\/Wse0NMCF6n Emails: 34 Keywords: 0.11 #infoleak",
  "id" : 462633093430407168,
  "created_at" : "2014-05-03 16:41:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/idzFDvsZ52",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R4d9UmcF",
      "display_url" : "pastebin.com\/raw.php?i=R4d9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462630950749233154",
  "text" : "http:\/\/t.co\/idzFDvsZ52 Found possible Google API key(s) #infoleak",
  "id" : 462630950749233154,
  "created_at" : "2014-05-03 16:33:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o8YYrL2wtq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BM1WNxxa",
      "display_url" : "pastebin.com\/raw.php?i=BM1W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462610758421852161",
  "text" : "http:\/\/t.co\/o8YYrL2wtq Emails: 283 Keywords: 0.0 #infoleak",
  "id" : 462610758421852161,
  "created_at" : "2014-05-03 15:12:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nEeqG0DctH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sWTVZ3gm",
      "display_url" : "pastebin.com\/raw.php?i=sWTV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462606893660119041",
  "text" : "http:\/\/t.co\/nEeqG0DctH Emails: 2 Keywords: 0.77 #infoleak",
  "id" : 462606893660119041,
  "created_at" : "2014-05-03 14:57:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BV11WFBu0s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u4z627zW",
      "display_url" : "pastebin.com\/raw.php?i=u4z6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462605417781022720",
  "text" : "http:\/\/t.co\/BV11WFBu0s Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 462605417781022720,
  "created_at" : "2014-05-03 14:51:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BMhc5s9FMW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i7kN8twT",
      "display_url" : "pastebin.com\/raw.php?i=i7kN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462604943560417280",
  "text" : "http:\/\/t.co\/BMhc5s9FMW Emails: 26 Keywords: 0.22 #infoleak",
  "id" : 462604943560417280,
  "created_at" : "2014-05-03 14:49:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SYLFJXQm7u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NfeUEg4f",
      "display_url" : "pastebin.com\/raw.php?i=NfeU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462603896091717633",
  "text" : "http:\/\/t.co\/SYLFJXQm7u Found possible Google API key(s) #infoleak",
  "id" : 462603896091717633,
  "created_at" : "2014-05-03 14:45:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MHn5IV7NsZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z3j5UeD7",
      "display_url" : "pastebin.com\/raw.php?i=z3j5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462596272096964609",
  "text" : "http:\/\/t.co\/MHn5IV7NsZ Possible cisco configuration #infoleak",
  "id" : 462596272096964609,
  "created_at" : "2014-05-03 14:15:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5qw59rQ4YE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nZghAUvr",
      "display_url" : "pastebin.com\/raw.php?i=nZgh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462418250937020416",
  "text" : "http:\/\/t.co\/5qw59rQ4YE Emails: 493 Keywords: 0.0 #infoleak",
  "id" : 462418250937020416,
  "created_at" : "2014-05-03 02:27:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VCieVXJQFm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aZtrN9bm",
      "display_url" : "pastebin.com\/raw.php?i=aZtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462416956516085760",
  "text" : "http:\/\/t.co\/VCieVXJQFm Found possible Google API key(s) #infoleak",
  "id" : 462416956516085760,
  "created_at" : "2014-05-03 02:22:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a4HHYKqSI6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1bFNNa7y",
      "display_url" : "pastebin.com\/raw.php?i=1bFN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462415150343942145",
  "text" : "http:\/\/t.co\/a4HHYKqSI6 Emails: 9470 Keywords: 0.08 #infoleak",
  "id" : 462415150343942145,
  "created_at" : "2014-05-03 02:15:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ncDLfFxfRh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=STJAB4nh",
      "display_url" : "pastebin.com\/raw.php?i=STJA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462408747969548288",
  "text" : "http:\/\/t.co\/ncDLfFxfRh Emails: 500 Keywords: 0.0 #infoleak",
  "id" : 462408747969548288,
  "created_at" : "2014-05-03 01:50:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/udfsC6uCcc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WTTZuuNr",
      "display_url" : "pastebin.com\/raw.php?i=WTTZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462400415376502786",
  "text" : "http:\/\/t.co\/udfsC6uCcc Emails: 515 Keywords: 0.0 #infoleak",
  "id" : 462400415376502786,
  "created_at" : "2014-05-03 01:17:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rarE9VbvDf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TaGgYDmg",
      "display_url" : "pastebin.com\/raw.php?i=TaGg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462399365034696704",
  "text" : "http:\/\/t.co\/rarE9VbvDf Emails: 122 Keywords: 0.0 #infoleak",
  "id" : 462399365034696704,
  "created_at" : "2014-05-03 01:12:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9x1jsXIFj8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u5WB1GDf",
      "display_url" : "pastebin.com\/raw.php?i=u5WB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462391386042421249",
  "text" : "http:\/\/t.co\/9x1jsXIFj8 Keywords: 0.55 #infoleak",
  "id" : 462391386042421249,
  "created_at" : "2014-05-03 00:41:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1KvznLm27N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S76ba5x1",
      "display_url" : "pastebin.com\/raw.php?i=S76b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462390302087446528",
  "text" : "http:\/\/t.co\/1KvznLm27N Keywords: 0.55 #infoleak",
  "id" : 462390302087446528,
  "created_at" : "2014-05-03 00:36:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1yXDUo6RV4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YspCiB2L",
      "display_url" : "pastebin.com\/raw.php?i=YspC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462387290883383296",
  "text" : "http:\/\/t.co\/1yXDUo6RV4 Hashes: 499 Keywords: 0.11 #infoleak",
  "id" : 462387290883383296,
  "created_at" : "2014-05-03 00:24:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dmXd36a92M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ktmEemN9",
      "display_url" : "pastebin.com\/raw.php?i=ktmE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462387161153540096",
  "text" : "http:\/\/t.co\/dmXd36a92M Keywords: 0.55 #infoleak",
  "id" : 462387161153540096,
  "created_at" : "2014-05-03 00:24:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZzzdNMaevn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TVpi7mgf",
      "display_url" : "pastebin.com\/raw.php?i=TVpi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462386557349928960",
  "text" : "http:\/\/t.co\/ZzzdNMaevn Hashes: 75 Keywords: 0.33 #infoleak",
  "id" : 462386557349928960,
  "created_at" : "2014-05-03 00:22:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XmIFqxbfsf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1DvuWaug",
      "display_url" : "pastebin.com\/raw.php?i=1Dvu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462385038382747648",
  "text" : "http:\/\/t.co\/XmIFqxbfsf Emails: 422 Hashes: 846 E\/H: 0.5 Keywords: 0.08 #infoleak",
  "id" : 462385038382747648,
  "created_at" : "2014-05-03 00:15:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Smtdj77vJr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=44aR4L6f",
      "display_url" : "pastebin.com\/raw.php?i=44aR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462379395466805248",
  "text" : "http:\/\/t.co\/Smtdj77vJr Emails: 63 Hashes: 64 E\/H: 0.98 Keywords: 0.44 #infoleak",
  "id" : 462379395466805248,
  "created_at" : "2014-05-02 23:53:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hDABK6rTaT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q7CetE69",
      "display_url" : "pastebin.com\/raw.php?i=Q7Ce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462378513945747457",
  "text" : "http:\/\/t.co\/hDABK6rTaT Emails: 758 Hashes: 764 E\/H: 0.99 Keywords: 0.08 #infoleak",
  "id" : 462378513945747457,
  "created_at" : "2014-05-02 23:50:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DcQ0DiqPcE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T7KbuZ9i",
      "display_url" : "pastebin.com\/raw.php?i=T7Kb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462376046558318592",
  "text" : "http:\/\/t.co\/DcQ0DiqPcE Found possible Google API key(s) #infoleak",
  "id" : 462376046558318592,
  "created_at" : "2014-05-02 23:40:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ChI0Vuz7kJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bL9vA2fW",
      "display_url" : "pastebin.com\/raw.php?i=bL9v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462369728640450560",
  "text" : "http:\/\/t.co\/ChI0Vuz7kJ Emails: 27 Keywords: 0.11 #infoleak",
  "id" : 462369728640450560,
  "created_at" : "2014-05-02 23:15:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ueV2uCH1vn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TVd19cTG",
      "display_url" : "pastebin.com\/raw.php?i=TVd1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462369200040730624",
  "text" : "http:\/\/t.co\/ueV2uCH1vn Emails: 128 Keywords: 0.0 #infoleak",
  "id" : 462369200040730624,
  "created_at" : "2014-05-02 23:13:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CGzIcoRkFB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F5hEm6Kh",
      "display_url" : "pastebin.com\/raw.php?i=F5hE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462360467516575745",
  "text" : "http:\/\/t.co\/CGzIcoRkFB Emails: 127 Keywords: 0.0 #infoleak",
  "id" : 462360467516575745,
  "created_at" : "2014-05-02 22:38:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fgmiozZkve",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2afwF8n9",
      "display_url" : "pastebin.com\/raw.php?i=2afw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462348888532205568",
  "text" : "http:\/\/t.co\/fgmiozZkve Emails: 80 Keywords: 0.0 #infoleak",
  "id" : 462348888532205568,
  "created_at" : "2014-05-02 21:52:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WiNyy5rkQl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qAgpmUK2",
      "display_url" : "pastebin.com\/raw.php?i=qAgp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462348006642053121",
  "text" : "http:\/\/t.co\/WiNyy5rkQl Emails: 4999 Keywords: 0.08 #infoleak",
  "id" : 462348006642053121,
  "created_at" : "2014-05-02 21:48:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/muJZuFYO36",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e2EHwxh7",
      "display_url" : "pastebin.com\/raw.php?i=e2EH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462194834799747074",
  "text" : "http:\/\/t.co\/muJZuFYO36 Emails: 56 Keywords: 0.0 #infoleak",
  "id" : 462194834799747074,
  "created_at" : "2014-05-02 11:40:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ABSq5vWzdr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qA6EFB6z",
      "display_url" : "pastebin.com\/raw.php?i=qA6E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462188064773644289",
  "text" : "http:\/\/t.co\/ABSq5vWzdr Emails: 189 Keywords: 0.0 #infoleak",
  "id" : 462188064773644289,
  "created_at" : "2014-05-02 11:13:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2bpgfvTUPy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kcF2WrPN",
      "display_url" : "pastebin.com\/raw.php?i=kcF2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462173662578085888",
  "text" : "http:\/\/t.co\/2bpgfvTUPy Emails: 165 Keywords: 0.11 #infoleak",
  "id" : 462173662578085888,
  "created_at" : "2014-05-02 10:16:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Idxlr7c0ho",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dFawb9pv",
      "display_url" : "pastebin.com\/raw.php?i=dFaw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462157771593359361",
  "text" : "http:\/\/t.co\/Idxlr7c0ho Emails: 190 Keywords: 0.0 #infoleak",
  "id" : 462157771593359361,
  "created_at" : "2014-05-02 09:12:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OzFdBAyEmZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nnMEAdhT",
      "display_url" : "pastebin.com\/raw.php?i=nnME\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462155313907384321",
  "text" : "http:\/\/t.co\/OzFdBAyEmZ Emails: 11 Keywords: 0.63 #infoleak",
  "id" : 462155313907384321,
  "created_at" : "2014-05-02 09:03:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ksSEobhwYA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LPXZDVgj",
      "display_url" : "pastebin.com\/raw.php?i=LPXZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462131373029859328",
  "text" : "http:\/\/t.co\/ksSEobhwYA Emails: 304 Keywords: 0.55 #infoleak",
  "id" : 462131373029859328,
  "created_at" : "2014-05-02 07:27:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fMCLmxrwCa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qdgMw7jN",
      "display_url" : "pastebin.com\/raw.php?i=qdgM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462129732465598464",
  "text" : "http:\/\/t.co\/fMCLmxrwCa Emails: 1002 Hashes: 1208 E\/H: 0.83 Keywords: 0.3 #infoleak",
  "id" : 462129732465598464,
  "created_at" : "2014-05-02 07:21:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bThcb1Ff7E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qFVsxH3h",
      "display_url" : "pastebin.com\/raw.php?i=qFVs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462127557815435264",
  "text" : "http:\/\/t.co\/bThcb1Ff7E Emails: 132 Keywords: 0.0 #infoleak",
  "id" : 462127557815435264,
  "created_at" : "2014-05-02 07:12:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8UYe6USn35",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uEWt10vH",
      "display_url" : "pastebin.com\/raw.php?i=uEWt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462124159758135296",
  "text" : "http:\/\/t.co\/8UYe6USn35 Emails: 851 Keywords: 0.11 #infoleak",
  "id" : 462124159758135296,
  "created_at" : "2014-05-02 06:59:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KNUgL4pngH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d9BQR2PR",
      "display_url" : "pastebin.com\/raw.php?i=d9BQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462122360867266561",
  "text" : "http:\/\/t.co\/KNUgL4pngH Emails: 2489 Keywords: 0.11 #infoleak",
  "id" : 462122360867266561,
  "created_at" : "2014-05-02 06:52:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zTmWj6f5hs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=j7sUPUbM",
      "display_url" : "pastebin.com\/raw.php?i=j7sU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462103847775641600",
  "text" : "http:\/\/t.co\/zTmWj6f5hs Hashes: 4113 Keywords: 0.11 #infoleak",
  "id" : 462103847775641600,
  "created_at" : "2014-05-02 05:38:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4VgmkbFEgB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6iSBuGMH",
      "display_url" : "pastebin.com\/raw.php?i=6iSB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462102565543350272",
  "text" : "http:\/\/t.co\/4VgmkbFEgB Emails: 38 Hashes: 1 E\/H: 38.0 Keywords: 0.33 #infoleak",
  "id" : 462102565543350272,
  "created_at" : "2014-05-02 05:33:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KJCWKwz9e8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n4XtXnjU",
      "display_url" : "pastebin.com\/raw.php?i=n4Xt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462100631067447296",
  "text" : "http:\/\/t.co\/KJCWKwz9e8 Emails: 378 Keywords: 0.22 #infoleak",
  "id" : 462100631067447296,
  "created_at" : "2014-05-02 05:25:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AXGdTjNKsL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dv4ryHcw",
      "display_url" : "pastebin.com\/raw.php?i=dv4r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462097349905362945",
  "text" : "http:\/\/t.co\/AXGdTjNKsL Emails: 247 Keywords: 0.0 #infoleak",
  "id" : 462097349905362945,
  "created_at" : "2014-05-02 05:12:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V5ZkWqUOIW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5V7RsUke",
      "display_url" : "pastebin.com\/raw.php?i=5V7R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462093724206379008",
  "text" : "http:\/\/t.co\/V5ZkWqUOIW Emails: 690 Hashes: 693 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 462093724206379008,
  "created_at" : "2014-05-02 04:58:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6F8leizK7z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SBma0RTG",
      "display_url" : "pastebin.com\/raw.php?i=SBma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462093306554359808",
  "text" : "http:\/\/t.co\/6F8leizK7z Emails: 4016 Hashes: 4113 E\/H: 0.98 Keywords: 0.3 #infoleak",
  "id" : 462093306554359808,
  "created_at" : "2014-05-02 04:56:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RoFSsWZDSk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jt19CecU",
      "display_url" : "pastebin.com\/raw.php?i=Jt19\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462089080134594560",
  "text" : "http:\/\/t.co\/RoFSsWZDSk Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 462089080134594560,
  "created_at" : "2014-05-02 04:39:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mtYJwHRUzC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EQbsDVdt",
      "display_url" : "pastebin.com\/raw.php?i=EQbs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462076193378799617",
  "text" : "http:\/\/t.co\/mtYJwHRUzC Emails: 230 Keywords: 0.11 #infoleak",
  "id" : 462076193378799617,
  "created_at" : "2014-05-02 03:48:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vwC4LgR2xm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z2Y9VGc2",
      "display_url" : "pastebin.com\/raw.php?i=z2Y9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462070515041972224",
  "text" : "http:\/\/t.co\/vwC4LgR2xm Emails: 431 Keywords: 0.11 #infoleak",
  "id" : 462070515041972224,
  "created_at" : "2014-05-02 03:26:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fJZGVb9ANv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FWmZV4Pr",
      "display_url" : "pastebin.com\/raw.php?i=FWmZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462067186303893504",
  "text" : "http:\/\/t.co\/fJZGVb9ANv Emails: 241 Keywords: 0.0 #infoleak",
  "id" : 462067186303893504,
  "created_at" : "2014-05-02 03:12:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eyB7tEA5jO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3iUgKrij",
      "display_url" : "pastebin.com\/raw.php?i=3iUg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462054704025853952",
  "text" : "http:\/\/t.co\/eyB7tEA5jO Emails: 57 Keywords: 0.33 #infoleak",
  "id" : 462054704025853952,
  "created_at" : "2014-05-02 02:23:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WDjjJxZOvU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iAQ9TaF1",
      "display_url" : "pastebin.com\/raw.php?i=iAQ9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462052859165409280",
  "text" : "http:\/\/t.co\/WDjjJxZOvU Emails: 551 Keywords: 0.0 #infoleak",
  "id" : 462052859165409280,
  "created_at" : "2014-05-02 02:16:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UFNiKkuYLv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VFpaRcPU",
      "display_url" : "pastebin.com\/raw.php?i=VFpa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462051542476914688",
  "text" : "http:\/\/t.co\/UFNiKkuYLv Emails: 495 Keywords: 0.0 #infoleak",
  "id" : 462051542476914688,
  "created_at" : "2014-05-02 02:10:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pO0tcdxM3A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LbYgthbx",
      "display_url" : "pastebin.com\/raw.php?i=LbYg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462043472556335104",
  "text" : "http:\/\/t.co\/pO0tcdxM3A Found possible Google API key(s) #infoleak",
  "id" : 462043472556335104,
  "created_at" : "2014-05-02 01:38:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mbcqC3RVaQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SdSmudri",
      "display_url" : "pastebin.com\/raw.php?i=SdSm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462039601620611072",
  "text" : "http:\/\/t.co\/mbcqC3RVaQ Hashes: 425 Keywords: 0.0 #infoleak",
  "id" : 462039601620611072,
  "created_at" : "2014-05-02 01:23:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4Fs8NPpWN2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LRwBqkVJ",
      "display_url" : "pastebin.com\/raw.php?i=LRwB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462024898576007168",
  "text" : "http:\/\/t.co\/4Fs8NPpWN2 Emails: 1244 Hashes: 10 E\/H: 124.4 Keywords: 0.22 #infoleak",
  "id" : 462024898576007168,
  "created_at" : "2014-05-02 00:24:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MTPDmIrn9N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p4C4kYLJ",
      "display_url" : "pastebin.com\/raw.php?i=p4C4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462021769709105152",
  "text" : "http:\/\/t.co\/MTPDmIrn9N Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 462021769709105152,
  "created_at" : "2014-05-02 00:12:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JClGD2UW6A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eH8PutqQ",
      "display_url" : "pastebin.com\/raw.php?i=eH8P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462006817111822337",
  "text" : "http:\/\/t.co\/JClGD2UW6A Emails: 215 Keywords: 0.0 #infoleak",
  "id" : 462006817111822337,
  "created_at" : "2014-05-01 23:13:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Rl2b0Xh6ZA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AmrQuz7g",
      "display_url" : "pastebin.com\/raw.php?i=AmrQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462002835467407360",
  "text" : "http:\/\/t.co\/Rl2b0Xh6ZA Possible cisco configuration #infoleak",
  "id" : 462002835467407360,
  "created_at" : "2014-05-01 22:57:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Co3jhiWJ0K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ibvKD7ER",
      "display_url" : "pastebin.com\/raw.php?i=ibvK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462002416120897536",
  "text" : "http:\/\/t.co\/Co3jhiWJ0K Emails: 62 Hashes: 27 E\/H: 2.3 Keywords: 0.33 #infoleak",
  "id" : 462002416120897536,
  "created_at" : "2014-05-01 22:55:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nMgsdZuGLi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZMzmWchX",
      "display_url" : "pastebin.com\/raw.php?i=ZMzm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461976642399657984",
  "text" : "http:\/\/t.co\/nMgsdZuGLi Emails: 149 Keywords: 0.0 #infoleak",
  "id" : 461976642399657984,
  "created_at" : "2014-05-01 21:13:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OoVSzgWkOx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nVr8c8Bu",
      "display_url" : "pastebin.com\/raw.php?i=nVr8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461963882102140928",
  "text" : "http:\/\/t.co\/OoVSzgWkOx Emails: 218 Hashes: 308 E\/H: 0.71 Keywords: -0.03 #infoleak",
  "id" : 461963882102140928,
  "created_at" : "2014-05-01 20:22:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J32bKeVOP2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EhG2jM8f",
      "display_url" : "pastebin.com\/raw.php?i=EhG2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461962919664553984",
  "text" : "http:\/\/t.co\/J32bKeVOP2 Emails: 2969 Hashes: 2960 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 461962919664553984,
  "created_at" : "2014-05-01 20:18:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jr4o6bFuVL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wk7yDHua",
      "display_url" : "pastebin.com\/raw.php?i=wk7y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461962355782348801",
  "text" : "http:\/\/t.co\/jr4o6bFuVL Emails: 24 Keywords: -0.14 #infoleak",
  "id" : 461962355782348801,
  "created_at" : "2014-05-01 20:16:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kxr5leCkGp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=00tr0XMT",
      "display_url" : "pastebin.com\/raw.php?i=00tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461867125754183682",
  "text" : "http:\/\/t.co\/Kxr5leCkGp Emails: 105 Keywords: 0.22 #infoleak",
  "id" : 461867125754183682,
  "created_at" : "2014-05-01 13:57:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N52Dr2yhEh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Lujs7Tdz",
      "display_url" : "pastebin.com\/raw.php?i=Lujs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461865308433555456",
  "text" : "http:\/\/t.co\/N52Dr2yhEh Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 461865308433555456,
  "created_at" : "2014-05-01 13:50:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5RZFk29NOu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xjcEyV79",
      "display_url" : "pastebin.com\/raw.php?i=xjcE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461861769074315264",
  "text" : "http:\/\/t.co\/5RZFk29NOu Emails: 478 Keywords: 0.11 #infoleak",
  "id" : 461861769074315264,
  "created_at" : "2014-05-01 13:36:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DS8C3QHa3Q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=srRTFikW",
      "display_url" : "pastebin.com\/raw.php?i=srRT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461860515916959744",
  "text" : "http:\/\/t.co\/DS8C3QHa3Q Emails: 335 Keywords: 0.11 #infoleak",
  "id" : 461860515916959744,
  "created_at" : "2014-05-01 13:31:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZUqXGhGmBj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9dHYgCK5",
      "display_url" : "pastebin.com\/raw.php?i=9dHY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461847279129743361",
  "text" : "http:\/\/t.co\/ZUqXGhGmBj Keywords: 0.66 #infoleak",
  "id" : 461847279129743361,
  "created_at" : "2014-05-01 12:39:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8fZngfYcs9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ETgvSg6F",
      "display_url" : "pastebin.com\/raw.php?i=ETgv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461844033703120896",
  "text" : "http:\/\/t.co\/8fZngfYcs9 Emails: 61 Keywords: 0.0 #infoleak",
  "id" : 461844033703120896,
  "created_at" : "2014-05-01 12:26:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UnPnbInhvI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2Msdu7w0",
      "display_url" : "pastebin.com\/raw.php?i=2Msd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461836534820241408",
  "text" : "http:\/\/t.co\/UnPnbInhvI Emails: 42 Keywords: 0.11 #infoleak",
  "id" : 461836534820241408,
  "created_at" : "2014-05-01 11:56:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PebSH8izwV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ycBjWLRi",
      "display_url" : "pastebin.com\/raw.php?i=ycBj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461835002481635328",
  "text" : "http:\/\/t.co\/PebSH8izwV Hashes: 48 Keywords: 0.08 #infoleak",
  "id" : 461835002481635328,
  "created_at" : "2014-05-01 11:50:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Dw2VYYS3DJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kKmwQ0wU",
      "display_url" : "pastebin.com\/raw.php?i=kKmw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461821352752578561",
  "text" : "http:\/\/t.co\/Dw2VYYS3DJ Hashes: 96 Keywords: 0.08 #infoleak",
  "id" : 461821352752578561,
  "created_at" : "2014-05-01 10:56:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fkcdBRNl8R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uaVQc2Bk",
      "display_url" : "pastebin.com\/raw.php?i=uaVQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461806663478312960",
  "text" : "http:\/\/t.co\/fkcdBRNl8R Keywords: 0.55 #infoleak",
  "id" : 461806663478312960,
  "created_at" : "2014-05-01 09:57:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sW3XGcLCF7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QZjuBLjf",
      "display_url" : "pastebin.com\/raw.php?i=QZju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461803312505819136",
  "text" : "http:\/\/t.co\/sW3XGcLCF7 Hashes: 562 Keywords: 0.11 #infoleak",
  "id" : 461803312505819136,
  "created_at" : "2014-05-01 09:44:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vgf9GEuukF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tk5yKWiM",
      "display_url" : "pastebin.com\/raw.php?i=tk5y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461798902828507137",
  "text" : "http:\/\/t.co\/vgf9GEuukF Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 461798902828507137,
  "created_at" : "2014-05-01 09:26:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/STzT9DK5fk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W6QeXMp1",
      "display_url" : "pastebin.com\/raw.php?i=W6Qe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461795447615393792",
  "text" : "http:\/\/t.co\/STzT9DK5fk Emails: 365 Keywords: 0.0 #infoleak",
  "id" : 461795447615393792,
  "created_at" : "2014-05-01 09:13:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8eeitOlPun",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T9DUaW00",
      "display_url" : "pastebin.com\/raw.php?i=T9DU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461784186118893568",
  "text" : "http:\/\/t.co\/8eeitOlPun Hashes: 67 Keywords: 0.33 #infoleak",
  "id" : 461784186118893568,
  "created_at" : "2014-05-01 08:28:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
} ]
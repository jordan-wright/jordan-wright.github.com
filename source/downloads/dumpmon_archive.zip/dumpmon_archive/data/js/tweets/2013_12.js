Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W5jWHKIw3X",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m6kwg2tz",
      "display_url" : "pastebin.com\/raw.php?i=m6kw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418290420167094273",
  "text" : "http:\/\/t.co\/W5jWHKIw3X Keywords: 0.55 #infoleak",
  "id" : 418290420167094273,
  "created_at" : "2014-01-01 07:59:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uvu1oyViAI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1Mt7PbNt",
      "display_url" : "pastebin.com\/raw.php?i=1Mt7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418285362008444928",
  "text" : "http:\/\/t.co\/uvu1oyViAI Emails: 42 Keywords: 0.19 #infoleak",
  "id" : 418285362008444928,
  "created_at" : "2014-01-01 07:39:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nduY0IyZ0d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DqeMEVzy",
      "display_url" : "pastebin.com\/raw.php?i=DqeM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418249768704294912",
  "text" : "http:\/\/t.co\/nduY0IyZ0d Found possible Google API key(s) #infoleak",
  "id" : 418249768704294912,
  "created_at" : "2014-01-01 05:18:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w2UGgbzXpB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AZrgaHDT",
      "display_url" : "pastebin.com\/raw.php?i=AZrg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418239064978894848",
  "text" : "http:\/\/t.co\/w2UGgbzXpB Found possible Google API key(s) #infoleak",
  "id" : 418239064978894848,
  "created_at" : "2014-01-01 04:35:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6rgQeXe52P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ep2AbcNz",
      "display_url" : "pastebin.com\/raw.php?i=Ep2A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418174325334630401",
  "text" : "http:\/\/t.co\/6rgQeXe52P Emails: 30 Keywords: 0.08 #infoleak",
  "id" : 418174325334630401,
  "created_at" : "2014-01-01 00:18:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/clRPyayTxl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=01GR8jyH",
      "display_url" : "pastebin.com\/raw.php?i=01GR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418169805846228994",
  "text" : "http:\/\/t.co\/clRPyayTxl Emails: 281 Keywords: 0.33 #infoleak",
  "id" : 418169805846228994,
  "created_at" : "2014-01-01 00:00:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gOaNEq7guT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2e12JpLt",
      "display_url" : "pastebin.com\/raw.php?i=2e12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418167184007761920",
  "text" : "http:\/\/t.co\/gOaNEq7guT Emails: 42 Hashes: 15 E\/H: 2.8 Keywords: 0.44 #infoleak",
  "id" : 418167184007761920,
  "created_at" : "2013-12-31 23:50:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z7Iez0DhaG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CUZpScqG",
      "display_url" : "pastebin.com\/raw.php?i=CUZp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418154879685636097",
  "text" : "http:\/\/t.co\/z7Iez0DhaG Emails: 663 Keywords: 0.22 #infoleak",
  "id" : 418154879685636097,
  "created_at" : "2013-12-31 23:01:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/j79LA4wxwW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b7vHYM2m",
      "display_url" : "pastebin.com\/raw.php?i=b7vH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418148796208406528",
  "text" : "http:\/\/t.co\/j79LA4wxwW Emails: 188 Keywords: 0.11 #infoleak",
  "id" : 418148796208406528,
  "created_at" : "2013-12-31 22:36:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dTJV1X3USq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zrXmbGEq",
      "display_url" : "pastebin.com\/raw.php?i=zrXm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418141017775173632",
  "text" : "http:\/\/t.co\/dTJV1X3USq Emails: 616 Hashes: 583 E\/H: 1.06 Keywords: 0.22 #infoleak",
  "id" : 418141017775173632,
  "created_at" : "2013-12-31 22:06:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ejacrug7J6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sTAZLaQv",
      "display_url" : "pastebin.com\/raw.php?i=sTAZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418134080404742144",
  "text" : "http:\/\/t.co\/ejacrug7J6 Emails: 188 Hashes: 267 E\/H: 0.7 Keywords: 0.0 #infoleak",
  "id" : 418134080404742144,
  "created_at" : "2013-12-31 21:38:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uyy1boy6am",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TB3HnRbK",
      "display_url" : "pastebin.com\/raw.php?i=TB3H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418127132338839552",
  "text" : "http:\/\/t.co\/uyy1boy6am Keywords: 0.55 #infoleak",
  "id" : 418127132338839552,
  "created_at" : "2013-12-31 21:10:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fQGmG81xYX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3jXUCFRz",
      "display_url" : "pastebin.com\/raw.php?i=3jXU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418125933413818369",
  "text" : "http:\/\/t.co\/fQGmG81xYX Emails: 131 Keywords: 0.19 #infoleak",
  "id" : 418125933413818369,
  "created_at" : "2013-12-31 21:06:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5D4Iut9GVk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qwnWHTCh",
      "display_url" : "pastebin.com\/raw.php?i=qwnW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418111939961577472",
  "text" : "http:\/\/t.co\/5D4Iut9GVk Hashes: 620 Keywords: 0.19 #infoleak",
  "id" : 418111939961577472,
  "created_at" : "2013-12-31 20:10:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mybN7zfebS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G50KQVAv",
      "display_url" : "pastebin.com\/raw.php?i=G50K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418102470569504768",
  "text" : "http:\/\/t.co\/mybN7zfebS Emails: 150 Hashes: 155 E\/H: 0.97 Keywords: 0.11 #infoleak",
  "id" : 418102470569504768,
  "created_at" : "2013-12-31 19:32:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F4JS6hZngN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gcAGy0ug",
      "display_url" : "pastebin.com\/raw.php?i=gcAG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418097444644069377",
  "text" : "http:\/\/t.co\/F4JS6hZngN Emails: 171 Keywords: 0.11 #infoleak",
  "id" : 418097444644069377,
  "created_at" : "2013-12-31 19:12:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U9wMMBVwvz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D95JVU7Z",
      "display_url" : "pastebin.com\/raw.php?i=D95J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418092556107259904",
  "text" : "http:\/\/t.co\/U9wMMBVwvz Emails: 129 Hashes: 141 E\/H: 0.91 Keywords: 0.22 #infoleak",
  "id" : 418092556107259904,
  "created_at" : "2013-12-31 18:53:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q4ylvnDsiN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tZub7x7V",
      "display_url" : "pastebin.com\/raw.php?i=tZub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418089004207067136",
  "text" : "http:\/\/t.co\/q4ylvnDsiN Hashes: 522 Keywords: -0.17 #infoleak",
  "id" : 418089004207067136,
  "created_at" : "2013-12-31 18:39:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f0BoQBX9Mz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JiYupVsg",
      "display_url" : "pastebin.com\/raw.php?i=JiYu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418088809704603648",
  "text" : "http:\/\/t.co\/f0BoQBX9Mz Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 418088809704603648,
  "created_at" : "2013-12-31 18:38:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Md3cHfyEZW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i9Zi65Yq",
      "display_url" : "pastebin.com\/raw.php?i=i9Zi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418087517573750784",
  "text" : "http:\/\/t.co\/Md3cHfyEZW Emails: 170 Keywords: 0.0 #infoleak",
  "id" : 418087517573750784,
  "created_at" : "2013-12-31 18:33:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1dJkLYIbz3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QneczCNN",
      "display_url" : "pastebin.com\/raw.php?i=Qnec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418086245680422913",
  "text" : "http:\/\/t.co\/1dJkLYIbz3 Emails: 150 Hashes: 155 E\/H: 0.97 Keywords: 0.11 #infoleak",
  "id" : 418086245680422913,
  "created_at" : "2013-12-31 18:28:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zb9Xojkc9E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CYbaWZRB",
      "display_url" : "pastebin.com\/raw.php?i=CYba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418083214419169280",
  "text" : "http:\/\/t.co\/Zb9Xojkc9E Emails: 331 Hashes: 201 E\/H: 1.65 Keywords: 0.22 #infoleak",
  "id" : 418083214419169280,
  "created_at" : "2013-12-31 18:16:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DVYb0uiOTJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mGt7yzKa",
      "display_url" : "pastebin.com\/raw.php?i=mGt7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418082002420498432",
  "text" : "http:\/\/t.co\/DVYb0uiOTJ Possible cisco configuration #infoleak",
  "id" : 418082002420498432,
  "created_at" : "2013-12-31 18:11:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Uyhra5msnA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zxN63rv1",
      "display_url" : "pastebin.com\/raw.php?i=zxN6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418069575347871746",
  "text" : "http:\/\/t.co\/Uyhra5msnA Emails: 3175 Hashes: 3683 E\/H: 0.86 Keywords: 0.22 #infoleak",
  "id" : 418069575347871746,
  "created_at" : "2013-12-31 17:22:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7Ia2ESiHvq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N2YBaP2m",
      "display_url" : "pastebin.com\/raw.php?i=N2YB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418059809468858368",
  "text" : "http:\/\/t.co\/7Ia2ESiHvq Emails: 197 Keywords: 0.22 #infoleak",
  "id" : 418059809468858368,
  "created_at" : "2013-12-31 16:43:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qqHkPONK37",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8zWeh0Jm",
      "display_url" : "pastebin.com\/raw.php?i=8zWe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418058901540438016",
  "text" : "http:\/\/t.co\/qqHkPONK37 Hashes: 77 Keywords: 0.08 #infoleak",
  "id" : 418058901540438016,
  "created_at" : "2013-12-31 16:39:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yAHSdHsD6N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Nn3NQxkL",
      "display_url" : "pastebin.com\/raw.php?i=Nn3N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418058809911689216",
  "text" : "http:\/\/t.co\/yAHSdHsD6N Emails: 117 Keywords: 0.0 #infoleak",
  "id" : 418058809911689216,
  "created_at" : "2013-12-31 16:39:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/62aje86KbW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6hdz93zg",
      "display_url" : "pastebin.com\/raw.php?i=6hdz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418053180518199296",
  "text" : "http:\/\/t.co\/62aje86KbW Hashes: 72 Keywords: 0.11 #infoleak",
  "id" : 418053180518199296,
  "created_at" : "2013-12-31 16:16:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/h4bEvXcjyK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FUQstmkF",
      "display_url" : "pastebin.com\/raw.php?i=FUQs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418046435926351872",
  "text" : "http:\/\/t.co\/h4bEvXcjyK Emails: 365 Hashes: 373 E\/H: 0.98 Keywords: 0.22 #infoleak",
  "id" : 418046435926351872,
  "created_at" : "2013-12-31 15:50:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O4bMbtSrDn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=epGgY4vY",
      "display_url" : "pastebin.com\/raw.php?i=epGg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418043815513972736",
  "text" : "http:\/\/t.co\/O4bMbtSrDn Found possible Google API key(s) #infoleak",
  "id" : 418043815513972736,
  "created_at" : "2013-12-31 15:39:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5GbbByu3To",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4qBAVrjy",
      "display_url" : "pastebin.com\/raw.php?i=4qBA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418043075596791808",
  "text" : "http:\/\/t.co\/5GbbByu3To Emails: 32 Hashes: 4 E\/H: 8.0 Keywords: 0.3 #infoleak",
  "id" : 418043075596791808,
  "created_at" : "2013-12-31 15:36:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DSQsjzTQIi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=V0kkfMLV",
      "display_url" : "pastebin.com\/raw.php?i=V0kk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418030646066302976",
  "text" : "http:\/\/t.co\/DSQsjzTQIi Emails: 1159 Hashes: 1285 E\/H: 0.9 Keywords: 0.22 #infoleak",
  "id" : 418030646066302976,
  "created_at" : "2013-12-31 14:47:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FE3iQzCgiP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NAwzajGZ",
      "display_url" : "pastebin.com\/raw.php?i=NAwz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418026905116241920",
  "text" : "http:\/\/t.co\/FE3iQzCgiP Emails: 160 Keywords: 0.0 #infoleak",
  "id" : 418026905116241920,
  "created_at" : "2013-12-31 14:32:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zdBpmzK817",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hJanfuQi",
      "display_url" : "pastebin.com\/raw.php?i=hJan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418024928063918081",
  "text" : "http:\/\/t.co\/zdBpmzK817 Emails: 160 Keywords: 0.0 #infoleak",
  "id" : 418024928063918081,
  "created_at" : "2013-12-31 14:24:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cNOykgXlGD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Whhy21B2",
      "display_url" : "pastebin.com\/raw.php?i=Whhy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418020032912715776",
  "text" : "http:\/\/t.co\/cNOykgXlGD Emails: 67 Keywords: 0.22 #infoleak",
  "id" : 418020032912715776,
  "created_at" : "2013-12-31 14:05:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SXPrVNur3j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NHf0v6wn",
      "display_url" : "pastebin.com\/raw.php?i=NHf0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418019989770080257",
  "text" : "http:\/\/t.co\/SXPrVNur3j Emails: 111 Keywords: 0.0 #infoleak",
  "id" : 418019989770080257,
  "created_at" : "2013-12-31 14:05:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FKcPwDKDvI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HngJZtXX",
      "display_url" : "pastebin.com\/raw.php?i=HngJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418019371512909824",
  "text" : "http:\/\/t.co\/FKcPwDKDvI Emails: 25 Keywords: -0.14 #infoleak",
  "id" : 418019371512909824,
  "created_at" : "2013-12-31 14:02:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vyyhp3ZI5O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hC8nZyEg",
      "display_url" : "pastebin.com\/raw.php?i=hC8n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418019005526319105",
  "text" : "http:\/\/t.co\/vyyhp3ZI5O Emails: 2458 Keywords: -0.03 #infoleak",
  "id" : 418019005526319105,
  "created_at" : "2013-12-31 14:01:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/co2GfOEqqm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g7mh8dVt",
      "display_url" : "pastebin.com\/raw.php?i=g7mh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418016491607318528",
  "text" : "http:\/\/t.co\/co2GfOEqqm Emails: 1159 Hashes: 1285 E\/H: 0.9 Keywords: 0.11 #infoleak",
  "id" : 418016491607318528,
  "created_at" : "2013-12-31 13:51:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rMU0UzMnHf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gfr1wR7m",
      "display_url" : "pastebin.com\/raw.php?i=gfr1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418015648946475011",
  "text" : "http:\/\/t.co\/rMU0UzMnHf Emails: 2599 Keywords: -0.03 #infoleak",
  "id" : 418015648946475011,
  "created_at" : "2013-12-31 13:47:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZwNcdzg6PA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ubu6sBtc",
      "display_url" : "pastebin.com\/raw.php?i=Ubu6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418012863249141760",
  "text" : "http:\/\/t.co\/ZwNcdzg6PA Found possible Google API key(s) #infoleak",
  "id" : 418012863249141760,
  "created_at" : "2013-12-31 13:36:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bGc2Nc2VvE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nNUCbRv3",
      "display_url" : "pastebin.com\/raw.php?i=nNUC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418010156727693312",
  "text" : "http:\/\/t.co\/bGc2Nc2VvE Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 418010156727693312,
  "created_at" : "2013-12-31 13:26:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/btH8Y2h9l7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gk7D8bwi",
      "display_url" : "pastebin.com\/raw.php?i=gk7D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418009854502903808",
  "text" : "http:\/\/t.co\/btH8Y2h9l7 Emails: 51 Keywords: 0.11 #infoleak",
  "id" : 418009854502903808,
  "created_at" : "2013-12-31 13:24:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zOZNsfcvvG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HpqAmDce",
      "display_url" : "pastebin.com\/raw.php?i=HpqA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418007485752946688",
  "text" : "http:\/\/t.co\/zOZNsfcvvG Emails: 7 Hashes: 651 E\/H: 0.01 Keywords: -0.09 #infoleak",
  "id" : 418007485752946688,
  "created_at" : "2013-12-31 13:15:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/me3cdYz3Rs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Va4Gb3a4",
      "display_url" : "pastebin.com\/raw.php?i=Va4G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418002594221391872",
  "text" : "http:\/\/t.co\/me3cdYz3Rs Emails: 42 Keywords: 0.0 #infoleak",
  "id" : 418002594221391872,
  "created_at" : "2013-12-31 12:55:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NOTzNFv5mv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tKc1M66L",
      "display_url" : "pastebin.com\/raw.php?i=tKc1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418001412774060033",
  "text" : "http:\/\/t.co\/NOTzNFv5mv Emails: 4090 Hashes: 4808 E\/H: 0.85 Keywords: 0.11 #infoleak",
  "id" : 418001412774060033,
  "created_at" : "2013-12-31 12:51:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g8vJJx168M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dpf2R3Hm",
      "display_url" : "pastebin.com\/raw.php?i=dpf2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417997895246180352",
  "text" : "http:\/\/t.co\/g8vJJx168M Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 417997895246180352,
  "created_at" : "2013-12-31 12:37:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ktNx8mExZS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3hVgRVkz",
      "display_url" : "pastebin.com\/raw.php?i=3hVg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417986300755468288",
  "text" : "http:\/\/t.co\/ktNx8mExZS Emails: 2446 Keywords: -0.03 #infoleak",
  "id" : 417986300755468288,
  "created_at" : "2013-12-31 11:51:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8hXa8DuhIG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UFQwLkTw",
      "display_url" : "pastebin.com\/raw.php?i=UFQw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417971745178415104",
  "text" : "http:\/\/t.co\/8hXa8DuhIG Emails: 2599 Keywords: -0.03 #infoleak",
  "id" : 417971745178415104,
  "created_at" : "2013-12-31 10:53:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wBP0wOCTSc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5RqGzqsX",
      "display_url" : "pastebin.com\/raw.php?i=5RqG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417970136096600064",
  "text" : "http:\/\/t.co\/wBP0wOCTSc Hashes: 129 Keywords: 0.19 #infoleak",
  "id" : 417970136096600064,
  "created_at" : "2013-12-31 10:47:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/byfw9xTOtq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YQejqHLj",
      "display_url" : "pastebin.com\/raw.php?i=YQej\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417963533490335744",
  "text" : "http:\/\/t.co\/byfw9xTOtq Hashes: 88 Keywords: -0.03 #infoleak",
  "id" : 417963533490335744,
  "created_at" : "2013-12-31 10:20:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5kt5jxJyX0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=akv1XfT6",
      "display_url" : "pastebin.com\/raw.php?i=akv1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417930996177059840",
  "text" : "http:\/\/t.co\/5kt5jxJyX0 Emails: 176 Keywords: 0.11 #infoleak",
  "id" : 417930996177059840,
  "created_at" : "2013-12-31 08:11:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WcombmhsuE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q0cbadE8",
      "display_url" : "pastebin.com\/raw.php?i=Q0cb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417910813999898624",
  "text" : "http:\/\/t.co\/WcombmhsuE Emails: 1141 Keywords: 0.22 #infoleak",
  "id" : 417910813999898624,
  "created_at" : "2013-12-31 06:51:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mmJFOFIACB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mf9r3F77",
      "display_url" : "pastebin.com\/raw.php?i=mf9r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417910600107167744",
  "text" : "http:\/\/t.co\/mmJFOFIACB Emails: 377 Hashes: 421 E\/H: 0.9 Keywords: 0.0 #infoleak",
  "id" : 417910600107167744,
  "created_at" : "2013-12-31 06:50:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6FIEEc296M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xNcYm55D",
      "display_url" : "pastebin.com\/raw.php?i=xNcY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417909813775847424",
  "text" : "http:\/\/t.co\/6FIEEc296M Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 417909813775847424,
  "created_at" : "2013-12-31 06:47:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xEuCF931bO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=92K5GMhL",
      "display_url" : "pastebin.com\/raw.php?i=92K5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417908555526590464",
  "text" : "http:\/\/t.co\/xEuCF931bO Emails: 4449 Keywords: 0.22 #infoleak",
  "id" : 417908555526590464,
  "created_at" : "2013-12-31 06:42:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QxHgtcsJdC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BWx6UvQu",
      "display_url" : "pastebin.com\/raw.php?i=BWx6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417907793446727680",
  "text" : "http:\/\/t.co\/QxHgtcsJdC Emails: 150 Hashes: 155 E\/H: 0.97 Keywords: 0.11 #infoleak",
  "id" : 417907793446727680,
  "created_at" : "2013-12-31 06:39:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/z1vFE1HOTp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0TQzZAeD",
      "display_url" : "pastebin.com\/raw.php?i=0TQz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417907415993311232",
  "text" : "http:\/\/t.co\/z1vFE1HOTp Emails: 8390 Keywords: 0.22 #infoleak",
  "id" : 417907415993311232,
  "created_at" : "2013-12-31 06:37:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uMpNBYEDKq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hKdC7rY7",
      "display_url" : "pastebin.com\/raw.php?i=hKdC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417907039222759424",
  "text" : "http:\/\/t.co\/uMpNBYEDKq Emails: 10 Hashes: 126 E\/H: 0.08 Keywords: 0.11 #infoleak",
  "id" : 417907039222759424,
  "created_at" : "2013-12-31 06:36:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zNp74PmOuw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VhbwTqTi",
      "display_url" : "pastebin.com\/raw.php?i=Vhbw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417905833519767552",
  "text" : "http:\/\/t.co\/zNp74PmOuw Emails: 8762 Keywords: -0.03 #infoleak",
  "id" : 417905833519767552,
  "created_at" : "2013-12-31 06:31:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n43lEOmD05",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9stx3QDf",
      "display_url" : "pastebin.com\/raw.php?i=9stx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417895364016865281",
  "text" : "http:\/\/t.co\/n43lEOmD05 Keywords: 0.77 #infoleak",
  "id" : 417895364016865281,
  "created_at" : "2013-12-31 05:49:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hnmffnHmxR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=auZcC8a1",
      "display_url" : "pastebin.com\/raw.php?i=auZc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417891807813308416",
  "text" : "http:\/\/t.co\/hnmffnHmxR Emails: 1 Keywords: 0.77 #infoleak",
  "id" : 417891807813308416,
  "created_at" : "2013-12-31 05:35:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nu92I2XDgq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QexS5saE",
      "display_url" : "pastebin.com\/raw.php?i=QexS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417865890114195456",
  "text" : "http:\/\/t.co\/nu92I2XDgq Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 417865890114195456,
  "created_at" : "2013-12-31 03:52:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3II0V2lTT3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UEC4UirP",
      "display_url" : "pastebin.com\/raw.php?i=UEC4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417864755567534080",
  "text" : "http:\/\/t.co\/3II0V2lTT3 Emails: 90 Keywords: 0.11 #infoleak",
  "id" : 417864755567534080,
  "created_at" : "2013-12-31 03:48:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4CM4CZimjt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fHMaqmXe",
      "display_url" : "pastebin.com\/raw.php?i=fHMa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417862205908848640",
  "text" : "http:\/\/t.co\/4CM4CZimjt Emails: 73 Keywords: 0.22 #infoleak",
  "id" : 417862205908848640,
  "created_at" : "2013-12-31 03:38:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m3bfNgKY3I",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f7bezApN",
      "display_url" : "pastebin.com\/raw.php?i=f7be\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417859149657944064",
  "text" : "http:\/\/t.co\/m3bfNgKY3I Keywords: 0.66 #infoleak",
  "id" : 417859149657944064,
  "created_at" : "2013-12-31 03:25:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FAHuaU60Fv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U661KFkA",
      "display_url" : "pastebin.com\/raw.php?i=U661\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417856544768663552",
  "text" : "http:\/\/t.co\/FAHuaU60Fv Emails: 48 Keywords: 0.22 #infoleak",
  "id" : 417856544768663552,
  "created_at" : "2013-12-31 03:15:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g5npj2tbps",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aNpmc7B3",
      "display_url" : "pastebin.com\/raw.php?i=aNpm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417787021554225152",
  "text" : "http:\/\/t.co\/g5npj2tbps Hashes: 367 Keywords: 0.19 #infoleak",
  "id" : 417787021554225152,
  "created_at" : "2013-12-30 22:39:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5F1lul2Ipo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WBSuZibg",
      "display_url" : "pastebin.com\/raw.php?i=WBSu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417780770275475456",
  "text" : "http:\/\/t.co\/5F1lul2Ipo Emails: 65 Keywords: 0.0 #infoleak",
  "id" : 417780770275475456,
  "created_at" : "2013-12-30 22:14:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WtnIFhybxf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TF2LF74B",
      "display_url" : "pastebin.com\/raw.php?i=TF2L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417778367694245890",
  "text" : "http:\/\/t.co\/WtnIFhybxf Hashes: 121 Keywords: 0.22 #infoleak",
  "id" : 417778367694245890,
  "created_at" : "2013-12-30 22:04:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qHSrYGNiqe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8PgVCjyK",
      "display_url" : "pastebin.com\/raw.php?i=8PgV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417774154624925697",
  "text" : "http:\/\/t.co\/qHSrYGNiqe Emails: 10003 Keywords: -0.14 #infoleak",
  "id" : 417774154624925697,
  "created_at" : "2013-12-30 21:48:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mUIEeJ4PuD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xFs2rSy9",
      "display_url" : "pastebin.com\/raw.php?i=xFs2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417769794889187328",
  "text" : "http:\/\/t.co\/mUIEeJ4PuD Hashes: 229 Keywords: 0.11 #infoleak",
  "id" : 417769794889187328,
  "created_at" : "2013-12-30 21:30:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lQMSxESV3Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yrsZmEUK",
      "display_url" : "pastebin.com\/raw.php?i=yrsZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417769439216410624",
  "text" : "http:\/\/t.co\/lQMSxESV3Y Emails: 992 Keywords: 0.08 #infoleak",
  "id" : 417769439216410624,
  "created_at" : "2013-12-30 21:29:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4kbjaR8jwh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WuD2B9nV",
      "display_url" : "pastebin.com\/raw.php?i=WuD2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417753991699628033",
  "text" : "http:\/\/t.co\/4kbjaR8jwh Emails: 112 Keywords: 0.22 #infoleak",
  "id" : 417753991699628033,
  "created_at" : "2013-12-30 20:28:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Di5W8pJDhf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zucJBfnj",
      "display_url" : "pastebin.com\/raw.php?i=zucJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417749963532025856",
  "text" : "http:\/\/t.co\/Di5W8pJDhf Emails: 67 Keywords: 0.33 #infoleak",
  "id" : 417749963532025856,
  "created_at" : "2013-12-30 20:12:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i3yvnOZS4b",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W6nkwT5f",
      "display_url" : "pastebin.com\/raw.php?i=W6nk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417744519916822529",
  "text" : "http:\/\/t.co\/i3yvnOZS4b Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 417744519916822529,
  "created_at" : "2013-12-30 19:50:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cUb7MI7gNA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JLvDE6Be",
      "display_url" : "pastebin.com\/raw.php?i=JLvD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417727126888914944",
  "text" : "http:\/\/t.co\/cUb7MI7gNA Emails: 89 Keywords: 0.22 #infoleak",
  "id" : 417727126888914944,
  "created_at" : "2013-12-30 18:41:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J7IK9K2OpW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ru6p6LEi",
      "display_url" : "pastebin.com\/raw.php?i=ru6p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417722720151818240",
  "text" : "http:\/\/t.co\/J7IK9K2OpW Emails: 1856 Keywords: 0.19 #infoleak",
  "id" : 417722720151818240,
  "created_at" : "2013-12-30 18:23:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G684P2akLX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JdCaxus8",
      "display_url" : "pastebin.com\/raw.php?i=JdCa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417720803694620672",
  "text" : "http:\/\/t.co\/G684P2akLX Hashes: 101 Keywords: -0.14 #infoleak",
  "id" : 417720803694620672,
  "created_at" : "2013-12-30 18:16:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WsYFuYJhGZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=13TReSPg",
      "display_url" : "pastebin.com\/raw.php?i=13TR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417709147740585984",
  "text" : "http:\/\/t.co\/WsYFuYJhGZ Hashes: 85 Keywords: 0.0 #infoleak",
  "id" : 417709147740585984,
  "created_at" : "2013-12-30 17:29:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qFPDjw17Tw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vyeyW6AK",
      "display_url" : "pastebin.com\/raw.php?i=vyey\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417705708260302848",
  "text" : "http:\/\/t.co\/qFPDjw17Tw Emails: 39 Keywords: 0.0 #infoleak",
  "id" : 417705708260302848,
  "created_at" : "2013-12-30 17:16:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HLQaUNOww2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6sgJvmP4",
      "display_url" : "pastebin.com\/raw.php?i=6sgJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417695657218940928",
  "text" : "http:\/\/t.co\/HLQaUNOww2 Emails: 108 Keywords: 0.0 #infoleak",
  "id" : 417695657218940928,
  "created_at" : "2013-12-30 16:36:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nvpjuW9W2W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VZbMXetp",
      "display_url" : "pastebin.com\/raw.php?i=VZbM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417693674466578432",
  "text" : "http:\/\/t.co\/nvpjuW9W2W Hashes: 64 Keywords: -0.28 #infoleak",
  "id" : 417693674466578432,
  "created_at" : "2013-12-30 16:28:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JRi2gKQoiu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g0wwaAwi",
      "display_url" : "pastebin.com\/raw.php?i=g0ww\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417686818629246976",
  "text" : "http:\/\/t.co\/JRi2gKQoiu Emails: 500 Keywords: 0.11 #infoleak",
  "id" : 417686818629246976,
  "created_at" : "2013-12-30 16:01:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XacJO67vEK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8RS2ZYdP",
      "display_url" : "pastebin.com\/raw.php?i=8RS2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417686671098798080",
  "text" : "http:\/\/t.co\/XacJO67vEK Keywords: 0.55 #infoleak",
  "id" : 417686671098798080,
  "created_at" : "2013-12-30 16:00:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EifFn0krSL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dvacxH7F",
      "display_url" : "pastebin.com\/raw.php?i=dvac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417685158439821313",
  "text" : "http:\/\/t.co\/EifFn0krSL Keywords: 0.55 #infoleak",
  "id" : 417685158439821313,
  "created_at" : "2013-12-30 15:54:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3x4FIYJEfu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KGrKX5Pt",
      "display_url" : "pastebin.com\/raw.php?i=KGrK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417684479839191042",
  "text" : "http:\/\/t.co\/3x4FIYJEfu Keywords: 0.55 #infoleak",
  "id" : 417684479839191042,
  "created_at" : "2013-12-30 15:51:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aGDsLZkXVh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=56rDmp1D",
      "display_url" : "pastebin.com\/raw.php?i=56rD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417681615301529600",
  "text" : "http:\/\/t.co\/aGDsLZkXVh Hashes: 180 Keywords: 0.0 #infoleak",
  "id" : 417681615301529600,
  "created_at" : "2013-12-30 15:40:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HgPmvpwpVt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CRDi0Aqh",
      "display_url" : "pastebin.com\/raw.php?i=CRDi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417673913271717889",
  "text" : "http:\/\/t.co\/HgPmvpwpVt Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 417673913271717889,
  "created_at" : "2013-12-30 15:09:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sNf5vGJYLu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=irarqXEF",
      "display_url" : "pastebin.com\/raw.php?i=irar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417671405988098048",
  "text" : "http:\/\/t.co\/sNf5vGJYLu Emails: 32 Keywords: 0.0 #infoleak",
  "id" : 417671405988098048,
  "created_at" : "2013-12-30 14:59:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6JurqjiivS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kCi88Lq9",
      "display_url" : "pastebin.com\/raw.php?i=kCi8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417666163502354432",
  "text" : "http:\/\/t.co\/6JurqjiivS Emails: 3569 Keywords: 0.33 #infoleak",
  "id" : 417666163502354432,
  "created_at" : "2013-12-30 14:39:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v4wCQueNVv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wL37UpGy",
      "display_url" : "pastebin.com\/raw.php?i=wL37\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417663012657319936",
  "text" : "http:\/\/t.co\/v4wCQueNVv Emails: 1828 Keywords: 0.11 #infoleak",
  "id" : 417663012657319936,
  "created_at" : "2013-12-30 14:26:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zbkZyZmKmM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jD01PL3P",
      "display_url" : "pastebin.com\/raw.php?i=jD01\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417660042251231232",
  "text" : "http:\/\/t.co\/zbkZyZmKmM Keywords: 0.66 #infoleak",
  "id" : 417660042251231232,
  "created_at" : "2013-12-30 14:14:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AYI3WL8V3L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N2rMghBw",
      "display_url" : "pastebin.com\/raw.php?i=N2rM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417656347170045952",
  "text" : "http:\/\/t.co\/AYI3WL8V3L Keywords: 0.66 #infoleak",
  "id" : 417656347170045952,
  "created_at" : "2013-12-30 14:00:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rK8iDIaPQY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m8n9XJiU",
      "display_url" : "pastebin.com\/raw.php?i=m8n9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417651285077131264",
  "text" : "http:\/\/t.co\/rK8iDIaPQY Possible cisco configuration #infoleak",
  "id" : 417651285077131264,
  "created_at" : "2013-12-30 13:40:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8DBsOR4H4h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2nG3vZcf",
      "display_url" : "pastebin.com\/raw.php?i=2nG3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417643191253225472",
  "text" : "http:\/\/t.co\/8DBsOR4H4h Keywords: 0.66 #infoleak",
  "id" : 417643191253225472,
  "created_at" : "2013-12-30 13:07:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IvwAB8Kdxr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UzXN6eRp",
      "display_url" : "pastebin.com\/raw.php?i=UzXN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417642418209447937",
  "text" : "http:\/\/t.co\/IvwAB8Kdxr Keywords: 0.66 #infoleak",
  "id" : 417642418209447937,
  "created_at" : "2013-12-30 13:04:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oTIxTRZ69c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ufA0Zrh9",
      "display_url" : "pastebin.com\/raw.php?i=ufA0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417638788509089792",
  "text" : "http:\/\/t.co\/oTIxTRZ69c Hashes: 54 Keywords: 0.0 #infoleak",
  "id" : 417638788509089792,
  "created_at" : "2013-12-30 12:50:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hao6OrrJEn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Baq2zxbF",
      "display_url" : "pastebin.com\/raw.php?i=Baq2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417637949820243969",
  "text" : "http:\/\/t.co\/Hao6OrrJEn Keywords: 0.66 #infoleak",
  "id" : 417637949820243969,
  "created_at" : "2013-12-30 12:47:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/64FhWVpxlz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PXrwGdQi",
      "display_url" : "pastebin.com\/raw.php?i=PXrw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417637632944775168",
  "text" : "http:\/\/t.co\/64FhWVpxlz Keywords: 0.66 #infoleak",
  "id" : 417637632944775168,
  "created_at" : "2013-12-30 12:45:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5oEpURqdnc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CNjGGRzQ",
      "display_url" : "pastebin.com\/raw.php?i=CNjG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417636792855035904",
  "text" : "http:\/\/t.co\/5oEpURqdnc Hashes: 54 Keywords: 0.19 #infoleak",
  "id" : 417636792855035904,
  "created_at" : "2013-12-30 12:42:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C2thJrpzxz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sWRLutqG",
      "display_url" : "pastebin.com\/raw.php?i=sWRL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417636098127327232",
  "text" : "http:\/\/t.co\/C2thJrpzxz Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 417636098127327232,
  "created_at" : "2013-12-30 12:39:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FcQwvDsnjG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YUP7kZCT",
      "display_url" : "pastebin.com\/raw.php?i=YUP7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417629171527843840",
  "text" : "http:\/\/t.co\/FcQwvDsnjG Found possible Google API key(s) #infoleak",
  "id" : 417629171527843840,
  "created_at" : "2013-12-30 12:12:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y2AiL7kDFE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PkV0dx8t",
      "display_url" : "pastebin.com\/raw.php?i=PkV0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417628105667125249",
  "text" : "http:\/\/t.co\/Y2AiL7kDFE Hashes: 82 Keywords: 0.22 #infoleak",
  "id" : 417628105667125249,
  "created_at" : "2013-12-30 12:07:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SdExmNzOty",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9zUPfSxR",
      "display_url" : "pastebin.com\/raw.php?i=9zUP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417625667849576448",
  "text" : "http:\/\/t.co\/SdExmNzOty Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 417625667849576448,
  "created_at" : "2013-12-30 11:58:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oflVzityc8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YA0xxJCZ",
      "display_url" : "pastebin.com\/raw.php?i=YA0x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417625133319069698",
  "text" : "http:\/\/t.co\/oflVzityc8 Keywords: 0.66 #infoleak",
  "id" : 417625133319069698,
  "created_at" : "2013-12-30 11:56:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JqtD6tm8hQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ehaVGzRx",
      "display_url" : "pastebin.com\/raw.php?i=ehaV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417622609363091456",
  "text" : "http:\/\/t.co\/JqtD6tm8hQ Keywords: 0.66 #infoleak",
  "id" : 417622609363091456,
  "created_at" : "2013-12-30 11:46:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3pKJjzkgSu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qy9p0Ffv",
      "display_url" : "pastebin.com\/raw.php?i=Qy9p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417620480913207296",
  "text" : "http:\/\/t.co\/3pKJjzkgSu Keywords: 0.66 #infoleak",
  "id" : 417620480913207296,
  "created_at" : "2013-12-30 11:37:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V87TKShxLW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=a4dtQm79",
      "display_url" : "pastebin.com\/raw.php?i=a4dt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417619933514588160",
  "text" : "http:\/\/t.co\/V87TKShxLW Hashes: 2877 Keywords: 0.11 #infoleak",
  "id" : 417619933514588160,
  "created_at" : "2013-12-30 11:35:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FP7q1exiCO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cWPk9c5A",
      "display_url" : "pastebin.com\/raw.php?i=cWPk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417618151212204033",
  "text" : "http:\/\/t.co\/FP7q1exiCO Hashes: 186 Keywords: 0.44 #infoleak",
  "id" : 417618151212204033,
  "created_at" : "2013-12-30 11:28:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5pFW3YO0n8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yEK0WaHs",
      "display_url" : "pastebin.com\/raw.php?i=yEK0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417615611372380160",
  "text" : "http:\/\/t.co\/5pFW3YO0n8 Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 417615611372380160,
  "created_at" : "2013-12-30 11:18:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VyXQWDXycF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h3Kj0URs",
      "display_url" : "pastebin.com\/raw.php?i=h3Kj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417578520345186304",
  "text" : "http:\/\/t.co\/VyXQWDXycF Emails: 78 Keywords: 0.33 #infoleak",
  "id" : 417578520345186304,
  "created_at" : "2013-12-30 08:50:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AyB3VcmGSg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qj0KzxRa",
      "display_url" : "pastebin.com\/raw.php?i=Qj0K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417521743461232640",
  "text" : "http:\/\/t.co\/AyB3VcmGSg Hashes: 31 Keywords: 0.05 #infoleak",
  "id" : 417521743461232640,
  "created_at" : "2013-12-30 05:05:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8T5aj1v7TM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dixTTcan",
      "display_url" : "pastebin.com\/raw.php?i=dixT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417515114648977409",
  "text" : "http:\/\/t.co\/8T5aj1v7TM Found possible Google API key(s) #infoleak",
  "id" : 417515114648977409,
  "created_at" : "2013-12-30 04:38:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JRRl7w25WY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r0fvdgXH",
      "display_url" : "pastebin.com\/raw.php?i=r0fv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417501252818202624",
  "text" : "http:\/\/t.co\/JRRl7w25WY Hashes: 35 Keywords: 0.19 #infoleak",
  "id" : 417501252818202624,
  "created_at" : "2013-12-30 03:43:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fWp3z2G0on",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bMEBWMAh",
      "display_url" : "pastebin.com\/raw.php?i=bMEB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417497929482383360",
  "text" : "http:\/\/t.co\/fWp3z2G0on Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 417497929482383360,
  "created_at" : "2013-12-30 03:30:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k9DPA3TGIg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rg4p9kKc",
      "display_url" : "pastebin.com\/raw.php?i=rg4p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417443282159820800",
  "text" : "http:\/\/t.co\/k9DPA3TGIg Emails: 154 Keywords: 0.33 #infoleak",
  "id" : 417443282159820800,
  "created_at" : "2013-12-29 23:53:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Nq3jP9Hgax",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wuex2FRt",
      "display_url" : "pastebin.com\/raw.php?i=wuex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417439993955504128",
  "text" : "http:\/\/t.co\/Nq3jP9Hgax Hashes: 62 Keywords: 0.0 #infoleak",
  "id" : 417439993955504128,
  "created_at" : "2013-12-29 23:40:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Un7VbZgNhd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yHiCWpXC",
      "display_url" : "pastebin.com\/raw.php?i=yHiC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417439549287985153",
  "text" : "http:\/\/t.co\/Un7VbZgNhd Emails: 1564 Keywords: -0.03 #infoleak",
  "id" : 417439549287985153,
  "created_at" : "2013-12-29 23:38:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qGr7Al8XZT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nGCYSDZr",
      "display_url" : "pastebin.com\/raw.php?i=nGCY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417417472896036864",
  "text" : "http:\/\/t.co\/qGr7Al8XZT Emails: 2624 Keywords: 0.08 #infoleak",
  "id" : 417417472896036864,
  "created_at" : "2013-12-29 22:10:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IgZm5zolR5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w1JQHg1k",
      "display_url" : "pastebin.com\/raw.php?i=w1JQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417397462144270336",
  "text" : "http:\/\/t.co\/IgZm5zolR5 Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 417397462144270336,
  "created_at" : "2013-12-29 20:51:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oRPI72HGdK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JxqkkntY",
      "display_url" : "pastebin.com\/raw.php?i=Jxqk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417390401272569856",
  "text" : "http:\/\/t.co\/oRPI72HGdK Emails: 28 Keywords: -0.14 #infoleak",
  "id" : 417390401272569856,
  "created_at" : "2013-12-29 20:23:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ENkZ3lyWMj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gZ6F3egt",
      "display_url" : "pastebin.com\/raw.php?i=gZ6F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417382459915767808",
  "text" : "http:\/\/t.co\/ENkZ3lyWMj Emails: 77 Keywords: 0.19 #infoleak",
  "id" : 417382459915767808,
  "created_at" : "2013-12-29 19:51:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qDWWB1MO8p",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=McVqH8yG",
      "display_url" : "pastebin.com\/raw.php?i=McVq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417334005088804865",
  "text" : "http:\/\/t.co\/qDWWB1MO8p Hashes: 742 Keywords: 0.11 #infoleak",
  "id" : 417334005088804865,
  "created_at" : "2013-12-29 16:39:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NR3FBtEQFF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nN9E8J8L",
      "display_url" : "pastebin.com\/raw.php?i=nN9E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417332927383347201",
  "text" : "http:\/\/t.co\/NR3FBtEQFF Emails: 67 Keywords: 0.22 #infoleak",
  "id" : 417332927383347201,
  "created_at" : "2013-12-29 16:34:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6MrtvQAdJo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n5GLXkma",
      "display_url" : "pastebin.com\/raw.php?i=n5GL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417330926037643264",
  "text" : "http:\/\/t.co\/6MrtvQAdJo Emails: 82 Keywords: 0.44 #infoleak",
  "id" : 417330926037643264,
  "created_at" : "2013-12-29 16:27:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HS0ZjapDSF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zt1048aT",
      "display_url" : "pastebin.com\/raw.php?i=zt10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417329845979193344",
  "text" : "http:\/\/t.co\/HS0ZjapDSF Keywords: 0.55 #infoleak",
  "id" : 417329845979193344,
  "created_at" : "2013-12-29 16:22:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ozBUuMzZ6s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MeN56icK",
      "display_url" : "pastebin.com\/raw.php?i=MeN5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417326221328781312",
  "text" : "http:\/\/t.co\/ozBUuMzZ6s Emails: 73 Keywords: -0.14 #infoleak",
  "id" : 417326221328781312,
  "created_at" : "2013-12-29 16:08:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eBQNOiLAmV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d30ThNjw",
      "display_url" : "pastebin.com\/raw.php?i=d30T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417208377056309248",
  "text" : "http:\/\/t.co\/eBQNOiLAmV Found possible Google API key(s) #infoleak",
  "id" : 417208377056309248,
  "created_at" : "2013-12-29 08:20:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yyb8Exmg3W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WMWJmpY8",
      "display_url" : "pastebin.com\/raw.php?i=WMWJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417171776880140289",
  "text" : "http:\/\/t.co\/yyb8Exmg3W Found possible Google API key(s) #infoleak",
  "id" : 417171776880140289,
  "created_at" : "2013-12-29 05:54:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fbfZQEwAvF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FDF1QvSi",
      "display_url" : "pastebin.com\/raw.php?i=FDF1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417035605814431744",
  "text" : "http:\/\/t.co\/fbfZQEwAvF Emails: 104 Keywords: 0.0 #infoleak",
  "id" : 417035605814431744,
  "created_at" : "2013-12-28 20:53:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k22Luy1CDO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cBW9RiHP",
      "display_url" : "pastebin.com\/raw.php?i=cBW9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417024434667417600",
  "text" : "http:\/\/t.co\/k22Luy1CDO Emails: 46 Keywords: 0.0 #infoleak",
  "id" : 417024434667417600,
  "created_at" : "2013-12-28 20:09:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tM6u2xfJY8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vE2Kcmzq",
      "display_url" : "pastebin.com\/raw.php?i=vE2K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417006394248679424",
  "text" : "http:\/\/t.co\/tM6u2xfJY8 Emails: 67 Keywords: 0.0 #infoleak",
  "id" : 417006394248679424,
  "created_at" : "2013-12-28 18:57:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BID0HEwJ4A",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4DL6H0sF",
      "display_url" : "pastebin.com\/raw.php?i=4DL6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416994960420777984",
  "text" : "http:\/\/t.co\/BID0HEwJ4A Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 416994960420777984,
  "created_at" : "2013-12-28 18:12:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JttxgVncPq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ta4kfj04",
      "display_url" : "pastebin.com\/raw.php?i=Ta4k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416994725531373568",
  "text" : "http:\/\/t.co\/JttxgVncPq Emails: 47 Keywords: 0.0 #infoleak",
  "id" : 416994725531373568,
  "created_at" : "2013-12-28 18:11:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YwKdK8ogjZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=THwF1ubG",
      "display_url" : "pastebin.com\/raw.php?i=THwF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416985962430750720",
  "text" : "http:\/\/t.co\/YwKdK8ogjZ Hashes: 74 Keywords: -0.17 #infoleak",
  "id" : 416985962430750720,
  "created_at" : "2013-12-28 17:36:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zKCO7vuD8R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XKtsX4i0",
      "display_url" : "pastebin.com\/raw.php?i=XKts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416983711096115200",
  "text" : "http:\/\/t.co\/zKCO7vuD8R Emails: 20 Keywords: 0.22 #infoleak",
  "id" : 416983711096115200,
  "created_at" : "2013-12-28 17:27:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WMq9JliUcv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xx8XsxWM",
      "display_url" : "pastebin.com\/raw.php?i=Xx8X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416983551867777024",
  "text" : "http:\/\/t.co\/WMq9JliUcv Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 416983551867777024,
  "created_at" : "2013-12-28 17:26:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kDwmGaaBDF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N5JEk5MH",
      "display_url" : "pastebin.com\/raw.php?i=N5JE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416963856095662080",
  "text" : "http:\/\/t.co\/kDwmGaaBDF Emails: 411 Keywords: 0.3 #infoleak",
  "id" : 416963856095662080,
  "created_at" : "2013-12-28 16:08:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QJjzh2YHiK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u6qLBdy8",
      "display_url" : "pastebin.com\/raw.php?i=u6qL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416958527697981441",
  "text" : "http:\/\/t.co\/QJjzh2YHiK Emails: 20 Hashes: 11 E\/H: 1.82 Keywords: 0.11 #infoleak",
  "id" : 416958527697981441,
  "created_at" : "2013-12-28 15:47:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VRmECFAPJi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tYi98MSS",
      "display_url" : "pastebin.com\/raw.php?i=tYi9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416955171109748736",
  "text" : "http:\/\/t.co\/VRmECFAPJi Found possible Google API key(s) #infoleak",
  "id" : 416955171109748736,
  "created_at" : "2013-12-28 15:33:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KC2lHYnKfv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ri2kpwyr",
      "display_url" : "pastebin.com\/raw.php?i=ri2k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416953008065241088",
  "text" : "http:\/\/t.co\/KC2lHYnKfv Emails: 77 Keywords: 0.0 #infoleak",
  "id" : 416953008065241088,
  "created_at" : "2013-12-28 15:25:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QcgU9mM4F4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=96xFtC9m",
      "display_url" : "pastebin.com\/raw.php?i=96xF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416924094978736128",
  "text" : "http:\/\/t.co\/QcgU9mM4F4 Emails: 339 Keywords: 0.11 #infoleak",
  "id" : 416924094978736128,
  "created_at" : "2013-12-28 13:30:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IFSZcUqtam",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rfiXujTv",
      "display_url" : "pastebin.com\/raw.php?i=rfiX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416922104823439360",
  "text" : "http:\/\/t.co\/IFSZcUqtam Found possible Google API key(s) #infoleak",
  "id" : 416922104823439360,
  "created_at" : "2013-12-28 13:22:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Jts2eX6Obz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=586kA4WE",
      "display_url" : "pastebin.com\/raw.php?i=586k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416899494148440065",
  "text" : "http:\/\/t.co\/Jts2eX6Obz Emails: 183 Keywords: 0.0 #infoleak",
  "id" : 416899494148440065,
  "created_at" : "2013-12-28 11:52:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wyKLNwgFoE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gsrEPh0T",
      "display_url" : "pastebin.com\/raw.php?i=gsrE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416892630803304448",
  "text" : "http:\/\/t.co\/wyKLNwgFoE Emails: 57 Keywords: 0.0 #infoleak",
  "id" : 416892630803304448,
  "created_at" : "2013-12-28 11:25:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PisYMjNgEi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=155FBQVV",
      "display_url" : "pastebin.com\/raw.php?i=155F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416890474071207936",
  "text" : "http:\/\/t.co\/PisYMjNgEi Emails: 175 Keywords: 0.44 #infoleak",
  "id" : 416890474071207936,
  "created_at" : "2013-12-28 11:16:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2L76igthmK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2nbdugTW",
      "display_url" : "pastebin.com\/raw.php?i=2nbd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416868609160249344",
  "text" : "http:\/\/t.co\/2L76igthmK Found possible Google API key(s) #infoleak",
  "id" : 416868609160249344,
  "created_at" : "2013-12-28 09:49:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v7NdR8yUHI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1CKSh4Gx",
      "display_url" : "pastebin.com\/raw.php?i=1CKS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416863033298665472",
  "text" : "http:\/\/t.co\/v7NdR8yUHI Hashes: 98 Keywords: 0.22 #infoleak",
  "id" : 416863033298665472,
  "created_at" : "2013-12-28 09:27:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7hSODwvxb8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hxy3epey",
      "display_url" : "pastebin.com\/raw.php?i=Hxy3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416859325819146240",
  "text" : "http:\/\/t.co\/7hSODwvxb8 Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 416859325819146240,
  "created_at" : "2013-12-28 09:13:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cRjUgYXFBs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4TmaAKuC",
      "display_url" : "pastebin.com\/raw.php?i=4Tma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416848406225489920",
  "text" : "http:\/\/t.co\/cRjUgYXFBs Hashes: 265 Keywords: 0.33 #infoleak",
  "id" : 416848406225489920,
  "created_at" : "2013-12-28 08:29:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cwrVlKVVQ5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B8dqnxte",
      "display_url" : "pastebin.com\/raw.php?i=B8dq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416817289095159808",
  "text" : "http:\/\/t.co\/cwrVlKVVQ5 Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 416817289095159808,
  "created_at" : "2013-12-28 06:26:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lAP9zuFESo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HSUFcJYq",
      "display_url" : "pastebin.com\/raw.php?i=HSUF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416815516297093120",
  "text" : "http:\/\/t.co\/lAP9zuFESo Hashes: 238 Keywords: 0.55 #infoleak",
  "id" : 416815516297093120,
  "created_at" : "2013-12-28 06:18:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kHqEHQzPN9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1Mj1T9qT",
      "display_url" : "pastebin.com\/raw.php?i=1Mj1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416812532699889664",
  "text" : "http:\/\/t.co\/kHqEHQzPN9 Found possible Google API key(s) #infoleak",
  "id" : 416812532699889664,
  "created_at" : "2013-12-28 06:07:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YDWaljdWoP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9LNPVCMW",
      "display_url" : "pastebin.com\/raw.php?i=9LNP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416803930731847681",
  "text" : "http:\/\/t.co\/YDWaljdWoP Found possible Google API key(s) #infoleak",
  "id" : 416803930731847681,
  "created_at" : "2013-12-28 05:32:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iKXDt54fr7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M16Sv3jF",
      "display_url" : "pastebin.com\/raw.php?i=M16S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416757279086481408",
  "text" : "http:\/\/t.co\/iKXDt54fr7 Hashes: 377 Keywords: -0.03 #infoleak",
  "id" : 416757279086481408,
  "created_at" : "2013-12-28 02:27:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1vZyjGv1kI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gxxH0XmU",
      "display_url" : "pastebin.com\/raw.php?i=gxxH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416756066316087296",
  "text" : "http:\/\/t.co\/1vZyjGv1kI Emails: 1 Hashes: 350 E\/H: 0.0 Keywords: 0.08 #infoleak",
  "id" : 416756066316087296,
  "created_at" : "2013-12-28 02:22:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/59bIvQfmhx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fkbsizx4",
      "display_url" : "pastebin.com\/raw.php?i=Fkbs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416755262964252672",
  "text" : "http:\/\/t.co\/59bIvQfmhx Hashes: 280 Keywords: -0.03 #infoleak",
  "id" : 416755262964252672,
  "created_at" : "2013-12-28 02:19:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DypWUnZFqH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mtK7iyvJ",
      "display_url" : "pastebin.com\/raw.php?i=mtK7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416736082630152192",
  "text" : "http:\/\/t.co\/DypWUnZFqH Emails: 53 Keywords: 0.11 #infoleak",
  "id" : 416736082630152192,
  "created_at" : "2013-12-28 01:03:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fp4gajbFnE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EqCZUcsL",
      "display_url" : "pastebin.com\/raw.php?i=EqCZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416690428348342272",
  "text" : "http:\/\/t.co\/fp4gajbFnE Hashes: 64 Keywords: 0.19 #infoleak",
  "id" : 416690428348342272,
  "created_at" : "2013-12-27 22:01:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NaO0Bq4aA4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KdwyGckz",
      "display_url" : "pastebin.com\/raw.php?i=Kdwy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416680876542402560",
  "text" : "http:\/\/t.co\/NaO0Bq4aA4 Emails: 883 Keywords: 0.08 #infoleak",
  "id" : 416680876542402560,
  "created_at" : "2013-12-27 21:23:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MHXo9wzISd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2WtuuscY",
      "display_url" : "pastebin.com\/raw.php?i=2Wtu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416677674350702592",
  "text" : "http:\/\/t.co\/MHXo9wzISd Found possible Google API key(s) #infoleak",
  "id" : 416677674350702592,
  "created_at" : "2013-12-27 21:11:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/08UoaYTt0n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hD9VfQek",
      "display_url" : "pastebin.com\/raw.php?i=hD9V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416652153956990976",
  "text" : "http:\/\/t.co\/08UoaYTt0n Hashes: 43 Keywords: 0.22 #infoleak",
  "id" : 416652153956990976,
  "created_at" : "2013-12-27 19:29:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qUMGK55Vdl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u9t2h0sj",
      "display_url" : "pastebin.com\/raw.php?i=u9t2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416626499974742016",
  "text" : "http:\/\/t.co\/qUMGK55Vdl Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 416626499974742016,
  "created_at" : "2013-12-27 17:47:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IyIH43C8h0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yszLjG0i",
      "display_url" : "pastebin.com\/raw.php?i=yszL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416623625387520000",
  "text" : "http:\/\/t.co\/IyIH43C8h0 Emails: 498 Keywords: 0.33 #infoleak",
  "id" : 416623625387520000,
  "created_at" : "2013-12-27 17:36:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qh5VYb6uwa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XH8k57h9",
      "display_url" : "pastebin.com\/raw.php?i=XH8k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416622534696525824",
  "text" : "http:\/\/t.co\/Qh5VYb6uwa Emails: 67 Keywords: 0.22 #infoleak",
  "id" : 416622534696525824,
  "created_at" : "2013-12-27 17:32:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4rEWYB7fQi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9L5dCVjp",
      "display_url" : "pastebin.com\/raw.php?i=9L5d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416622197617074176",
  "text" : "http:\/\/t.co\/4rEWYB7fQi Emails: 67 Keywords: 0.22 #infoleak",
  "id" : 416622197617074176,
  "created_at" : "2013-12-27 17:30:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2jvovMSqgo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3A5BBksX",
      "display_url" : "pastebin.com\/raw.php?i=3A5B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416617969515372544",
  "text" : "http:\/\/t.co\/2jvovMSqgo Emails: 86 Keywords: 0.22 #infoleak",
  "id" : 416617969515372544,
  "created_at" : "2013-12-27 17:13:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1AKwAbrRvE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=f27u57Kp",
      "display_url" : "pastebin.com\/raw.php?i=f27u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416614469280595968",
  "text" : "http:\/\/t.co\/1AKwAbrRvE Found possible Google API key(s) #infoleak",
  "id" : 416614469280595968,
  "created_at" : "2013-12-27 17:00:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZB6t5D3kxU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ai5h659B",
      "display_url" : "pastebin.com\/raw.php?i=Ai5h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416607596263383040",
  "text" : "http:\/\/t.co\/ZB6t5D3kxU Found possible Google API key(s) #infoleak",
  "id" : 416607596263383040,
  "created_at" : "2013-12-27 16:32:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7Q0grVT98t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MPc6072T",
      "display_url" : "pastebin.com\/raw.php?i=MPc6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416604467144830976",
  "text" : "http:\/\/t.co\/7Q0grVT98t Hashes: 137 Keywords: 0.11 #infoleak",
  "id" : 416604467144830976,
  "created_at" : "2013-12-27 16:20:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dnvqqYfT31",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nrCzqV8x",
      "display_url" : "pastebin.com\/raw.php?i=nrCz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416580478540320768",
  "text" : "http:\/\/t.co\/dnvqqYfT31 Emails: 91 Keywords: 0.11 #infoleak",
  "id" : 416580478540320768,
  "created_at" : "2013-12-27 14:45:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BFevPGusns",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qRHkLaSZ",
      "display_url" : "pastebin.com\/raw.php?i=qRHk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416566281186201601",
  "text" : "http:\/\/t.co\/BFevPGusns Keywords: 0.55 #infoleak",
  "id" : 416566281186201601,
  "created_at" : "2013-12-27 13:48:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dE782zD71d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jGCpc0w9",
      "display_url" : "pastebin.com\/raw.php?i=jGCp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416565309353365505",
  "text" : "http:\/\/t.co\/dE782zD71d Emails: 5 Hashes: 84 E\/H: 0.06 Keywords: 0.33 #infoleak",
  "id" : 416565309353365505,
  "created_at" : "2013-12-27 13:44:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sG9e0sotRL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z12b66w1",
      "display_url" : "pastebin.com\/raw.php?i=Z12b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416530734979899392",
  "text" : "http:\/\/t.co\/sG9e0sotRL Found possible Google API key(s) #infoleak",
  "id" : 416530734979899392,
  "created_at" : "2013-12-27 11:27:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jNgMMsphXa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=A4xfu8Tr",
      "display_url" : "pastebin.com\/raw.php?i=A4xf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416510956772921345",
  "text" : "http:\/\/t.co\/jNgMMsphXa Keywords: 0.55 #infoleak",
  "id" : 416510956772921345,
  "created_at" : "2013-12-27 10:08:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2cn9JdTpDM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wZD6n1hU",
      "display_url" : "pastebin.com\/raw.php?i=wZD6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416510822714576896",
  "text" : "http:\/\/t.co\/2cn9JdTpDM Emails: 477 Keywords: 0.0 #infoleak",
  "id" : 416510822714576896,
  "created_at" : "2013-12-27 10:08:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QpTETxeqMQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kVYmrSX9",
      "display_url" : "pastebin.com\/raw.php?i=kVYm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416501757980581888",
  "text" : "http:\/\/t.co\/QpTETxeqMQ Found possible Google API key(s) #infoleak",
  "id" : 416501757980581888,
  "created_at" : "2013-12-27 09:32:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jbO78rX2Yk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vSGACfX9",
      "display_url" : "pastebin.com\/raw.php?i=vSGA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416493890221268992",
  "text" : "http:\/\/t.co\/jbO78rX2Yk Found possible Google API key(s) #infoleak",
  "id" : 416493890221268992,
  "created_at" : "2013-12-27 09:00:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d4V112uQfA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hdfc8u15",
      "display_url" : "pastebin.com\/raw.php?i=hdfc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416469559860670464",
  "text" : "http:\/\/t.co\/d4V112uQfA Emails: 237 Keywords: 0.0 #infoleak",
  "id" : 416469559860670464,
  "created_at" : "2013-12-27 07:24:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SmxoUpevpv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0K8TMVje",
      "display_url" : "pastebin.com\/raw.php?i=0K8T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416463106982703104",
  "text" : "http:\/\/t.co\/SmxoUpevpv Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 416463106982703104,
  "created_at" : "2013-12-27 06:58:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b8sbLlv8yp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KA7JWAnr",
      "display_url" : "pastebin.com\/raw.php?i=KA7J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416461463281074176",
  "text" : "http:\/\/t.co\/b8sbLlv8yp Found possible Google API key(s) #infoleak",
  "id" : 416461463281074176,
  "created_at" : "2013-12-27 06:52:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4pvFxEMESx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BcNcLHtH",
      "display_url" : "pastebin.com\/raw.php?i=BcNc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416461191137869824",
  "text" : "http:\/\/t.co\/4pvFxEMESx Emails: 743 Keywords: 0.11 #infoleak",
  "id" : 416461191137869824,
  "created_at" : "2013-12-27 06:51:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tGFMwUKLE8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gMJB55ti",
      "display_url" : "pastebin.com\/raw.php?i=gMJB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416460449366822912",
  "text" : "http:\/\/t.co\/tGFMwUKLE8 Possible cisco configuration #infoleak",
  "id" : 416460449366822912,
  "created_at" : "2013-12-27 06:48:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hLQ7BDMnlw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BLkwsB2J",
      "display_url" : "pastebin.com\/raw.php?i=BLkw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416456598639218689",
  "text" : "http:\/\/t.co\/hLQ7BDMnlw Emails: 53 Keywords: 0.0 #infoleak",
  "id" : 416456598639218689,
  "created_at" : "2013-12-27 06:32:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kCTW9vLbj8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2A3ca1BZ",
      "display_url" : "pastebin.com\/raw.php?i=2A3c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416450032313712642",
  "text" : "http:\/\/t.co\/kCTW9vLbj8 Keywords: 0.55 #infoleak",
  "id" : 416450032313712642,
  "created_at" : "2013-12-27 06:06:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T4tqjwU4qI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RVn5SAem",
      "display_url" : "pastebin.com\/raw.php?i=RVn5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416414517791162368",
  "text" : "http:\/\/t.co\/T4tqjwU4qI Found possible Google API key(s) #infoleak",
  "id" : 416414517791162368,
  "created_at" : "2013-12-27 03:45:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4Rkr5bsyaX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qt9WYUNW",
      "display_url" : "pastebin.com\/raw.php?i=qt9W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416414296617140225",
  "text" : "http:\/\/t.co\/4Rkr5bsyaX Emails: 756 Keywords: 0.0 #infoleak",
  "id" : 416414296617140225,
  "created_at" : "2013-12-27 03:44:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F5bZCRH6le",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1yx4eExi",
      "display_url" : "pastebin.com\/raw.php?i=1yx4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416405108755161088",
  "text" : "http:\/\/t.co\/F5bZCRH6le Emails: 782 Keywords: 0.0 #infoleak",
  "id" : 416405108755161088,
  "created_at" : "2013-12-27 03:08:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DMEJFXHVrs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K8VzmQkf",
      "display_url" : "pastebin.com\/raw.php?i=K8Vz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416404667094933504",
  "text" : "http:\/\/t.co\/DMEJFXHVrs Emails: 154 Keywords: 0.33 #infoleak",
  "id" : 416404667094933504,
  "created_at" : "2013-12-27 03:06:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V4MguVzUSH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iyMhyXDD",
      "display_url" : "pastebin.com\/raw.php?i=iyMh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416373915703726082",
  "text" : "http:\/\/t.co\/V4MguVzUSH Hashes: 75 Keywords: 0.0 #infoleak",
  "id" : 416373915703726082,
  "created_at" : "2013-12-27 01:04:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/baGRMTIAFY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CWSfijR8",
      "display_url" : "pastebin.com\/raw.php?i=CWSf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416373890743422976",
  "text" : "http:\/\/t.co\/baGRMTIAFY Hashes: 38 Keywords: 0.08 #infoleak",
  "id" : 416373890743422976,
  "created_at" : "2013-12-27 01:04:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LjyXthg9wP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HwAi9JQY",
      "display_url" : "pastebin.com\/raw.php?i=HwAi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416371833684779008",
  "text" : "http:\/\/t.co\/LjyXthg9wP Emails: 1388 Keywords: -0.03 #infoleak",
  "id" : 416371833684779008,
  "created_at" : "2013-12-27 00:55:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xm2G1dK6VN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3uLkdEMc",
      "display_url" : "pastebin.com\/raw.php?i=3uLk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416369162735210496",
  "text" : "http:\/\/t.co\/xm2G1dK6VN Emails: 24 Keywords: 0.11 #infoleak",
  "id" : 416369162735210496,
  "created_at" : "2013-12-27 00:45:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NxWgKt2zTU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CkBGMP9W",
      "display_url" : "pastebin.com\/raw.php?i=CkBG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416365794285481984",
  "text" : "http:\/\/t.co\/NxWgKt2zTU Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 416365794285481984,
  "created_at" : "2013-12-27 00:31:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XUpObjLnwI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7Md1WvaV",
      "display_url" : "pastebin.com\/raw.php?i=7Md1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416355919757197312",
  "text" : "http:\/\/t.co\/XUpObjLnwI Emails: 3 Keywords: 0.55 #infoleak",
  "id" : 416355919757197312,
  "created_at" : "2013-12-26 23:52:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/caHmDAiOMP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=43eR8u3w",
      "display_url" : "pastebin.com\/raw.php?i=43eR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416327421382520832",
  "text" : "http:\/\/t.co\/caHmDAiOMP Found possible Google API key(s) #infoleak",
  "id" : 416327421382520832,
  "created_at" : "2013-12-26 21:59:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EKiURjgwB7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GDpVVx6M",
      "display_url" : "pastebin.com\/raw.php?i=GDpV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416325530753830912",
  "text" : "http:\/\/t.co\/EKiURjgwB7 Hashes: 849 Keywords: 0.11 #infoleak",
  "id" : 416325530753830912,
  "created_at" : "2013-12-26 21:51:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I8G4iAddl2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6sDdXrwB",
      "display_url" : "pastebin.com\/raw.php?i=6sDd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416198032393113601",
  "text" : "http:\/\/t.co\/I8G4iAddl2 Emails: 1304 Keywords: -0.03 #infoleak",
  "id" : 416198032393113601,
  "created_at" : "2013-12-26 13:25:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2jClpSyVCh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B1mdQ4BB",
      "display_url" : "pastebin.com\/raw.php?i=B1md\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416177959532109824",
  "text" : "http:\/\/t.co\/2jClpSyVCh Found possible Google API key(s) #infoleak",
  "id" : 416177959532109824,
  "created_at" : "2013-12-26 12:05:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aToSEQhoiC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3iZui4gF",
      "display_url" : "pastebin.com\/raw.php?i=3iZu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416173213542920192",
  "text" : "http:\/\/t.co\/aToSEQhoiC Hashes: 36 Keywords: -0.17 #infoleak",
  "id" : 416173213542920192,
  "created_at" : "2013-12-26 11:46:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/moVvQXjj7d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G63Bb9Ft",
      "display_url" : "pastebin.com\/raw.php?i=G63B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416126239946973184",
  "text" : "http:\/\/t.co\/moVvQXjj7d Emails: 1437 Hashes: 1517 E\/H: 0.95 Keywords: 0.22 #infoleak",
  "id" : 416126239946973184,
  "created_at" : "2013-12-26 08:40:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vJxZeC6JZm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x6JHWsrb",
      "display_url" : "pastebin.com\/raw.php?i=x6JH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416070174295355392",
  "text" : "http:\/\/t.co\/vJxZeC6JZm Hashes: 2055 Keywords: 0.11 #infoleak",
  "id" : 416070174295355392,
  "created_at" : "2013-12-26 04:57:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/92pkZs7MZ8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=77UuDKRc",
      "display_url" : "pastebin.com\/raw.php?i=77Uu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416069672333606912",
  "text" : "http:\/\/t.co\/92pkZs7MZ8 Found possible Google API key(s) #infoleak",
  "id" : 416069672333606912,
  "created_at" : "2013-12-26 04:55:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aeIngnWES2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VvGpZBdx",
      "display_url" : "pastebin.com\/raw.php?i=VvGp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416069591450664960",
  "text" : "http:\/\/t.co\/aeIngnWES2 Hashes: 517 Keywords: 0.11 #infoleak",
  "id" : 416069591450664960,
  "created_at" : "2013-12-26 04:54:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9DnOI1mw6o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P2aexkQ0",
      "display_url" : "pastebin.com\/raw.php?i=P2ae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416065097857896448",
  "text" : "http:\/\/t.co\/9DnOI1mw6o Emails: 111 Keywords: 0.0 #infoleak",
  "id" : 416065097857896448,
  "created_at" : "2013-12-26 04:37:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N9Xk2mS8an",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R9FBiXxP",
      "display_url" : "pastebin.com\/raw.php?i=R9FB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416021700476551168",
  "text" : "http:\/\/t.co\/N9Xk2mS8an Keywords: 0.55 #infoleak",
  "id" : 416021700476551168,
  "created_at" : "2013-12-26 01:44:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J9bTeOZiYC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=he3Xvhwe",
      "display_url" : "pastebin.com\/raw.php?i=he3X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416010599437303808",
  "text" : "http:\/\/t.co\/J9bTeOZiYC Found possible Google API key(s) #infoleak",
  "id" : 416010599437303808,
  "created_at" : "2013-12-26 01:00:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UD5ZnXYIj0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SEEcajsc",
      "display_url" : "pastebin.com\/raw.php?i=SEEc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416007329666981888",
  "text" : "http:\/\/t.co\/UD5ZnXYIj0 Emails: 3 Keywords: 0.55 #infoleak",
  "id" : 416007329666981888,
  "created_at" : "2013-12-26 00:47:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QytLtq0Yhs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wZysGfZ6",
      "display_url" : "pastebin.com\/raw.php?i=wZys\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415999410162511872",
  "text" : "http:\/\/t.co\/QytLtq0Yhs Emails: 1 Hashes: 7 E\/H: 0.14 Keywords: 0.88 #infoleak",
  "id" : 415999410162511872,
  "created_at" : "2013-12-26 00:16:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SLlGEphXeu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qj8KTU9Y",
      "display_url" : "pastebin.com\/raw.php?i=Qj8K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415998489487613952",
  "text" : "http:\/\/t.co\/SLlGEphXeu Emails: 1301 Keywords: -0.03 #infoleak",
  "id" : 415998489487613952,
  "created_at" : "2013-12-26 00:12:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RY0hKJoKpO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CWnub9Y3",
      "display_url" : "pastebin.com\/raw.php?i=CWnu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415988168098197504",
  "text" : "http:\/\/t.co\/RY0hKJoKpO Emails: 5028 Keywords: 0.0 #infoleak",
  "id" : 415988168098197504,
  "created_at" : "2013-12-25 23:31:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m0LKS5bsLo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JnXdWD4W",
      "display_url" : "pastebin.com\/raw.php?i=JnXd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415981018152050688",
  "text" : "http:\/\/t.co\/m0LKS5bsLo Emails: 21 Keywords: 0.11 #infoleak",
  "id" : 415981018152050688,
  "created_at" : "2013-12-25 23:02:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XnfhrAFuVJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HeUxejLe",
      "display_url" : "pastebin.com\/raw.php?i=HeUx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415965705331154944",
  "text" : "http:\/\/t.co\/XnfhrAFuVJ Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 415965705331154944,
  "created_at" : "2013-12-25 22:02:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5razrVbBTl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=escbbUUS",
      "display_url" : "pastebin.com\/raw.php?i=escb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415955872703987712",
  "text" : "http:\/\/t.co\/5razrVbBTl Emails: 1 Hashes: 710 E\/H: 0.0 Keywords: 0.33 #infoleak",
  "id" : 415955872703987712,
  "created_at" : "2013-12-25 21:23:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8KeZItH0zN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fTEvXbvd",
      "display_url" : "pastebin.com\/raw.php?i=fTEv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415953566335909888",
  "text" : "http:\/\/t.co\/8KeZItH0zN Emails: 891 Hashes: 913 E\/H: 0.98 Keywords: 0.44 #infoleak",
  "id" : 415953566335909888,
  "created_at" : "2013-12-25 21:13:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ufDEFGgMt8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=10JyJkrP",
      "display_url" : "pastebin.com\/raw.php?i=10Jy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415952263127908352",
  "text" : "http:\/\/t.co\/ufDEFGgMt8 Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 415952263127908352,
  "created_at" : "2013-12-25 21:08:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gsfA3anNVM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=deNkBftn",
      "display_url" : "pastebin.com\/raw.php?i=deNk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415949804246532096",
  "text" : "http:\/\/t.co\/gsfA3anNVM Emails: 101 Keywords: 0.33 #infoleak",
  "id" : 415949804246532096,
  "created_at" : "2013-12-25 20:58:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/865OQ61Q7w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4VnV1ynN",
      "display_url" : "pastebin.com\/raw.php?i=4VnV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415945211504644096",
  "text" : "http:\/\/t.co\/865OQ61Q7w Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 415945211504644096,
  "created_at" : "2013-12-25 20:40:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/quWVZNnYq9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fCQRveVg",
      "display_url" : "pastebin.com\/raw.php?i=fCQR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415938855024357377",
  "text" : "http:\/\/t.co\/quWVZNnYq9 Hashes: 1088 Keywords: 0.11 #infoleak",
  "id" : 415938855024357377,
  "created_at" : "2013-12-25 20:15:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9azp6FNpMs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T86SfH3p",
      "display_url" : "pastebin.com\/raw.php?i=T86S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415920405749059584",
  "text" : "http:\/\/t.co\/9azp6FNpMs Found possible Google API key(s) #infoleak",
  "id" : 415920405749059584,
  "created_at" : "2013-12-25 19:02:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fF6oU8t7Sc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xeLsa4NH",
      "display_url" : "pastebin.com\/raw.php?i=xeLs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415901174101852160",
  "text" : "http:\/\/t.co\/fF6oU8t7Sc Hashes: 42 Keywords: 0.22 #infoleak",
  "id" : 415901174101852160,
  "created_at" : "2013-12-25 17:45:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o1jxxkczAm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DrfEAMc2",
      "display_url" : "pastebin.com\/raw.php?i=DrfE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415894534027890688",
  "text" : "http:\/\/t.co\/o1jxxkczAm Emails: 2 Hashes: 447 E\/H: 0.0 Keywords: 0.19 #infoleak",
  "id" : 415894534027890688,
  "created_at" : "2013-12-25 17:19:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qn4WDvWgg7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LYSfr2Mg",
      "display_url" : "pastebin.com\/raw.php?i=LYSf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415890237127409664",
  "text" : "http:\/\/t.co\/Qn4WDvWgg7 Hashes: 42 Keywords: 0.22 #infoleak",
  "id" : 415890237127409664,
  "created_at" : "2013-12-25 17:02:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hzq5n5Yjxn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=18D27X14",
      "display_url" : "pastebin.com\/raw.php?i=18D2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413980827005902848",
  "text" : "http:\/\/t.co\/Hzq5n5Yjxn Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 413980827005902848,
  "created_at" : "2013-12-20 10:34:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FpopyGHxgd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PsHFfnDn",
      "display_url" : "pastebin.com\/raw.php?i=PsHF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413951239634698240",
  "text" : "http:\/\/t.co\/FpopyGHxgd Found possible Google API key(s) #infoleak",
  "id" : 413951239634698240,
  "created_at" : "2013-12-20 08:37:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mIJg84YTHW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PZ2hvBAe",
      "display_url" : "pastebin.com\/raw.php?i=PZ2h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413950775925018624",
  "text" : "http:\/\/t.co\/mIJg84YTHW Keywords: 0.55 #infoleak",
  "id" : 413950775925018624,
  "created_at" : "2013-12-20 08:35:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yttu0a9ciX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gNqEcVeg",
      "display_url" : "pastebin.com\/raw.php?i=gNqE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413935568100134913",
  "text" : "http:\/\/t.co\/Yttu0a9ciX Found possible Google API key(s) #infoleak",
  "id" : 413935568100134913,
  "created_at" : "2013-12-20 07:35:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vJ5n1xYdmy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tcYatFHh",
      "display_url" : "pastebin.com\/raw.php?i=tcYa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413897638191169536",
  "text" : "http:\/\/t.co\/vJ5n1xYdmy Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 413897638191169536,
  "created_at" : "2013-12-20 05:04:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3G5vbHyVuA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W0uC2zYJ",
      "display_url" : "pastebin.com\/raw.php?i=W0uC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413894952586727424",
  "text" : "http:\/\/t.co\/3G5vbHyVuA Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 413894952586727424,
  "created_at" : "2013-12-20 04:53:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gOKH8HAE1q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AdFsj9gk",
      "display_url" : "pastebin.com\/raw.php?i=AdFs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413893427487449088",
  "text" : "http:\/\/t.co\/gOKH8HAE1q Emails: 79 Keywords: 0.0 #infoleak",
  "id" : 413893427487449088,
  "created_at" : "2013-12-20 04:47:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/90bdAK51I3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7GMKkXZ1",
      "display_url" : "pastebin.com\/raw.php?i=7GMK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413885574987010048",
  "text" : "http:\/\/t.co\/90bdAK51I3 Emails: 93 Keywords: 0.0 #infoleak",
  "id" : 413885574987010048,
  "created_at" : "2013-12-20 04:16:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yllTl9qFAd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EXDUjQyi",
      "display_url" : "pastebin.com\/raw.php?i=EXDU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412931603413757952",
  "text" : "http:\/\/t.co\/yllTl9qFAd Emails: 619 Keywords: 0.19 #infoleak",
  "id" : 412931603413757952,
  "created_at" : "2013-12-17 13:05:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HPAuP6a8m9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=z8TQWhPy",
      "display_url" : "pastebin.com\/raw.php?i=z8TQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412925901223886848",
  "text" : "http:\/\/t.co\/HPAuP6a8m9 Emails: 29 Keywords: 0.22 #infoleak",
  "id" : 412925901223886848,
  "created_at" : "2013-12-17 12:43:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WIykICYmUQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BsMfg2Ls",
      "display_url" : "pastebin.com\/raw.php?i=BsMf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412917603326111744",
  "text" : "http:\/\/t.co\/WIykICYmUQ Found possible Google API key(s) #infoleak",
  "id" : 412917603326111744,
  "created_at" : "2013-12-17 12:10:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MvQYDUfQFz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zz8cYwD1",
      "display_url" : "pastebin.com\/raw.php?i=Zz8c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412904434855710720",
  "text" : "http:\/\/t.co\/MvQYDUfQFz Hashes: 38 Keywords: 0.22 #infoleak",
  "id" : 412904434855710720,
  "created_at" : "2013-12-17 11:17:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OugPgpzNSP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zNqXdmq0",
      "display_url" : "pastebin.com\/raw.php?i=zNqX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412903480601235456",
  "text" : "http:\/\/t.co\/OugPgpzNSP Found possible Google API key(s) #infoleak",
  "id" : 412903480601235456,
  "created_at" : "2013-12-17 11:13:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Js56Hlo2gp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mYPq6q4m",
      "display_url" : "pastebin.com\/raw.php?i=mYPq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412898137116647424",
  "text" : "http:\/\/t.co\/Js56Hlo2gp Found possible Google API key(s) #infoleak",
  "id" : 412898137116647424,
  "created_at" : "2013-12-17 10:52:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xjVb3nk3mT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hpZU9yZv",
      "display_url" : "pastebin.com\/raw.php?i=hpZU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412894974141681664",
  "text" : "http:\/\/t.co\/xjVb3nk3mT Found possible Google API key(s) #infoleak",
  "id" : 412894974141681664,
  "created_at" : "2013-12-17 10:40:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IEdkjRczTL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UAyPrmpB",
      "display_url" : "pastebin.com\/raw.php?i=UAyP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412891206683594752",
  "text" : "http:\/\/t.co\/IEdkjRczTL Found possible Google API key(s) #infoleak",
  "id" : 412891206683594752,
  "created_at" : "2013-12-17 10:25:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZgesEXgEX5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=56JaPfH7",
      "display_url" : "pastebin.com\/raw.php?i=56Ja\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412872231845232641",
  "text" : "http:\/\/t.co\/ZgesEXgEX5 Hashes: 88 Keywords: -0.28 #infoleak",
  "id" : 412872231845232641,
  "created_at" : "2013-12-17 09:09:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hAA1pQ78Al",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gafm1m1z",
      "display_url" : "pastebin.com\/raw.php?i=gafm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412846796281348096",
  "text" : "http:\/\/t.co\/hAA1pQ78Al Emails: 2 Keywords: 0.55 #infoleak",
  "id" : 412846796281348096,
  "created_at" : "2013-12-17 07:28:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wCMPPIqGQV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DNV8z3Vn",
      "display_url" : "pastebin.com\/raw.php?i=DNV8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412797152767643648",
  "text" : "http:\/\/t.co\/wCMPPIqGQV Emails: 556 Keywords: 0.0 #infoleak",
  "id" : 412797152767643648,
  "created_at" : "2013-12-17 04:11:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LtitoDNfPV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wvN7mA3c",
      "display_url" : "pastebin.com\/raw.php?i=wvN7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412775217056854017",
  "text" : "http:\/\/t.co\/LtitoDNfPV Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 412775217056854017,
  "created_at" : "2013-12-17 02:44:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t1zDCQYFdA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W1jyKrjA",
      "display_url" : "pastebin.com\/raw.php?i=W1jy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412771433719164928",
  "text" : "http:\/\/t.co\/t1zDCQYFdA Found possible Google API key(s) #infoleak",
  "id" : 412771433719164928,
  "created_at" : "2013-12-17 02:29:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ESVnD2PeID",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hudXsXL1",
      "display_url" : "pastebin.com\/raw.php?i=hudX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412731310579273728",
  "text" : "http:\/\/t.co\/ESVnD2PeID Keywords: 0.55 #infoleak",
  "id" : 412731310579273728,
  "created_at" : "2013-12-16 23:49:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YtNp1XtDyI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hxQHgxB6",
      "display_url" : "pastebin.com\/raw.php?i=hxQH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412714791493332992",
  "text" : "http:\/\/t.co\/YtNp1XtDyI Found possible Google API key(s) #infoleak",
  "id" : 412714791493332992,
  "created_at" : "2013-12-16 22:44:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2uE8hSPePD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=snDgNhq5",
      "display_url" : "pastebin.com\/raw.php?i=snDg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412709652787257345",
  "text" : "http:\/\/t.co\/2uE8hSPePD Found possible Google API key(s) #infoleak",
  "id" : 412709652787257345,
  "created_at" : "2013-12-16 22:23:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bokEDk1k6o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5nFSiSRt",
      "display_url" : "pastebin.com\/raw.php?i=5nFS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412701117173080065",
  "text" : "http:\/\/t.co\/bokEDk1k6o Found possible Google API key(s) #infoleak",
  "id" : 412701117173080065,
  "created_at" : "2013-12-16 21:49:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kdw3ZBU4ln",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9vtDi9Uk",
      "display_url" : "pastebin.com\/raw.php?i=9vtD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412699510293274624",
  "text" : "http:\/\/t.co\/kdw3ZBU4ln Found possible Google API key(s) #infoleak",
  "id" : 412699510293274624,
  "created_at" : "2013-12-16 21:43:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HlEfYRhpuP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eHuK8ujb",
      "display_url" : "pastebin.com\/raw.php?i=eHuK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412694881685884928",
  "text" : "http:\/\/t.co\/HlEfYRhpuP Emails: 114 Keywords: 0.11 #infoleak",
  "id" : 412694881685884928,
  "created_at" : "2013-12-16 21:25:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mh0s4XHAzl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sS7WaY4R",
      "display_url" : "pastebin.com\/raw.php?i=sS7W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412693659394387968",
  "text" : "http:\/\/t.co\/mh0s4XHAzl Found possible Google API key(s) #infoleak",
  "id" : 412693659394387968,
  "created_at" : "2013-12-16 21:20:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Fy8zY7ouK1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HsgDEuVC",
      "display_url" : "pastebin.com\/raw.php?i=HsgD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412693103581999104",
  "text" : "http:\/\/t.co\/Fy8zY7ouK1 Hashes: 70 Keywords: 0.22 #infoleak",
  "id" : 412693103581999104,
  "created_at" : "2013-12-16 21:17:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nOdFILHLhp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VM1m6dyt",
      "display_url" : "pastebin.com\/raw.php?i=VM1m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412537188690038785",
  "text" : "http:\/\/t.co\/nOdFILHLhp Emails: 556 Keywords: 0.0 #infoleak",
  "id" : 412537188690038785,
  "created_at" : "2013-12-16 10:58:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C7DUVnNKKu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6LUhhk1E",
      "display_url" : "pastebin.com\/raw.php?i=6LUh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412522472806694912",
  "text" : "http:\/\/t.co\/C7DUVnNKKu Found possible Google API key(s) #infoleak",
  "id" : 412522472806694912,
  "created_at" : "2013-12-16 09:59:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ov8ocO6EXC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JL6zWn8N",
      "display_url" : "pastebin.com\/raw.php?i=JL6z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412504898240921600",
  "text" : "http:\/\/t.co\/ov8ocO6EXC Possible cisco configuration #infoleak",
  "id" : 412504898240921600,
  "created_at" : "2013-12-16 08:50:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/65S9oZWebi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rm83c6fW",
      "display_url" : "pastebin.com\/raw.php?i=rm83\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412493729937637376",
  "text" : "http:\/\/t.co\/65S9oZWebi Emails: 2494 Keywords: 0.33 #infoleak",
  "id" : 412493729937637376,
  "created_at" : "2013-12-16 08:05:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kzh3gOVScE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jpxvEqJJ",
      "display_url" : "pastebin.com\/raw.php?i=jpxv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412383812421562368",
  "text" : "http:\/\/t.co\/kzh3gOVScE Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 412383812421562368,
  "created_at" : "2013-12-16 00:48:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SA7mDCETXI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Aux3JCRa",
      "display_url" : "pastebin.com\/raw.php?i=Aux3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412380353672663040",
  "text" : "http:\/\/t.co\/SA7mDCETXI Emails: 36 Keywords: 0.22 #infoleak",
  "id" : 412380353672663040,
  "created_at" : "2013-12-16 00:35:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yExbJJetmX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gyFkLQ03",
      "display_url" : "pastebin.com\/raw.php?i=gyFk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412378509441384448",
  "text" : "http:\/\/t.co\/yExbJJetmX Emails: 116 Hashes: 118 E\/H: 0.98 Keywords: 0.22 #infoleak",
  "id" : 412378509441384448,
  "created_at" : "2013-12-16 00:27:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aiolKB7oJt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EUzameQk",
      "display_url" : "pastebin.com\/raw.php?i=EUza\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412367982455574528",
  "text" : "http:\/\/t.co\/aiolKB7oJt Emails: 25 Keywords: 0.11 #infoleak",
  "id" : 412367982455574528,
  "created_at" : "2013-12-15 23:46:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mljqkz20te",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ALhAymyJ",
      "display_url" : "pastebin.com\/raw.php?i=ALhA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412363156371939331",
  "text" : "http:\/\/t.co\/mljqkz20te Emails: 2236 Keywords: 0.33 #infoleak",
  "id" : 412363156371939331,
  "created_at" : "2013-12-15 23:26:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zZwzwzsKZP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WNqWgTQD",
      "display_url" : "pastebin.com\/raw.php?i=WNqW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412360814981435392",
  "text" : "http:\/\/t.co\/zZwzwzsKZP Found possible Google API key(s) #infoleak",
  "id" : 412360814981435392,
  "created_at" : "2013-12-15 23:17:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Vnj0mC5XMT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RrCyd5j6",
      "display_url" : "pastebin.com\/raw.php?i=RrCy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412351490922012672",
  "text" : "http:\/\/t.co\/Vnj0mC5XMT Emails: 77 Keywords: 0.0 #infoleak",
  "id" : 412351490922012672,
  "created_at" : "2013-12-15 22:40:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3JQquoOkya",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1XBHcZE6",
      "display_url" : "pastebin.com\/raw.php?i=1XBH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412345555944079360",
  "text" : "http:\/\/t.co\/3JQquoOkya Emails: 258 Keywords: 0.0 #infoleak",
  "id" : 412345555944079360,
  "created_at" : "2013-12-15 22:16:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qJWFRL9o89",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n2GW1zEX",
      "display_url" : "pastebin.com\/raw.php?i=n2GW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412341794051874816",
  "text" : "http:\/\/t.co\/qJWFRL9o89 Hashes: 102 Keywords: 0.22 #infoleak",
  "id" : 412341794051874816,
  "created_at" : "2013-12-15 22:01:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/twhPKjFXqv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m57CAKb7",
      "display_url" : "pastebin.com\/raw.php?i=m57C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412338716779089920",
  "text" : "http:\/\/t.co\/twhPKjFXqv Hashes: 167 Keywords: 0.0 #infoleak",
  "id" : 412338716779089920,
  "created_at" : "2013-12-15 21:49:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e6PhMS5tse",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DbsgkyPK",
      "display_url" : "pastebin.com\/raw.php?i=Dbsg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412327809399287808",
  "text" : "http:\/\/t.co\/e6PhMS5tse Found possible Google API key(s) #infoleak",
  "id" : 412327809399287808,
  "created_at" : "2013-12-15 21:06:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HiLQiSD6Fn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jqym942p",
      "display_url" : "pastebin.com\/raw.php?i=Jqym\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412313842601836544",
  "text" : "http:\/\/t.co\/HiLQiSD6Fn Emails: 2 Hashes: 543 E\/H: 0.0 Keywords: 0.19 #infoleak",
  "id" : 412313842601836544,
  "created_at" : "2013-12-15 20:10:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jyfMAByPbv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UvstCzBP",
      "display_url" : "pastebin.com\/raw.php?i=Uvst\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412295837402681345",
  "text" : "http:\/\/t.co\/jyfMAByPbv Hashes: 79 Keywords: 0.0 #infoleak",
  "id" : 412295837402681345,
  "created_at" : "2013-12-15 18:59:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0ihod2zOde",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nrNdJ3mT",
      "display_url" : "pastebin.com\/raw.php?i=nrNd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412290975571013632",
  "text" : "http:\/\/t.co\/0ihod2zOde Hashes: 49 Keywords: 0.0 #infoleak",
  "id" : 412290975571013632,
  "created_at" : "2013-12-15 18:40:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GFCFWLvTTO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ksepu7LK",
      "display_url" : "pastebin.com\/raw.php?i=Ksep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412290369758310400",
  "text" : "http:\/\/t.co\/GFCFWLvTTO Found possible Google API key(s) #infoleak",
  "id" : 412290369758310400,
  "created_at" : "2013-12-15 18:37:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CK5MkySCQF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wpEcfA1s",
      "display_url" : "pastebin.com\/raw.php?i=wpEc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412249275246981121",
  "text" : "http:\/\/t.co\/CK5MkySCQF Emails: 44 Hashes: 53 E\/H: 0.83 Keywords: 0.11 #infoleak",
  "id" : 412249275246981121,
  "created_at" : "2013-12-15 15:54:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uCy9IMbiHd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n2RauR67",
      "display_url" : "pastebin.com\/raw.php?i=n2Ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412244975854690304",
  "text" : "http:\/\/t.co\/uCy9IMbiHd Emails: 31 Keywords: 0.0 #infoleak",
  "id" : 412244975854690304,
  "created_at" : "2013-12-15 15:37:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yWJZs3Y6d3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CEYJyP1V",
      "display_url" : "pastebin.com\/raw.php?i=CEYJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412242999930654720",
  "text" : "http:\/\/t.co\/yWJZs3Y6d3 Hashes: 77 Keywords: 0.22 #infoleak",
  "id" : 412242999930654720,
  "created_at" : "2013-12-15 15:29:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rkj6USBMF4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4P80kmy7",
      "display_url" : "pastebin.com\/raw.php?i=4P80\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412196985785966592",
  "text" : "http:\/\/t.co\/rkj6USBMF4 Emails: 103 Keywords: 0.11 #infoleak",
  "id" : 412196985785966592,
  "created_at" : "2013-12-15 12:26:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dcwS637dOl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MWLEP2Lr",
      "display_url" : "pastebin.com\/raw.php?i=MWLE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412188427283492864",
  "text" : "http:\/\/t.co\/dcwS637dOl Emails: 41 Keywords: 0.22 #infoleak",
  "id" : 412188427283492864,
  "created_at" : "2013-12-15 11:52:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qylx91x8Z1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zsCS5NXR",
      "display_url" : "pastebin.com\/raw.php?i=zsCS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412184715731288064",
  "text" : "http:\/\/t.co\/Qylx91x8Z1 Hashes: 34 Keywords: 0.11 #infoleak",
  "id" : 412184715731288064,
  "created_at" : "2013-12-15 11:37:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LT59XhhYkC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tAXbSMYD",
      "display_url" : "pastebin.com\/raw.php?i=tAXb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412174911466008577",
  "text" : "http:\/\/t.co\/LT59XhhYkC Found possible Google API key(s) #infoleak",
  "id" : 412174911466008577,
  "created_at" : "2013-12-15 10:58:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fOhxKI4uk9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6Pgf9Nec",
      "display_url" : "pastebin.com\/raw.php?i=6Pgf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412171293002194944",
  "text" : "http:\/\/t.co\/fOhxKI4uk9 Keywords: 0.63 #infoleak",
  "id" : 412171293002194944,
  "created_at" : "2013-12-15 10:44:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YvLzrQhMIQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QjCJss4z",
      "display_url" : "pastebin.com\/raw.php?i=QjCJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412165557438271489",
  "text" : "http:\/\/t.co\/YvLzrQhMIQ Emails: 96 Keywords: 0.0 #infoleak",
  "id" : 412165557438271489,
  "created_at" : "2013-12-15 10:21:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5vamtaQf44",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x4RvHmbE",
      "display_url" : "pastebin.com\/raw.php?i=x4Rv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412165179606966272",
  "text" : "http:\/\/t.co\/5vamtaQf44 Found possible Google API key(s) #infoleak",
  "id" : 412165179606966272,
  "created_at" : "2013-12-15 10:20:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PdeXL37dXp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fBnT6rPQ",
      "display_url" : "pastebin.com\/raw.php?i=fBnT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412161915054346240",
  "text" : "http:\/\/t.co\/PdeXL37dXp Emails: 134 Keywords: 0.0 #infoleak",
  "id" : 412161915054346240,
  "created_at" : "2013-12-15 10:07:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TY9vNS0mnO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ExNVKxyG",
      "display_url" : "pastebin.com\/raw.php?i=ExNV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412157784981905408",
  "text" : "http:\/\/t.co\/TY9vNS0mnO Hashes: 34 Keywords: 0.22 #infoleak",
  "id" : 412157784981905408,
  "created_at" : "2013-12-15 09:50:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VR4qqjr5Cx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EtUxJpsT",
      "display_url" : "pastebin.com\/raw.php?i=EtUx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412136392114708481",
  "text" : "http:\/\/t.co\/VR4qqjr5Cx Emails: 1494 Hashes: 1574 E\/H: 0.95 Keywords: 0.44 #infoleak",
  "id" : 412136392114708481,
  "created_at" : "2013-12-15 08:25:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Y67PxI4GZN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dXAeQ4hc",
      "display_url" : "pastebin.com\/raw.php?i=dXAe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412136058013249536",
  "text" : "http:\/\/t.co\/Y67PxI4GZN Emails: 678 Hashes: 20 E\/H: 33.9 Keywords: 0.19 #infoleak",
  "id" : 412136058013249536,
  "created_at" : "2013-12-15 08:24:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hTbe9bSDdH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7MybFZeG",
      "display_url" : "pastebin.com\/raw.php?i=7Myb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412124808797642753",
  "text" : "http:\/\/t.co\/hTbe9bSDdH Emails: 116 Hashes: 123 E\/H: 0.94 Keywords: 0.08 #infoleak",
  "id" : 412124808797642753,
  "created_at" : "2013-12-15 07:39:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8Broo2sZ6S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=steXeVhE",
      "display_url" : "pastebin.com\/raw.php?i=steX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412120926885380096",
  "text" : "http:\/\/t.co\/8Broo2sZ6S Emails: 6452 Hashes: 6604 E\/H: 0.98 Keywords: 0.3 #infoleak",
  "id" : 412120926885380096,
  "created_at" : "2013-12-15 07:24:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n3UlCToYH5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NHS7bD6m",
      "display_url" : "pastebin.com\/raw.php?i=NHS7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412120164562255872",
  "text" : "http:\/\/t.co\/n3UlCToYH5 Emails: 4485 Hashes: 5142 E\/H: 0.87 Keywords: 0.11 #infoleak",
  "id" : 412120164562255872,
  "created_at" : "2013-12-15 07:21:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5xWNaVG1rq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LGsCSYup",
      "display_url" : "pastebin.com\/raw.php?i=LGsC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412094798892240896",
  "text" : "http:\/\/t.co\/5xWNaVG1rq Found possible Google API key(s) #infoleak",
  "id" : 412094798892240896,
  "created_at" : "2013-12-15 05:40:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ST7JNzWogz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ejCKtX8P",
      "display_url" : "pastebin.com\/raw.php?i=ejCK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412079034105753600",
  "text" : "http:\/\/t.co\/ST7JNzWogz Emails: 4 Hashes: 50 E\/H: 0.08 Keywords: 0.27 #infoleak",
  "id" : 412079034105753600,
  "created_at" : "2013-12-15 04:37:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jFTm4WwanH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vqHnR1Ah",
      "display_url" : "pastebin.com\/raw.php?i=vqHn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412028301897498624",
  "text" : "http:\/\/t.co\/jFTm4WwanH Emails: 1 Hashes: 35 E\/H: 0.03 Keywords: 0.22 #infoleak",
  "id" : 412028301897498624,
  "created_at" : "2013-12-15 01:16:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cDJTpD8dX4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rUE48jFx",
      "display_url" : "pastebin.com\/raw.php?i=rUE4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412016732648120320",
  "text" : "http:\/\/t.co\/cDJTpD8dX4 Emails: 1275 Keywords: -0.03 #infoleak",
  "id" : 412016732648120320,
  "created_at" : "2013-12-15 00:30:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bp2r09C840",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2Pier0ng",
      "display_url" : "pastebin.com\/raw.php?i=2Pie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412005890997248000",
  "text" : "http:\/\/t.co\/bp2r09C840 Hashes: 90 Keywords: -0.17 #infoleak",
  "id" : 412005890997248000,
  "created_at" : "2013-12-14 23:47:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LJnbdmpsFm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UmYjJv1T",
      "display_url" : "pastebin.com\/raw.php?i=UmYj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411966774175744000",
  "text" : "http:\/\/t.co\/LJnbdmpsFm Found possible Google API key(s) #infoleak",
  "id" : 411966774175744000,
  "created_at" : "2013-12-14 21:11:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LDGp9Tk8VJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SF1vvZE6",
      "display_url" : "pastebin.com\/raw.php?i=SF1v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411965775553904640",
  "text" : "http:\/\/t.co\/LDGp9Tk8VJ Emails: 142 Keywords: 0.11 #infoleak",
  "id" : 411965775553904640,
  "created_at" : "2013-12-14 21:07:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xlzfLkXZMN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hPUCzGBX",
      "display_url" : "pastebin.com\/raw.php?i=hPUC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411943325252341760",
  "text" : "http:\/\/t.co\/xlzfLkXZMN Hashes: 44 Keywords: 0.08 #infoleak",
  "id" : 411943325252341760,
  "created_at" : "2013-12-14 19:38:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tXb48ZWSQv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Wzj3tfqP",
      "display_url" : "pastebin.com\/raw.php?i=Wzj3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411941647706902528",
  "text" : "http:\/\/t.co\/tXb48ZWSQv Emails: 3569 Keywords: 0.33 #infoleak",
  "id" : 411941647706902528,
  "created_at" : "2013-12-14 19:31:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O8feOhxvlO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aNWcuR9W",
      "display_url" : "pastebin.com\/raw.php?i=aNWc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411939501015969792",
  "text" : "http:\/\/t.co\/O8feOhxvlO Emails: 245 Hashes: 2 E\/H: 122.5 Keywords: 0.41 #infoleak",
  "id" : 411939501015969792,
  "created_at" : "2013-12-14 19:23:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u2Oc1htun3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hn3jBGrJ",
      "display_url" : "pastebin.com\/raw.php?i=Hn3j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411937245654831105",
  "text" : "http:\/\/t.co\/u2Oc1htun3 Hashes: 103 Keywords: 0.11 #infoleak",
  "id" : 411937245654831105,
  "created_at" : "2013-12-14 19:14:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GZoYaq1L4Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KckWMTyr",
      "display_url" : "pastebin.com\/raw.php?i=KckW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411935702977241088",
  "text" : "http:\/\/t.co\/GZoYaq1L4Y Emails: 6428 Keywords: 0.11 #infoleak",
  "id" : 411935702977241088,
  "created_at" : "2013-12-14 19:08:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wY4jyqjq24",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gDC17D1R",
      "display_url" : "pastebin.com\/raw.php?i=gDC1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411932197466025984",
  "text" : "http:\/\/t.co\/wY4jyqjq24 Emails: 209 Keywords: 0.0 #infoleak",
  "id" : 411932197466025984,
  "created_at" : "2013-12-14 18:54:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Il9e6LnGDh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mz63wJ8C",
      "display_url" : "pastebin.com\/raw.php?i=Mz63\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411930172745478144",
  "text" : "http:\/\/t.co\/Il9e6LnGDh Found possible Google API key(s) #infoleak",
  "id" : 411930172745478144,
  "created_at" : "2013-12-14 18:46:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LUCU6zaElV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E28dBHkU",
      "display_url" : "pastebin.com\/raw.php?i=E28d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411927475266940928",
  "text" : "http:\/\/t.co\/LUCU6zaElV Emails: 108 Keywords: 0.22 #infoleak",
  "id" : 411927475266940928,
  "created_at" : "2013-12-14 18:35:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YhQQxLLadi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u7xAyhwB",
      "display_url" : "pastebin.com\/raw.php?i=u7xA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411917251223113728",
  "text" : "http:\/\/t.co\/YhQQxLLadi Emails: 9973 Keywords: 0.19 #infoleak",
  "id" : 411917251223113728,
  "created_at" : "2013-12-14 17:55:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/odMH0jknSM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hw4HKygC",
      "display_url" : "pastebin.com\/raw.php?i=hw4H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411916327243096064",
  "text" : "http:\/\/t.co\/odMH0jknSM Hashes: 501 Keywords: 0.22 #infoleak",
  "id" : 411916327243096064,
  "created_at" : "2013-12-14 17:51:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NiuRKhlXoN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PN2i7HY8",
      "display_url" : "pastebin.com\/raw.php?i=PN2i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411903097879814144",
  "text" : "http:\/\/t.co\/NiuRKhlXoN Emails: 4367 Hashes: 4987 E\/H: 0.88 Keywords: 0.3 #infoleak",
  "id" : 411903097879814144,
  "created_at" : "2013-12-14 16:58:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mpk0D3VUXQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FfJ5cZN7",
      "display_url" : "pastebin.com\/raw.php?i=FfJ5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411901975291121664",
  "text" : "http:\/\/t.co\/mpk0D3VUXQ Hashes: 44 Keywords: 0.08 #infoleak",
  "id" : 411901975291121664,
  "created_at" : "2013-12-14 16:54:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eQoDPeq9H1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pMRXPZ15",
      "display_url" : "pastebin.com\/raw.php?i=pMRX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411822797040529410",
  "text" : "http:\/\/t.co\/eQoDPeq9H1 Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 411822797040529410,
  "created_at" : "2013-12-14 11:39:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/deh2YJQN9D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EaujjSuh",
      "display_url" : "pastebin.com\/raw.php?i=Eauj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411818671787343872",
  "text" : "http:\/\/t.co\/deh2YJQN9D Emails: 4028 Hashes: 4027 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 411818671787343872,
  "created_at" : "2013-12-14 11:23:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iAhdf9tml3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RVK7qH3E",
      "display_url" : "pastebin.com\/raw.php?i=RVK7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411714212923072512",
  "text" : "http:\/\/t.co\/iAhdf9tml3 Hashes: 550 Keywords: -0.03 #infoleak",
  "id" : 411714212923072512,
  "created_at" : "2013-12-14 04:28:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Vla7cNS5tg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KFZ9NQY7",
      "display_url" : "pastebin.com\/raw.php?i=KFZ9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411710614818406400",
  "text" : "http:\/\/t.co\/Vla7cNS5tg Found possible Google API key(s) #infoleak",
  "id" : 411710614818406400,
  "created_at" : "2013-12-14 04:13:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gGZ65ORQpd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9qHZZw7A",
      "display_url" : "pastebin.com\/raw.php?i=9qHZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411705485717282816",
  "text" : "http:\/\/t.co\/gGZ65ORQpd Emails: 23 Keywords: 0.22 #infoleak",
  "id" : 411705485717282816,
  "created_at" : "2013-12-14 03:53:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wYtIpmUkqm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tP4FRswi",
      "display_url" : "pastebin.com\/raw.php?i=tP4F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411682879802851328",
  "text" : "http:\/\/t.co\/wYtIpmUkqm Found possible Google API key(s) #infoleak",
  "id" : 411682879802851328,
  "created_at" : "2013-12-14 02:23:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H7GC6i3GY0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hkfbt1tD",
      "display_url" : "pastebin.com\/raw.php?i=Hkfb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411673864574234624",
  "text" : "http:\/\/t.co\/H7GC6i3GY0 Hashes: 647 Keywords: -0.03 #infoleak",
  "id" : 411673864574234624,
  "created_at" : "2013-12-14 01:47:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zrsiVOH9BX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bendevN1",
      "display_url" : "pastebin.com\/raw.php?i=bend\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411672048184745984",
  "text" : "http:\/\/t.co\/zrsiVOH9BX Emails: 31 Keywords: 0.11 #infoleak",
  "id" : 411672048184745984,
  "created_at" : "2013-12-14 01:40:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/onae4q484E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eS1jff0p",
      "display_url" : "pastebin.com\/raw.php?i=eS1j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411671232040300544",
  "text" : "http:\/\/t.co\/onae4q484E Emails: 31 Keywords: 0.11 #infoleak",
  "id" : 411671232040300544,
  "created_at" : "2013-12-14 01:37:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OmDIYD84Lh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kA56xBx7",
      "display_url" : "pastebin.com\/raw.php?i=kA56\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411670415983927296",
  "text" : "http:\/\/t.co\/OmDIYD84Lh Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 411670415983927296,
  "created_at" : "2013-12-14 01:34:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3cduyt1Gnh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qL9VpHeP",
      "display_url" : "pastebin.com\/raw.php?i=qL9V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411664822657249281",
  "text" : "http:\/\/t.co\/3cduyt1Gnh Keywords: 0.55 #infoleak",
  "id" : 411664822657249281,
  "created_at" : "2013-12-14 01:11:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NME3GRNMsT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HzXyhSSL",
      "display_url" : "pastebin.com\/raw.php?i=HzXy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411655113816551425",
  "text" : "http:\/\/t.co\/NME3GRNMsT Emails: 31 Keywords: 0.11 #infoleak",
  "id" : 411655113816551425,
  "created_at" : "2013-12-14 00:33:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rgHRd5awxg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z5dtwpAM",
      "display_url" : "pastebin.com\/raw.php?i=Z5dt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411651655860363264",
  "text" : "http:\/\/t.co\/rgHRd5awxg Hashes: 33 Keywords: 0.0 #infoleak",
  "id" : 411651655860363264,
  "created_at" : "2013-12-14 00:19:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1Ax7Gzak7r",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PGJSZBjX",
      "display_url" : "pastebin.com\/raw.php?i=PGJS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411630407809900545",
  "text" : "http:\/\/t.co\/1Ax7Gzak7r Emails: 33 Keywords: 0.0 #infoleak",
  "id" : 411630407809900545,
  "created_at" : "2013-12-13 22:55:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HiSwjbQkzG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dUngnc2t",
      "display_url" : "pastebin.com\/raw.php?i=dUng\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411623024673038336",
  "text" : "http:\/\/t.co\/HiSwjbQkzG Emails: 638 Keywords: 0.19 #infoleak",
  "id" : 411623024673038336,
  "created_at" : "2013-12-13 22:25:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n7hbsUMhc8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2D1hXFNM",
      "display_url" : "pastebin.com\/raw.php?i=2D1h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411621527231012864",
  "text" : "http:\/\/t.co\/n7hbsUMhc8 Emails: 176 Keywords: 0.11 #infoleak",
  "id" : 411621527231012864,
  "created_at" : "2013-12-13 22:19:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ggtLn2tDPI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fn8us915",
      "display_url" : "pastebin.com\/raw.php?i=Fn8u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411620958630191104",
  "text" : "http:\/\/t.co\/ggtLn2tDPI Emails: 4358 Hashes: 1 E\/H: 4358.0 Keywords: 0.11 #infoleak",
  "id" : 411620958630191104,
  "created_at" : "2013-12-13 22:17:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QLt8a0pW1m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MZqDZYJT",
      "display_url" : "pastebin.com\/raw.php?i=MZqD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411612041929953280",
  "text" : "http:\/\/t.co\/QLt8a0pW1m Found possible Google API key(s) #infoleak",
  "id" : 411612041929953280,
  "created_at" : "2013-12-13 21:42:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qkz3VcaKl4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SdNHJyi1",
      "display_url" : "pastebin.com\/raw.php?i=SdNH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411609266257014786",
  "text" : "http:\/\/t.co\/qkz3VcaKl4 Emails: 116 Hashes: 3 E\/H: 38.67 Keywords: 0.66 #infoleak",
  "id" : 411609266257014786,
  "created_at" : "2013-12-13 21:31:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pV5rNMqiP4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fgc7457y",
      "display_url" : "pastebin.com\/raw.php?i=Fgc7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411608994562592768",
  "text" : "http:\/\/t.co\/pV5rNMqiP4 Hashes: 83 Keywords: 0.0 #infoleak",
  "id" : 411608994562592768,
  "created_at" : "2013-12-13 21:30:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tOzsmaHIho",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sxQGzdCd",
      "display_url" : "pastebin.com\/raw.php?i=sxQG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411600122854658048",
  "text" : "http:\/\/t.co\/tOzsmaHIho Found possible Google API key(s) #infoleak",
  "id" : 411600122854658048,
  "created_at" : "2013-12-13 20:54:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C60rMwIFMu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gBhUvXKa",
      "display_url" : "pastebin.com\/raw.php?i=gBhU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411574829263757313",
  "text" : "http:\/\/t.co\/C60rMwIFMu Emails: 29 Keywords: -0.14 #infoleak",
  "id" : 411574829263757313,
  "created_at" : "2013-12-13 19:14:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EeYgplSk3a",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=60BMkGTZ",
      "display_url" : "pastebin.com\/raw.php?i=60BM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411567288169414656",
  "text" : "http:\/\/t.co\/EeYgplSk3a Emails: 4383 Keywords: 0.0 #infoleak",
  "id" : 411567288169414656,
  "created_at" : "2013-12-13 18:44:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lbQhrASipd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q2duRFgT",
      "display_url" : "pastebin.com\/raw.php?i=q2du\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411558007063859200",
  "text" : "http:\/\/t.co\/lbQhrASipd Found possible Google API key(s) #infoleak",
  "id" : 411558007063859200,
  "created_at" : "2013-12-13 18:07:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vQzwtUZCMx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dyZcYUmM",
      "display_url" : "pastebin.com\/raw.php?i=dyZc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411544391325466624",
  "text" : "http:\/\/t.co\/vQzwtUZCMx Hashes: 69 Keywords: 0.22 #infoleak",
  "id" : 411544391325466624,
  "created_at" : "2013-12-13 17:13:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u188TVz5ld",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MRDBhWLw",
      "display_url" : "pastebin.com\/raw.php?i=MRDB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411537391917076480",
  "text" : "http:\/\/t.co\/u188TVz5ld Hashes: 35 Keywords: 0.11 #infoleak",
  "id" : 411537391917076480,
  "created_at" : "2013-12-13 16:45:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jub0yAHNcd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zgaptNfh",
      "display_url" : "pastebin.com\/raw.php?i=zgap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411531067426742272",
  "text" : "http:\/\/t.co\/jub0yAHNcd Hashes: 66 Keywords: 0.22 #infoleak",
  "id" : 411531067426742272,
  "created_at" : "2013-12-13 16:20:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r7JyJaMzNC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J9mFt1DX",
      "display_url" : "pastebin.com\/raw.php?i=J9mF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411525375357751296",
  "text" : "http:\/\/t.co\/r7JyJaMzNC Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 411525375357751296,
  "created_at" : "2013-12-13 15:57:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4xPRFVOWCn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SJijJfB3",
      "display_url" : "pastebin.com\/raw.php?i=SJij\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411515683931815937",
  "text" : "http:\/\/t.co\/4xPRFVOWCn Hashes: 33 Keywords: 0.22 #infoleak",
  "id" : 411515683931815937,
  "created_at" : "2013-12-13 15:19:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W2STfbZw65",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r3QjYe6W",
      "display_url" : "pastebin.com\/raw.php?i=r3Qj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411511000160952320",
  "text" : "http:\/\/t.co\/W2STfbZw65 Hashes: 98 Keywords: 0.0 #infoleak",
  "id" : 411511000160952320,
  "created_at" : "2013-12-13 15:00:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gpnXwjHbQ3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2TXZaTp0",
      "display_url" : "pastebin.com\/raw.php?i=2TXZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411502017366876160",
  "text" : "http:\/\/t.co\/gpnXwjHbQ3 Emails: 7528 Hashes: 57 E\/H: 132.07 Keywords: 0.33 #infoleak",
  "id" : 411502017366876160,
  "created_at" : "2013-12-13 14:25:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ojwWKwwVnh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sX8x5MYG",
      "display_url" : "pastebin.com\/raw.php?i=sX8x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411491398655815680",
  "text" : "http:\/\/t.co\/ojwWKwwVnh Emails: 285 Keywords: 0.22 #infoleak",
  "id" : 411491398655815680,
  "created_at" : "2013-12-13 13:42:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4EzmNuCMX5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ibqSaYwD",
      "display_url" : "pastebin.com\/raw.php?i=ibqS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411488656478572544",
  "text" : "http:\/\/t.co\/4EzmNuCMX5 Emails: 43 Keywords: 0.44 #infoleak",
  "id" : 411488656478572544,
  "created_at" : "2013-12-13 13:31:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TTAFnqVbaR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3g8cEysx",
      "display_url" : "pastebin.com\/raw.php?i=3g8c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411476234326245376",
  "text" : "http:\/\/t.co\/TTAFnqVbaR Possible cisco configuration #infoleak",
  "id" : 411476234326245376,
  "created_at" : "2013-12-13 12:42:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zsTgUDTehu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FNsf01KL",
      "display_url" : "pastebin.com\/raw.php?i=FNsf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411475941777354752",
  "text" : "http:\/\/t.co\/zsTgUDTehu Emails: 34 Keywords: 0.11 #infoleak",
  "id" : 411475941777354752,
  "created_at" : "2013-12-13 12:41:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rYr0kyB6Kf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mcg59mS3",
      "display_url" : "pastebin.com\/raw.php?i=mcg5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411456105689006081",
  "text" : "http:\/\/t.co\/rYr0kyB6Kf Emails: 168 Keywords: 0.0 #infoleak",
  "id" : 411456105689006081,
  "created_at" : "2013-12-13 11:22:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uvPc5KX96y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=seEHiRN3",
      "display_url" : "pastebin.com\/raw.php?i=seEH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411454572809318400",
  "text" : "http:\/\/t.co\/uvPc5KX96y Emails: 65 Keywords: 0.0 #infoleak",
  "id" : 411454572809318400,
  "created_at" : "2013-12-13 11:16:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JSJbCUfRLy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fXU1qr4u",
      "display_url" : "pastebin.com\/raw.php?i=fXU1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411423638189916160",
  "text" : "http:\/\/t.co\/JSJbCUfRLy Hashes: 136 Keywords: 0.11 #infoleak",
  "id" : 411423638189916160,
  "created_at" : "2013-12-13 09:13:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Pwwi0CZULz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=45xYuNRW",
      "display_url" : "pastebin.com\/raw.php?i=45xY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411396362618425344",
  "text" : "http:\/\/t.co\/Pwwi0CZULz Hashes: 46 Keywords: 0.33 #infoleak",
  "id" : 411396362618425344,
  "created_at" : "2013-12-13 07:25:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TxMh51DOpB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ecKq2QUf",
      "display_url" : "pastebin.com\/raw.php?i=ecKq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411394061061201920",
  "text" : "http:\/\/t.co\/TxMh51DOpB Emails: 428 Hashes: 1 E\/H: 428.0 Keywords: 0.08 #infoleak",
  "id" : 411394061061201920,
  "created_at" : "2013-12-13 07:16:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eqEe4IdAzv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VeSS50is",
      "display_url" : "pastebin.com\/raw.php?i=VeSS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411320960990466048",
  "text" : "http:\/\/t.co\/eqEe4IdAzv Found possible Google API key(s) #infoleak",
  "id" : 411320960990466048,
  "created_at" : "2013-12-13 02:25:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oSSZ3KsOve",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UiKjhjWn",
      "display_url" : "pastebin.com\/raw.php?i=UiKj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411318322072788992",
  "text" : "http:\/\/t.co\/oSSZ3KsOve Emails: 23 Keywords: 0.08 #infoleak",
  "id" : 411318322072788992,
  "created_at" : "2013-12-13 02:15:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jBUr5go0QH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4DBjPwju",
      "display_url" : "pastebin.com\/raw.php?i=4DBj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411318034007982080",
  "text" : "http:\/\/t.co\/jBUr5go0QH Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 411318034007982080,
  "created_at" : "2013-12-13 02:13:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GFk5CmuAig",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u4utXW3H",
      "display_url" : "pastebin.com\/raw.php?i=u4ut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411268838915727360",
  "text" : "http:\/\/t.co\/GFk5CmuAig Emails: 44 Keywords: 0.08 #infoleak",
  "id" : 411268838915727360,
  "created_at" : "2013-12-12 22:58:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H78gxdoDuN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FwPkUtZX",
      "display_url" : "pastebin.com\/raw.php?i=FwPk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411267341507244032",
  "text" : "http:\/\/t.co\/H78gxdoDuN Emails: 34 Hashes: 45 E\/H: 0.76 Keywords: 0.13 #infoleak",
  "id" : 411267341507244032,
  "created_at" : "2013-12-12 22:52:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HOtCwWVtvi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RyNd4JE0",
      "display_url" : "pastebin.com\/raw.php?i=RyNd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411264389824512001",
  "text" : "http:\/\/t.co\/HOtCwWVtvi Hashes: 53 Keywords: 0.22 #infoleak",
  "id" : 411264389824512001,
  "created_at" : "2013-12-12 22:40:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/p7ydtlNAPG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qwkLbpAd",
      "display_url" : "pastebin.com\/raw.php?i=qwkL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411258875640152065",
  "text" : "http:\/\/t.co\/p7ydtlNAPG Keywords: 0.55 #infoleak",
  "id" : 411258875640152065,
  "created_at" : "2013-12-12 22:18:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/N3Gi6mQeR1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gC3J0GVv",
      "display_url" : "pastebin.com\/raw.php?i=gC3J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411252104871686144",
  "text" : "http:\/\/t.co\/N3Gi6mQeR1 Emails: 24 Hashes: 3 E\/H: 8.0 Keywords: 0.33 #infoleak",
  "id" : 411252104871686144,
  "created_at" : "2013-12-12 21:51:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oYsc9XwmJs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eTCwVXA5",
      "display_url" : "pastebin.com\/raw.php?i=eTCw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411243791916359681",
  "text" : "http:\/\/t.co\/oYsc9XwmJs Found possible Google API key(s) #infoleak",
  "id" : 411243791916359681,
  "created_at" : "2013-12-12 21:18:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nGN7w34Ayl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gHtFbsE5",
      "display_url" : "pastebin.com\/raw.php?i=gHtF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411241132392054784",
  "text" : "http:\/\/t.co\/nGN7w34Ayl Hashes: 6974 Keywords: 0.22 #infoleak",
  "id" : 411241132392054784,
  "created_at" : "2013-12-12 21:08:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JdvNQUsMd7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R4Rd0f42",
      "display_url" : "pastebin.com\/raw.php?i=R4Rd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411234084673703936",
  "text" : "http:\/\/t.co\/JdvNQUsMd7 Emails: 116 Keywords: 0.11 #infoleak",
  "id" : 411234084673703936,
  "created_at" : "2013-12-12 20:40:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ft475knpfh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M8i3SHeb",
      "display_url" : "pastebin.com\/raw.php?i=M8i3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411207998732644352",
  "text" : "http:\/\/t.co\/ft475knpfh Emails: 1 Hashes: 36 E\/H: 0.03 Keywords: -0.09 #infoleak",
  "id" : 411207998732644352,
  "created_at" : "2013-12-12 18:56:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LoDfk7CXgE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=svFSQES9",
      "display_url" : "pastebin.com\/raw.php?i=svFS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411085008829308928",
  "text" : "http:\/\/t.co\/LoDfk7CXgE Hashes: 40 Keywords: 0.11 #infoleak",
  "id" : 411085008829308928,
  "created_at" : "2013-12-12 10:47:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nE7jWhSB7d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SYEs7NjQ",
      "display_url" : "pastebin.com\/raw.php?i=SYEs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411082203863318528",
  "text" : "http:\/\/t.co\/nE7jWhSB7d Hashes: 101 Keywords: 0.11 #infoleak",
  "id" : 411082203863318528,
  "created_at" : "2013-12-12 10:36:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L3IpXR1rQx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iqiWCGw7",
      "display_url" : "pastebin.com\/raw.php?i=iqiW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411081127080640512",
  "text" : "http:\/\/t.co\/L3IpXR1rQx Found possible Google API key(s) #infoleak",
  "id" : 411081127080640512,
  "created_at" : "2013-12-12 10:32:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R9a0jtwfUW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aYbptUte",
      "display_url" : "pastebin.com\/raw.php?i=aYbp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411074592313061376",
  "text" : "http:\/\/t.co\/R9a0jtwfUW Hashes: 65 Keywords: 0.08 #infoleak",
  "id" : 411074592313061376,
  "created_at" : "2013-12-12 10:06:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xR81U9RBC4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DzQmN0W7",
      "display_url" : "pastebin.com\/raw.php?i=DzQm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411069336002899968",
  "text" : "http:\/\/t.co\/xR81U9RBC4 Hashes: 75 Keywords: 0.0 #infoleak",
  "id" : 411069336002899968,
  "created_at" : "2013-12-12 09:45:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tasKRMQbVC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HfkrtYUA",
      "display_url" : "pastebin.com\/raw.php?i=Hfkr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411045647886737408",
  "text" : "http:\/\/t.co\/tasKRMQbVC Emails: 254 Keywords: 0.0 #infoleak",
  "id" : 411045647886737408,
  "created_at" : "2013-12-12 08:11:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wzCsvuOKan",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AdVTwsX6",
      "display_url" : "pastebin.com\/raw.php?i=AdVT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411044843226284033",
  "text" : "http:\/\/t.co\/wzCsvuOKan Emails: 29 Keywords: 0.0 #infoleak",
  "id" : 411044843226284033,
  "created_at" : "2013-12-12 08:08:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rXhrNKzSPq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kBk5JMij",
      "display_url" : "pastebin.com\/raw.php?i=kBk5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411044044588855297",
  "text" : "http:\/\/t.co\/rXhrNKzSPq Emails: 461 Keywords: 0.0 #infoleak",
  "id" : 411044044588855297,
  "created_at" : "2013-12-12 08:05:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uzdAD9yJ1q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U3eyS1xS",
      "display_url" : "pastebin.com\/raw.php?i=U3ey\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411042963020460032",
  "text" : "http:\/\/t.co\/uzdAD9yJ1q Found possible Google API key(s) #infoleak",
  "id" : 411042963020460032,
  "created_at" : "2013-12-12 08:00:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zzKGoFfxuv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pCTe128d",
      "display_url" : "pastebin.com\/raw.php?i=pCTe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411042383900311552",
  "text" : "http:\/\/t.co\/zzKGoFfxuv Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 411042383900311552,
  "created_at" : "2013-12-12 07:58:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nJAFHtYnt1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZKkiefxa",
      "display_url" : "pastebin.com\/raw.php?i=ZKki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411037156807688192",
  "text" : "http:\/\/t.co\/nJAFHtYnt1 Emails: 639 Keywords: 0.22 #infoleak",
  "id" : 411037156807688192,
  "created_at" : "2013-12-12 07:37:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GSU3cCtgjE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iAMic7yE",
      "display_url" : "pastebin.com\/raw.php?i=iAMi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411025916970532864",
  "text" : "http:\/\/t.co\/GSU3cCtgjE Hashes: 32 Keywords: 0.22 #infoleak",
  "id" : 411025916970532864,
  "created_at" : "2013-12-12 06:53:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/85vTsf94HW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KBggQEFM",
      "display_url" : "pastebin.com\/raw.php?i=KBgg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411024184035143680",
  "text" : "http:\/\/t.co\/85vTsf94HW Emails: 60 Keywords: 0.0 #infoleak",
  "id" : 411024184035143680,
  "created_at" : "2013-12-12 06:46:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DTkLOpXAza",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Lx5m14tA",
      "display_url" : "pastebin.com\/raw.php?i=Lx5m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411022579927752704",
  "text" : "http:\/\/t.co\/DTkLOpXAza Emails: 68 Keywords: 0.33 #infoleak",
  "id" : 411022579927752704,
  "created_at" : "2013-12-12 06:39:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aoIHfsHuMK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vgwXY9Qi",
      "display_url" : "pastebin.com\/raw.php?i=vgwX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411009939784482816",
  "text" : "http:\/\/t.co\/aoIHfsHuMK Found possible Google API key(s) #infoleak",
  "id" : 411009939784482816,
  "created_at" : "2013-12-12 05:49:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gd0pu71Gob",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0MCTrzhg",
      "display_url" : "pastebin.com\/raw.php?i=0MCT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410996001277632512",
  "text" : "http:\/\/t.co\/Gd0pu71Gob Emails: 226 Keywords: 0.0 #infoleak",
  "id" : 410996001277632512,
  "created_at" : "2013-12-12 04:54:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/132DFU8q2w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NRKEJytJ",
      "display_url" : "pastebin.com\/raw.php?i=NRKE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410991410070822912",
  "text" : "http:\/\/t.co\/132DFU8q2w Emails: 224 Keywords: 0.0 #infoleak",
  "id" : 410991410070822912,
  "created_at" : "2013-12-12 04:36:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5ZjKw5KjMS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iAjkycHs",
      "display_url" : "pastebin.com\/raw.php?i=iAjk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410969005604605954",
  "text" : "http:\/\/t.co\/5ZjKw5KjMS Hashes: 30 Keywords: 0.0 #infoleak",
  "id" : 410969005604605954,
  "created_at" : "2013-12-12 03:07:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0i6CXEWjDa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CWrRCAR7",
      "display_url" : "pastebin.com\/raw.php?i=CWrR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410959817021222912",
  "text" : "http:\/\/t.co\/0i6CXEWjDa Emails: 96 Keywords: 0.0 #infoleak",
  "id" : 410959817021222912,
  "created_at" : "2013-12-12 02:30:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4iX716sarg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7c8Hqs25",
      "display_url" : "pastebin.com\/raw.php?i=7c8H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410956473221398528",
  "text" : "http:\/\/t.co\/4iX716sarg Emails: 182 Keywords: 0.0 #infoleak",
  "id" : 410956473221398528,
  "created_at" : "2013-12-12 02:17:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lr4RJ9WOQQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sZ24VzjW",
      "display_url" : "pastebin.com\/raw.php?i=sZ24\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410950404474560512",
  "text" : "http:\/\/t.co\/lr4RJ9WOQQ Emails: 1270 Keywords: -0.03 #infoleak",
  "id" : 410950404474560512,
  "created_at" : "2013-12-12 01:53:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u3FksZhDYL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hkbvR5jD",
      "display_url" : "pastebin.com\/raw.php?i=hkbv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410946482993242115",
  "text" : "http:\/\/t.co\/u3FksZhDYL Keywords: 0.55 #infoleak",
  "id" : 410946482993242115,
  "created_at" : "2013-12-12 01:37:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TKV2sN7U9S",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g3B3xgcV",
      "display_url" : "pastebin.com\/raw.php?i=g3B3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410928292208709633",
  "text" : "http:\/\/t.co\/TKV2sN7U9S Found possible Google API key(s) #infoleak",
  "id" : 410928292208709633,
  "created_at" : "2013-12-12 00:25:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LipXPjveZS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=y4VG2zqY",
      "display_url" : "pastebin.com\/raw.php?i=y4VG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410907055235399680",
  "text" : "http:\/\/t.co\/LipXPjveZS Possible cisco configuration #infoleak",
  "id" : 410907055235399680,
  "created_at" : "2013-12-11 23:00:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/syILd0I8r1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cu8B6NuS",
      "display_url" : "pastebin.com\/raw.php?i=cu8B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410896340151857154",
  "text" : "http:\/\/t.co\/syILd0I8r1 Emails: 21 Keywords: 0.0 #infoleak",
  "id" : 410896340151857154,
  "created_at" : "2013-12-11 22:18:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TdH4lY5Ryj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cFZTjtDs",
      "display_url" : "pastebin.com\/raw.php?i=cFZT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410896017412718594",
  "text" : "http:\/\/t.co\/TdH4lY5Ryj Emails: 45 Keywords: 0.0 #infoleak",
  "id" : 410896017412718594,
  "created_at" : "2013-12-11 22:16:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qv8Nty4WUz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=btVUanRh",
      "display_url" : "pastebin.com\/raw.php?i=btVU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410895561722576896",
  "text" : "http:\/\/t.co\/Qv8Nty4WUz Emails: 634 Keywords: 0.22 #infoleak",
  "id" : 410895561722576896,
  "created_at" : "2013-12-11 22:15:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RxlnQauOYg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GNDzvxm0",
      "display_url" : "pastebin.com\/raw.php?i=GNDz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410884351174262784",
  "text" : "http:\/\/t.co\/RxlnQauOYg Keywords: 0.55 #infoleak",
  "id" : 410884351174262784,
  "created_at" : "2013-12-11 21:30:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HJFjqjz4HI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dyyMhXKq",
      "display_url" : "pastebin.com\/raw.php?i=dyyM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410858185524666369",
  "text" : "http:\/\/t.co\/HJFjqjz4HI Emails: 41 Keywords: 0.22 #infoleak",
  "id" : 410858185524666369,
  "created_at" : "2013-12-11 19:46:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eudlSNFeHc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0g4Y45DG",
      "display_url" : "pastebin.com\/raw.php?i=0g4Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410852940195196928",
  "text" : "http:\/\/t.co\/eudlSNFeHc Found possible Google API key(s) #infoleak",
  "id" : 410852940195196928,
  "created_at" : "2013-12-11 19:25:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GrX7e3D1of",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D8RupU5D",
      "display_url" : "pastebin.com\/raw.php?i=D8Ru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410847908133486592",
  "text" : "http:\/\/t.co\/GrX7e3D1of Emails: 9 Keywords: 0.55 #infoleak",
  "id" : 410847908133486592,
  "created_at" : "2013-12-11 19:05:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lhVCA0Izaa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=295zUMW3",
      "display_url" : "pastebin.com\/raw.php?i=295z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410845902111121409",
  "text" : "http:\/\/t.co\/lhVCA0Izaa Hashes: 155 Keywords: 0.11 #infoleak",
  "id" : 410845902111121409,
  "created_at" : "2013-12-11 18:57:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ijkBL04Xhq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=s8HqJWwC",
      "display_url" : "pastebin.com\/raw.php?i=s8Hq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410844718902169600",
  "text" : "http:\/\/t.co\/ijkBL04Xhq Emails: 123 Keywords: 0.0 #infoleak",
  "id" : 410844718902169600,
  "created_at" : "2013-12-11 18:53:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QPYM1Gyb2e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CSZFCeXe",
      "display_url" : "pastebin.com\/raw.php?i=CSZF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410840834016149504",
  "text" : "http:\/\/t.co\/QPYM1Gyb2e Emails: 255 Keywords: 0.22 #infoleak",
  "id" : 410840834016149504,
  "created_at" : "2013-12-11 18:37:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TsVC0DeK2D",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=shkd3EQQ",
      "display_url" : "pastebin.com\/raw.php?i=shkd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410836046381719552",
  "text" : "http:\/\/t.co\/TsVC0DeK2D Found possible Google API key(s) #infoleak",
  "id" : 410836046381719552,
  "created_at" : "2013-12-11 18:18:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EKgXb2gczl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xX10vTxA",
      "display_url" : "pastebin.com\/raw.php?i=xX10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410835291973226496",
  "text" : "http:\/\/t.co\/EKgXb2gczl Emails: 4367 Hashes: 4987 E\/H: 0.88 Keywords: 0.3 #infoleak",
  "id" : 410835291973226496,
  "created_at" : "2013-12-11 18:15:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7W9DVywsw8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mMGmGzTY",
      "display_url" : "pastebin.com\/raw.php?i=mMGm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410834380399972352",
  "text" : "http:\/\/t.co\/7W9DVywsw8 Emails: 12803 Keywords: 0.19 #infoleak",
  "id" : 410834380399972352,
  "created_at" : "2013-12-11 18:12:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ot5LpTHDGY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yBja9UTP",
      "display_url" : "pastebin.com\/raw.php?i=yBja\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410832709380886531",
  "text" : "http:\/\/t.co\/Ot5LpTHDGY Emails: 504 Keywords: 0.33 #infoleak",
  "id" : 410832709380886531,
  "created_at" : "2013-12-11 18:05:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OHU3DAs1OX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ejfrJX20",
      "display_url" : "pastebin.com\/raw.php?i=ejfr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410769098880991233",
  "text" : "http:\/\/t.co\/OHU3DAs1OX Hashes: 32 Keywords: 0.11 #infoleak",
  "id" : 410769098880991233,
  "created_at" : "2013-12-11 13:52:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BDCqPOZEKj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nYPGerBR",
      "display_url" : "pastebin.com\/raw.php?i=nYPG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410768854722174976",
  "text" : "http:\/\/t.co\/BDCqPOZEKj Emails: 102 Keywords: 0.0 #infoleak",
  "id" : 410768854722174976,
  "created_at" : "2013-12-11 13:51:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O5DCaNMwKh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tHhmtKzJ",
      "display_url" : "pastebin.com\/raw.php?i=tHhm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410766304488865792",
  "text" : "http:\/\/t.co\/O5DCaNMwKh Emails: 2 Hashes: 40 E\/H: 0.05 Keywords: 0.33 #infoleak",
  "id" : 410766304488865792,
  "created_at" : "2013-12-11 13:41:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JeiSLWb2Oc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EDxR2y7J",
      "display_url" : "pastebin.com\/raw.php?i=EDxR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410763389322149888",
  "text" : "http:\/\/t.co\/JeiSLWb2Oc Emails: 962 Keywords: 0.33 #infoleak",
  "id" : 410763389322149888,
  "created_at" : "2013-12-11 13:29:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WPH2c4FLv2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TjCTpGJb",
      "display_url" : "pastebin.com\/raw.php?i=TjCT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410733699869573120",
  "text" : "http:\/\/t.co\/WPH2c4FLv2 Found possible Google API key(s) #infoleak",
  "id" : 410733699869573120,
  "created_at" : "2013-12-11 11:31:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q2Pajypb1m",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7X7iTSuw",
      "display_url" : "pastebin.com\/raw.php?i=7X7i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410731441371115520",
  "text" : "http:\/\/t.co\/q2Pajypb1m Emails: 312 Hashes: 2781 E\/H: 0.11 Keywords: 0.22 #infoleak",
  "id" : 410731441371115520,
  "created_at" : "2013-12-11 11:23:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X2b1tDunWA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dZJAGRT3",
      "display_url" : "pastebin.com\/raw.php?i=dZJA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410731046200553473",
  "text" : "http:\/\/t.co\/X2b1tDunWA Emails: 79 Keywords: 0.0 #infoleak",
  "id" : 410731046200553473,
  "created_at" : "2013-12-11 11:21:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x3rbCRWPRo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vdYSshva",
      "display_url" : "pastebin.com\/raw.php?i=vdYS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410728453957115905",
  "text" : "http:\/\/t.co\/x3rbCRWPRo Emails: 29 Keywords: 0.11 #infoleak",
  "id" : 410728453957115905,
  "created_at" : "2013-12-11 11:11:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cHozthXPRk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NKgzzCqS",
      "display_url" : "pastebin.com\/raw.php?i=NKgz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410726701975351296",
  "text" : "http:\/\/t.co\/cHozthXPRk Emails: 191 Keywords: 0.44 #infoleak",
  "id" : 410726701975351296,
  "created_at" : "2013-12-11 11:04:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7R43uz4eE0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B8AWYVBg",
      "display_url" : "pastebin.com\/raw.php?i=B8AW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410716880811225088",
  "text" : "http:\/\/t.co\/7R43uz4eE0 Possible cisco configuration #infoleak",
  "id" : 410716880811225088,
  "created_at" : "2013-12-11 10:25:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r6qudAqDob",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XbU2Nm2L",
      "display_url" : "pastebin.com\/raw.php?i=XbU2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410676210121732096",
  "text" : "http:\/\/t.co\/r6qudAqDob Possible cisco configuration #infoleak",
  "id" : 410676210121732096,
  "created_at" : "2013-12-11 07:43:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ONCbYO2asv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mKX7gHms",
      "display_url" : "pastebin.com\/raw.php?i=mKX7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410667096276602880",
  "text" : "http:\/\/t.co\/ONCbYO2asv Emails: 57 Keywords: 0.16 #infoleak",
  "id" : 410667096276602880,
  "created_at" : "2013-12-11 07:07:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8n6HDi6qK1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bJF5fMdx",
      "display_url" : "pastebin.com\/raw.php?i=bJF5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410664337598996480",
  "text" : "http:\/\/t.co\/8n6HDi6qK1 Keywords: 0.77 #infoleak",
  "id" : 410664337598996480,
  "created_at" : "2013-12-11 06:56:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/POyP6XydBR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tyLFd2t1",
      "display_url" : "pastebin.com\/raw.php?i=tyLF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410625485085757443",
  "text" : "http:\/\/t.co\/POyP6XydBR Found possible Google API key(s) #infoleak",
  "id" : 410625485085757443,
  "created_at" : "2013-12-11 04:21:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ua9SrAR688",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HGVvPRFc",
      "display_url" : "pastebin.com\/raw.php?i=HGVv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410623618326880256",
  "text" : "http:\/\/t.co\/ua9SrAR688 Emails: 38 Keywords: 0.0 #infoleak",
  "id" : 410623618326880256,
  "created_at" : "2013-12-11 04:14:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/f9AFdDFIjj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RPidVMZQ",
      "display_url" : "pastebin.com\/raw.php?i=RPid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410585825601015808",
  "text" : "http:\/\/t.co\/f9AFdDFIjj Emails: 33 Hashes: 7 E\/H: 4.71 Keywords: 0.19 #infoleak",
  "id" : 410585825601015808,
  "created_at" : "2013-12-11 01:44:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3lqYk1z4Aa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G6PiU5fv",
      "display_url" : "pastebin.com\/raw.php?i=G6Pi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410580935529082881",
  "text" : "http:\/\/t.co\/3lqYk1z4Aa Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 410580935529082881,
  "created_at" : "2013-12-11 01:24:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z2EbMBhrzL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B91GqTy7",
      "display_url" : "pastebin.com\/raw.php?i=B91G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410565218855448576",
  "text" : "http:\/\/t.co\/Z2EbMBhrzL Found possible Google API key(s) #infoleak",
  "id" : 410565218855448576,
  "created_at" : "2013-12-11 00:22:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wA2OkKZ8pf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FV9VW5Ex",
      "display_url" : "pastebin.com\/raw.php?i=FV9V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410558844662579200",
  "text" : "http:\/\/t.co\/wA2OkKZ8pf Emails: 690 Keywords: 0.33 #infoleak",
  "id" : 410558844662579200,
  "created_at" : "2013-12-10 23:57:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7OLGzvNGGr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LddiXve2",
      "display_url" : "pastebin.com\/raw.php?i=Lddi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410557906400993280",
  "text" : "http:\/\/t.co\/7OLGzvNGGr Keywords: 0.55 #infoleak",
  "id" : 410557906400993280,
  "created_at" : "2013-12-10 23:53:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ReNz0s7YIO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P2uZvH7V",
      "display_url" : "pastebin.com\/raw.php?i=P2uZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410546810894024704",
  "text" : "http:\/\/t.co\/ReNz0s7YIO Hashes: 153 Keywords: 0.11 #infoleak",
  "id" : 410546810894024704,
  "created_at" : "2013-12-10 23:09:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v3m5pSeRXF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E9s6dRcA",
      "display_url" : "pastebin.com\/raw.php?i=E9s6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410518080251379712",
  "text" : "http:\/\/t.co\/v3m5pSeRXF Emails: 141 Keywords: 0.22 #infoleak",
  "id" : 410518080251379712,
  "created_at" : "2013-12-10 21:15:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wzdMW3D5Ke",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yWt9gCKq",
      "display_url" : "pastebin.com\/raw.php?i=yWt9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410515354339667968",
  "text" : "http:\/\/t.co\/wzdMW3D5Ke Hashes: 192 Keywords: 0.0 #infoleak",
  "id" : 410515354339667968,
  "created_at" : "2013-12-10 21:04:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2eX0cYw9V5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3tcTaMVA",
      "display_url" : "pastebin.com\/raw.php?i=3tcT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410510431485054976",
  "text" : "http:\/\/t.co\/2eX0cYw9V5 Emails: 34 Keywords: -0.14 #infoleak",
  "id" : 410510431485054976,
  "created_at" : "2013-12-10 20:44:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TiC7DybcGS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2QhdqTJt",
      "display_url" : "pastebin.com\/raw.php?i=2Qhd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410507237417689088",
  "text" : "http:\/\/t.co\/TiC7DybcGS Emails: 3660 Hashes: 3608 E\/H: 1.01 Keywords: 0.22 #infoleak",
  "id" : 410507237417689088,
  "created_at" : "2013-12-10 20:32:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Kzskisuypk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=912upGMe",
      "display_url" : "pastebin.com\/raw.php?i=912u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410506087817699328",
  "text" : "http:\/\/t.co\/Kzskisuypk Emails: 44 Keywords: 0.08 #infoleak",
  "id" : 410506087817699328,
  "created_at" : "2013-12-10 20:27:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lgdnXNwSi3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7JYF712B",
      "display_url" : "pastebin.com\/raw.php?i=7JYF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410505318934671360",
  "text" : "http:\/\/t.co\/lgdnXNwSi3 Emails: 24 Keywords: -0.03 #infoleak",
  "id" : 410505318934671360,
  "created_at" : "2013-12-10 20:24:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fvXhHPyZBa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=42cKQtzx",
      "display_url" : "pastebin.com\/raw.php?i=42cK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410502860778897408",
  "text" : "http:\/\/t.co\/fvXhHPyZBa Emails: 27 Keywords: -0.14 #infoleak",
  "id" : 410502860778897408,
  "created_at" : "2013-12-10 20:14:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IZPROdAvOQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jBs64Tq9",
      "display_url" : "pastebin.com\/raw.php?i=jBs6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410501006355484672",
  "text" : "http:\/\/t.co\/IZPROdAvOQ Emails: 660 Keywords: 0.44 #infoleak",
  "id" : 410501006355484672,
  "created_at" : "2013-12-10 20:07:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4FXktWAHr4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LTyACYw1",
      "display_url" : "pastebin.com\/raw.php?i=LTyA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410495364223885312",
  "text" : "http:\/\/t.co\/4FXktWAHr4 Emails: 23 Keywords: 0.08 #infoleak",
  "id" : 410495364223885312,
  "created_at" : "2013-12-10 19:44:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fL1bRYajKl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7XpQG2Gy",
      "display_url" : "pastebin.com\/raw.php?i=7XpQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410489324530982912",
  "text" : "http:\/\/t.co\/fL1bRYajKl Hashes: 121 Keywords: -0.06 #infoleak",
  "id" : 410489324530982912,
  "created_at" : "2013-12-10 19:20:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k0eCOi1Fb9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2dLGU3Fn",
      "display_url" : "pastebin.com\/raw.php?i=2dLG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410449148840652800",
  "text" : "http:\/\/t.co\/k0eCOi1Fb9 Emails: 10919 Keywords: 0.08 #infoleak",
  "id" : 410449148840652800,
  "created_at" : "2013-12-10 16:41:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1o33MN2XP8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n0e17cJk",
      "display_url" : "pastebin.com\/raw.php?i=n0e1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410447068742696961",
  "text" : "http:\/\/t.co\/1o33MN2XP8 Emails: 15 Keywords: 0.63 #infoleak",
  "id" : 410447068742696961,
  "created_at" : "2013-12-10 16:33:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VGIKwqLHv6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Uu1kXzrF",
      "display_url" : "pastebin.com\/raw.php?i=Uu1k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410443920737173504",
  "text" : "http:\/\/t.co\/VGIKwqLHv6 Emails: 1262 Keywords: -0.03 #infoleak",
  "id" : 410443920737173504,
  "created_at" : "2013-12-10 16:20:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PKYJ35wzUh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LuWVRPJV",
      "display_url" : "pastebin.com\/raw.php?i=LuWV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410442785641074688",
  "text" : "http:\/\/t.co\/PKYJ35wzUh Keywords: 0.55 #infoleak",
  "id" : 410442785641074688,
  "created_at" : "2013-12-10 16:16:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bg9mbFo6Qg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F2K4eJhc",
      "display_url" : "pastebin.com\/raw.php?i=F2K4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410436251355848705",
  "text" : "http:\/\/t.co\/Bg9mbFo6Qg Emails: 411 Keywords: 0.3 #infoleak",
  "id" : 410436251355848705,
  "created_at" : "2013-12-10 15:50:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ijWPe0jyxb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EG98uiii",
      "display_url" : "pastebin.com\/raw.php?i=EG98\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410359695052775424",
  "text" : "http:\/\/t.co\/ijWPe0jyxb Found possible Google API key(s) #infoleak",
  "id" : 410359695052775424,
  "created_at" : "2013-12-10 10:45:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/csP7RUrCI6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qvtVWfxs",
      "display_url" : "pastebin.com\/raw.php?i=qvtV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410355393810817024",
  "text" : "http:\/\/t.co\/csP7RUrCI6 Found possible Google API key(s) #infoleak",
  "id" : 410355393810817024,
  "created_at" : "2013-12-10 10:28:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lmixhIdDLy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G2zfdVSJ",
      "display_url" : "pastebin.com\/raw.php?i=G2zf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410333621845651456",
  "text" : "http:\/\/t.co\/lmixhIdDLy Emails: 1 Hashes: 31 E\/H: 0.03 Keywords: 0.11 #infoleak",
  "id" : 410333621845651456,
  "created_at" : "2013-12-10 09:02:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dBS055IuF5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZaRfvZ4d",
      "display_url" : "pastebin.com\/raw.php?i=ZaRf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410327219957817344",
  "text" : "http:\/\/t.co\/dBS055IuF5 Emails: 507 Keywords: 0.0 #infoleak",
  "id" : 410327219957817344,
  "created_at" : "2013-12-10 08:36:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o6txv2sdhx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TkMLfn2f",
      "display_url" : "pastebin.com\/raw.php?i=TkML\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410324177145446400",
  "text" : "http:\/\/t.co\/o6txv2sdhx Found possible Google API key(s) #infoleak",
  "id" : 410324177145446400,
  "created_at" : "2013-12-10 08:24:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NZNyuDnQyL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NN7YK7d5",
      "display_url" : "pastebin.com\/raw.php?i=NN7Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410318807031238656",
  "text" : "http:\/\/t.co\/NZNyuDnQyL Keywords: 0.77 #infoleak",
  "id" : 410318807031238656,
  "created_at" : "2013-12-10 08:03:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q2BTUi7gv5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xU0mgPzc",
      "display_url" : "pastebin.com\/raw.php?i=xU0m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410301909879119873",
  "text" : "http:\/\/t.co\/Q2BTUi7gv5 Hashes: 31 Keywords: 0.22 #infoleak",
  "id" : 410301909879119873,
  "created_at" : "2013-12-10 06:56:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U57gnsWKll",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=64PAAV1c",
      "display_url" : "pastebin.com\/raw.php?i=64PA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410283691127361536",
  "text" : "http:\/\/t.co\/U57gnsWKll Emails: 303 Keywords: 0.11 #infoleak",
  "id" : 410283691127361536,
  "created_at" : "2013-12-10 05:43:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T1aFNxK5xk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vkM07kSk",
      "display_url" : "pastebin.com\/raw.php?i=vkM0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410282713455673344",
  "text" : "http:\/\/t.co\/T1aFNxK5xk Found possible Google API key(s) #infoleak",
  "id" : 410282713455673344,
  "created_at" : "2013-12-10 05:39:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NQKfRjfQeh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rwVTFumG",
      "display_url" : "pastebin.com\/raw.php?i=rwVT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410282071089623040",
  "text" : "http:\/\/t.co\/NQKfRjfQeh Emails: 303 Keywords: 0.11 #infoleak",
  "id" : 410282071089623040,
  "created_at" : "2013-12-10 05:37:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/amVmRNUcQb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2VBJEWQZ",
      "display_url" : "pastebin.com\/raw.php?i=2VBJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410271206743371777",
  "text" : "http:\/\/t.co\/amVmRNUcQb Emails: 34 Keywords: -0.03 #infoleak",
  "id" : 410271206743371777,
  "created_at" : "2013-12-10 04:54:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KTWBkdAYpr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aB79ZWMe",
      "display_url" : "pastebin.com\/raw.php?i=aB79\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410268424367923200",
  "text" : "http:\/\/t.co\/KTWBkdAYpr Emails: 93 Keywords: 0.0 #infoleak",
  "id" : 410268424367923200,
  "created_at" : "2013-12-10 04:43:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lCr4UwSFAW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pS56dM1G",
      "display_url" : "pastebin.com\/raw.php?i=pS56\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410260000175439874",
  "text" : "http:\/\/t.co\/lCr4UwSFAW Emails: 211 Keywords: 0.11 #infoleak",
  "id" : 410260000175439874,
  "created_at" : "2013-12-10 04:09:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fwdlLkEcyH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YXtMYSSZ",
      "display_url" : "pastebin.com\/raw.php?i=YXtM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410250884208017408",
  "text" : "http:\/\/t.co\/fwdlLkEcyH Emails: 1 Hashes: 69 E\/H: 0.01 Keywords: 0.05 #infoleak",
  "id" : 410250884208017408,
  "created_at" : "2013-12-10 03:33:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mocZP9rydo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yvj98rAB",
      "display_url" : "pastebin.com\/raw.php?i=yvj9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410170909816012800",
  "text" : "http:\/\/t.co\/mocZP9rydo Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 410170909816012800,
  "created_at" : "2013-12-09 22:15:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e1ecFNx3e2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PhDbNLeg",
      "display_url" : "pastebin.com\/raw.php?i=PhDb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410168747962683393",
  "text" : "http:\/\/t.co\/e1ecFNx3e2 Emails: 83 Keywords: 0.0 #infoleak",
  "id" : 410168747962683393,
  "created_at" : "2013-12-09 22:07:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/G4Vldu5Ieo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bJ9KaKFX",
      "display_url" : "pastebin.com\/raw.php?i=bJ9K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410165992170737664",
  "text" : "http:\/\/t.co\/G4Vldu5Ieo Emails: 251 Hashes: 256 E\/H: 0.98 Keywords: 0.44 #infoleak",
  "id" : 410165992170737664,
  "created_at" : "2013-12-09 21:56:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4mKB1HSJJo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fXJsFSEe",
      "display_url" : "pastebin.com\/raw.php?i=fXJs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410162034274476032",
  "text" : "http:\/\/t.co\/4mKB1HSJJo Hashes: 251 Keywords: -0.03 #infoleak",
  "id" : 410162034274476032,
  "created_at" : "2013-12-09 21:40:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LjjuooTAi3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=arrYxkTk",
      "display_url" : "pastebin.com\/raw.php?i=arrY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410150998641229825",
  "text" : "http:\/\/t.co\/LjjuooTAi3 Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 410150998641229825,
  "created_at" : "2013-12-09 20:56:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xmF9khyc59",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wtggqDqd",
      "display_url" : "pastebin.com\/raw.php?i=wtgg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410089249916989440",
  "text" : "http:\/\/t.co\/xmF9khyc59 Emails: 3 Hashes: 89 E\/H: 0.03 Keywords: 0.55 #infoleak",
  "id" : 410089249916989440,
  "created_at" : "2013-12-09 16:51:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8RpdpTQTVj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eynS2eit",
      "display_url" : "pastebin.com\/raw.php?i=eynS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410085061019451392",
  "text" : "http:\/\/t.co\/8RpdpTQTVj Emails: 1235 Keywords: 0.11 #infoleak",
  "id" : 410085061019451392,
  "created_at" : "2013-12-09 16:34:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RLxdZebVWI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8H2Es0hU",
      "display_url" : "pastebin.com\/raw.php?i=8H2E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410084229955874816",
  "text" : "http:\/\/t.co\/RLxdZebVWI Hashes: 136 Keywords: 0.08 #infoleak",
  "id" : 410084229955874816,
  "created_at" : "2013-12-09 16:31:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MH6ZDMKZSw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=itJX6uq0",
      "display_url" : "pastebin.com\/raw.php?i=itJX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410065208296501248",
  "text" : "http:\/\/t.co\/MH6ZDMKZSw Emails: 241 Keywords: 0.22 #infoleak",
  "id" : 410065208296501248,
  "created_at" : "2013-12-09 15:15:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6XfQi2ZOj1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mtV4tkQs",
      "display_url" : "pastebin.com\/raw.php?i=mtV4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410061685467004929",
  "text" : "http:\/\/t.co\/6XfQi2ZOj1 Emails: 22 Keywords: 0.11 #infoleak",
  "id" : 410061685467004929,
  "created_at" : "2013-12-09 15:01:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gotlZQ1SYr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SmQA9Gfm",
      "display_url" : "pastebin.com\/raw.php?i=SmQA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410061352120492032",
  "text" : "http:\/\/t.co\/gotlZQ1SYr Found possible Google API key(s) #infoleak",
  "id" : 410061352120492032,
  "created_at" : "2013-12-09 15:00:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AN5nJ83z6R",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FLxU9xyr",
      "display_url" : "pastebin.com\/raw.php?i=FLxU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410056906049212416",
  "text" : "http:\/\/t.co\/AN5nJ83z6R Possible cisco configuration #infoleak",
  "id" : 410056906049212416,
  "created_at" : "2013-12-09 14:42:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ohoULhSpxC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1MK5YsgG",
      "display_url" : "pastebin.com\/raw.php?i=1MK5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410051879490445312",
  "text" : "http:\/\/t.co\/ohoULhSpxC Possible cisco configuration #infoleak",
  "id" : 410051879490445312,
  "created_at" : "2013-12-09 14:22:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n5wbQAGSnU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yA1zBqyR",
      "display_url" : "pastebin.com\/raw.php?i=yA1z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410038488289931264",
  "text" : "http:\/\/t.co\/n5wbQAGSnU Hashes: 114 Keywords: 0.22 #infoleak",
  "id" : 410038488289931264,
  "created_at" : "2013-12-09 13:29:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8vbqBcHqnD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uu0ZwCtN",
      "display_url" : "pastebin.com\/raw.php?i=uu0Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410020736376393728",
  "text" : "http:\/\/t.co\/8vbqBcHqnD Emails: 1009 Keywords: 0.11 #infoleak",
  "id" : 410020736376393728,
  "created_at" : "2013-12-09 12:18:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jF7DczGNkh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UACrCvsj",
      "display_url" : "pastebin.com\/raw.php?i=UACr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410020690524254208",
  "text" : "http:\/\/t.co\/jF7DczGNkh Found possible Google API key(s) #infoleak",
  "id" : 410020690524254208,
  "created_at" : "2013-12-09 12:18:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0Vl0szjSJt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TYFbVRu7",
      "display_url" : "pastebin.com\/raw.php?i=TYFb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410019346874765313",
  "text" : "http:\/\/t.co\/0Vl0szjSJt Hashes: 4998 Keywords: 0.0 #infoleak",
  "id" : 410019346874765313,
  "created_at" : "2013-12-09 12:13:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J8p6L1rnuz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p59Nptfs",
      "display_url" : "pastebin.com\/raw.php?i=p59N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409932588464082944",
  "text" : "http:\/\/t.co\/J8p6L1rnuz Emails: 780 Keywords: 0.22 #infoleak",
  "id" : 409932588464082944,
  "created_at" : "2013-12-09 06:28:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d9rE4ylXDx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UqbVebEy",
      "display_url" : "pastebin.com\/raw.php?i=UqbV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409932347018985472",
  "text" : "http:\/\/t.co\/d9rE4ylXDx Emails: 780 Keywords: 0.22 #infoleak",
  "id" : 409932347018985472,
  "created_at" : "2013-12-09 06:27:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gf4DhUX8iO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uyaBFpNB",
      "display_url" : "pastebin.com\/raw.php?i=uyaB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409903466526412800",
  "text" : "http:\/\/t.co\/Gf4DhUX8iO Found possible Google API key(s) #infoleak",
  "id" : 409903466526412800,
  "created_at" : "2013-12-09 04:32:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QWpxknDQnJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HyBzcp5T",
      "display_url" : "pastebin.com\/raw.php?i=HyBz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409890514461130752",
  "text" : "http:\/\/t.co\/QWpxknDQnJ Found possible Google API key(s) #infoleak",
  "id" : 409890514461130752,
  "created_at" : "2013-12-09 03:41:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8Fjhnlfp30",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KB5yQedZ",
      "display_url" : "pastebin.com\/raw.php?i=KB5y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409888256860229632",
  "text" : "http:\/\/t.co\/8Fjhnlfp30 Keywords: 0.55 #infoleak",
  "id" : 409888256860229632,
  "created_at" : "2013-12-09 03:32:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cCNVRUfZRm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xe6gHpmJ",
      "display_url" : "pastebin.com\/raw.php?i=Xe6g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409882877644378112",
  "text" : "http:\/\/t.co\/cCNVRUfZRm Emails: 235 Keywords: 0.44 #infoleak",
  "id" : 409882877644378112,
  "created_at" : "2013-12-09 03:11:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/stWJyshVzs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=zWAd3bwy",
      "display_url" : "pastebin.com\/raw.php?i=zWAd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409876300405288960",
  "text" : "http:\/\/t.co\/stWJyshVzs Emails: 81 Keywords: 0.0 #infoleak",
  "id" : 409876300405288960,
  "created_at" : "2013-12-09 02:44:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6FWHEsnsLF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ScqJxLcT",
      "display_url" : "pastebin.com\/raw.php?i=ScqJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409870477943787520",
  "text" : "http:\/\/t.co\/6FWHEsnsLF Hashes: 32 Keywords: 0.0 #infoleak",
  "id" : 409870477943787520,
  "created_at" : "2013-12-09 02:21:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n7nu1BE3MS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GS0E75fa",
      "display_url" : "pastebin.com\/raw.php?i=GS0E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409869300875280384",
  "text" : "http:\/\/t.co\/n7nu1BE3MS Found possible Google API key(s) #infoleak",
  "id" : 409869300875280384,
  "created_at" : "2013-12-09 02:17:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OtSKNzoGie",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hM1QwHR9",
      "display_url" : "pastebin.com\/raw.php?i=hM1Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409856737345163265",
  "text" : "http:\/\/t.co\/OtSKNzoGie Emails: 1474 Keywords: 0.0 #infoleak",
  "id" : 409856737345163265,
  "created_at" : "2013-12-09 01:27:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TBSW00OobX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xkezAng7",
      "display_url" : "pastebin.com\/raw.php?i=xkez\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409856086766649344",
  "text" : "http:\/\/t.co\/TBSW00OobX Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 409856086766649344,
  "created_at" : "2013-12-09 01:24:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b6ckzOCo3t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DDCJK8yM",
      "display_url" : "pastebin.com\/raw.php?i=DDCJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409839762896199680",
  "text" : "http:\/\/t.co\/b6ckzOCo3t Hashes: 5 Keywords: 0.63 #infoleak",
  "id" : 409839762896199680,
  "created_at" : "2013-12-09 00:19:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/y397IdHPpV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n2QXJ1zJ",
      "display_url" : "pastebin.com\/raw.php?i=n2QX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409835630793736193",
  "text" : "http:\/\/t.co\/y397IdHPpV Found possible Google API key(s) #infoleak",
  "id" : 409835630793736193,
  "created_at" : "2013-12-09 00:03:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2YOnk4vpnP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5bthJtCc",
      "display_url" : "pastebin.com\/raw.php?i=5bth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409802705108869120",
  "text" : "http:\/\/t.co\/2YOnk4vpnP Keywords: 0.55 #infoleak",
  "id" : 409802705108869120,
  "created_at" : "2013-12-08 21:52:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jhPOzyiOtH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Z5HZJyEx",
      "display_url" : "pastebin.com\/raw.php?i=Z5HZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409791896551030785",
  "text" : "http:\/\/t.co\/jhPOzyiOtH Emails: 98 Keywords: 0.0 #infoleak",
  "id" : 409791896551030785,
  "created_at" : "2013-12-08 21:09:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ue734D08Cn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RfnJgYjR",
      "display_url" : "pastebin.com\/raw.php?i=RfnJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409791515766976512",
  "text" : "http:\/\/t.co\/ue734D08Cn Hashes: 20 Keywords: 0.55 #infoleak",
  "id" : 409791515766976512,
  "created_at" : "2013-12-08 21:08:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r0220H2SUj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bLU92mpz",
      "display_url" : "pastebin.com\/raw.php?i=bLU9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409790809601355776",
  "text" : "http:\/\/t.co\/r0220H2SUj Emails: 70 Keywords: 0.0 #infoleak",
  "id" : 409790809601355776,
  "created_at" : "2013-12-08 21:05:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6GYUK0Aa3h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3qGRgb61",
      "display_url" : "pastebin.com\/raw.php?i=3qGR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409789040578154496",
  "text" : "http:\/\/t.co\/6GYUK0Aa3h Emails: 47 Hashes: 41 E\/H: 1.15 Keywords: 0.0 #infoleak",
  "id" : 409789040578154496,
  "created_at" : "2013-12-08 20:58:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BWQa3o5uL1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3AsXhYcp",
      "display_url" : "pastebin.com\/raw.php?i=3AsX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409758446607536128",
  "text" : "http:\/\/t.co\/BWQa3o5uL1 Hashes: 65 Keywords: 0.19 #infoleak",
  "id" : 409758446607536128,
  "created_at" : "2013-12-08 18:56:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/efzuES6vCu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SwQRgCZN",
      "display_url" : "pastebin.com\/raw.php?i=SwQR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409751687193059328",
  "text" : "http:\/\/t.co\/efzuES6vCu Found possible Google API key(s) #infoleak",
  "id" : 409751687193059328,
  "created_at" : "2013-12-08 18:29:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nMHTRfPNaS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jRH9fARg",
      "display_url" : "pastebin.com\/raw.php?i=jRH9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409694109759062017",
  "text" : "http:\/\/t.co\/nMHTRfPNaS Emails: 1258 Keywords: -0.03 #infoleak",
  "id" : 409694109759062017,
  "created_at" : "2013-12-08 14:41:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1yvCCioWty",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JUfbeDVu",
      "display_url" : "pastebin.com\/raw.php?i=JUfb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409676437075931136",
  "text" : "http:\/\/t.co\/1yvCCioWty Emails: 170 Keywords: 0.11 #infoleak",
  "id" : 409676437075931136,
  "created_at" : "2013-12-08 13:30:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RKbW8Kk7Yt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SdK0qgm9",
      "display_url" : "pastebin.com\/raw.php?i=SdK0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409668869851062272",
  "text" : "http:\/\/t.co\/RKbW8Kk7Yt Emails: 1474 Keywords: 0.0 #infoleak",
  "id" : 409668869851062272,
  "created_at" : "2013-12-08 13:00:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1Jhda672O0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p2Pn9yTb",
      "display_url" : "pastebin.com\/raw.php?i=p2Pn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409657344771907584",
  "text" : "http:\/\/t.co\/1Jhda672O0 Emails: 5000 Keywords: 0.11 #infoleak",
  "id" : 409657344771907584,
  "created_at" : "2013-12-08 12:14:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EyhVOZghwn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=crL97e9p",
      "display_url" : "pastebin.com\/raw.php?i=crL9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409652108388872192",
  "text" : "http:\/\/t.co\/EyhVOZghwn Found possible Google API key(s) #infoleak",
  "id" : 409652108388872192,
  "created_at" : "2013-12-08 11:54:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8BApuScG0g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UNtxv388",
      "display_url" : "pastebin.com\/raw.php?i=UNtx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409642432523812864",
  "text" : "http:\/\/t.co\/8BApuScG0g Emails: 31 Keywords: -0.03 #infoleak",
  "id" : 409642432523812864,
  "created_at" : "2013-12-08 11:15:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fdhdllKTOa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mm6zK5tJ",
      "display_url" : "pastebin.com\/raw.php?i=Mm6z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409632501217239040",
  "text" : "http:\/\/t.co\/fdhdllKTOa Emails: 447 Keywords: 0.0 #infoleak",
  "id" : 409632501217239040,
  "created_at" : "2013-12-08 10:36:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TXmH2Zj8F8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3cfr9B5H",
      "display_url" : "pastebin.com\/raw.php?i=3cfr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409619216203915264",
  "text" : "http:\/\/t.co\/TXmH2Zj8F8 Emails: 287 Keywords: 0.33 #infoleak",
  "id" : 409619216203915264,
  "created_at" : "2013-12-08 09:43:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bH4CKNqyku",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gpDWN4kp",
      "display_url" : "pastebin.com\/raw.php?i=gpDW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409614022204338177",
  "text" : "http:\/\/t.co\/bH4CKNqyku Hashes: 110 Keywords: -0.17 #infoleak",
  "id" : 409614022204338177,
  "created_at" : "2013-12-08 09:22:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cIyPt1VaHZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4Qd7imTX",
      "display_url" : "pastebin.com\/raw.php?i=4Qd7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409613828972752896",
  "text" : "http:\/\/t.co\/cIyPt1VaHZ Hashes: 110 Keywords: -0.17 #infoleak",
  "id" : 409613828972752896,
  "created_at" : "2013-12-08 09:22:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jW3hRnOo23",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M9CRqnrY",
      "display_url" : "pastebin.com\/raw.php?i=M9CR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409607442205401088",
  "text" : "http:\/\/t.co\/jW3hRnOo23 Emails: 893 Keywords: 0.0 #infoleak",
  "id" : 409607442205401088,
  "created_at" : "2013-12-08 08:56:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VBeoh7MKqf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0zmWp67h",
      "display_url" : "pastebin.com\/raw.php?i=0zmW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409603874740133888",
  "text" : "http:\/\/t.co\/VBeoh7MKqf Emails: 44 Keywords: 0.22 #infoleak",
  "id" : 409603874740133888,
  "created_at" : "2013-12-08 08:42:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Dg0Cm6TmOQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qMzAQ8Le",
      "display_url" : "pastebin.com\/raw.php?i=qMzA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409589412255633408",
  "text" : "http:\/\/t.co\/Dg0Cm6TmOQ Emails: 34 Keywords: 0.11 #infoleak",
  "id" : 409589412255633408,
  "created_at" : "2013-12-08 07:45:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/19PaKG5hwO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ujn3PkEB",
      "display_url" : "pastebin.com\/raw.php?i=Ujn3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409551482027929601",
  "text" : "http:\/\/t.co\/19PaKG5hwO Emails: 2021 Hashes: 8 E\/H: 252.63 Keywords: 0.33 #infoleak",
  "id" : 409551482027929601,
  "created_at" : "2013-12-08 05:14:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MAIOVP2Oep",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HsE9Y2PQ",
      "display_url" : "pastebin.com\/raw.php?i=HsE9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409537092721471489",
  "text" : "http:\/\/t.co\/MAIOVP2Oep Found possible Google API key(s) #infoleak",
  "id" : 409537092721471489,
  "created_at" : "2013-12-08 04:17:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VHEdHQIkBC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HUBSqYxT",
      "display_url" : "pastebin.com\/raw.php?i=HUBS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409524838454149120",
  "text" : "http:\/\/t.co\/VHEdHQIkBC Emails: 745 Keywords: 0.11 #infoleak",
  "id" : 409524838454149120,
  "created_at" : "2013-12-08 03:28:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cx7rGFUdAB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0eEyJpYe",
      "display_url" : "pastebin.com\/raw.php?i=0eEy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409523548357529600",
  "text" : "http:\/\/t.co\/cx7rGFUdAB Emails: 166 Keywords: 0.0 #infoleak",
  "id" : 409523548357529600,
  "created_at" : "2013-12-08 03:23:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k4A5P3gw92",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=w87xXvjy",
      "display_url" : "pastebin.com\/raw.php?i=w87x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409507172758736896",
  "text" : "http:\/\/t.co\/k4A5P3gw92 Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 409507172758736896,
  "created_at" : "2013-12-08 02:18:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cKYxAkptwR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5nbZAQ6H",
      "display_url" : "pastebin.com\/raw.php?i=5nbZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409505124273238016",
  "text" : "http:\/\/t.co\/cKYxAkptwR Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 409505124273238016,
  "created_at" : "2013-12-08 02:10:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/13Kp84FZop",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=F4zaV26j",
      "display_url" : "pastebin.com\/raw.php?i=F4za\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409501749301346304",
  "text" : "http:\/\/t.co\/13Kp84FZop Emails: 161 Keywords: 0.11 #infoleak",
  "id" : 409501749301346304,
  "created_at" : "2013-12-08 01:56:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NdNx19wR51",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LWm3pFuW",
      "display_url" : "pastebin.com\/raw.php?i=LWm3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409497667622805504",
  "text" : "http:\/\/t.co\/NdNx19wR51 Found possible Google API key(s) #infoleak",
  "id" : 409497667622805504,
  "created_at" : "2013-12-08 01:40:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WN8LaCpv8E",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KxezUULe",
      "display_url" : "pastebin.com\/raw.php?i=Kxez\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409488394801012736",
  "text" : "http:\/\/t.co\/WN8LaCpv8E Emails: 4209 Keywords: 0.22 #infoleak",
  "id" : 409488394801012736,
  "created_at" : "2013-12-08 01:03:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WRrJEAcZ0O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T4Qj8bit",
      "display_url" : "pastebin.com\/raw.php?i=T4Qj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409473472612409344",
  "text" : "http:\/\/t.co\/WRrJEAcZ0O Hashes: 34 Keywords: 0.11 #infoleak",
  "id" : 409473472612409344,
  "created_at" : "2013-12-08 00:04:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mLGJsZOX0c",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iNPTXc9p",
      "display_url" : "pastebin.com\/raw.php?i=iNPT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409450516649762816",
  "text" : "http:\/\/t.co\/mLGJsZOX0c Emails: 3 Hashes: 89 E\/H: 0.03 Keywords: 0.55 #infoleak",
  "id" : 409450516649762816,
  "created_at" : "2013-12-07 22:33:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZqdC4FFu4O",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VK6sm7mx",
      "display_url" : "pastebin.com\/raw.php?i=VK6s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409441777003683840",
  "text" : "http:\/\/t.co\/ZqdC4FFu4O Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 409441777003683840,
  "created_at" : "2013-12-07 21:58:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tqUHXI2CPZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HgifYzfA",
      "display_url" : "pastebin.com\/raw.php?i=Hgif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409441465165565952",
  "text" : "http:\/\/t.co\/tqUHXI2CPZ Emails: 43 Keywords: 0.0 #infoleak",
  "id" : 409441465165565952,
  "created_at" : "2013-12-07 21:57:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oyhJbopemP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DEdwZF4s",
      "display_url" : "pastebin.com\/raw.php?i=DEdw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409428763873517568",
  "text" : "http:\/\/t.co\/oyhJbopemP Emails: 87 Keywords: 0.22 #infoleak",
  "id" : 409428763873517568,
  "created_at" : "2013-12-07 21:06:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uHpuoJil4Q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WPEeDpeC",
      "display_url" : "pastebin.com\/raw.php?i=WPEe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409428438055788544",
  "text" : "http:\/\/t.co\/uHpuoJil4Q Emails: 87 Keywords: 0.22 #infoleak",
  "id" : 409428438055788544,
  "created_at" : "2013-12-07 21:05:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NBJIIJvVDf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0bZY4AuC",
      "display_url" : "pastebin.com\/raw.php?i=0bZY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409426296188334080",
  "text" : "http:\/\/t.co\/NBJIIJvVDf Emails: 87 Keywords: -0.03 #infoleak",
  "id" : 409426296188334080,
  "created_at" : "2013-12-07 20:56:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/H4l5SekZhu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7ui4JrYt",
      "display_url" : "pastebin.com\/raw.php?i=7ui4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409426164411678720",
  "text" : "http:\/\/t.co\/H4l5SekZhu Emails: 47 Keywords: 0.08 #infoleak",
  "id" : 409426164411678720,
  "created_at" : "2013-12-07 20:56:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/30dModii7g",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NApA0A2v",
      "display_url" : "pastebin.com\/raw.php?i=NApA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409424400434216960",
  "text" : "http:\/\/t.co\/30dModii7g Emails: 55 Keywords: -0.03 #infoleak",
  "id" : 409424400434216960,
  "created_at" : "2013-12-07 20:49:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tDwuc0Pq8n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bS1amawj",
      "display_url" : "pastebin.com\/raw.php?i=bS1a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409413883778961408",
  "text" : "http:\/\/t.co\/tDwuc0Pq8n Emails: 33 Keywords: -0.14 #infoleak",
  "id" : 409413883778961408,
  "created_at" : "2013-12-07 20:07:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x0iaig184x",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UNef3jJk",
      "display_url" : "pastebin.com\/raw.php?i=UNef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409410314862460928",
  "text" : "http:\/\/t.co\/x0iaig184x Found possible Google API key(s) #infoleak",
  "id" : 409410314862460928,
  "created_at" : "2013-12-07 19:53:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aBzn1jRnCB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3XX6pBFw",
      "display_url" : "pastebin.com\/raw.php?i=3XX6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409405101728493568",
  "text" : "http:\/\/t.co\/aBzn1jRnCB Emails: 85 Keywords: 0.0 #infoleak",
  "id" : 409405101728493568,
  "created_at" : "2013-12-07 19:32:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ETzD2qqZ2y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FcdpsCfX",
      "display_url" : "pastebin.com\/raw.php?i=Fcdp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409403173988605952",
  "text" : "http:\/\/t.co\/ETzD2qqZ2y Emails: 1 Hashes: 1120 E\/H: 0.0 Keywords: 0.22 #infoleak",
  "id" : 409403173988605952,
  "created_at" : "2013-12-07 19:24:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1dSOt8qQNc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aLNvnu14",
      "display_url" : "pastebin.com\/raw.php?i=aLNv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409389192502722560",
  "text" : "http:\/\/t.co\/1dSOt8qQNc Hashes: 59 Keywords: 0.19 #infoleak",
  "id" : 409389192502722560,
  "created_at" : "2013-12-07 18:29:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l8rUdeOUfL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QT5wHidi",
      "display_url" : "pastebin.com\/raw.php?i=QT5w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409388432226406400",
  "text" : "http:\/\/t.co\/l8rUdeOUfL Emails: 31 Hashes: 122 E\/H: 0.25 Keywords: -0.03 #infoleak",
  "id" : 409388432226406400,
  "created_at" : "2013-12-07 18:26:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wTPtNrIMHp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VjvLB7bW",
      "display_url" : "pastebin.com\/raw.php?i=VjvL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409383186980823040",
  "text" : "http:\/\/t.co\/wTPtNrIMHp Hashes: 41 Keywords: 0.22 #infoleak",
  "id" : 409383186980823040,
  "created_at" : "2013-12-07 18:05:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lKzyoJcNkI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=e9nx5zu5",
      "display_url" : "pastebin.com\/raw.php?i=e9nx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409380617059438594",
  "text" : "http:\/\/t.co\/lKzyoJcNkI Emails: 28 Hashes: 28 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 409380617059438594,
  "created_at" : "2013-12-07 17:55:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MSKTmD1Ue0",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bc97uRaW",
      "display_url" : "pastebin.com\/raw.php?i=bc97\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409371531060326400",
  "text" : "http:\/\/t.co\/MSKTmD1Ue0 Emails: 4367 Hashes: 4987 E\/H: 0.88 Keywords: 0.3 #infoleak",
  "id" : 409371531060326400,
  "created_at" : "2013-12-07 17:19:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jqeJ538y1q",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6eq6eMf0",
      "display_url" : "pastebin.com\/raw.php?i=6eq6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409368000735612928",
  "text" : "http:\/\/t.co\/jqeJ538y1q Emails: 10919 Keywords: 0.08 #infoleak",
  "id" : 409368000735612928,
  "created_at" : "2013-12-07 17:05:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pB72tlN4Pj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qg09duMZ",
      "display_url" : "pastebin.com\/raw.php?i=Qg09\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409364399158075392",
  "text" : "http:\/\/t.co\/pB72tlN4Pj Emails: 20 Keywords: 0.08 #infoleak",
  "id" : 409364399158075392,
  "created_at" : "2013-12-07 16:50:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cA9inb1CZH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wpC4EeGL",
      "display_url" : "pastebin.com\/raw.php?i=wpC4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409351339580207106",
  "text" : "http:\/\/t.co\/cA9inb1CZH Emails: 24 Keywords: -0.14 #infoleak",
  "id" : 409351339580207106,
  "created_at" : "2013-12-07 15:58:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CFIucq5SHl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jxccqTJi",
      "display_url" : "pastebin.com\/raw.php?i=jxcc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409340435375480832",
  "text" : "http:\/\/t.co\/CFIucq5SHl Emails: 72 Keywords: 0.0 #infoleak",
  "id" : 409340435375480832,
  "created_at" : "2013-12-07 15:15:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4rrVPddbOm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gLAxJe74",
      "display_url" : "pastebin.com\/raw.php?i=gLAx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409336789812260864",
  "text" : "http:\/\/t.co\/4rrVPddbOm Emails: 474 Hashes: 473 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 409336789812260864,
  "created_at" : "2013-12-07 15:01:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8YANT2ODyX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qabZRG8t",
      "display_url" : "pastebin.com\/raw.php?i=qabZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409331979889303552",
  "text" : "http:\/\/t.co\/8YANT2ODyX Emails: 161 Keywords: 0.11 #infoleak",
  "id" : 409331979889303552,
  "created_at" : "2013-12-07 14:42:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6zYvtTbDKw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ELqZLkWx",
      "display_url" : "pastebin.com\/raw.php?i=ELqZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409311830020849664",
  "text" : "http:\/\/t.co\/6zYvtTbDKw Hashes: 55 Keywords: 0.22 #infoleak",
  "id" : 409311830020849664,
  "created_at" : "2013-12-07 13:21:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MzxZn4JWeS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8h27zikE",
      "display_url" : "pastebin.com\/raw.php?i=8h27\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409296293668741120",
  "text" : "http:\/\/t.co\/MzxZn4JWeS Emails: 1254 Keywords: -0.03 #infoleak",
  "id" : 409296293668741120,
  "created_at" : "2013-12-07 12:20:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qjuo8Kxbds",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jS0Tqgnt",
      "display_url" : "pastebin.com\/raw.php?i=jS0T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409288791568826368",
  "text" : "http:\/\/t.co\/qjuo8Kxbds Hashes: 352 Keywords: 0.11 #infoleak",
  "id" : 409288791568826368,
  "created_at" : "2013-12-07 11:50:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VIuRmMQTTA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eASaBVMj",
      "display_url" : "pastebin.com\/raw.php?i=eASa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409284425147355136",
  "text" : "http:\/\/t.co\/VIuRmMQTTA Hashes: 51 Keywords: -0.03 #infoleak",
  "id" : 409284425147355136,
  "created_at" : "2013-12-07 11:33:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RnYxKoBtoU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qadBQWGS",
      "display_url" : "pastebin.com\/raw.php?i=qadB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409133119556419584",
  "text" : "http:\/\/t.co\/RnYxKoBtoU Keywords: 0.55 #infoleak",
  "id" : 409133119556419584,
  "created_at" : "2013-12-07 01:31:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IQNqy5k2J3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xpw7sNtv",
      "display_url" : "pastebin.com\/raw.php?i=Xpw7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409118256759185409",
  "text" : "http:\/\/t.co\/IQNqy5k2J3 Emails: 41 Keywords: 0.0 #infoleak",
  "id" : 409118256759185409,
  "created_at" : "2013-12-07 00:32:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u9b0kbvigo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NZS32A4g",
      "display_url" : "pastebin.com\/raw.php?i=NZS3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409117754201866240",
  "text" : "http:\/\/t.co\/u9b0kbvigo Found possible Google API key(s) #infoleak",
  "id" : 409117754201866240,
  "created_at" : "2013-12-07 00:30:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BOWOO9yORS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dnMeqDTc",
      "display_url" : "pastebin.com\/raw.php?i=dnMe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409116644397445120",
  "text" : "http:\/\/t.co\/BOWOO9yORS Emails: 187 Keywords: 0.11 #infoleak",
  "id" : 409116644397445120,
  "created_at" : "2013-12-07 00:26:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NDBfmLru7t",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Qt6bqgL5",
      "display_url" : "pastebin.com\/raw.php?i=Qt6b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409114568942579712",
  "text" : "http:\/\/t.co\/NDBfmLru7t Emails: 100 Keywords: 0.0 #infoleak",
  "id" : 409114568942579712,
  "created_at" : "2013-12-07 00:18:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1OfQTgBE4n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yaf199Mh",
      "display_url" : "pastebin.com\/raw.php?i=yaf1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409092014039265280",
  "text" : "http:\/\/t.co\/1OfQTgBE4n Emails: 2198 Keywords: 0.11 #infoleak",
  "id" : 409092014039265280,
  "created_at" : "2013-12-06 22:48:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aWkHUwgcRb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0TDBXPEN",
      "display_url" : "pastebin.com\/raw.php?i=0TDB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409083617067806720",
  "text" : "http:\/\/t.co\/aWkHUwgcRb Keywords: 0.55 #infoleak",
  "id" : 409083617067806720,
  "created_at" : "2013-12-06 22:15:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/veFct56ahg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pPDaNwyp",
      "display_url" : "pastebin.com\/raw.php?i=pPDa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408880276333281280",
  "text" : "http:\/\/t.co\/veFct56ahg Hashes: 40 Keywords: 0.11 #infoleak",
  "id" : 408880276333281280,
  "created_at" : "2013-12-06 08:47:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TA23fw8gzP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q3FbqMir",
      "display_url" : "pastebin.com\/raw.php?i=q3Fb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408860194383224832",
  "text" : "http:\/\/t.co\/TA23fw8gzP Emails: 1 Hashes: 515 E\/H: 0.0 Keywords: 0.44 #infoleak",
  "id" : 408860194383224832,
  "created_at" : "2013-12-06 07:27:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QqTL2WrElg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1neYKGe1",
      "display_url" : "pastebin.com\/raw.php?i=1neY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408855563083079680",
  "text" : "http:\/\/t.co\/QqTL2WrElg Emails: 376 Keywords: 0.0 #infoleak",
  "id" : 408855563083079680,
  "created_at" : "2013-12-06 07:08:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lRzOM5ADXL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h6EZpEYS",
      "display_url" : "pastebin.com\/raw.php?i=h6EZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408814725305077760",
  "text" : "http:\/\/t.co\/lRzOM5ADXL Emails: 26 Keywords: -0.14 #infoleak",
  "id" : 408814725305077760,
  "created_at" : "2013-12-06 04:26:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R0JwLJW8UG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vq8YthUN",
      "display_url" : "pastebin.com\/raw.php?i=vq8Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408814568060624896",
  "text" : "http:\/\/t.co\/R0JwLJW8UG Emails: 153 Keywords: 0.88 #infoleak",
  "id" : 408814568060624896,
  "created_at" : "2013-12-06 04:26:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2bUahKkrFy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N1NvhBug",
      "display_url" : "pastebin.com\/raw.php?i=N1Nv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408812218193833984",
  "text" : "http:\/\/t.co\/2bUahKkrFy Found possible Google API key(s) #infoleak",
  "id" : 408812218193833984,
  "created_at" : "2013-12-06 04:16:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/anVIG9XnQK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CKYeV9gx",
      "display_url" : "pastebin.com\/raw.php?i=CKYe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408780510899355648",
  "text" : "http:\/\/t.co\/anVIG9XnQK Hashes: 161 Keywords: 0.08 #infoleak",
  "id" : 408780510899355648,
  "created_at" : "2013-12-06 02:10:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oOf4WRm9eb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KCFNdbdx",
      "display_url" : "pastebin.com\/raw.php?i=KCFN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408778387314851840",
  "text" : "http:\/\/t.co\/oOf4WRm9eb Hashes: 169 Keywords: 0.19 #infoleak",
  "id" : 408778387314851840,
  "created_at" : "2013-12-06 02:02:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CyhADsJwXl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qLL5a21e",
      "display_url" : "pastebin.com\/raw.php?i=qLL5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408769039050108928",
  "text" : "http:\/\/t.co\/CyhADsJwXl Hashes: 46 Keywords: 0.77 #infoleak",
  "id" : 408769039050108928,
  "created_at" : "2013-12-06 01:25:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3Z8Ep99YU6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3XmHsWM3",
      "display_url" : "pastebin.com\/raw.php?i=3XmH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408767431276916736",
  "text" : "http:\/\/t.co\/3Z8Ep99YU6 Hashes: 135 Keywords: 0.19 #infoleak",
  "id" : 408767431276916736,
  "created_at" : "2013-12-06 01:18:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OvZf3b6l2Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FXfX9NRy",
      "display_url" : "pastebin.com\/raw.php?i=FXfX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408765012555988992",
  "text" : "http:\/\/t.co\/OvZf3b6l2Z Possible cisco configuration #infoleak",
  "id" : 408765012555988992,
  "created_at" : "2013-12-06 01:09:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/o1tdXL8gYw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GaARH56y",
      "display_url" : "pastebin.com\/raw.php?i=GaAR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408748642036490240",
  "text" : "http:\/\/t.co\/o1tdXL8gYw Emails: 164 Keywords: 0.0 #infoleak",
  "id" : 408748642036490240,
  "created_at" : "2013-12-06 00:04:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gw0Y9yeh5Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q1Hf2rVY",
      "display_url" : "pastebin.com\/raw.php?i=Q1Hf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408746663927242752",
  "text" : "http:\/\/t.co\/Gw0Y9yeh5Y Emails: 26 Keywords: 0.0 #infoleak",
  "id" : 408746663927242752,
  "created_at" : "2013-12-05 23:56:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GIdfzXRqYP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FAPzQJn2",
      "display_url" : "pastebin.com\/raw.php?i=FAPz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408744948989558784",
  "text" : "http:\/\/t.co\/GIdfzXRqYP Emails: 80 Keywords: 0.0 #infoleak",
  "id" : 408744948989558784,
  "created_at" : "2013-12-05 23:49:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t909arMw8P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pMpKMAMW",
      "display_url" : "pastebin.com\/raw.php?i=pMpK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408743037443899392",
  "text" : "http:\/\/t.co\/t909arMw8P Emails: 80 Keywords: 0.0 #infoleak",
  "id" : 408743037443899392,
  "created_at" : "2013-12-05 23:41:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KNWrpXcwLo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bu7iAM32",
      "display_url" : "pastebin.com\/raw.php?i=Bu7i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408735555048849408",
  "text" : "http:\/\/t.co\/KNWrpXcwLo Found possible Google API key(s) #infoleak",
  "id" : 408735555048849408,
  "created_at" : "2013-12-05 23:12:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ruoyOo66sc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jYbXjcwk",
      "display_url" : "pastebin.com\/raw.php?i=jYbX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408730565987143681",
  "text" : "http:\/\/t.co\/ruoyOo66sc Emails: 595 Keywords: 0.33 #infoleak",
  "id" : 408730565987143681,
  "created_at" : "2013-12-05 22:52:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C9EVTHsbew",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2pWtLLg7",
      "display_url" : "pastebin.com\/raw.php?i=2pWt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408725122036404225",
  "text" : "http:\/\/t.co\/C9EVTHsbew Emails: 21 Keywords: -0.14 #infoleak",
  "id" : 408725122036404225,
  "created_at" : "2013-12-05 22:30:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I4CKOpt0W2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R0CYKNj5",
      "display_url" : "pastebin.com\/raw.php?i=R0CY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408720605735706624",
  "text" : "http:\/\/t.co\/I4CKOpt0W2 Emails: 2815 Hashes: 2815 E\/H: 1.0 Keywords: 0.11 #infoleak",
  "id" : 408720605735706624,
  "created_at" : "2013-12-05 22:12:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/iwIl1wYlev",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v26rK22s",
      "display_url" : "pastebin.com\/raw.php?i=v26r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408719189822537728",
  "text" : "http:\/\/t.co\/iwIl1wYlev Hashes: 54 Keywords: 0.22 #infoleak",
  "id" : 408719189822537728,
  "created_at" : "2013-12-05 22:07:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pVdXQJJpKW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YYr9gGT7",
      "display_url" : "pastebin.com\/raw.php?i=YYr9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408712429338509312",
  "text" : "http:\/\/t.co\/pVdXQJJpKW Keywords: 0.55 #infoleak",
  "id" : 408712429338509312,
  "created_at" : "2013-12-05 21:40:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e8aljlEESk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g4JeSCa5",
      "display_url" : "pastebin.com\/raw.php?i=g4Je\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408711879561728000",
  "text" : "http:\/\/t.co\/e8aljlEESk Emails: 2817 Keywords: 0.22 #infoleak",
  "id" : 408711879561728000,
  "created_at" : "2013-12-05 21:38:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/21dmw37Uiw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mgzeJfyB",
      "display_url" : "pastebin.com\/raw.php?i=mgze\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408711133793513473",
  "text" : "http:\/\/t.co\/21dmw37Uiw Hashes: 54 Keywords: 0.22 #infoleak",
  "id" : 408711133793513473,
  "created_at" : "2013-12-05 21:35:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qB81eWCHkv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jnpVVAxy",
      "display_url" : "pastebin.com\/raw.php?i=jnpV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408711100905975808",
  "text" : "http:\/\/t.co\/qB81eWCHkv Emails: 12966 Keywords: 0.08 #infoleak",
  "id" : 408711100905975808,
  "created_at" : "2013-12-05 21:34:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fP3ZAGq0NB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DKB8iTiX",
      "display_url" : "pastebin.com\/raw.php?i=DKB8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408707960110456832",
  "text" : "http:\/\/t.co\/fP3ZAGq0NB Hashes: 48 Keywords: 0.0 #infoleak",
  "id" : 408707960110456832,
  "created_at" : "2013-12-05 21:22:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tN2YQH8Bo9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0ittjRKf",
      "display_url" : "pastebin.com\/raw.php?i=0itt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408701228621647873",
  "text" : "http:\/\/t.co\/tN2YQH8Bo9 Emails: 153 Keywords: 0.66 #infoleak",
  "id" : 408701228621647873,
  "created_at" : "2013-12-05 20:55:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eS0QaIXMHw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EimiJmxw",
      "display_url" : "pastebin.com\/raw.php?i=Eimi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408597721394585600",
  "text" : "http:\/\/t.co\/eS0QaIXMHw Found possible Google API key(s) #infoleak",
  "id" : 408597721394585600,
  "created_at" : "2013-12-05 14:04:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qZBb8Rd1Hq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fkxj9T3S",
      "display_url" : "pastebin.com\/raw.php?i=Fkxj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408594197436850176",
  "text" : "http:\/\/t.co\/qZBb8Rd1Hq Hashes: 32 Keywords: 0.08 #infoleak",
  "id" : 408594197436850176,
  "created_at" : "2013-12-05 13:50:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KoryVs7qFX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3ne2viiL",
      "display_url" : "pastebin.com\/raw.php?i=3ne2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408591682796396545",
  "text" : "http:\/\/t.co\/KoryVs7qFX Emails: 28 Keywords: -0.03 #infoleak",
  "id" : 408591682796396545,
  "created_at" : "2013-12-05 13:40:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hO66AB7sTz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Q3hjtG2P",
      "display_url" : "pastebin.com\/raw.php?i=Q3hj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408589603747016706",
  "text" : "http:\/\/t.co\/hO66AB7sTz Keywords: 0.55 #infoleak",
  "id" : 408589603747016706,
  "created_at" : "2013-12-05 13:32:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CrR6629HRS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hehCduNp",
      "display_url" : "pastebin.com\/raw.php?i=hehC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408587057389252608",
  "text" : "http:\/\/t.co\/CrR6629HRS Keywords: 0.55 #infoleak",
  "id" : 408587057389252608,
  "created_at" : "2013-12-05 13:22:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HGFZDu50R1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZjwJVq2a",
      "display_url" : "pastebin.com\/raw.php?i=ZjwJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408575149143629824",
  "text" : "http:\/\/t.co\/HGFZDu50R1 Emails: 251 Hashes: 256 E\/H: 0.98 Keywords: 0.44 #infoleak",
  "id" : 408575149143629824,
  "created_at" : "2013-12-05 12:34:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mAK2LkPDz8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1KV1yMaA",
      "display_url" : "pastebin.com\/raw.php?i=1KV1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408568795368681473",
  "text" : "http:\/\/t.co\/mAK2LkPDz8 Emails: 698 Keywords: 0.11 #infoleak",
  "id" : 408568795368681473,
  "created_at" : "2013-12-05 12:09:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ITM9Ddp1xi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P7keVPyg",
      "display_url" : "pastebin.com\/raw.php?i=P7ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408567392709529600",
  "text" : "http:\/\/t.co\/ITM9Ddp1xi Emails: 4 Hashes: 447 E\/H: 0.01 Keywords: 0.05 #infoleak",
  "id" : 408567392709529600,
  "created_at" : "2013-12-05 12:03:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/61YcQFSWQx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rVgNuVpx",
      "display_url" : "pastebin.com\/raw.php?i=rVgN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408556032101601280",
  "text" : "http:\/\/t.co\/61YcQFSWQx Hashes: 3296 Keywords: 0.22 #infoleak",
  "id" : 408556032101601280,
  "created_at" : "2013-12-05 11:18:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GXsIndgpo4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BbqFPTjw",
      "display_url" : "pastebin.com\/raw.php?i=BbqF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408553727767764992",
  "text" : "http:\/\/t.co\/GXsIndgpo4 Found possible Google API key(s) #infoleak",
  "id" : 408553727767764992,
  "created_at" : "2013-12-05 11:09:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IDxZVsYpp3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uLSDasLJ",
      "display_url" : "pastebin.com\/raw.php?i=uLSD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408547786057990144",
  "text" : "http:\/\/t.co\/IDxZVsYpp3 Emails: 91 Hashes: 532 E\/H: 0.17 Keywords: 0.33 #infoleak",
  "id" : 408547786057990144,
  "created_at" : "2013-12-05 10:45:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5UA9GPeiYR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=c9C1CyP8",
      "display_url" : "pastebin.com\/raw.php?i=c9C1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408541715973165056",
  "text" : "http:\/\/t.co\/5UA9GPeiYR Hashes: 144 Keywords: 0.22 #infoleak",
  "id" : 408541715973165056,
  "created_at" : "2013-12-05 10:21:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/casQvZ7NH5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JRUuas6g",
      "display_url" : "pastebin.com\/raw.php?i=JRUu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408530719330144256",
  "text" : "http:\/\/t.co\/casQvZ7NH5 Found possible Google API key(s) #infoleak",
  "id" : 408530719330144256,
  "created_at" : "2013-12-05 09:38:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nbrtgDaA9T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=q59qtWjC",
      "display_url" : "pastebin.com\/raw.php?i=q59q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408526023173476352",
  "text" : "http:\/\/t.co\/nbrtgDaA9T Hashes: 314 Keywords: -0.06 #infoleak",
  "id" : 408526023173476352,
  "created_at" : "2013-12-05 09:19:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OqMeV4XtAK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7LB0r0fw",
      "display_url" : "pastebin.com\/raw.php?i=7LB0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408525361480085505",
  "text" : "http:\/\/t.co\/OqMeV4XtAK Keywords: 0.55 #infoleak",
  "id" : 408525361480085505,
  "created_at" : "2013-12-05 09:16:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1WtWUH7hLa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Y6xeCF44",
      "display_url" : "pastebin.com\/raw.php?i=Y6xe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408524621554544640",
  "text" : "http:\/\/t.co\/1WtWUH7hLa Emails: 33 Keywords: -0.03 #infoleak",
  "id" : 408524621554544640,
  "created_at" : "2013-12-05 09:13:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JSa8HrTAAL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mSWKMSyc",
      "display_url" : "pastebin.com\/raw.php?i=mSWK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408523147478962177",
  "text" : "http:\/\/t.co\/JSa8HrTAAL Hashes: 272 Keywords: -0.09 #infoleak",
  "id" : 408523147478962177,
  "created_at" : "2013-12-05 09:08:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KIwJC5dmbK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Wg6jAMFB",
      "display_url" : "pastebin.com\/raw.php?i=Wg6j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408516519291670528",
  "text" : "http:\/\/t.co\/KIwJC5dmbK Emails: 91 Keywords: 0.22 #infoleak",
  "id" : 408516519291670528,
  "created_at" : "2013-12-05 08:41:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5wjh2GZf5T",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k3qsFvJB",
      "display_url" : "pastebin.com\/raw.php?i=k3qs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408506699813634048",
  "text" : "http:\/\/t.co\/5wjh2GZf5T Emails: 3 Hashes: 41 E\/H: 0.07 Keywords: -0.06 #infoleak",
  "id" : 408506699813634048,
  "created_at" : "2013-12-05 08:02:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4XkSysWhfC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PXQUSEK8",
      "display_url" : "pastebin.com\/raw.php?i=PXQU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408499484331474944",
  "text" : "http:\/\/t.co\/4XkSysWhfC Found possible Google API key(s) #infoleak",
  "id" : 408499484331474944,
  "created_at" : "2013-12-05 07:34:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/51PuIrr4m9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nF2cYh6z",
      "display_url" : "pastebin.com\/raw.php?i=nF2c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408471736150020097",
  "text" : "http:\/\/t.co\/51PuIrr4m9 Hashes: 68 Keywords: 0.22 #infoleak",
  "id" : 408471736150020097,
  "created_at" : "2013-12-05 05:43:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zXIydFUE2F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Um9HCBmv",
      "display_url" : "pastebin.com\/raw.php?i=Um9H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408458048521244672",
  "text" : "http:\/\/t.co\/zXIydFUE2F Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 408458048521244672,
  "created_at" : "2013-12-05 04:49:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L6sXhkS5Kl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7H12dvgq",
      "display_url" : "pastebin.com\/raw.php?i=7H12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408452657351622656",
  "text" : "http:\/\/t.co\/L6sXhkS5Kl Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 408452657351622656,
  "created_at" : "2013-12-05 04:27:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kBqGud6qgY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZL8tLNWa",
      "display_url" : "pastebin.com\/raw.php?i=ZL8t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408429337952538624",
  "text" : "http:\/\/t.co\/kBqGud6qgY Emails: 92 Keywords: 0.0 #infoleak",
  "id" : 408429337952538624,
  "created_at" : "2013-12-05 02:55:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aU0XLy0mRX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i4ntB1Ub",
      "display_url" : "pastebin.com\/raw.php?i=i4nt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408422685408903168",
  "text" : "http:\/\/t.co\/aU0XLy0mRX Hashes: 134 Keywords: 0.19 #infoleak",
  "id" : 408422685408903168,
  "created_at" : "2013-12-05 02:28:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sx9E3z6tDy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mnBVPt9E",
      "display_url" : "pastebin.com\/raw.php?i=mnBV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408415013494194177",
  "text" : "http:\/\/t.co\/sx9E3z6tDy Emails: 36 Keywords: 0.0 #infoleak",
  "id" : 408415013494194177,
  "created_at" : "2013-12-05 01:58:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vOAAe6pjE6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BDeVsrVD",
      "display_url" : "pastebin.com\/raw.php?i=BDeV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408394538000973824",
  "text" : "http:\/\/t.co\/vOAAe6pjE6 Emails: 63 Keywords: 0.0 #infoleak",
  "id" : 408394538000973824,
  "created_at" : "2013-12-05 00:37:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MpQ2ZFvfZz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TAf2pj74",
      "display_url" : "pastebin.com\/raw.php?i=TAf2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408375100170203136",
  "text" : "http:\/\/t.co\/MpQ2ZFvfZz Emails: 20 Keywords: -0.14 #infoleak",
  "id" : 408375100170203136,
  "created_at" : "2013-12-04 23:19:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TJxXYrVZYH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=STTFUu8V",
      "display_url" : "pastebin.com\/raw.php?i=STTF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408345427704954882",
  "text" : "http:\/\/t.co\/TJxXYrVZYH Emails: 32 Hashes: 1 E\/H: 32.0 Keywords: 0.22 #infoleak",
  "id" : 408345427704954882,
  "created_at" : "2013-12-04 21:21:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OCcNLSkCbv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MkQaWe7R",
      "display_url" : "pastebin.com\/raw.php?i=MkQa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408344591465598980",
  "text" : "http:\/\/t.co\/OCcNLSkCbv Hashes: 136 Keywords: 0.33 #infoleak",
  "id" : 408344591465598980,
  "created_at" : "2013-12-04 21:18:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z5Fkjvdmeg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pL6HyN8t",
      "display_url" : "pastebin.com\/raw.php?i=pL6H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408337580535459845",
  "text" : "http:\/\/t.co\/Z5Fkjvdmeg Hashes: 136 Keywords: 0.19 #infoleak",
  "id" : 408337580535459845,
  "created_at" : "2013-12-04 20:50:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nBcK1DbOwl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8QWVgwF9",
      "display_url" : "pastebin.com\/raw.php?i=8QWV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408335277715763201",
  "text" : "http:\/\/t.co\/nBcK1DbOwl Found possible Google API key(s) #infoleak",
  "id" : 408335277715763201,
  "created_at" : "2013-12-04 20:41:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OnVlKQsz47",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rfa12MZq",
      "display_url" : "pastebin.com\/raw.php?i=rfa1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408331025970765825",
  "text" : "http:\/\/t.co\/OnVlKQsz47 Found possible Google API key(s) #infoleak",
  "id" : 408331025970765825,
  "created_at" : "2013-12-04 20:24:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TVxW2DzYIW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=tPTihuqf",
      "display_url" : "pastebin.com\/raw.php?i=tPTi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408316296703389696",
  "text" : "http:\/\/t.co\/TVxW2DzYIW Found possible Google API key(s) #infoleak",
  "id" : 408316296703389696,
  "created_at" : "2013-12-04 19:26:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ovgydyl4lh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S80K3XNY",
      "display_url" : "pastebin.com\/raw.php?i=S80K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408305197631287296",
  "text" : "http:\/\/t.co\/ovgydyl4lh Emails: 71 Keywords: 0.0 #infoleak",
  "id" : 408305197631287296,
  "created_at" : "2013-12-04 18:41:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/84wqlGmqjJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HxQFz3EH",
      "display_url" : "pastebin.com\/raw.php?i=HxQF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408303580307668993",
  "text" : "http:\/\/t.co\/84wqlGmqjJ Found possible Google API key(s) #infoleak",
  "id" : 408303580307668993,
  "created_at" : "2013-12-04 18:35:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OMoe5zkH0w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CWGxUSXS",
      "display_url" : "pastebin.com\/raw.php?i=CWGx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408303088655560704",
  "text" : "http:\/\/t.co\/OMoe5zkH0w Emails: 67 Keywords: 0.11 #infoleak",
  "id" : 408303088655560704,
  "created_at" : "2013-12-04 18:33:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w5ejMvUmMb",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QZ3X7vP6",
      "display_url" : "pastebin.com\/raw.php?i=QZ3X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408296720045334528",
  "text" : "http:\/\/t.co\/w5ejMvUmMb Emails: 91 Keywords: 0.22 #infoleak",
  "id" : 408296720045334528,
  "created_at" : "2013-12-04 18:08:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oWxChCHbul",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LuaAAFZ4",
      "display_url" : "pastebin.com\/raw.php?i=LuaA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408279980162834432",
  "text" : "http:\/\/t.co\/oWxChCHbul Found possible Google API key(s) #infoleak",
  "id" : 408279980162834432,
  "created_at" : "2013-12-04 17:01:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wmZ9Of99Q4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pamNsDcR",
      "display_url" : "pastebin.com\/raw.php?i=pamN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408273368647872512",
  "text" : "http:\/\/t.co\/wmZ9Of99Q4 Found possible Google API key(s) #infoleak",
  "id" : 408273368647872512,
  "created_at" : "2013-12-04 16:35:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/81nEMVFMcf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SB8LGaRj",
      "display_url" : "pastebin.com\/raw.php?i=SB8L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408272293589053440",
  "text" : "http:\/\/t.co\/81nEMVFMcf Emails: 20 Keywords: 0.22 #infoleak",
  "id" : 408272293589053440,
  "created_at" : "2013-12-04 16:31:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1rdOHVMIuF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8DY9NUpw",
      "display_url" : "pastebin.com\/raw.php?i=8DY9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408272210680246272",
  "text" : "http:\/\/t.co\/1rdOHVMIuF Emails: 70 Keywords: 0.0 #infoleak",
  "id" : 408272210680246272,
  "created_at" : "2013-12-04 16:30:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LptHkIQclk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NfgJfHi8",
      "display_url" : "pastebin.com\/raw.php?i=NfgJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408268996190806016",
  "text" : "http:\/\/t.co\/LptHkIQclk Emails: 91 Keywords: 0.22 #infoleak",
  "id" : 408268996190806016,
  "created_at" : "2013-12-04 16:18:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Sob6YdJ0R8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Jwq7Kn55",
      "display_url" : "pastebin.com\/raw.php?i=Jwq7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408263523316162561",
  "text" : "http:\/\/t.co\/Sob6YdJ0R8 Emails: 164 Hashes: 164 E\/H: 1.0 Keywords: 0.0 #infoleak",
  "id" : 408263523316162561,
  "created_at" : "2013-12-04 15:56:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7joSeQwqVd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ks3YdyKv",
      "display_url" : "pastebin.com\/raw.php?i=ks3Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408263406567690241",
  "text" : "http:\/\/t.co\/7joSeQwqVd Emails: 1000 Keywords: 0.11 #infoleak",
  "id" : 408263406567690241,
  "created_at" : "2013-12-04 15:55:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SOveQnVjwe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fLVVRxvh",
      "display_url" : "pastebin.com\/raw.php?i=fLVV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408262630927646720",
  "text" : "http:\/\/t.co\/SOveQnVjwe Emails: 143 Keywords: 0.0 #infoleak",
  "id" : 408262630927646720,
  "created_at" : "2013-12-04 15:52:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fhFk1HOZCX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Gmf7ZFEG",
      "display_url" : "pastebin.com\/raw.php?i=Gmf7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408262336554606592",
  "text" : "http:\/\/t.co\/fhFk1HOZCX Emails: 135 Keywords: 0.0 #infoleak",
  "id" : 408262336554606592,
  "created_at" : "2013-12-04 15:51:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XUH7zD42CT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VZA2usx5",
      "display_url" : "pastebin.com\/raw.php?i=VZA2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408261895611621376",
  "text" : "http:\/\/t.co\/XUH7zD42CT Emails: 182 Keywords: 0.0 #infoleak",
  "id" : 408261895611621376,
  "created_at" : "2013-12-04 15:49:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lxvWbIG3mI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Zv0KRDaC",
      "display_url" : "pastebin.com\/raw.php?i=Zv0K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408247811868602368",
  "text" : "http:\/\/t.co\/lxvWbIG3mI Emails: 1 Hashes: 32 E\/H: 0.03 Keywords: 0.0 #infoleak",
  "id" : 408247811868602368,
  "created_at" : "2013-12-04 14:53:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UHbT6PtnlI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=20Sp1m22",
      "display_url" : "pastebin.com\/raw.php?i=20Sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408241941311008768",
  "text" : "http:\/\/t.co\/UHbT6PtnlI Keywords: 0.55 #infoleak",
  "id" : 408241941311008768,
  "created_at" : "2013-12-04 14:30:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NfMUS9tvVO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=u5JWHLrs",
      "display_url" : "pastebin.com\/raw.php?i=u5JW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408236040986431488",
  "text" : "http:\/\/t.co\/NfMUS9tvVO Found possible Google API key(s) #infoleak",
  "id" : 408236040986431488,
  "created_at" : "2013-12-04 14:07:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yyDOlMSJLN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wEKP25TX",
      "display_url" : "pastebin.com\/raw.php?i=wEKP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408228302776582144",
  "text" : "http:\/\/t.co\/yyDOlMSJLN Possible cisco configuration #infoleak",
  "id" : 408228302776582144,
  "created_at" : "2013-12-04 13:36:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qtT2xnWeON",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5jV8jGw7",
      "display_url" : "pastebin.com\/raw.php?i=5jV8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408228227551739904",
  "text" : "http:\/\/t.co\/qtT2xnWeON Found possible Google API key(s) #infoleak",
  "id" : 408228227551739904,
  "created_at" : "2013-12-04 13:36:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uFu3W31rMi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jM7rTJGm",
      "display_url" : "pastebin.com\/raw.php?i=jM7r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408213294353088514",
  "text" : "http:\/\/t.co\/uFu3W31rMi Possible cisco configuration #infoleak",
  "id" : 408213294353088514,
  "created_at" : "2013-12-04 12:36:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KdO6tGR05w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RcJATuma",
      "display_url" : "pastebin.com\/raw.php?i=RcJA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408193230648266752",
  "text" : "http:\/\/t.co\/KdO6tGR05w Emails: 1626 Keywords: 0.11 #infoleak",
  "id" : 408193230648266752,
  "created_at" : "2013-12-04 11:17:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ND7XXWiIxl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P5LyH8eC",
      "display_url" : "pastebin.com\/raw.php?i=P5Ly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408183186607202304",
  "text" : "http:\/\/t.co\/ND7XXWiIxl Emails: 89 Hashes: 143 E\/H: 0.62 Keywords: 0.44 #infoleak",
  "id" : 408183186607202304,
  "created_at" : "2013-12-04 10:37:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4yprROXlPc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=akc4jhgj",
      "display_url" : "pastebin.com\/raw.php?i=akc4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408172053787717632",
  "text" : "http:\/\/t.co\/4yprROXlPc Emails: 2 Hashes: 160 E\/H: 0.01 Keywords: 0.33 #infoleak",
  "id" : 408172053787717632,
  "created_at" : "2013-12-04 09:52:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mz7aVZEvOM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4SjRbWyP",
      "display_url" : "pastebin.com\/raw.php?i=4SjR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408148849224462336",
  "text" : "http:\/\/t.co\/mz7aVZEvOM Hashes: 123 Keywords: 0.08 #infoleak",
  "id" : 408148849224462336,
  "created_at" : "2013-12-04 08:20:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SYG3sjoU8M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r5SsZP2G",
      "display_url" : "pastebin.com\/raw.php?i=r5Ss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408147817941565440",
  "text" : "http:\/\/t.co\/SYG3sjoU8M Emails: 542 Keywords: 0.0 #infoleak",
  "id" : 408147817941565440,
  "created_at" : "2013-12-04 08:16:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DsOTTvbvu8",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YjqyRHM7",
      "display_url" : "pastebin.com\/raw.php?i=Yjqy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408141381228445697",
  "text" : "http:\/\/t.co\/DsOTTvbvu8 Hashes: 38 Keywords: -0.03 #infoleak",
  "id" : 408141381228445697,
  "created_at" : "2013-12-04 07:51:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zvNr68kNzm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AjhPmKcL",
      "display_url" : "pastebin.com\/raw.php?i=AjhP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408139555535994880",
  "text" : "http:\/\/t.co\/zvNr68kNzm Emails: 1509 Keywords: 0.66 #infoleak",
  "id" : 408139555535994880,
  "created_at" : "2013-12-04 07:43:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PcxwZlbc8P",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=02r8Y9rR",
      "display_url" : "pastebin.com\/raw.php?i=02r8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408133987354161152",
  "text" : "http:\/\/t.co\/PcxwZlbc8P Emails: 10792 Keywords: 0.33 #infoleak",
  "id" : 408133987354161152,
  "created_at" : "2013-12-04 07:21:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dH5hMEAg6h",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v6cyH1Pg",
      "display_url" : "pastebin.com\/raw.php?i=v6cy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408131486160674816",
  "text" : "http:\/\/t.co\/dH5hMEAg6h Emails: 9482 Keywords: 0.33 #infoleak",
  "id" : 408131486160674816,
  "created_at" : "2013-12-04 07:11:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6PMxVsc5Wo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8T3x3H8V",
      "display_url" : "pastebin.com\/raw.php?i=8T3x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408130920034476032",
  "text" : "http:\/\/t.co\/6PMxVsc5Wo Emails: 11077 Keywords: 0.19 #infoleak",
  "id" : 408130920034476032,
  "created_at" : "2013-12-04 07:09:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SOn93pt4Zt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R9F6YsvT",
      "display_url" : "pastebin.com\/raw.php?i=R9F6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408129396587769856",
  "text" : "http:\/\/t.co\/SOn93pt4Zt Emails: 10065 Keywords: 0.33 #infoleak",
  "id" : 408129396587769856,
  "created_at" : "2013-12-04 07:03:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9ojtVh7ymR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nr7fP3Gt",
      "display_url" : "pastebin.com\/raw.php?i=nr7f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408127878136483840",
  "text" : "http:\/\/t.co\/9ojtVh7ymR Emails: 10337 Keywords: 0.22 #infoleak",
  "id" : 408127878136483840,
  "created_at" : "2013-12-04 06:57:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/K3An4nSvWd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N1LPMG2Y",
      "display_url" : "pastebin.com\/raw.php?i=N1LP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408126535430713344",
  "text" : "http:\/\/t.co\/K3An4nSvWd Emails: 9352 Keywords: 0.19 #infoleak",
  "id" : 408126535430713344,
  "created_at" : "2013-12-04 06:52:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cODRF7Gyie",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ppJjuRR1",
      "display_url" : "pastebin.com\/raw.php?i=ppJj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408124329386201088",
  "text" : "http:\/\/t.co\/cODRF7Gyie Emails: 9919 Keywords: 0.44 #infoleak",
  "id" : 408124329386201088,
  "created_at" : "2013-12-04 06:43:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TdopxnBYVp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hpFZRxgq",
      "display_url" : "pastebin.com\/raw.php?i=hpFZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408123789667340288",
  "text" : "http:\/\/t.co\/TdopxnBYVp Emails: 10025 Keywords: 0.19 #infoleak",
  "id" : 408123789667340288,
  "created_at" : "2013-12-04 06:41:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ahkwAr3RqO",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=G9rDbjXD",
      "display_url" : "pastebin.com\/raw.php?i=G9rD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408122127712149504",
  "text" : "http:\/\/t.co\/ahkwAr3RqO Emails: 9282 Keywords: 0.3 #infoleak",
  "id" : 408122127712149504,
  "created_at" : "2013-12-04 06:34:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KPVRaQR1lS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ASyYDPch",
      "display_url" : "pastebin.com\/raw.php?i=ASyY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408117353281355776",
  "text" : "http:\/\/t.co\/KPVRaQR1lS Hashes: 10 Keywords: 0.55 #infoleak",
  "id" : 408117353281355776,
  "created_at" : "2013-12-04 06:15:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8URrk6kI1j",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=thChtDug",
      "display_url" : "pastebin.com\/raw.php?i=thCh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408093167691378688",
  "text" : "http:\/\/t.co\/8URrk6kI1j Emails: 133 Keywords: 0.0 #infoleak",
  "id" : 408093167691378688,
  "created_at" : "2013-12-04 04:39:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cOauPqvOh5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E5ces207",
      "display_url" : "pastebin.com\/raw.php?i=E5ce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408084038591590402",
  "text" : "http:\/\/t.co\/cOauPqvOh5 Emails: 122 Keywords: 0.0 #infoleak",
  "id" : 408084038591590402,
  "created_at" : "2013-12-04 04:03:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7PnPPjCdIx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hnDEBAub",
      "display_url" : "pastebin.com\/raw.php?i=hnDE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408083425078169600",
  "text" : "http:\/\/t.co\/7PnPPjCdIx Emails: 96 Keywords: 0.0 #infoleak",
  "id" : 408083425078169600,
  "created_at" : "2013-12-04 04:00:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1HuAYb3WWK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=D2Tq4RcB",
      "display_url" : "pastebin.com\/raw.php?i=D2Tq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408075448355000320",
  "text" : "http:\/\/t.co\/1HuAYb3WWK Emails: 50 Keywords: 0.0 #infoleak",
  "id" : 408075448355000320,
  "created_at" : "2013-12-04 03:29:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CBvaUBAHLu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K728HTek",
      "display_url" : "pastebin.com\/raw.php?i=K728\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408039391332798464",
  "text" : "http:\/\/t.co\/CBvaUBAHLu Emails: 26 Keywords: -0.14 #infoleak",
  "id" : 408039391332798464,
  "created_at" : "2013-12-04 01:05:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gMofJyV4Qc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0Q1hHJ49",
      "display_url" : "pastebin.com\/raw.php?i=0Q1h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408030895510007808",
  "text" : "http:\/\/t.co\/gMofJyV4Qc Emails: 1222 Keywords: -0.14 #infoleak",
  "id" : 408030895510007808,
  "created_at" : "2013-12-04 00:32:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JcvcsyJMx3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t9J5BKZT",
      "display_url" : "pastebin.com\/raw.php?i=t9J5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408006482538426368",
  "text" : "http:\/\/t.co\/JcvcsyJMx3 Emails: 144 Keywords: 0.33 #infoleak",
  "id" : 408006482538426368,
  "created_at" : "2013-12-03 22:55:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XleW8OP1in",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cmedshir",
      "display_url" : "pastebin.com\/raw.php?i=Cmed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407995955145748482",
  "text" : "http:\/\/t.co\/XleW8OP1in Emails: 637 Keywords: 0.33 #infoleak",
  "id" : 407995955145748482,
  "created_at" : "2013-12-03 22:13:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tvRzh9bmGz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7qbesewQ",
      "display_url" : "pastebin.com\/raw.php?i=7qbe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407993056860717057",
  "text" : "http:\/\/t.co\/tvRzh9bmGz Emails: 1 Keywords: 0.55 #infoleak",
  "id" : 407993056860717057,
  "created_at" : "2013-12-03 22:01:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gj5gvGqLgw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SJPXpFVY",
      "display_url" : "pastebin.com\/raw.php?i=SJPX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407992424401612800",
  "text" : "http:\/\/t.co\/gj5gvGqLgw Found possible Google API key(s) #infoleak",
  "id" : 407992424401612800,
  "created_at" : "2013-12-03 21:59:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DA2UqjwzQZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=t1veLrei",
      "display_url" : "pastebin.com\/raw.php?i=t1ve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407990764640034817",
  "text" : "http:\/\/t.co\/DA2UqjwzQZ Emails: 91 Keywords: 0.22 #infoleak",
  "id" : 407990764640034817,
  "created_at" : "2013-12-03 21:52:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xpkWCivTou",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vzEReSea",
      "display_url" : "pastebin.com\/raw.php?i=vzER\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407989201506799617",
  "text" : "http:\/\/t.co\/xpkWCivTou Hashes: 35 Keywords: 0.11 #infoleak",
  "id" : 407989201506799617,
  "created_at" : "2013-12-03 21:46:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/A5mbZSzwZq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rvz5bMLH",
      "display_url" : "pastebin.com\/raw.php?i=rvz5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407988169238265856",
  "text" : "http:\/\/t.co\/A5mbZSzwZq Emails: 170 Keywords: 0.0 #infoleak",
  "id" : 407988169238265856,
  "created_at" : "2013-12-03 21:42:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0sR2Iohsmf",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RcX9wfX8",
      "display_url" : "pastebin.com\/raw.php?i=RcX9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407975015410192384",
  "text" : "http:\/\/t.co\/0sR2Iohsmf Emails: 394 Keywords: 0.11 #infoleak",
  "id" : 407975015410192384,
  "created_at" : "2013-12-03 20:49:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kp3goWgOvY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KZ2WcUHE",
      "display_url" : "pastebin.com\/raw.php?i=KZ2W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407968811103424512",
  "text" : "http:\/\/t.co\/kp3goWgOvY Emails: 68 Hashes: 68 E\/H: 1.0 Keywords: 0.0 #infoleak",
  "id" : 407968811103424512,
  "created_at" : "2013-12-03 20:25:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/O8kST8ga2Y",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NNzMjydY",
      "display_url" : "pastebin.com\/raw.php?i=NNzM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407950689457819648",
  "text" : "http:\/\/t.co\/O8kST8ga2Y Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 407950689457819648,
  "created_at" : "2013-12-03 19:13:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sgetiGa4Cc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0QxkUtrY",
      "display_url" : "pastebin.com\/raw.php?i=0Qxk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407936240348962816",
  "text" : "http:\/\/t.co\/sgetiGa4Cc Emails: 923 Keywords: 0.11 #infoleak",
  "id" : 407936240348962816,
  "created_at" : "2013-12-03 18:15:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LNNITEsRW6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0ZmKbqtV",
      "display_url" : "pastebin.com\/raw.php?i=0ZmK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407935959842320386",
  "text" : "http:\/\/t.co\/LNNITEsRW6 Emails: 75 Hashes: 2 E\/H: 37.5 Keywords: 0.44 #infoleak",
  "id" : 407935959842320386,
  "created_at" : "2013-12-03 18:14:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gdb57rfREg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Nc2sVkAP",
      "display_url" : "pastebin.com\/raw.php?i=Nc2s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407930543410405376",
  "text" : "http:\/\/t.co\/Gdb57rfREg Emails: 407 Keywords: 0.22 #infoleak",
  "id" : 407930543410405376,
  "created_at" : "2013-12-03 17:53:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ldwVQH1hcA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=55sAi7Mx",
      "display_url" : "pastebin.com\/raw.php?i=55sA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407929054726074369",
  "text" : "http:\/\/t.co\/ldwVQH1hcA Emails: 132 Keywords: 0.22 #infoleak",
  "id" : 407929054726074369,
  "created_at" : "2013-12-03 17:47:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WPezGEnfwW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R1ugZQdB",
      "display_url" : "pastebin.com\/raw.php?i=R1ug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407925240346341376",
  "text" : "http:\/\/t.co\/WPezGEnfwW Possible cisco configuration #infoleak",
  "id" : 407925240346341376,
  "created_at" : "2013-12-03 17:32:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cFnd98oTRP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qgKkUjY3",
      "display_url" : "pastebin.com\/raw.php?i=qgKk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407924337283321856",
  "text" : "http:\/\/t.co\/cFnd98oTRP Hashes: 109 Keywords: 0.22 #infoleak",
  "id" : 407924337283321856,
  "created_at" : "2013-12-03 17:28:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hTS0WVhoGE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ATziSMPw",
      "display_url" : "pastebin.com\/raw.php?i=ATzi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407921462851276800",
  "text" : "http:\/\/t.co\/hTS0WVhoGE Emails: 46 Keywords: 0.11 #infoleak",
  "id" : 407921462851276800,
  "created_at" : "2013-12-03 17:17:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OndUqHB8Kh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=n6EcQhkW",
      "display_url" : "pastebin.com\/raw.php?i=n6Ec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407917400948875264",
  "text" : "http:\/\/t.co\/OndUqHB8Kh Emails: 2832 Keywords: 0.11 #infoleak",
  "id" : 407917400948875264,
  "created_at" : "2013-12-03 17:01:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FPZxrPEIBo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eQjNT0g8",
      "display_url" : "pastebin.com\/raw.php?i=eQjN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407916087485820928",
  "text" : "http:\/\/t.co\/FPZxrPEIBo Emails: 2657 Keywords: 0.11 #infoleak",
  "id" : 407916087485820928,
  "created_at" : "2013-12-03 16:55:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4MBxUK8PMM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=x0pTFGCk",
      "display_url" : "pastebin.com\/raw.php?i=x0pT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407898148107849729",
  "text" : "http:\/\/t.co\/4MBxUK8PMM Possible cisco configuration #infoleak",
  "id" : 407898148107849729,
  "created_at" : "2013-12-03 15:44:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vGUf39qk4z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gJJk9CQc",
      "display_url" : "pastebin.com\/raw.php?i=gJJk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407897389907718144",
  "text" : "http:\/\/t.co\/vGUf39qk4z Found possible Google API key(s) #infoleak",
  "id" : 407897389907718144,
  "created_at" : "2013-12-03 15:41:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tCr64RESsZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=whC52F7J",
      "display_url" : "pastebin.com\/raw.php?i=whC5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407892989818568705",
  "text" : "http:\/\/t.co\/tCr64RESsZ Hashes: 486 Keywords: 0.19 #infoleak",
  "id" : 407892989818568705,
  "created_at" : "2013-12-03 15:24:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fIy446W5r3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=apXceMT0",
      "display_url" : "pastebin.com\/raw.php?i=apXc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407891774988767236",
  "text" : "http:\/\/t.co\/fIy446W5r3 Emails: 86 Keywords: 0.0 #infoleak",
  "id" : 407891774988767236,
  "created_at" : "2013-12-03 15:19:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qxxOmbLXJT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9HjPGJts",
      "display_url" : "pastebin.com\/raw.php?i=9HjP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407889638397726721",
  "text" : "http:\/\/t.co\/qxxOmbLXJT Possible cisco configuration #infoleak",
  "id" : 407889638397726721,
  "created_at" : "2013-12-03 15:10:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/s10NDZvzyz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ntv972xC",
      "display_url" : "pastebin.com\/raw.php?i=Ntv9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407888936082493440",
  "text" : "http:\/\/t.co\/s10NDZvzyz Possible cisco configuration #infoleak",
  "id" : 407888936082493440,
  "created_at" : "2013-12-03 15:07:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pmpCFzVkaB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Cy14qEhV",
      "display_url" : "pastebin.com\/raw.php?i=Cy14\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407886649247268864",
  "text" : "http:\/\/t.co\/pmpCFzVkaB Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 407886649247268864,
  "created_at" : "2013-12-03 14:58:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gBt72y7nd6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Xmsy7zRy",
      "display_url" : "pastebin.com\/raw.php?i=Xmsy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407874473476378624",
  "text" : "http:\/\/t.co\/gBt72y7nd6 Emails: 479 Keywords: 0.33 #infoleak",
  "id" : 407874473476378624,
  "created_at" : "2013-12-03 14:10:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HuqTHojWaj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ApXwdUEm",
      "display_url" : "pastebin.com\/raw.php?i=ApXw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407862724815622144",
  "text" : "http:\/\/t.co\/HuqTHojWaj Emails: 22 Keywords: 0.0 #infoleak",
  "id" : 407862724815622144,
  "created_at" : "2013-12-03 13:23:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bhv4jtG1rC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZFDCFkYr",
      "display_url" : "pastebin.com\/raw.php?i=ZFDC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407858805314056192",
  "text" : "http:\/\/t.co\/bhv4jtG1rC Hashes: 202 Keywords: 0.11 #infoleak",
  "id" : 407858805314056192,
  "created_at" : "2013-12-03 13:08:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0FudzZthUS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=12bDcsuc",
      "display_url" : "pastebin.com\/raw.php?i=12bD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407848467013185536",
  "text" : "http:\/\/t.co\/0FudzZthUS Emails: 1714 Hashes: 4100 E\/H: 0.42 Keywords: 0.08 #infoleak",
  "id" : 407848467013185536,
  "created_at" : "2013-12-03 12:27:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gsvh6gJiCi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HAqBuN3B",
      "display_url" : "pastebin.com\/raw.php?i=HAqB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407846219176620033",
  "text" : "http:\/\/t.co\/Gsvh6gJiCi Hashes: 41 Keywords: -0.03 #infoleak",
  "id" : 407846219176620033,
  "created_at" : "2013-12-03 12:18:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E1DHB3qWtD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NHJvDidE",
      "display_url" : "pastebin.com\/raw.php?i=NHJv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407840178447740928",
  "text" : "http:\/\/t.co\/E1DHB3qWtD Hashes: 33 Keywords: 0.11 #infoleak",
  "id" : 407840178447740928,
  "created_at" : "2013-12-03 11:54:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ErXaUQleZ2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=AYPnjM0X",
      "display_url" : "pastebin.com\/raw.php?i=AYPn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407837088004853760",
  "text" : "http:\/\/t.co\/ErXaUQleZ2 Hashes: 50 Keywords: -0.06 #infoleak",
  "id" : 407837088004853760,
  "created_at" : "2013-12-03 11:41:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qcjn8cOL6u",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KNrXGd3Q",
      "display_url" : "pastebin.com\/raw.php?i=KNrX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407829776879996928",
  "text" : "http:\/\/t.co\/qcjn8cOL6u Emails: 20 Keywords: 0.08 #infoleak",
  "id" : 407829776879996928,
  "created_at" : "2013-12-03 11:12:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c0wyAZbSuI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=eyYP8QF9",
      "display_url" : "pastebin.com\/raw.php?i=eyYP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407829640338616320",
  "text" : "http:\/\/t.co\/c0wyAZbSuI Emails: 24 Keywords: -0.03 #infoleak",
  "id" : 407829640338616320,
  "created_at" : "2013-12-03 11:12:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QIubLVGQ0v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=fjTWrYew",
      "display_url" : "pastebin.com\/raw.php?i=fjTW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407817177618599937",
  "text" : "http:\/\/t.co\/QIubLVGQ0v Emails: 63 Keywords: 0.22 #infoleak",
  "id" : 407817177618599937,
  "created_at" : "2013-12-03 10:22:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FivoTHqfTB",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=abKRb5G8",
      "display_url" : "pastebin.com\/raw.php?i=abKR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407817114754379776",
  "text" : "http:\/\/t.co\/FivoTHqfTB Emails: 24 Keywords: -0.14 #infoleak",
  "id" : 407817114754379776,
  "created_at" : "2013-12-03 10:22:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VNMw6b5s5H",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bGLpS1Rz",
      "display_url" : "pastebin.com\/raw.php?i=bGLp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407816562771374080",
  "text" : "http:\/\/t.co\/VNMw6b5s5H Hashes: 88 Keywords: 0.22 #infoleak",
  "id" : 407816562771374080,
  "created_at" : "2013-12-03 10:20:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XTE4991zxn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7ZHjaJ2v",
      "display_url" : "pastebin.com\/raw.php?i=7ZHj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407785661903548417",
  "text" : "http:\/\/t.co\/XTE4991zxn Hashes: 154 Keywords: 0.08 #infoleak",
  "id" : 407785661903548417,
  "created_at" : "2013-12-03 08:17:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/moklUOYQCs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QPjBfpca",
      "display_url" : "pastebin.com\/raw.php?i=QPjB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407755822228176896",
  "text" : "http:\/\/t.co\/moklUOYQCs Emails: 19 Hashes: 1 E\/H: 19.0 Keywords: 0.55 #infoleak",
  "id" : 407755822228176896,
  "created_at" : "2013-12-03 06:18:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ISd3HYW8Rg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=miasBgXf",
      "display_url" : "pastebin.com\/raw.php?i=mias\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407747892619661312",
  "text" : "http:\/\/t.co\/ISd3HYW8Rg Keywords: 0.66 #infoleak",
  "id" : 407747892619661312,
  "created_at" : "2013-12-03 05:47:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WQkVo2x4LX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xwKg8pXX",
      "display_url" : "pastebin.com\/raw.php?i=xwKg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407664345993060352",
  "text" : "http:\/\/t.co\/WQkVo2x4LX Emails: 13349 Hashes: 9 E\/H: 1483.22 Keywords: 0.3 #infoleak",
  "id" : 407664345993060352,
  "created_at" : "2013-12-03 00:15:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sIl3O5PPAu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2xgfTrQ5",
      "display_url" : "pastebin.com\/raw.php?i=2xgf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407642331743928320",
  "text" : "http:\/\/t.co\/sIl3O5PPAu Emails: 926 Keywords: 0.11 #infoleak",
  "id" : 407642331743928320,
  "created_at" : "2013-12-02 22:48:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/d2zkAKGdCX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=51kg9kC9",
      "display_url" : "pastebin.com\/raw.php?i=51kg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407642014155431936",
  "text" : "http:\/\/t.co\/d2zkAKGdCX Emails: 327 Keywords: 0.11 #infoleak",
  "id" : 407642014155431936,
  "created_at" : "2013-12-02 22:46:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/L9OSK4M0ag",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dcJdbSHH",
      "display_url" : "pastebin.com\/raw.php?i=dcJd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407638498858905601",
  "text" : "http:\/\/t.co\/L9OSK4M0ag Emails: 4438 Keywords: 0.19 #infoleak",
  "id" : 407638498858905601,
  "created_at" : "2013-12-02 22:32:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5anOKbtQjh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jqWVPPeM",
      "display_url" : "pastebin.com\/raw.php?i=jqWV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407634080084152322",
  "text" : "http:\/\/t.co\/5anOKbtQjh Emails: 29 Keywords: 0.08 #infoleak",
  "id" : 407634080084152322,
  "created_at" : "2013-12-02 22:15:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BXBaclIy1e",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dnG941cd",
      "display_url" : "pastebin.com\/raw.php?i=dnG9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407633742220361728",
  "text" : "http:\/\/t.co\/BXBaclIy1e Found possible Google API key(s) #infoleak",
  "id" : 407633742220361728,
  "created_at" : "2013-12-02 22:13:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/40TWMJ6IUo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Mj3e4kWK",
      "display_url" : "pastebin.com\/raw.php?i=Mj3e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407623335959224321",
  "text" : "http:\/\/t.co\/40TWMJ6IUo Emails: 1752 Keywords: 0.33 #infoleak",
  "id" : 407623335959224321,
  "created_at" : "2013-12-02 21:32:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8FYC8IxocP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=WGN5twT8",
      "display_url" : "pastebin.com\/raw.php?i=WGN5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407621361981341697",
  "text" : "http:\/\/t.co\/8FYC8IxocP Emails: 478 Keywords: 0.0 #infoleak",
  "id" : 407621361981341697,
  "created_at" : "2013-12-02 21:24:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PGzCYdsBvG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sT62X0t1",
      "display_url" : "pastebin.com\/raw.php?i=sT62\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407566273657049088",
  "text" : "http:\/\/t.co\/PGzCYdsBvG Emails: 91 Hashes: 532 E\/H: 0.17 Keywords: 0.33 #infoleak",
  "id" : 407566273657049088,
  "created_at" : "2013-12-02 17:45:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KhT8EeNYUC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iKK60s8r",
      "display_url" : "pastebin.com\/raw.php?i=iKK6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407564593041379328",
  "text" : "http:\/\/t.co\/KhT8EeNYUC Hashes: 325 Keywords: 0.41 #infoleak",
  "id" : 407564593041379328,
  "created_at" : "2013-12-02 17:39:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/M2AwI51R8K",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2rNfAHqX",
      "display_url" : "pastebin.com\/raw.php?i=2rNf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407563073738653696",
  "text" : "http:\/\/t.co\/M2AwI51R8K Emails: 2744 Hashes: 2725 E\/H: 1.01 Keywords: 0.22 #infoleak",
  "id" : 407563073738653696,
  "created_at" : "2013-12-02 17:33:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2xiYqKYEqn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aTWfDq7u",
      "display_url" : "pastebin.com\/raw.php?i=aTWf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407557771697999872",
  "text" : "http:\/\/t.co\/2xiYqKYEqn Hashes: 70 Keywords: 0.22 #infoleak",
  "id" : 407557771697999872,
  "created_at" : "2013-12-02 17:11:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/de1OXhA4q1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=H8pwyPdX",
      "display_url" : "pastebin.com\/raw.php?i=H8pw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407541178419011584",
  "text" : "http:\/\/t.co\/de1OXhA4q1 Emails: 29 Keywords: -0.03 #infoleak",
  "id" : 407541178419011584,
  "created_at" : "2013-12-02 16:06:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R45Xz67x20",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YCMcrzDK",
      "display_url" : "pastebin.com\/raw.php?i=YCMc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407540899095126017",
  "text" : "http:\/\/t.co\/R45Xz67x20 Emails: 639 Hashes: 640 E\/H: 1.0 Keywords: 0.3 #infoleak",
  "id" : 407540899095126017,
  "created_at" : "2013-12-02 16:04:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8mMd9VJZ9Z",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T4JHzRZQ",
      "display_url" : "pastebin.com\/raw.php?i=T4JH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407531547042934784",
  "text" : "http:\/\/t.co\/8mMd9VJZ9Z Found possible Google API key(s) #infoleak",
  "id" : 407531547042934784,
  "created_at" : "2013-12-02 15:27:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/mYa9TfD1Tp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=K1gunRuK",
      "display_url" : "pastebin.com\/raw.php?i=K1gu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407520991011549184",
  "text" : "http:\/\/t.co\/mYa9TfD1Tp Emails: 2 Hashes: 48 E\/H: 0.04 Keywords: 0.16 #infoleak",
  "id" : 407520991011549184,
  "created_at" : "2013-12-02 14:45:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DCrc8SnXxd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=CfBknVtH",
      "display_url" : "pastebin.com\/raw.php?i=CfBk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407519238388068353",
  "text" : "http:\/\/t.co\/DCrc8SnXxd Emails: 160 Hashes: 209 E\/H: 0.77 Keywords: 0.11 #infoleak",
  "id" : 407519238388068353,
  "created_at" : "2013-12-02 14:38:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ymLFqaD3uG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TY7Bk4Z5",
      "display_url" : "pastebin.com\/raw.php?i=TY7B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407509046548123648",
  "text" : "http:\/\/t.co\/ymLFqaD3uG Emails: 666 Keywords: 0.0 #infoleak",
  "id" : 407509046548123648,
  "created_at" : "2013-12-02 13:58:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OBrhHIUIun",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RfceNG1M",
      "display_url" : "pastebin.com\/raw.php?i=Rfce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407508979888033792",
  "text" : "http:\/\/t.co\/OBrhHIUIun Hashes: 76 Keywords: 0.0 #infoleak",
  "id" : 407508979888033792,
  "created_at" : "2013-12-02 13:58:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fcbQtGOgR7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=g3A54nxv",
      "display_url" : "pastebin.com\/raw.php?i=g3A5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407499500085727233",
  "text" : "http:\/\/t.co\/fcbQtGOgR7 Emails: 31 Keywords: -0.14 #infoleak",
  "id" : 407499500085727233,
  "created_at" : "2013-12-02 13:20:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6c8PSH67LZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=wy9bKpuY",
      "display_url" : "pastebin.com\/raw.php?i=wy9b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407475882710663169",
  "text" : "http:\/\/t.co\/6c8PSH67LZ Hashes: 54 Keywords: -0.03 #infoleak",
  "id" : 407475882710663169,
  "created_at" : "2013-12-02 11:46:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UM41RqgR9G",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SwG50Ucm",
      "display_url" : "pastebin.com\/raw.php?i=SwG5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407472812106850305",
  "text" : "http:\/\/t.co\/UM41RqgR9G Emails: 71 Hashes: 1 E\/H: 71.0 Keywords: 0.0 #infoleak",
  "id" : 407472812106850305,
  "created_at" : "2013-12-02 11:34:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kx8q4WpYOt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=yJ5jKhd1",
      "display_url" : "pastebin.com\/raw.php?i=yJ5j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407472457788833792",
  "text" : "http:\/\/t.co\/kx8q4WpYOt Emails: 91 Keywords: 0.33 #infoleak",
  "id" : 407472457788833792,
  "created_at" : "2013-12-02 11:32:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DpsoahX2bo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VXRbRU5x",
      "display_url" : "pastebin.com\/raw.php?i=VXRb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407466106194915328",
  "text" : "http:\/\/t.co\/DpsoahX2bo Emails: 1 Hashes: 35 E\/H: 0.03 Keywords: 0.11 #infoleak",
  "id" : 407466106194915328,
  "created_at" : "2013-12-02 11:07:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HOFJGNO7Um",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mkhVsFbv",
      "display_url" : "pastebin.com\/raw.php?i=mkhV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407465628249767936",
  "text" : "http:\/\/t.co\/HOFJGNO7Um Found possible Google API key(s) #infoleak",
  "id" : 407465628249767936,
  "created_at" : "2013-12-02 11:05:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qWORmQcvek",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=utLk2yW6",
      "display_url" : "pastebin.com\/raw.php?i=utLk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407459948671418368",
  "text" : "http:\/\/t.co\/qWORmQcvek Hashes: 189 Keywords: -0.06 #infoleak",
  "id" : 407459948671418368,
  "created_at" : "2013-12-02 10:43:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XyxPJ9xzlC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FJQ4gtw1",
      "display_url" : "pastebin.com\/raw.php?i=FJQ4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407447385166471168",
  "text" : "http:\/\/t.co\/XyxPJ9xzlC Emails: 1288 Hashes: 1462 E\/H: 0.88 Keywords: 0.22 #infoleak",
  "id" : 407447385166471168,
  "created_at" : "2013-12-02 09:53:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2CpxALFOlX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9HXj3L8H",
      "display_url" : "pastebin.com\/raw.php?i=9HXj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407442837001625602",
  "text" : "http:\/\/t.co\/2CpxALFOlX Hashes: 290 Keywords: 0.41 #infoleak",
  "id" : 407442837001625602,
  "created_at" : "2013-12-02 09:35:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tHIR4OjJUw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HFY1e0fU",
      "display_url" : "pastebin.com\/raw.php?i=HFY1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407432742641876992",
  "text" : "http:\/\/t.co\/tHIR4OjJUw Keywords: 0.55 #infoleak",
  "id" : 407432742641876992,
  "created_at" : "2013-12-02 08:55:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6pvPTFecIM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jDUdMrn3",
      "display_url" : "pastebin.com\/raw.php?i=jDUd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407429983863185408",
  "text" : "http:\/\/t.co\/6pvPTFecIM Emails: 25 Keywords: -0.03 #infoleak",
  "id" : 407429983863185408,
  "created_at" : "2013-12-02 08:44:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a4rObohcyw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5zaVaZV3",
      "display_url" : "pastebin.com\/raw.php?i=5zaV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407425970035884032",
  "text" : "http:\/\/t.co\/a4rObohcyw Emails: 20 Hashes: 7 E\/H: 2.86 Keywords: 0.02 #infoleak",
  "id" : 407425970035884032,
  "created_at" : "2013-12-02 08:28:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Dxoza9R4HY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ZiCERKDp",
      "display_url" : "pastebin.com\/raw.php?i=ZiCE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407394734978527232",
  "text" : "http:\/\/t.co\/Dxoza9R4HY Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 407394734978527232,
  "created_at" : "2013-12-02 06:24:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lys1slz2Rx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=k4Q1Qgh8",
      "display_url" : "pastebin.com\/raw.php?i=k4Q1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407393584476737536",
  "text" : "http:\/\/t.co\/lys1slz2Rx Emails: 54 Keywords: 0.0 #infoleak",
  "id" : 407393584476737536,
  "created_at" : "2013-12-02 06:19:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cbSIQYrU5v",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DDHNEHcJ",
      "display_url" : "pastebin.com\/raw.php?i=DDHN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407381702093197313",
  "text" : "http:\/\/t.co\/cbSIQYrU5v Emails: 240 Keywords: 0.11 #infoleak",
  "id" : 407381702093197313,
  "created_at" : "2013-12-02 05:32:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/tCp6S0eMnN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rjXJchRJ",
      "display_url" : "pastebin.com\/raw.php?i=rjXJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407381033672114176",
  "text" : "http:\/\/t.co\/tCp6S0eMnN Emails: 179 Keywords: 0.22 #infoleak",
  "id" : 407381033672114176,
  "created_at" : "2013-12-02 05:29:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FX077gdR9w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=r7QgXtZa",
      "display_url" : "pastebin.com\/raw.php?i=r7Qg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407348083563843584",
  "text" : "http:\/\/t.co\/FX077gdR9w Found possible Google API key(s) #infoleak",
  "id" : 407348083563843584,
  "created_at" : "2013-12-02 03:18:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aDdyqn21FM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=i8C7nTE3",
      "display_url" : "pastebin.com\/raw.php?i=i8C7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407342173256839168",
  "text" : "http:\/\/t.co\/aDdyqn21FM Emails: 792 Keywords: 0.22 #infoleak",
  "id" : 407342173256839168,
  "created_at" : "2013-12-02 02:55:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZMyampJa2l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=B2y0yySD",
      "display_url" : "pastebin.com\/raw.php?i=B2y0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407339698168664064",
  "text" : "http:\/\/t.co\/ZMyampJa2l Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 407339698168664064,
  "created_at" : "2013-12-02 02:45:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TUXA2ODKfg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jAfcHGTY",
      "display_url" : "pastebin.com\/raw.php?i=jAfc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407297487024566272",
  "text" : "http:\/\/t.co\/TUXA2ODKfg Emails: 23 Keywords: 0.0 #infoleak",
  "id" : 407297487024566272,
  "created_at" : "2013-12-01 23:57:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Lp6W3uAqRP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xu617x1D",
      "display_url" : "pastebin.com\/raw.php?i=xu61\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407295692650979328",
  "text" : "http:\/\/t.co\/Lp6W3uAqRP Hashes: 250 Keywords: -0.14 #infoleak",
  "id" : 407295692650979328,
  "created_at" : "2013-12-01 23:50:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1cLMB2pdzo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ANhAAp9R",
      "display_url" : "pastebin.com\/raw.php?i=ANhA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407286318847119361",
  "text" : "http:\/\/t.co\/1cLMB2pdzo Found possible Google API key(s) #infoleak",
  "id" : 407286318847119361,
  "created_at" : "2013-12-01 23:13:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/88e9NfSrcA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xRuCpeg0",
      "display_url" : "pastebin.com\/raw.php?i=xRuC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407285376022093824",
  "text" : "http:\/\/t.co\/88e9NfSrcA Emails: 179 Keywords: 0.0 #infoleak",
  "id" : 407285376022093824,
  "created_at" : "2013-12-01 23:09:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KMYsEdoFbk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KxBdystB",
      "display_url" : "pastebin.com\/raw.php?i=KxBd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407263375815483393",
  "text" : "http:\/\/t.co\/KMYsEdoFbk Found possible Google API key(s) #infoleak",
  "id" : 407263375815483393,
  "created_at" : "2013-12-01 21:42:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OZ9m0g77az",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DaC02d1h",
      "display_url" : "pastebin.com\/raw.php?i=DaC0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407259746362605568",
  "text" : "http:\/\/t.co\/OZ9m0g77az Hashes: 43 Keywords: 0.22 #infoleak",
  "id" : 407259746362605568,
  "created_at" : "2013-12-01 21:27:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GpX5oIlC2N",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=0GE7mBHC",
      "display_url" : "pastebin.com\/raw.php?i=0GE7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407252561461116929",
  "text" : "http:\/\/t.co\/GpX5oIlC2N Emails: 37 Keywords: 0.22 #infoleak",
  "id" : 407252561461116929,
  "created_at" : "2013-12-01 20:59:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e49uUJRTRT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1s29yaJZ",
      "display_url" : "pastebin.com\/raw.php?i=1s29\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407245550820392960",
  "text" : "http:\/\/t.co\/e49uUJRTRT Emails: 28 Hashes: 1 E\/H: 28.0 Keywords: 0.3 #infoleak",
  "id" : 407245550820392960,
  "created_at" : "2013-12-01 20:31:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Wdr8tNqWWY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BpMkvZgi",
      "display_url" : "pastebin.com\/raw.php?i=BpMk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407241303965962240",
  "text" : "http:\/\/t.co\/Wdr8tNqWWY Emails: 20 Keywords: 0.33 #infoleak",
  "id" : 407241303965962240,
  "created_at" : "2013-12-01 20:14:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PG6uHwgWKZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KNRruxk9",
      "display_url" : "pastebin.com\/raw.php?i=KNRr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407241165801390081",
  "text" : "http:\/\/t.co\/PG6uHwgWKZ Found possible Google API key(s) #infoleak",
  "id" : 407241165801390081,
  "created_at" : "2013-12-01 20:13:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jfYvBjdIlZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N9dwXjJq",
      "display_url" : "pastebin.com\/raw.php?i=N9dw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407238364694200320",
  "text" : "http:\/\/t.co\/jfYvBjdIlZ Found possible Google API key(s) #infoleak",
  "id" : 407238364694200320,
  "created_at" : "2013-12-01 20:02:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0fJCCqe8KU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=L2WLj4De",
      "display_url" : "pastebin.com\/raw.php?i=L2WL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407213243925426176",
  "text" : "http:\/\/t.co\/0fJCCqe8KU Emails: 58 Keywords: 0.0 #infoleak",
  "id" : 407213243925426176,
  "created_at" : "2013-12-01 18:22:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lsLoBNczvA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uaLAC7XM",
      "display_url" : "pastebin.com\/raw.php?i=uaLA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407206828179615744",
  "text" : "http:\/\/t.co\/lsLoBNczvA Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 407206828179615744,
  "created_at" : "2013-12-01 17:57:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2KOrIiO3Ws",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MijRjedx",
      "display_url" : "pastebin.com\/raw.php?i=MijR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407206566987722752",
  "text" : "http:\/\/t.co\/2KOrIiO3Ws Keywords: 0.55 #infoleak",
  "id" : 407206566987722752,
  "created_at" : "2013-12-01 17:56:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RTq13dfUyA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ux20rhHK",
      "display_url" : "pastebin.com\/raw.php?i=ux20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407141317378969600",
  "text" : "http:\/\/t.co\/RTq13dfUyA Found possible Google API key(s) #infoleak",
  "id" : 407141317378969600,
  "created_at" : "2013-12-01 13:37:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qEsvO9YkiN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BACTw1Lu",
      "display_url" : "pastebin.com\/raw.php?i=BACT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407133185420455936",
  "text" : "http:\/\/t.co\/qEsvO9YkiN Found possible Google API key(s) #infoleak",
  "id" : 407133185420455936,
  "created_at" : "2013-12-01 13:04:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/e3J3WneEmS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pa2YLwRy",
      "display_url" : "pastebin.com\/raw.php?i=pa2Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407113699019591680",
  "text" : "http:\/\/t.co\/e3J3WneEmS Emails: 440 Keywords: -0.03 #infoleak",
  "id" : 407113699019591680,
  "created_at" : "2013-12-01 11:47:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r8OqbzQGX7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Rs7mYa7w",
      "display_url" : "pastebin.com\/raw.php?i=Rs7m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407101787175264256",
  "text" : "http:\/\/t.co\/r8OqbzQGX7 Emails: 84 Keywords: 0.11 #infoleak",
  "id" : 407101787175264256,
  "created_at" : "2013-12-01 11:00:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5Vlz3539CP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d3V90RmX",
      "display_url" : "pastebin.com\/raw.php?i=d3V9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407092264343572480",
  "text" : "http:\/\/t.co\/5Vlz3539CP Hashes: 39 Keywords: -0.03 #infoleak",
  "id" : 407092264343572480,
  "created_at" : "2013-12-01 10:22:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JU1O1hn4LR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VfShv1EW",
      "display_url" : "pastebin.com\/raw.php?i=VfSh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407091864781602817",
  "text" : "http:\/\/t.co\/JU1O1hn4LR Hashes: 39 Keywords: -0.03 #infoleak",
  "id" : 407091864781602817,
  "created_at" : "2013-12-01 10:20:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PhChh5q5ew",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BRwSUFm0",
      "display_url" : "pastebin.com\/raw.php?i=BRwS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407091788214591488",
  "text" : "http:\/\/t.co\/PhChh5q5ew Emails: 3 Hashes: 74 E\/H: 0.04 Keywords: 0.0 #infoleak",
  "id" : 407091788214591488,
  "created_at" : "2013-12-01 10:20:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0h1QBCgiXN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9vgzkjRg",
      "display_url" : "pastebin.com\/raw.php?i=9vgz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407091427156307968",
  "text" : "http:\/\/t.co\/0h1QBCgiXN Hashes: 39 Keywords: -0.03 #infoleak",
  "id" : 407091427156307968,
  "created_at" : "2013-12-01 10:18:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1zJPnt0Rmx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=v5aauEV5",
      "display_url" : "pastebin.com\/raw.php?i=v5aa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407090872505729024",
  "text" : "http:\/\/t.co\/1zJPnt0Rmx Hashes: 39 Keywords: -0.03 #infoleak",
  "id" : 407090872505729024,
  "created_at" : "2013-12-01 10:16:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
} ]
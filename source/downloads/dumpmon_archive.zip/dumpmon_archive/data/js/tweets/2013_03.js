Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SzFEmoGB0L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mGWa15Av",
      "display_url" : "pastebin.com\/raw.php?i=mGWa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318577531387277312",
  "text" : "http:\/\/t.co\/SzFEmoGB0L Emails: 1 Hashes: 3 E\/H: 0.33 Keywords: 0.99 #infoleak",
  "id" : 318577531387277312,
  "created_at" : "2013-04-01 04:16:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pe4lP3gz6w",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GaXWjzSp",
      "display_url" : "pastebin.com\/raw.php?i=GaXW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318569508077973504",
  "text" : "http:\/\/t.co\/pe4lP3gz6w Emails: 99 Keywords: 0.22 #infoleak",
  "id" : 318569508077973504,
  "created_at" : "2013-04-01 03:44:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OjGRaZTUnl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=d9uujVWh",
      "display_url" : "pastebin.com\/raw.php?i=d9uu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318556798506389505",
  "text" : "http:\/\/t.co\/OjGRaZTUnl Keywords: 0.55 #infoleak",
  "id" : 318556798506389505,
  "created_at" : "2013-04-01 02:53:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pH9iBoVGET",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m99vUQWL",
      "display_url" : "pastebin.com\/raw.php?i=m99v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318542167557677057",
  "text" : "http:\/\/t.co\/pH9iBoVGET Found possible Google API key(s) #infoleak",
  "id" : 318542167557677057,
  "created_at" : "2013-04-01 01:55:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ifjyLkr8zp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Kd093NQi",
      "display_url" : "pastebin.com\/raw.php?i=Kd09\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318533630303547392",
  "text" : "http:\/\/t.co\/ifjyLkr8zp Emails: 2294 Hashes: 2402 E\/H: 0.96 Keywords: 0.44 #infoleak",
  "id" : 318533630303547392,
  "created_at" : "2013-04-01 01:21:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ToVN5zucSK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jTsVh4v7",
      "display_url" : "pastebin.com\/raw.php?i=jTsV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318532507102478337",
  "text" : "http:\/\/t.co\/ToVN5zucSK Emails: 106 Keywords: 0.0 #infoleak",
  "id" : 318532507102478337,
  "created_at" : "2013-04-01 01:17:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaspberryPi",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318516587978174464",
  "text" : "Fun fact! I'm running completely from a #RaspberryPi!",
  "id" : 318516587978174464,
  "created_at" : "2013-04-01 00:14:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318513513154879488",
  "geo" : { },
  "id_str" : "318515181468676096",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon An interactive session of someone configuring a Cisco device (password appears to be \"class\")",
  "id" : 318515181468676096,
  "in_reply_to_status_id" : 318513513154879488,
  "created_at" : "2013-04-01 00:08:31 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VOIbbNidSy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QBFfUVpm",
      "display_url" : "pastebin.com\/raw.php?i=QBFf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318513970820550656",
  "text" : "http:\/\/t.co\/VOIbbNidSy Emails: 1718 Keywords: 0.11 #infoleak",
  "id" : 318513970820550656,
  "created_at" : "2013-04-01 00:03:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xtoljAxyJI",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/7238753\/text",
      "display_url" : "pastie.org\/pastes\/7238753\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318513513154879488",
  "text" : "http:\/\/t.co\/xtoljAxyJI Possible Cisco configuration #infoleak",
  "id" : 318513513154879488,
  "created_at" : "2013-04-01 00:01:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HCAKTSWnBj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6DktSmHM",
      "display_url" : "pastebin.com\/raw.php?i=6Dkt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318506259127103488",
  "text" : "http:\/\/t.co\/HCAKTSWnBj Emails: 59 Hashes: 61 E\/H: 0.97 Keywords: 0.55 #infoleak",
  "id" : 318506259127103488,
  "created_at" : "2013-03-31 23:33:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5vjyFZVM9L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ninaVpWX",
      "display_url" : "pastebin.com\/raw.php?i=nina\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318493632468512768",
  "text" : "http:\/\/t.co\/5vjyFZVM9L Emails: 65 Keywords: 0.0 #infoleak",
  "id" : 318493632468512768,
  "created_at" : "2013-03-31 22:42:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8xXbHDYaMJ",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s21TU02Wfr",
      "display_url" : "slexy.org\/raw\/s21TU02Wfr"
    } ]
  },
  "geo" : { },
  "id_str" : "318488524611526657",
  "text" : "http:\/\/t.co\/8xXbHDYaMJ Emails: 2973 Keywords: 0.33 #infoleak",
  "id" : 318488524611526657,
  "created_at" : "2013-03-31 22:22:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WUPXDvKMXU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=jzC7f4S1",
      "display_url" : "pastebin.com\/raw.php?i=jzC7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318482857360257024",
  "text" : "http:\/\/t.co\/WUPXDvKMXU Emails: 140 Keywords: 0.11 #infoleak",
  "id" : 318482857360257024,
  "created_at" : "2013-03-31 22:00:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0NuCCpo16s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=R5U9uYd4",
      "display_url" : "pastebin.com\/raw.php?i=R5U9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318481352632696832",
  "text" : "http:\/\/t.co\/0NuCCpo16s Emails: 394 Keywords: 0.11 #infoleak",
  "id" : 318481352632696832,
  "created_at" : "2013-03-31 21:54:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KG06DWxmKQ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W1EL2Kns",
      "display_url" : "pastebin.com\/raw.php?i=W1EL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318480688540172288",
  "text" : "http:\/\/t.co\/KG06DWxmKQ Emails: 101 Keywords: 0.0 #infoleak",
  "id" : 318480688540172288,
  "created_at" : "2013-03-31 21:51:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vcUkPZ3iOn",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=29ax1NgZ",
      "display_url" : "pastebin.com\/raw.php?i=29ax\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318478611185291265",
  "text" : "http:\/\/t.co\/vcUkPZ3iOn Emails: 21 Keywords: 0.33 #infoleak",
  "id" : 318478611185291265,
  "created_at" : "2013-03-31 21:43:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i4pADUIUVF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ptsPRq33",
      "display_url" : "pastebin.com\/raw.php?i=ptsP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318478101967413249",
  "text" : "http:\/\/t.co\/i4pADUIUVF Emails: 22 Keywords: 0.22 #infoleak",
  "id" : 318478101967413249,
  "created_at" : "2013-03-31 21:41:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7ihXw9TWGv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=m8eVHcZb",
      "display_url" : "pastebin.com\/raw.php?i=m8eV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318477132814770176",
  "text" : "http:\/\/t.co\/7ihXw9TWGv Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 318477132814770176,
  "created_at" : "2013-03-31 21:37:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/I8cePX9icK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rAKG5jVQ",
      "display_url" : "pastebin.com\/raw.php?i=rAKG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318475222875508738",
  "text" : "http:\/\/t.co\/I8cePX9icK Emails: 34 Hashes: 1 E\/H: 34.0 Keywords: 0.22 #infoleak",
  "id" : 318475222875508738,
  "created_at" : "2013-03-31 21:29:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2tSaJ1GaYE",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bn1faVmb",
      "display_url" : "pastebin.com\/raw.php?i=Bn1f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318472163143319553",
  "text" : "http:\/\/t.co\/2tSaJ1GaYE Emails: 22 Keywords: 0.33 #infoleak",
  "id" : 318472163143319553,
  "created_at" : "2013-03-31 21:17:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8q7NtTe8Db",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YzBQpxNj",
      "display_url" : "pastebin.com\/raw.php?i=YzBQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318468339246694400",
  "text" : "http:\/\/t.co\/8q7NtTe8Db Emails: 417 Keywords: 0.55 #infoleak",
  "id" : 318468339246694400,
  "created_at" : "2013-03-31 21:02:23 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qCn7nu6WXa",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pQhe8iKW",
      "display_url" : "pastebin.com\/raw.php?i=pQhe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318461169226625025",
  "text" : "http:\/\/t.co\/qCn7nu6WXa Keywords: 0.55 #infoleak",
  "id" : 318461169226625025,
  "created_at" : "2013-03-31 20:33:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/95BXB4LMwR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hiLak0ts",
      "display_url" : "pastebin.com\/raw.php?i=hiLa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318450751112368128",
  "text" : "http:\/\/t.co\/95BXB4LMwR Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 318450751112368128,
  "created_at" : "2013-03-31 19:52:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8xXbHDYaMJ",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s21TU02Wfr",
      "display_url" : "slexy.org\/raw\/s21TU02Wfr"
    } ]
  },
  "geo" : { },
  "id_str" : "318449617530400768",
  "text" : "http:\/\/t.co\/8xXbHDYaMJ Emails: 2973 Keywords: 0.33 #infoleak",
  "id" : 318449617530400768,
  "created_at" : "2013-03-31 19:47:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aMbY1zqkMs",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=EDCYjrWX",
      "display_url" : "pastebin.com\/raw.php?i=EDCY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318435069402435584",
  "text" : "http:\/\/t.co\/aMbY1zqkMs Emails: 10000 Keywords: 0.11 #infoleak",
  "id" : 318435069402435584,
  "created_at" : "2013-03-31 18:50:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vykiRIKNCh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=LsMqYrvT",
      "display_url" : "pastebin.com\/raw.php?i=LsMq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318423931562369024",
  "text" : "http:\/\/t.co\/vykiRIKNCh Emails: 114 Keywords: 0.33 #infoleak",
  "id" : 318423931562369024,
  "created_at" : "2013-03-31 18:05:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/9m8NCExeJy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7ErZNLW8",
      "display_url" : "pastebin.com\/raw.php?i=7ErZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318423462018433024",
  "text" : "http:\/\/t.co\/9m8NCExeJy Emails: 197 Hashes: 192 E\/H: 1.03 Keywords: 0.33 #infoleak",
  "id" : 318423462018433024,
  "created_at" : "2013-03-31 18:04:04 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zn5sflthzG",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=23m1sHrU",
      "display_url" : "pastebin.com\/raw.php?i=23m1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318422889588211712",
  "text" : "http:\/\/t.co\/Zn5sflthzG Emails: 20 Keywords: 0.0 #infoleak",
  "id" : 318422889588211712,
  "created_at" : "2013-03-31 18:01:47 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CcHD560e2L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=91T3ccxV",
      "display_url" : "pastebin.com\/raw.php?i=91T3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318417529531924480",
  "text" : "http:\/\/t.co\/CcHD560e2L Emails: 3641 Keywords: 0.22 #infoleak",
  "id" : 318417529531924480,
  "created_at" : "2013-03-31 17:40:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m2Y6cO3diL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=XRX2Tkba",
      "display_url" : "pastebin.com\/raw.php?i=XRX2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318417029260521473",
  "text" : "http:\/\/t.co\/m2Y6cO3diL Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 318417029260521473,
  "created_at" : "2013-03-31 17:38:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/XL2ZrXrDeL",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/7213672\/text",
      "display_url" : "pastie.org\/pastes\/7213672\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318416844354621440",
  "text" : "http:\/\/t.co\/XL2ZrXrDeL Emails: 35 Keywords: 0.0 #infoleak",
  "id" : 318416844354621440,
  "created_at" : "2013-03-31 17:37:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fN6zUxF4rk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aVFwhxVC",
      "display_url" : "pastebin.com\/raw.php?i=aVFw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318400905345105920",
  "text" : "http:\/\/t.co\/fN6zUxF4rk Emails: 825 Keywords: 0.33 #infoleak",
  "id" : 318400905345105920,
  "created_at" : "2013-03-31 16:34:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qBvuqhqRM7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pHgcR30w",
      "display_url" : "pastebin.com\/raw.php?i=pHgc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318399680788721664",
  "text" : "http:\/\/t.co\/qBvuqhqRM7 Emails: 395 Keywords: 0.11 #infoleak",
  "id" : 318399680788721664,
  "created_at" : "2013-03-31 16:29:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318387569161293824",
  "text" : "Oh no! Technical Difficulties. Don't worry - we're on it!",
  "id" : 318387569161293824,
  "created_at" : "2013-03-31 15:41:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8xXbHDYaMJ",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s21TU02Wfr",
      "display_url" : "slexy.org\/raw\/s21TU02Wfr"
    } ]
  },
  "geo" : { },
  "id_str" : "318386849657806848",
  "text" : "http:\/\/t.co\/8xXbHDYaMJ Emails: 2973 Keywords: 0.33 #infoleak",
  "id" : 318386849657806848,
  "created_at" : "2013-03-31 15:38:34 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Lil7lJd0iM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RpFhQ5b0",
      "display_url" : "pastebin.com\/raw.php?i=RpFh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318223798639935488",
  "text" : "http:\/\/t.co\/Lil7lJd0iM Emails: 29 Keywords: 0.11 #infoleak",
  "id" : 318223798639935488,
  "created_at" : "2013-03-31 04:50:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jXIY6H40SD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gjfn0Tqx",
      "display_url" : "pastebin.com\/raw.php?i=gjfn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318212295815733248",
  "text" : "http:\/\/t.co\/jXIY6H40SD Possible Cisco configuration #infoleak",
  "id" : 318212295815733248,
  "created_at" : "2013-03-31 04:04:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hd9CdM6FFj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vRmQNPiP",
      "display_url" : "pastebin.com\/raw.php?i=vRmQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318211598332334080",
  "text" : "http:\/\/t.co\/hd9CdM6FFj Emails: 53 Keywords: 0.11 #infoleak",
  "id" : 318211598332334080,
  "created_at" : "2013-03-31 04:02:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4XMBym5wFW",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=avF7paWP",
      "display_url" : "pastebin.com\/raw.php?i=avF7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318210509436493825",
  "text" : "http:\/\/t.co\/4XMBym5wFW Emails: 29 Keywords: 0.11 #infoleak",
  "id" : 318210509436493825,
  "created_at" : "2013-03-31 03:57:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LRHSpRERlP",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/7189237\/text",
      "display_url" : "pastie.org\/pastes\/7189237\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318203270218780673",
  "text" : "http:\/\/t.co\/LRHSpRERlP Emails: 26 Keywords: 0.11 #infoleak",
  "id" : 318203270218780673,
  "created_at" : "2013-03-31 03:29:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/15zt2N62vz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W7tXCuWY",
      "display_url" : "pastebin.com\/raw.php?i=W7tX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318173046890442752",
  "text" : "http:\/\/t.co\/15zt2N62vz Emails: 26 Keywords: 0.52 #infoleak",
  "id" : 318173046890442752,
  "created_at" : "2013-03-31 01:29:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TMsrMQw0hv",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KuhZ5kaF",
      "display_url" : "pastebin.com\/raw.php?i=KuhZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318172113682968576",
  "text" : "http:\/\/t.co\/TMsrMQw0hv Emails: 26 Keywords: 0.11 #infoleak",
  "id" : 318172113682968576,
  "created_at" : "2013-03-31 01:25:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8rHlUAPSE5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Enbv6hCJ",
      "display_url" : "pastebin.com\/raw.php?i=Enbv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318171525096292353",
  "text" : "http:\/\/t.co\/8rHlUAPSE5 Emails: 131 Keywords: 0.11 #infoleak",
  "id" : 318171525096292353,
  "created_at" : "2013-03-31 01:22:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PZcyHpwcd7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nRxuFYXC",
      "display_url" : "pastebin.com\/raw.php?i=nRxu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318170755089199106",
  "text" : "http:\/\/t.co\/PZcyHpwcd7 Emails: 131 Keywords: 0.11 #infoleak",
  "id" : 318170755089199106,
  "created_at" : "2013-03-31 01:19:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus",
      "screen_name" : "gusfoo",
      "indices" : [ 0, 7 ],
      "id_str" : "99546519",
      "id" : 99546519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318053914429755392",
  "geo" : { },
  "id_str" : "318169404129038337",
  "in_reply_to_user_id" : 99546519,
  "text" : "@gusfoo Hi! I'm working with my creators to implement a feature where you can tweet an email address and I'll let you know if I've seen it!",
  "id" : 318169404129038337,
  "in_reply_to_status_id" : 318053914429755392,
  "created_at" : "2013-03-31 01:14:31 +0000",
  "in_reply_to_screen_name" : "gusfoo",
  "in_reply_to_user_id_str" : "99546519",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/R0MLgBKnq3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U81GTSSd",
      "display_url" : "pastebin.com\/raw.php?i=U81G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318164210930556928",
  "text" : "http:\/\/t.co\/R0MLgBKnq3 Emails: 34 Keywords: -0.14 #infoleak",
  "id" : 318164210930556928,
  "created_at" : "2013-03-31 00:53:53 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/V3qrIhMgsh",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=cX0knK2v",
      "display_url" : "pastebin.com\/raw.php?i=cX0k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318158323000168448",
  "text" : "http:\/\/t.co\/V3qrIhMgsh Possible Cisco configuration #infoleak",
  "id" : 318158323000168448,
  "created_at" : "2013-03-31 00:30:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/b2vHyAo6Ig",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mTApxsmy",
      "display_url" : "pastebin.com\/raw.php?i=mTAp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318156803038912512",
  "text" : "http:\/\/t.co\/b2vHyAo6Ig Emails: 609 Keywords: 0.11 #infoleak",
  "id" : 318156803038912512,
  "created_at" : "2013-03-31 00:24:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hNn3Uc7RDY",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=S7RKhAVE",
      "display_url" : "pastebin.com\/raw.php?i=S7RK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318155127888433152",
  "text" : "http:\/\/t.co\/hNn3Uc7RDY Emails: 26 Keywords: -0.03 #infoleak",
  "id" : 318155127888433152,
  "created_at" : "2013-03-31 00:17:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OAQCHfDNnF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=W4Vx1dBM",
      "display_url" : "pastebin.com\/raw.php?i=W4Vx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318153415379259393",
  "text" : "http:\/\/t.co\/OAQCHfDNnF Hashes: 206 Keywords: 0.0 #infoleak",
  "id" : 318153415379259393,
  "created_at" : "2013-03-31 00:10:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/u0JaxiIUmi",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=im4WC7sA",
      "display_url" : "pastebin.com\/raw.php?i=im4W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318151623316754432",
  "text" : "http:\/\/t.co\/u0JaxiIUmi Found possible Google API key(s) #infoleak",
  "id" : 318151623316754432,
  "created_at" : "2013-03-31 00:03:52 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Pl0UXZufJ4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ab0vtXNh",
      "display_url" : "pastebin.com\/raw.php?i=ab0v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318150767397715969",
  "text" : "http:\/\/t.co\/Pl0UXZufJ4 Emails: 60 Keywords: 0.19 #infoleak",
  "id" : 318150767397715969,
  "created_at" : "2013-03-31 00:00:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wsjnNJsJBC",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xk4zspAA",
      "display_url" : "pastebin.com\/raw.php?i=xk4z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318150512509857792",
  "text" : "http:\/\/t.co\/wsjnNJsJBC Emails: 44 Keywords: 0.41 #infoleak",
  "id" : 318150512509857792,
  "created_at" : "2013-03-30 23:59:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2vSEZHbZMK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=p0ZK3Am9",
      "display_url" : "pastebin.com\/raw.php?i=p0ZK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318148492201705472",
  "text" : "http:\/\/t.co\/2vSEZHbZMK Emails: 20 Hashes: 1 E\/H: 20.0 Keywords: -0.14 #infoleak",
  "id" : 318148492201705472,
  "created_at" : "2013-03-30 23:51:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hPN0cy8o9W",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=T9455s3F",
      "display_url" : "pastebin.com\/raw.php?i=T945\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318124327620980737",
  "text" : "http:\/\/t.co\/hPN0cy8o9W Keywords: 0.55 #infoleak",
  "id" : 318124327620980737,
  "created_at" : "2013-03-30 22:15:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TeE1WgxaOd",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=U0aCtpPv",
      "display_url" : "pastebin.com\/raw.php?i=U0aC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318123938133704705",
  "text" : "http:\/\/t.co\/TeE1WgxaOd Emails: 41 Keywords: 0.41 #infoleak",
  "id" : 318123938133704705,
  "created_at" : "2013-03-30 22:13:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CvEpeXiQtH",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qDr5e0Ek",
      "display_url" : "pastebin.com\/raw.php?i=qDr5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318116239497117696",
  "text" : "http:\/\/t.co\/CvEpeXiQtH Keywords: 0.55 #infoleak",
  "id" : 318116239497117696,
  "created_at" : "2013-03-30 21:43:16 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NHqmGXb0y9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7FzWvpjY",
      "display_url" : "pastebin.com\/raw.php?i=7FzW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318116050027814912",
  "text" : "http:\/\/t.co\/NHqmGXb0y9 Emails: 29 Hashes: 8 E\/H: 3.63 Keywords: 0.22 #infoleak",
  "id" : 318116050027814912,
  "created_at" : "2013-03-30 21:42:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xYbq8VYYXr",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SGHRgaAk",
      "display_url" : "pastebin.com\/raw.php?i=SGHR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318115752198676480",
  "text" : "http:\/\/t.co\/xYbq8VYYXr Found possible Google API key(s) #infoleak",
  "id" : 318115752198676480,
  "created_at" : "2013-03-30 21:41:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TRkwhXDD9M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=52z4wZ6a",
      "display_url" : "pastebin.com\/raw.php?i=52z4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318115359804760064",
  "text" : "http:\/\/t.co\/TRkwhXDD9M Emails: 41 Keywords: 0.41 #infoleak",
  "id" : 318115359804760064,
  "created_at" : "2013-03-30 21:39:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/22DB0j5dk5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=HNmHMe7T",
      "display_url" : "pastebin.com\/raw.php?i=HNmH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318114799097630721",
  "text" : "http:\/\/t.co\/22DB0j5dk5 Keywords: 0.66 #infoleak",
  "id" : 318114799097630721,
  "created_at" : "2013-03-30 21:37:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uXGmOOS7lD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=NaW8JvYM",
      "display_url" : "pastebin.com\/raw.php?i=NaW8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318113935767265280",
  "text" : "http:\/\/t.co\/uXGmOOS7lD Keywords: 0.55 #infoleak",
  "id" : 318113935767265280,
  "created_at" : "2013-03-30 21:34:07 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2JcbARdfYL",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/7187188\/text",
      "display_url" : "pastie.org\/pastes\/7187188\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318099162002493440",
  "text" : "http:\/\/t.co\/2JcbARdfYL Found possible Google API key(s) #infoleak",
  "id" : 318099162002493440,
  "created_at" : "2013-03-30 20:35:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QZTZfzBHyc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hStSFqHk",
      "display_url" : "pastebin.com\/raw.php?i=hStS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318096220570673152",
  "text" : "http:\/\/t.co\/QZTZfzBHyc Emails: 31 Keywords: 0.22 #infoleak",
  "id" : 318096220570673152,
  "created_at" : "2013-03-30 20:23:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/C2ruXNyBEV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=E7rjWt7p",
      "display_url" : "pastebin.com\/raw.php?i=E7rj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318094361197944832",
  "text" : "http:\/\/t.co\/C2ruXNyBEV Emails: 44 Keywords: 0.22 #infoleak",
  "id" : 318094361197944832,
  "created_at" : "2013-03-30 20:16:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LHojIVEmNp",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=M4HZi21f",
      "display_url" : "pastebin.com\/raw.php?i=M4HZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318094354059243520",
  "text" : "http:\/\/t.co\/LHojIVEmNp Emails: 1 Hashes: 36 E\/H: 0.03 Keywords: 0.22 #infoleak",
  "id" : 318094354059243520,
  "created_at" : "2013-03-30 20:16:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FG9dOXRKRR",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hcvAb3eW",
      "display_url" : "pastebin.com\/raw.php?i=hcvA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318079368939331585",
  "text" : "http:\/\/t.co\/FG9dOXRKRR Emails: 295 Keywords: -0.03 #infoleak",
  "id" : 318079368939331585,
  "created_at" : "2013-03-30 19:16:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HLx5pHPSGX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=iXkpSqte",
      "display_url" : "pastebin.com\/raw.php?i=iXkp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318076665043509248",
  "text" : "http:\/\/t.co\/HLx5pHPSGX Emails: 112 Keywords: 0.0 #infoleak",
  "id" : 318076665043509248,
  "created_at" : "2013-03-30 19:06:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6UDxro2o17",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=PVS6FNd0",
      "display_url" : "pastebin.com\/raw.php?i=PVS6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318074096925679616",
  "text" : "http:\/\/t.co\/6UDxro2o17 Possible Cisco configuration #infoleak",
  "id" : 318074096925679616,
  "created_at" : "2013-03-30 18:55:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8x0xnpnVDg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nymYy9bs",
      "display_url" : "pastebin.com\/raw.php?i=nymY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318074042827542528",
  "text" : "http:\/\/t.co\/8x0xnpnVDg Emails: 663 Keywords: 0.0 #infoleak",
  "id" : 318074042827542528,
  "created_at" : "2013-03-30 18:55:35 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q6THrwUduT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=kmVJM2gP",
      "display_url" : "pastebin.com\/raw.php?i=kmVJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318074034078236673",
  "text" : "http:\/\/t.co\/Q6THrwUduT Emails: 25 Keywords: 0.11 #infoleak",
  "id" : 318074034078236673,
  "created_at" : "2013-03-30 18:55:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/MiQra7qh2L",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KJVbyv62",
      "display_url" : "pastebin.com\/raw.php?i=KJVb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318055903901384704",
  "text" : "http:\/\/t.co\/MiQra7qh2L Hashes: 3381 Keywords: 0.22 #infoleak",
  "id" : 318055903901384704,
  "created_at" : "2013-03-30 17:43:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6puqnQiojx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=angfnT3D",
      "display_url" : "pastebin.com\/raw.php?i=angf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318053181219299328",
  "text" : "http:\/\/t.co\/6puqnQiojx Hashes: 3601 Keywords: 0.44 #infoleak",
  "id" : 318053181219299328,
  "created_at" : "2013-03-30 17:32:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vsG74wP94l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vdCeyg8K",
      "display_url" : "pastebin.com\/raw.php?i=vdCe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318040302004875266",
  "text" : "http:\/\/t.co\/vsG74wP94l Hashes: 33 Keywords: 0.0 #infoleak",
  "id" : 318040302004875266,
  "created_at" : "2013-03-30 16:41:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J6DBGiWXK6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=40yTUTEC",
      "display_url" : "pastebin.com\/raw.php?i=40yT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318037280445063168",
  "text" : "http:\/\/t.co\/J6DBGiWXK6 Emails: 251 Keywords: 0.22 #infoleak",
  "id" : 318037280445063168,
  "created_at" : "2013-03-30 16:29:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vqmrQIs8N7",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1WfTKLUK",
      "display_url" : "pastebin.com\/raw.php?i=1WfT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318036737924411393",
  "text" : "http:\/\/t.co\/vqmrQIs8N7 Emails: 202 Keywords: 0.11 #infoleak",
  "id" : 318036737924411393,
  "created_at" : "2013-03-30 16:27:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317947145737097216",
  "geo" : { },
  "id_str" : "318028223667654657",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon This also appears to be vulnerable to SQL Injection!",
  "id" : 318028223667654657,
  "in_reply_to_status_id" : 317947145737097216,
  "created_at" : "2013-03-30 15:53:31 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z5KU5OKIn9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Hj543avN",
      "display_url" : "pastebin.com\/raw.php?i=Hj54\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318008677527334913",
  "text" : "http:\/\/t.co\/Z5KU5OKIn9 Emails: 29 Hashes: 42 E\/H: 0.69 Keywords: 0.0 #infoleak",
  "id" : 318008677527334913,
  "created_at" : "2013-03-30 14:35:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c4DnZQHktH",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2ZgIuUAgo",
      "display_url" : "slexy.org\/raw\/s2ZgIuUAgo"
    } ]
  },
  "geo" : { },
  "id_str" : "317995758035013632",
  "text" : "http:\/\/t.co\/c4DnZQHktH Emails: 1151 Hashes: 21 E\/H: 54.81 Keywords: 0.41 #infoleak",
  "id" : 317995758035013632,
  "created_at" : "2013-03-30 13:44:31 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RgtmIxIjzQ",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/7170226\/text",
      "display_url" : "pastie.org\/pastes\/7170226\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317947145737097216",
  "text" : "http:\/\/t.co\/RgtmIxIjzQ Found possible Google API key(s) #infoleak",
  "id" : 317947145737097216,
  "created_at" : "2013-03-30 10:31:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dump Monitor",
      "screen_name" : "dumpmon",
      "indices" : [ 0, 8 ],
      "id_str" : "1231625892",
      "id" : 1231625892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317826614429892608",
  "geo" : { },
  "id_str" : "317869855896379392",
  "in_reply_to_user_id" : 1231625892,
  "text" : "@dumpmon I'm working on removing false positives. The emails are \"valid\", just not used. This is why we can't have nice things! :D",
  "id" : 317869855896379392,
  "in_reply_to_status_id" : 317826614429892608,
  "created_at" : "2013-03-30 05:24:14 +0000",
  "in_reply_to_screen_name" : "dumpmon",
  "in_reply_to_user_id_str" : "1231625892",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HI09bZOgp5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UtESnSXj",
      "display_url" : "pastebin.com\/raw.php?i=UtES\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317826614429892608",
  "text" : "http:\/\/t.co\/HI09bZOgp5 Emails: 103 Keywords: 0.0 #infoleak",
  "id" : 317826614429892608,
  "created_at" : "2013-03-30 02:32:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/a1MDDm5yZt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FjqgbeG4",
      "display_url" : "pastebin.com\/raw.php?i=Fjqg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317825614646226945",
  "text" : "http:\/\/t.co\/a1MDDm5yZt Emails: 30 Keywords: -0.03 #infoleak",
  "id" : 317825614646226945,
  "created_at" : "2013-03-30 02:28:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ORY6OvVYJk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=VB3df0GZ",
      "display_url" : "pastebin.com\/raw.php?i=VB3d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317824158618759168",
  "text" : "http:\/\/t.co\/ORY6OvVYJk Emails: 48 Keywords: 0.0 #infoleak",
  "id" : 317824158618759168,
  "created_at" : "2013-03-30 02:22:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZFO1wXbT1d",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=hW05Yf1S",
      "display_url" : "pastebin.com\/raw.php?i=hW05\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317822293734719488",
  "text" : "http:\/\/t.co\/ZFO1wXbT1d Emails: 246 Keywords: 0.0 #infoleak",
  "id" : 317822293734719488,
  "created_at" : "2013-03-30 02:15:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UcqsjKIKNI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vdrgdJ0u",
      "display_url" : "pastebin.com\/raw.php?i=vdrg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317818584707506176",
  "text" : "http:\/\/t.co\/UcqsjKIKNI Emails: 2 Hashes: 166 E\/H: 0.01 Keywords: 0.3 #infoleak",
  "id" : 317818584707506176,
  "created_at" : "2013-03-30 02:00:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jk8QQ4YYfl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YkF4tzQe",
      "display_url" : "pastebin.com\/raw.php?i=YkF4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317815554813603841",
  "text" : "http:\/\/t.co\/jk8QQ4YYfl Emails: 30 Keywords: -0.03 #infoleak",
  "id" : 317815554813603841,
  "created_at" : "2013-03-30 01:48:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5Wa4GSJKnc",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FtWhJr3g",
      "display_url" : "pastebin.com\/raw.php?i=FtWh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317812656016871425",
  "text" : "http:\/\/t.co\/5Wa4GSJKnc Emails: 116 Keywords: 0.33 #infoleak",
  "id" : 317812656016871425,
  "created_at" : "2013-03-30 01:36:56 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/c4DnZQHktH",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2ZgIuUAgo",
      "display_url" : "slexy.org\/raw\/s2ZgIuUAgo"
    } ]
  },
  "geo" : { },
  "id_str" : "317804920457797633",
  "text" : "http:\/\/t.co\/c4DnZQHktH Emails: 1151 Hashes: 21 E\/H: 54.81 Keywords: 0.41 #infoleak",
  "id" : 317804920457797633,
  "created_at" : "2013-03-30 01:06:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WT9JaXDw2l",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8QNtpisq",
      "display_url" : "pastebin.com\/raw.php?i=8QNt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317804292079755264",
  "text" : "http:\/\/t.co\/WT9JaXDw2l Emails: 33 Keywords: 0.08 #infoleak",
  "id" : 317804292079755264,
  "created_at" : "2013-03-30 01:03:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/szeYs42HkK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mV9ZQgN1",
      "display_url" : "pastebin.com\/raw.php?i=mV9Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317800353787678721",
  "text" : "http:\/\/t.co\/szeYs42HkK Emails: 165 Keywords: 0.11 #infoleak",
  "id" : 317800353787678721,
  "created_at" : "2013-03-30 00:48:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WwHv9VX4br",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UTCtq6XZ",
      "display_url" : "pastebin.com\/raw.php?i=UTCt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317771285138653184",
  "text" : "http:\/\/t.co\/WwHv9VX4br Hashes: 54 Keywords: 0.33 #infoleak",
  "id" : 317771285138653184,
  "created_at" : "2013-03-29 22:52:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FdOQeXL8Sk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3shVWj41",
      "display_url" : "pastebin.com\/raw.php?i=3shV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317770922964688896",
  "text" : "http:\/\/t.co\/FdOQeXL8Sk Emails: 1 Hashes: 4 E\/H: 0.25 Keywords: 0.55 #infoleak",
  "id" : 317770922964688896,
  "created_at" : "2013-03-29 22:51:06 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RabcIW9tr4",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=J9FRCSZp",
      "display_url" : "pastebin.com\/raw.php?i=J9FR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317755817799581696",
  "text" : "http:\/\/t.co\/RabcIW9tr4 Emails: 23 Keywords: 0.22 #infoleak",
  "id" : 317755817799581696,
  "created_at" : "2013-03-29 21:51:05 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U8phSpvzkk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=7muRM9yE",
      "display_url" : "pastebin.com\/raw.php?i=7muR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317755532008116224",
  "text" : "http:\/\/t.co\/U8phSpvzkk Emails: 23 Keywords: 0.11 #infoleak",
  "id" : 317755532008116224,
  "created_at" : "2013-03-29 21:49:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IY8KVaYeWg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RkV19KuS",
      "display_url" : "pastebin.com\/raw.php?i=RkV1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317752531923107843",
  "text" : "http:\/\/t.co\/IY8KVaYeWg Emails: 1085 Hashes: 1792 E\/H: 0.61 Keywords: 0.44 #infoleak",
  "id" : 317752531923107843,
  "created_at" : "2013-03-29 21:38:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dP26djKhNJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DwA1Hgvu",
      "display_url" : "pastebin.com\/raw.php?i=DwA1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317749736360771585",
  "text" : "http:\/\/t.co\/dP26djKhNJ Hashes: 97 Keywords: -0.06 #infoleak",
  "id" : 317749736360771585,
  "created_at" : "2013-03-29 21:26:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/m3ShxW7AVV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BQUGFxeu",
      "display_url" : "pastebin.com\/raw.php?i=BQUG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317737806162186242",
  "text" : "http:\/\/t.co\/m3ShxW7AVV Emails: 27 Keywords: 0.0 #infoleak",
  "id" : 317737806162186242,
  "created_at" : "2013-03-29 20:39:30 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/lDnIMniixZ",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/7165705\/text",
      "display_url" : "pastie.org\/pastes\/7165705\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317727836674854912",
  "text" : "http:\/\/t.co\/lDnIMniixZ Hashes: 237 Keywords: 0.0 #infoleak",
  "id" : 317727836674854912,
  "created_at" : "2013-03-29 19:59:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rIYCeRJvXg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=DzVsYbKK",
      "display_url" : "pastebin.com\/raw.php?i=DzVs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317725812025589763",
  "text" : "http:\/\/t.co\/rIYCeRJvXg Keywords: 0.55 #infoleak",
  "id" : 317725812025589763,
  "created_at" : "2013-03-29 19:51:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DgQRgpSFTI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UQ1VbqtP",
      "display_url" : "pastebin.com\/raw.php?i=UQ1V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317724030704689152",
  "text" : "http:\/\/t.co\/DgQRgpSFTI Emails: 464 Keywords: 0.0 #infoleak",
  "id" : 317724030704689152,
  "created_at" : "2013-03-29 19:44:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/l19QC9edxP",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Ri6MdMKK",
      "display_url" : "pastebin.com\/raw.php?i=Ri6M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317721527355338752",
  "text" : "http:\/\/t.co\/l19QC9edxP Emails: 156 Keywords: 0.44 #infoleak",
  "id" : 317721527355338752,
  "created_at" : "2013-03-29 19:34:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xDj3WIJWYZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=h9Hxiqck",
      "display_url" : "pastebin.com\/raw.php?i=h9Hx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317717887659958272",
  "text" : "http:\/\/t.co\/xDj3WIJWYZ Emails: 139 Keywords: 0.11 #infoleak",
  "id" : 317717887659958272,
  "created_at" : "2013-03-29 19:20:21 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Z8W770xgBo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=insfaNRf",
      "display_url" : "pastebin.com\/raw.php?i=insf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317715487675015168",
  "text" : "http:\/\/t.co\/Z8W770xgBo Hashes: 182 Keywords: 0.3 #infoleak",
  "id" : 317715487675015168,
  "created_at" : "2013-03-29 19:10:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yoNiADHu6o",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GkmJYdCn",
      "display_url" : "pastebin.com\/raw.php?i=GkmJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317711415010013184",
  "text" : "http:\/\/t.co\/yoNiADHu6o Emails: 1 Hashes: 4 E\/H: 0.25 Keywords: 0.55 #infoleak",
  "id" : 317711415010013184,
  "created_at" : "2013-03-29 18:54:38 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7rNEF9DHeg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qpDN04i3",
      "display_url" : "pastebin.com\/raw.php?i=qpDN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317710563134275584",
  "text" : "http:\/\/t.co\/7rNEF9DHeg Emails: 129 Hashes: 245 E\/H: 0.53 Keywords: 0.08 #infoleak",
  "id" : 317710563134275584,
  "created_at" : "2013-03-29 18:51:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wpxeneGy4n",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KVSe2f6N",
      "display_url" : "pastebin.com\/raw.php?i=KVSe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317706358671691776",
  "text" : "http:\/\/t.co\/wpxeneGy4n Emails: 5 Keywords: 0.55 #infoleak",
  "id" : 317706358671691776,
  "created_at" : "2013-03-29 18:34:33 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/30QHILWRcu",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=RBXTnbUn",
      "display_url" : "pastebin.com\/raw.php?i=RBXT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317705777261445121",
  "text" : "http:\/\/t.co\/30QHILWRcu Emails: 137 Keywords: 0.0 #infoleak",
  "id" : 317705777261445121,
  "created_at" : "2013-03-29 18:32:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YvgRuJazjt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BZDjnQf8",
      "display_url" : "pastebin.com\/raw.php?i=BZDj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317676077336121346",
  "text" : "http:\/\/t.co\/YvgRuJazjt Hashes: 148 Keywords: 0.52 #infoleak",
  "id" : 317676077336121346,
  "created_at" : "2013-03-29 16:34:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DKPwNe0lFe",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=bCY3KuVu",
      "display_url" : "pastebin.com\/raw.php?i=bCY3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317660351653101569",
  "text" : "http:\/\/t.co\/DKPwNe0lFe Keywords: 0.55 #infoleak",
  "id" : 317660351653101569,
  "created_at" : "2013-03-29 15:31:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KhBoq1xXJt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ztFgZeNQ",
      "display_url" : "pastebin.com\/raw.php?i=ztFg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317659721165332480",
  "text" : "http:\/\/t.co\/KhBoq1xXJt Emails: 46 Keywords: 0.0 #infoleak",
  "id" : 317659721165332480,
  "created_at" : "2013-03-29 15:29:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WmRtidJX3F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=qiki6d6w",
      "display_url" : "pastebin.com\/raw.php?i=qiki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317658965360119809",
  "text" : "http:\/\/t.co\/WmRtidJX3F Hashes: 1870 Keywords: -0.03 #infoleak",
  "id" : 317658965360119809,
  "created_at" : "2013-03-29 15:26:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zo4GMSNknj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=dw7YKhTv",
      "display_url" : "pastebin.com\/raw.php?i=dw7Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317653857243115520",
  "text" : "http:\/\/t.co\/zo4GMSNknj Emails: 37 Keywords: 0.44 #infoleak",
  "id" : 317653857243115520,
  "created_at" : "2013-03-29 15:05:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fq8pOAfm45",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6mpmZpvz",
      "display_url" : "pastebin.com\/raw.php?i=6mpm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317651957303083008",
  "text" : "http:\/\/t.co\/fq8pOAfm45 Found possible Google API key(s) #infoleak",
  "id" : 317651957303083008,
  "created_at" : "2013-03-29 14:58:22 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Mp58uZS4Za",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aN7Ba3q0",
      "display_url" : "pastebin.com\/raw.php?i=aN7B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317651696996204546",
  "text" : "http:\/\/t.co\/Mp58uZS4Za Hashes: 1495 Keywords: -0.03 #infoleak",
  "id" : 317651696996204546,
  "created_at" : "2013-03-29 14:57:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sZgAaS2lDX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=STghDJpS",
      "display_url" : "pastebin.com\/raw.php?i=STgh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317651405999583232",
  "text" : "http:\/\/t.co\/sZgAaS2lDX Hashes: 1790 Keywords: -0.03 #infoleak",
  "id" : 317651405999583232,
  "created_at" : "2013-03-29 14:56:11 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wkilMcCHsJ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3WZRk7d0",
      "display_url" : "pastebin.com\/raw.php?i=3WZR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317648006046425088",
  "text" : "http:\/\/t.co\/wkilMcCHsJ Hashes: 1723 Keywords: 0.11 #infoleak",
  "id" : 317648006046425088,
  "created_at" : "2013-03-29 14:42:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/r2sPAcvaZT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SGZGfSyK",
      "display_url" : "pastebin.com\/raw.php?i=SGZG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317647576885260289",
  "text" : "http:\/\/t.co\/r2sPAcvaZT Hashes: 3381 Keywords: 0.22 #infoleak",
  "id" : 317647576885260289,
  "created_at" : "2013-03-29 14:40:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wmPMwrKApw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6xc2K0tD",
      "display_url" : "pastebin.com\/raw.php?i=6xc2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317646779464171520",
  "text" : "http:\/\/t.co\/wmPMwrKApw Emails: 33 Keywords: 0.0 #infoleak",
  "id" : 317646779464171520,
  "created_at" : "2013-03-29 14:37:48 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317643313572352000",
  "text" : "Sorry for the 6 hour downtime last night! Looks like I had an error and had to take a break. I'm back, and will have updates made soon!",
  "id" : 317643313572352000,
  "created_at" : "2013-03-29 14:24:02 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yIO74W6Njy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TzC9GFae",
      "display_url" : "pastebin.com\/raw.php?i=TzC9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317638895548370944",
  "text" : "http:\/\/t.co\/yIO74W6Njy Hashes: 46 Keywords: -0.14 #infoleak",
  "id" : 317638895548370944,
  "created_at" : "2013-03-29 14:06:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SqqdQbCPpt",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=nDjXbeww",
      "display_url" : "pastebin.com\/raw.php?i=nDjX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317637123006144512",
  "text" : "http:\/\/t.co\/SqqdQbCPpt Emails: 86 Keywords: 0.0 #infoleak",
  "id" : 317637123006144512,
  "created_at" : "2013-03-29 13:59:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nksKaa5Tu1",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2yZWERxWp",
      "display_url" : "slexy.org\/raw\/s2yZWERxWp"
    } ]
  },
  "geo" : { },
  "id_str" : "317627307223314432",
  "text" : "http:\/\/t.co\/nksKaa5Tu1 Emails: 522 Keywords: 0.08 #infoleak",
  "id" : 317627307223314432,
  "created_at" : "2013-03-29 13:20:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Hgvm6ZsgdD",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=P53MBATB",
      "display_url" : "pastebin.com\/raw.php?i=P53M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317517741584175104",
  "text" : "http:\/\/t.co\/Hgvm6ZsgdD Emails: 185 Hashes: 192 E\/H: 0.96 Keywords: 0.44 #infoleak",
  "id" : 317517741584175104,
  "created_at" : "2013-03-29 06:05:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/54TVSyvvQ3",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=62zFncnj",
      "display_url" : "pastebin.com\/raw.php?i=62zF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317512852267208705",
  "text" : "http:\/\/t.co\/54TVSyvvQ3 Emails: 30 Hashes: 30 E\/H: 1.0 Keywords: 0.44 #infoleak",
  "id" : 317512852267208705,
  "created_at" : "2013-03-29 05:45:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dEPSpJpjLA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UDcyw2m4",
      "display_url" : "pastebin.com\/raw.php?i=UDcy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317511047911186432",
  "text" : "http:\/\/t.co\/dEPSpJpjLA Emails: 115 Keywords: 0.55 #infoleak",
  "id" : 317511047911186432,
  "created_at" : "2013-03-29 05:38:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jzqRpZMPjk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JnNn1mmX",
      "display_url" : "pastebin.com\/raw.php?i=JnNn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317510082395000832",
  "text" : "http:\/\/t.co\/jzqRpZMPjk Emails: 1 Keywords: 0.66 #infoleak",
  "id" : 317510082395000832,
  "created_at" : "2013-03-29 05:34:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YWbwYDa4AZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2NXy9k8B",
      "display_url" : "pastebin.com\/raw.php?i=2NXy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317506383543148544",
  "text" : "http:\/\/t.co\/YWbwYDa4AZ Emails: 426 Keywords: 0.33 #infoleak",
  "id" : 317506383543148544,
  "created_at" : "2013-03-29 05:19:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YPchHXMHe9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pkazbHne",
      "display_url" : "pastebin.com\/raw.php?i=pkaz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317502131986890752",
  "text" : "http:\/\/t.co\/YPchHXMHe9 Emails: 424 Keywords: 0.33 #infoleak",
  "id" : 317502131986890752,
  "created_at" : "2013-03-29 05:03:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zxod53YvwT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vV6dgegy",
      "display_url" : "pastebin.com\/raw.php?i=vV6d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317498217203896321",
  "text" : "http:\/\/t.co\/zxod53YvwT Found possible Google API key(s) #infoleak",
  "id" : 317498217203896321,
  "created_at" : "2013-03-29 04:47:28 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eqwEwGgvAZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KU4pbaR4",
      "display_url" : "pastebin.com\/raw.php?i=KU4p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317497801229598720",
  "text" : "http:\/\/t.co\/eqwEwGgvAZ Found possible Google API key(s) #infoleak",
  "id" : 317497801229598720,
  "created_at" : "2013-03-29 04:45:49 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/qEaqrIEQOT",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gcfunYxh",
      "display_url" : "pastebin.com\/raw.php?i=gcfu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317486578832379905",
  "text" : "http:\/\/t.co\/qEaqrIEQOT Found possible Google API key(s) #infoleak",
  "id" : 317486578832379905,
  "created_at" : "2013-03-29 04:01:13 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EE7cT2PG1G",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/7158136\/text",
      "display_url" : "pastie.org\/pastes\/7158136\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317484630443978752",
  "text" : "http:\/\/t.co\/EE7cT2PG1G Found possible Google API key(s) #infoleak",
  "id" : 317484630443978752,
  "created_at" : "2013-03-29 03:53:29 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8AGigq4VQN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=b3StvGtG",
      "display_url" : "pastebin.com\/raw.php?i=b3St\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317471413462237185",
  "text" : "http:\/\/t.co\/8AGigq4VQN Emails: 39 Hashes: 2 E\/H: 19.5 Keywords: 0.33 #infoleak",
  "id" : 317471413462237185,
  "created_at" : "2013-03-29 03:00:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nksKaa5Tu1",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2yZWERxWp",
      "display_url" : "slexy.org\/raw\/s2yZWERxWp"
    } ]
  },
  "geo" : { },
  "id_str" : "317464694145310722",
  "text" : "http:\/\/t.co\/nksKaa5Tu1 Emails: 522 Keywords: 0.08#infoleak",
  "id" : 317464694145310722,
  "created_at" : "2013-03-29 02:34:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/W0x3yIrHE1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Nn8CEG1B",
      "display_url" : "pastebin.com\/raw.php?i=Nn8C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317443417510645760",
  "text" : "http:\/\/t.co\/W0x3yIrHE1 Found possible Google API key(s)",
  "id" : 317443417510645760,
  "created_at" : "2013-03-29 01:09:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Vhev1bIqcM",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=QH8Jx40f",
      "display_url" : "pastebin.com\/raw.php?i=QH8J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317431588189241344",
  "text" : "http:\/\/t.co\/Vhev1bIqcM Keywords: 0.66 #infoleak",
  "id" : 317431588189241344,
  "created_at" : "2013-03-29 00:22:42 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J47b1vOlDz",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=3hscmiMM",
      "display_url" : "pastebin.com\/raw.php?i=3hsc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317422260682125312",
  "text" : "http:\/\/t.co\/J47b1vOlDz Found possible Google API key(s)",
  "id" : 317422260682125312,
  "created_at" : "2013-03-28 23:45:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ov4dGm11qV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=4HTBYDds",
      "display_url" : "pastebin.com\/raw.php?i=4HTB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317417732515704833",
  "text" : "http:\/\/t.co\/Ov4dGm11qV Found possible Google API key(s)",
  "id" : 317417732515704833,
  "created_at" : "2013-03-28 23:27:39 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ezyohHbuvx",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=1HXQC2TL",
      "display_url" : "pastebin.com\/raw.php?i=1HXQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317415316894384128",
  "text" : "http:\/\/t.co\/ezyohHbuvx Emails: 697 Hashes: 1 E\/H: 697.0 Keywords: 0.19 #infoleak",
  "id" : 317415316894384128,
  "created_at" : "2013-03-28 23:18:03 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yMh85KAGoZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=rJajFHYv",
      "display_url" : "pastebin.com\/raw.php?i=rJaj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317414236026449920",
  "text" : "http:\/\/t.co\/yMh85KAGoZ Emails: 31 Keywords: -0.14 #infoleak",
  "id" : 317414236026449920,
  "created_at" : "2013-03-28 23:13:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J1Xx3dXhPL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=akQy3QFd",
      "display_url" : "pastebin.com\/raw.php?i=akQy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317406221680386050",
  "text" : "http:\/\/t.co\/J1Xx3dXhPL Emails: 23 Keywords: 0.05 #infoleak",
  "id" : 317406221680386050,
  "created_at" : "2013-03-28 22:41:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/SD3oreTVlX",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pYVpRb7x",
      "display_url" : "pastebin.com\/raw.php?i=pYVp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317401276268810240",
  "text" : "http:\/\/t.co\/SD3oreTVlX Hashes: 32 Keywords: 0.22 #infoleak",
  "id" : 317401276268810240,
  "created_at" : "2013-03-28 22:22:15 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nksKaa5Tu1",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2yZWERxWp",
      "display_url" : "slexy.org\/raw\/s2yZWERxWp"
    } ]
  },
  "geo" : { },
  "id_str" : "317399309538717697",
  "text" : "http:\/\/t.co\/nksKaa5Tu1 Emails: 522 Keywords: 0.08 #infoleak",
  "id" : 317399309538717697,
  "created_at" : "2013-03-28 22:14:27 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/eJHzsfFuaK",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=UkL8QScT",
      "display_url" : "pastebin.com\/raw.php?i=UkL8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317397007268462593",
  "text" : "http:\/\/t.co\/eJHzsfFuaK Found possible Google API key(s)",
  "id" : 317397007268462593,
  "created_at" : "2013-03-28 22:05:18 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/OUszMudAJA",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=TrnZ2P9g",
      "display_url" : "pastebin.com\/raw.php?i=TrnZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317392842421063682",
  "text" : "http:\/\/t.co\/OUszMudAJA Found possible Google API key(s)",
  "id" : 317392842421063682,
  "created_at" : "2013-03-28 21:48:45 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/riDzQR1GzL",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xbEiYpdP",
      "display_url" : "pastebin.com\/raw.php?i=xbEi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317388984420560897",
  "text" : "http:\/\/t.co\/riDzQR1GzL Emails: 29 Hashes: 29 E\/H: 1.0 Keywords: 0.22 #infoleak",
  "id" : 317388984420560897,
  "created_at" : "2013-03-28 21:33:25 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GMwKCNHkCN",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=6AKZ9TLF",
      "display_url" : "pastebin.com\/raw.php?i=6AKZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317386284303781889",
  "text" : "http:\/\/t.co\/GMwKCNHkCN Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 317386284303781889,
  "created_at" : "2013-03-28 21:22:41 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/15DaM7Fago",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2i6GcyxY",
      "display_url" : "pastebin.com\/raw.php?i=2i6G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317385542952177664",
  "text" : "http:\/\/t.co\/15DaM7Fago Emails: 28 Keywords: 0.0 #infoleak",
  "id" : 317385542952177664,
  "created_at" : "2013-03-28 21:19:44 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8D6j8zG2Tk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N47dCrHe",
      "display_url" : "pastebin.com\/raw.php?i=N47d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317375943566049280",
  "text" : "http:\/\/t.co\/8D6j8zG2Tk Emails: 25 Keywords: 0.0 #infoleak",
  "id" : 317375943566049280,
  "created_at" : "2013-03-28 20:41:36 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zY9bh6uHR9",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FQPdULQR",
      "display_url" : "pastebin.com\/raw.php?i=FQPd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317365554518302720",
  "text" : "http:\/\/t.co\/zY9bh6uHR9 Emails: 40 Keywords: 0.0 #infoleak",
  "id" : 317365554518302720,
  "created_at" : "2013-03-28 20:00:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JBKoFZG0AI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=uSLey67D",
      "display_url" : "pastebin.com\/raw.php?i=uSLe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317356372700319744",
  "text" : "http:\/\/t.co\/JBKoFZG0AI Emails: 51 Keywords: 0.11 #infoleak",
  "id" : 317356372700319744,
  "created_at" : "2013-03-28 19:23:50 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1OXEdtcjzw",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=N9PSTKsZ",
      "display_url" : "pastebin.com\/raw.php?i=N9PS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317354398542090240",
  "text" : "http:\/\/t.co\/1OXEdtcjzw Emails: 51 Keywords: 0.0 #infoleak",
  "id" : 317354398542090240,
  "created_at" : "2013-03-28 19:15:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JMzeI2QSA6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=5RDhDu3N",
      "display_url" : "pastebin.com\/raw.php?i=5RDh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317353874384097281",
  "text" : "http:\/\/t.co\/JMzeI2QSA6 Emails: 51 Keywords: 0.0 #infoleak",
  "id" : 317353874384097281,
  "created_at" : "2013-03-28 19:13:54 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/w2Sc0pKm8F",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Yh5Nyxph",
      "display_url" : "pastebin.com\/raw.php?i=Yh5N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317348938489409536",
  "text" : "http:\/\/t.co\/w2Sc0pKm8F Emails: 138 Keywords: 0.0 #infoleak",
  "id" : 317348938489409536,
  "created_at" : "2013-03-28 18:54:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nksKaa5Tu1",
      "expanded_url" : "http:\/\/slexy.org\/raw\/s2yZWERxWp",
      "display_url" : "slexy.org\/raw\/s2yZWERxWp"
    } ]
  },
  "geo" : { },
  "id_str" : "317346831728263168",
  "text" : "http:\/\/t.co\/nksKaa5Tu1 Emails: 522 Keywords: 0.08 #infoleak",
  "id" : 317346831728263168,
  "created_at" : "2013-03-28 18:45:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Q7foSm3pKl",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=vdDmv7Ew",
      "display_url" : "pastebin.com\/raw.php?i=vdDm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317331037971677184",
  "text" : "http:\/\/t.co\/Q7foSm3pKl Hashes: 30 Keywords: 0.11 #infoleak",
  "id" : 317331037971677184,
  "created_at" : "2013-03-28 17:43:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/EpAr3JFWfk",
      "expanded_url" : "http:\/\/pastie.org\/pastes\/7152479\/text",
      "display_url" : "pastie.org\/pastes\/7152479\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317318159784882176",
  "text" : "http:\/\/t.co\/EpAr3JFWfk Emails: 30 Keywords: 0.0 #infoleak",
  "id" : 317318159784882176,
  "created_at" : "2013-03-28 16:51:59 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sNMBuaic0M",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GEGYUq8L",
      "display_url" : "pastebin.com\/raw.php?i=GEGY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317296127164698626",
  "text" : "http:\/\/t.co\/sNMBuaic0M Emails: 301 Keywords: 0.0 #infoleak",
  "id" : 317296127164698626,
  "created_at" : "2013-03-28 15:24:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5Dxw2J1nw5",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=xhWyUuie",
      "display_url" : "pastebin.com\/raw.php?i=xhWy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317295844397285379",
  "text" : "http:\/\/t.co\/5Dxw2J1nw5 Keywords: 0.66 #infoleak",
  "id" : 317295844397285379,
  "created_at" : "2013-03-28 15:23:19 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/skmuiU5Way",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pff84Fay",
      "display_url" : "pastebin.com\/raw.php?i=pff8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317294497534971905",
  "text" : "http:\/\/t.co\/skmuiU5Way Emails: 100 Keywords: 0.22 #infoleak",
  "id" : 317294497534971905,
  "created_at" : "2013-03-28 15:17:57 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RdgOyEwR15",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=YSWB7uHE",
      "display_url" : "pastebin.com\/raw.php?i=YSWB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317287215828959234",
  "text" : "http:\/\/t.co\/RdgOyEwR15 Emails: 1850 Keywords: 0.19 #infoleak",
  "id" : 317287215828959234,
  "created_at" : "2013-03-28 14:49:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fFZ5CniiQy",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=FGp9K0Vq",
      "display_url" : "pastebin.com\/raw.php?i=FGp9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317282105149255681",
  "text" : "http:\/\/t.co\/fFZ5CniiQy Emails: 31 Keywords: 0.11 #infoleak",
  "id" : 317282105149255681,
  "created_at" : "2013-03-28 14:28:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jI100XXAoZ",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=sVpgM0XM",
      "display_url" : "pastebin.com\/raw.php?i=sVpg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317281673010110465",
  "text" : "http:\/\/t.co\/jI100XXAoZ Emails: 20835 Keywords: 0.33 #infoleak",
  "id" : 317281673010110465,
  "created_at" : "2013-03-28 14:27:00 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ClB5syedr6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=SVWGJ4BD",
      "display_url" : "pastebin.com\/raw.php?i=SVWG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317275549888299008",
  "text" : "http:\/\/t.co\/ClB5syedr6 Emails: 1 Hashes: 1 E\/H: 1.0 Keywords: 0.66 #infoleak",
  "id" : 317275549888299008,
  "created_at" : "2013-03-28 14:02:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T4lKVyHPRo",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=JqXpZ0gs",
      "display_url" : "pastebin.com\/raw.php?i=JqXp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317264992242114563",
  "text" : "http:\/\/t.co\/T4lKVyHPRo Emails: 65 Keywords: 0.44 #infoleak",
  "id" : 317264992242114563,
  "created_at" : "2013-03-28 13:20:43 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JAtgBrP8a6",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=BCSX96Hc",
      "display_url" : "pastebin.com\/raw.php?i=BCSX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317255791692374017",
  "text" : "http:\/\/t.co\/JAtgBrP8a6 Emails: 123 Keywords: 0.11 #infoleak",
  "id" : 317255791692374017,
  "created_at" : "2013-03-28 12:44:09 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Daq4vFdwys",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=aHxagyDj",
      "display_url" : "pastebin.com\/raw.php?i=aHxa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317253810877784065",
  "text" : "http:\/\/t.co\/Daq4vFdwys Emails: 155 Keywords: 0.66 #infoleak",
  "id" : 317253810877784065,
  "created_at" : "2013-03-28 12:36:17 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fVXJGbz7VF",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=9bbcS0Rc",
      "display_url" : "pastebin.com\/raw.php?i=9bbc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317246696906174464",
  "text" : "http:\/\/t.co\/fVXJGbz7VF Keywords: 0.66 #infoleak",
  "id" : 317246696906174464,
  "created_at" : "2013-03-28 12:08:01 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Zj8izU1Lxm",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GnXP04Y3",
      "display_url" : "pastebin.com\/raw.php?i=GnXP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317246382345957376",
  "text" : "http:\/\/t.co\/Zj8izU1Lxm Found possible Google API key(s)",
  "id" : 317246382345957376,
  "created_at" : "2013-03-28 12:06:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HDEJSafPSU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=MLbs9DiL",
      "display_url" : "pastebin.com\/raw.php?i=MLbs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317235421031575554",
  "text" : "http:\/\/t.co\/HDEJSafPSU Hashes: 117 Keywords: 0.0 #infoleak",
  "id" : 317235421031575554,
  "created_at" : "2013-03-28 11:23:12 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sAbtu268nq",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Bx4Rmm4A",
      "display_url" : "pastebin.com\/raw.php?i=Bx4R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317228908330242049",
  "text" : "http:\/\/t.co\/sAbtu268nq Found possible Google API key(s)",
  "id" : 317228908330242049,
  "created_at" : "2013-03-28 10:57:20 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3DCHbBinpS",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=ca3xmnDU",
      "display_url" : "pastebin.com\/raw.php?i=ca3x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317222524461133825",
  "text" : "http:\/\/t.co\/3DCHbBinpS Emails: 24 Keywords: 0.0 #infoleak",
  "id" : 317222524461133825,
  "created_at" : "2013-03-28 10:31:58 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YuPaZdbj0s",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=Fnnt27cU",
      "display_url" : "pastebin.com\/raw.php?i=Fnnt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317219302472310785",
  "text" : "http:\/\/t.co\/YuPaZdbj0s Emails: 25 Keywords: -0.14 #infoleak",
  "id" : 317219302472310785,
  "created_at" : "2013-03-28 10:19:10 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZMOiMg5vS1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=2Pn1ZPTy",
      "display_url" : "pastebin.com\/raw.php?i=2Pn1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317210562792656897",
  "text" : "http:\/\/t.co\/ZMOiMg5vS1 Emails: 49 Keywords: 0.22 #infoleak",
  "id" : 317210562792656897,
  "created_at" : "2013-03-28 09:44:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8Hm30JqCVk",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=csYUxSFy",
      "display_url" : "pastebin.com\/raw.php?i=csYU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317203792611405826",
  "text" : "http:\/\/t.co\/8Hm30JqCVk Emails: 48 Keywords: 0.11 #infoleak",
  "id" : 317203792611405826,
  "created_at" : "2013-03-28 09:17:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0TkUdpn3zI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=GMHXdivv",
      "display_url" : "pastebin.com\/raw.php?i=GMHX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317191771656425472",
  "text" : "http:\/\/t.co\/0TkUdpn3zI Emails: 155 Hashes: 2 E\/H: 77.5 Keywords: 0.3 #infoleak",
  "id" : 317191771656425472,
  "created_at" : "2013-03-28 08:29:46 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cKaWQOZfpg",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=8ZdZiL9M",
      "display_url" : "pastebin.com\/raw.php?i=8ZdZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317183156551819265",
  "text" : "http:\/\/t.co\/cKaWQOZfpg Emails: 40 Hashes: 2 E\/H: 20.0 Keywords: 0.22 #infoleak",
  "id" : 317183156551819265,
  "created_at" : "2013-03-28 07:55:32 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1u4iSvROeI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=C9kzCqWE",
      "display_url" : "pastebin.com\/raw.php?i=C9kz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317171409250050048",
  "text" : "http:\/\/t.co\/1u4iSvROeI Emails: 14 Hashes: 9 E\/H: 1.56 Keywords: 0.55 #infoleak",
  "id" : 317171409250050048,
  "created_at" : "2013-03-28 07:08:51 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4fRI2gkQdU",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=gKn7UpDW",
      "display_url" : "pastebin.com\/raw.php?i=gKn7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317165133191335936",
  "text" : "http:\/\/t.co\/4fRI2gkQdU Emails: 475 Keywords: -0.03 #infoleak",
  "id" : 317165133191335936,
  "created_at" : "2013-03-28 06:43:55 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IjovPXRDO2",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=mhwXjupQ",
      "display_url" : "pastebin.com\/raw.php?i=mhwX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317162304196210688",
  "text" : "http:\/\/t.co\/IjovPXRDO2 Emails: 14 Hashes: 9 E\/H: 1.56 Keywords: 0.55 #infoleak",
  "id" : 317162304196210688,
  "created_at" : "2013-03-28 06:32:40 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/t8dgF8TiY1",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=871BTpWZ",
      "display_url" : "pastebin.com\/raw.php?i=871B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317161538232389632",
  "text" : "http:\/\/t.co\/t8dgF8TiY1 Emails: 39 Keywords: -0.14 #infoleak",
  "id" : 317161538232389632,
  "created_at" : "2013-03-28 06:29:37 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/jI9X33PBPI",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=pw2CQTUK",
      "display_url" : "pastebin.com\/raw.php?i=pw2C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317161491319115776",
  "text" : "http:\/\/t.co\/jI9X33PBPI Emails: 38 Hashes: 2 E\/H: 19.0 Keywords: 0.3 #infoleak",
  "id" : 317161491319115776,
  "created_at" : "2013-03-28 06:29:26 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wvn2CTm0pV",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=L8ur9iRV",
      "display_url" : "pastebin.com\/raw.php?i=L8ur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317142816683880448",
  "text" : "http:\/\/t.co\/wvn2CTm0pV Emails: 255 Keywords: 0.11 #infoleak",
  "id" : 317142816683880448,
  "created_at" : "2013-03-28 05:15:14 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoleak",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/RvyzRivezj",
      "expanded_url" : "http:\/\/pastebin.com\/raw.php?i=KTSSSxqt",
      "display_url" : "pastebin.com\/raw.php?i=KTSS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317141096436215808",
  "text" : "http:\/\/t.co\/RvyzRivezj Emails: 21 Keywords: -0.03 #infoleak",
  "id" : 317141096436215808,
  "created_at" : "2013-03-28 05:08:24 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/raidersec.blogspot.com\" rel=\"nofollow\"\u003Edumpmon_bot\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317127188333883392",
  "text" : "First tweet! Will start posting updates soon.",
  "id" : 317127188333883392,
  "created_at" : "2013-03-28 04:13:08 +0000",
  "user" : {
    "name" : "Dump Monitor",
    "screen_name" : "dumpmon",
    "protected" : false,
    "id_str" : "1231625892",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325699354\/4746c3f3916af93790e0def25342490b_normal.png",
    "id" : 1231625892,
    "verified" : false
  }
} ]